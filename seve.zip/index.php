<?php
declare(strict_types=1);

/* ==========================================================================
   SÈVE — contrôleur frontal
   --------------------------------------------------------------------------
   Même architecture que /pannacotaclub déjà en ligne sur le même hébergement :
   toutes les adresses du dossier passent par ce fichier.

       /seve/                  → accueil
       /seve/createurs         → l'annuaire des créateurs
       /seve/profil/c9         → la fiche du profil c9
       /seve/pages/…php        → le fichier de page correspondant
       tout le reste           → page introuvable (404)

   Le dossier fonctionne aussi bien à la racine d'un domaine que dans un
   sous-dossier (public_html/seve/) : le préfixe est déduit automatiquement.
   ========================================================================== */

require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/pages.php';
require __DIR__ . '/includes/donnees.php';

$uri    = (string) (parse_url((string) ($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH) ?: '/');
$method = (string) ($_SERVER['REQUEST_METHOD'] ?? 'GET');
$base   = seve_base_path();

/* Le fichier ne répond que pour son propre dossier (ou la racine du domaine). */
if ($base !== '' && $uri !== $base && !str_starts_with($uri, $base . '/')) {
    http_response_code(404);
    exit;
}

/* Adresse demandée, sans le préfixe du dossier : '' , '/createurs' … */
$path = $base === '' ? $uri : substr($uri, strlen($base));

/* Repli quand le serveur ne réécrit pas les adresses : index.php?p=createurs */
if (isset($_GET['p']) && $_GET['p'] !== '') {
    $path = '/' . (string) preg_replace('/[^A-Za-z0-9_\/-]/', '', (string) $_GET['p']);
}

/* --------------------------------------------------------------------------
   API JSON : les relevés du compte OnlyFans (saisis ou importés par la
   créatrice). Répond en JSON et s'arrête là, sans rendre de page.
   -------------------------------------------------------------------------- */
if ($path === '/api' || str_starts_with($path, '/api/')) {
    require __DIR__ . '/includes/api.php';
    seve_api_repondre($path, $method, seve_api_corps());
}

/* --------------------------------------------------------------------------
   Releveur de la boîte de dépôt : /seve/cron-lettres?cle=…
   Le dossier cron/ est interdit en direct par le .htaccess ; cette adresse
   unique permet à une tâche planifiée qui ne sait appeler qu'une adresse web
   de déclencher le relevé, à condition de présenter le secret de config.php.
   -------------------------------------------------------------------------- */
if ($path === '/cron-lettres' || $path === '/cron-lettres.php') {
    if (!seve_service_ouvert()) { http_response_code(503); exit; }
    require __DIR__ . '/cron/lettres.php';
    exit;
}

/* --------------------------------------------------------------------------
   Écran de vérification de l'installation : /seve/verification
   (accessible aussi en /seve/verification.php, puisque le .htaccess de la
   racine du domaine retire l'extension .php des adresses).
   -------------------------------------------------------------------------- */
if ($path === '/verification' || $path === '/verification.php') {
    require __DIR__ . '/includes/verification.php';
    seve_headers();
    seve_maintenance();
    seve_gate();
    seve_verification();
}

render_php_page($path, $method, $_POST);
