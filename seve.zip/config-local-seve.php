<?php
return array (
  'admin_identifiant' => 'admin',
  'admin_hash' => '$2y$10$TgzpluWefJNDMxrEwtDXruw28fjoeL8P5Qooy1u8.fzBO9L9gW25G',
);
