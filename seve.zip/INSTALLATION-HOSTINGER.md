# Sève — installation ouverte sous `missiona.eu/seve/`

**Déploiement à faire par le propriétaire.** Ce paquet n'a pas été envoyé sur Hostinger par l'assistant. Il installe uniquement le dossier `/seve/` et ne modifie pas Missiona. Avant toute mise à jour, sauvegardez `public_html/seve/`, y compris son dossier privé `data/`.

## Installation recommandée : un fichier PHP

1. Vérifiez HTTPS, PHP 8.1+ et les extensions `pdo_sqlite` et `gd`. Le dossier `public_html/seve/` doit être accessible en écriture par PHP. Vérifiez que l'hébergement interdit le téléchargement de `seve/data/` et de `seve/config-local-seve.php`.
2. Déposez `seve-installateur.php` dans `public_html/` (pas dans `/seve/`). Ouvrez exactement `https://missiona.eu/seve-installateur.php`.
3. Saisissez la **clé d'installation fournie séparément** et un **nouveau** mot de passe admin d'au moins 14 caractères, avec confirmation. Ne partagez ce mot de passe avec personne. Un changement de mot de passe à la réinstallation déconnecte l'ancien administrateur.
4. Cliquez **Installer et ouvrir Sève**. L'installation copie les fichiers, conserve le dossier `data/` (comptes, messages, images, relevés), crée l'empreinte admin dans `config-local-seve.php`, active le mode refuge global, puis bascule `ouverture_publique` à `true` dans `config.php`. Le serveur ne se considère ouvert que si la configuration admin et les extensions requises sont présentes. Le ZIP et l'installateur ne contiennent aucun mot de passe admin.
5. Vérifiez `https://missiona.eu/seve/api/statut` : `"ouvert":true`. Vérifiez `https://missiona.eu/seve/api/mode` : `"refuge":true,"ouvert":true`. Faites ensuite une inscription d'essai, un message et sa réponse par `#/admin/refuge`. Contrôlez manuellement la majorité d'un compte par `#/admin/majorite`, puis testez un PNG privé en attente, sa validation et son retrait dans `#/admin/images`.
6. **Supprimez l'installateur après réussite**, depuis sa page avec la clé ou dans le gestionnaire de fichiers. Ne déposez jamais la clé sur le site public.

Une clé fausse, un mot de passe trop court, l'absence des extensions ou une extraction incomplète empêchent l'ouverture. Si le site existant était déjà ouvert, faites les mises à jour sur une période de faible trafic, avec sauvegarde et plan de retour arrière. Le fichier `config.php` est conservé lors des mises à jour, sauf les drapeaux d'ouverture et de référencement activés en fin d'installation ; les autres réglages et le contenu utilisateur ne sont pas écrasés.

## Administration et protection des PNG

- Administration Sève indépendante : `https://missiona.eu/seve/#/admin/connexion`. Aucune connexion admin rapide. Mot de passe stocké haché dans `config-local-seve.php` ; ne l'écrivez pas en clair dans un fichier.
- Le contrôle de majorité exige une **vraie vérification manuelle** par l'éditeur avant l'envoi de PNG. Enregistrez une référence de contrôle, pas la copie de la pièce dans le chat ni dans les fichiers Sève. La confirmation « 18 ans » à l'inscription n'est pas une vérification de pièce.
- Chaque PNG exige l'accord de l'expéditrice et son attestation de droits et consentements. Les fichiers sont limités à 4 Mo et 2048 px, décodés puis réencodés par GD, stockés dans `data/images` hors accès public. Les PNG attendent la validation manuelle de l'administrateur ; celui-ci peut retirer une image en attente **ou déjà approuvée**. Seuls le compte expéditeur et l'admin ont accès au fichier approuvé, jamais l'annuaire public.
- Cette déclaration du déposant ne prouve pas à elle seule l'âge et le consentement de **toutes** les personnes représentées. Il appartient au modérateur d'appliquer la procédure appropriée, et à l'éditeur de vérifier la conformité juridique du service avant d'accepter des contenus explicites.

## Mentions et vie privée

L'éditeur a donné comme pseudonyme public **Sève**, adresse de contact/signalement **missiona.eu@gmail.com**, et hébergeur **Hostinger**. Il déclare avoir transmis sa véritable identité et ses coordonnées à son hébergeur ; l'installateur ne peut pas le contrôler. Vérifiez que le nom légal de l'entité Hostinger dans les mentions correspond à votre contrat, et documentez vos pratiques de sauvegarde, suppression, signalement et modération. Aucune entreprise ni SIRET n'est inventé.

## ZIP (secours, sans ouverture automatique)

Le fichier ZIP contient le dossier `seve/` et peut être extrait dans `public_html`. **Il reste fermé par défaut** : aucun admin n'y est configuré, aucun réglage d'ouverture n'est activé. Pour obtenir l'ouverture automatique sûre, utilisez l'installateur PHP ci-dessus plutôt qu'une extraction directe.
