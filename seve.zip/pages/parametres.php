<?php
declare(strict_types=1);

/* Page « parametres » de Sève — https://missiona.eu/seve/pages/parametres.php */

require_once __DIR__ . '/_page.php';

seve_page('parametres');
