<?php
declare(strict_types=1);

/* Page « remboursements et litiges » de Sève — https://missiona.eu/seve/pages/litiges.php */

require_once __DIR__ . '/_page.php';

seve_page('litiges');
