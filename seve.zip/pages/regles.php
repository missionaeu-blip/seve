<?php
declare(strict_types=1);

/* Page « regles » de Sève — https://missiona.eu/seve/pages/regles.php */

require_once __DIR__ . '/_page.php';

seve_page('regles');
