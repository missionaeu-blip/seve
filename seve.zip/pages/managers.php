<?php
declare(strict_types=1);

/* Page « managers » de Sève — https://missiona.eu/seve/pages/managers.php */

require_once __DIR__ . '/_page.php';

seve_page('managers');
