<?php
declare(strict_types=1);

/* Page « confidentialite » de Sève — https://missiona.eu/seve/pages/confidentialite.php */

require_once __DIR__ . '/_page.php';

seve_page('confidentialite');
