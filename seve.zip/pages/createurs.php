<?php
declare(strict_types=1);

/* Page « createurs » de Sève — https://missiona.eu/seve/pages/createurs.php */

require_once __DIR__ . '/_page.php';

seve_page('createurs');
