<?php
declare(strict_types=1);

/* Page « profil » de Sève — https://missiona.eu/seve/pages/profil.php */

require_once __DIR__ . '/_page.php';

seve_page('profil');
