<?php
declare(strict_types=1);

/* Page « demandes » de Sève — https://missiona.eu/seve/pages/demandes.php */

require_once __DIR__ . '/_page.php';

seve_page('demandes');
