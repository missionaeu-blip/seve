<?php
declare(strict_types=1);

/* Page « messages » de Sève — https://missiona.eu/seve/pages/messages.php */

require_once __DIR__ . '/_page.php';

seve_page('messages');
