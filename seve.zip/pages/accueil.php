<?php
declare(strict_types=1);

/* Page « accueil » de Sève — https://missiona.eu/seve/pages/accueil.php */

require_once __DIR__ . '/_page.php';

seve_page('accueil');
