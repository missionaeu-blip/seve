<?php
declare(strict_types=1);

/* Page « connexion » de Sève — https://missiona.eu/seve/pages/connexion.php */

require_once __DIR__ . '/_page.php';

seve_page('connexion');
