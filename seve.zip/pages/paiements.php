<?php
declare(strict_types=1);

/* Page « paiements » de Sève — https://missiona.eu/seve/pages/paiements.php */

require_once __DIR__ . '/_page.php';

seve_page('paiements');
