<?php
declare(strict_types=1);

/* Page « comment-ca-marche » de Sève — https://missiona.eu/seve/pages/comment-ca-marche.php */

require_once __DIR__ . '/_page.php';

seve_page('comment-ca-marche');
