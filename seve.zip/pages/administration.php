<?php
declare(strict_types=1);

/* Page « administration » de Sève — https://missiona.eu/seve/pages/administration.php */

require_once __DIR__ . '/_page.php';

seve_page('administration');
