<?php
declare(strict_types=1);

/* Modèle commun aux pages du site : chaque fichier de pages/ affiche une page
   précise de l'application (le contenu est rendu par app.html + assets/js). */

require_once dirname(__DIR__) . '/includes/bootstrap.php';
require_once dirname(__DIR__) . '/includes/pages.php';
