<?php
declare(strict_types=1);

/* Page « mon espace tranquille » de Sève — https://missiona.eu/seve/pages/tranquille.php */

require_once __DIR__ . '/_page.php';

seve_page('tranquille');
