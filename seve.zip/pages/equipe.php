<?php
declare(strict_types=1);

/* Page « parler à l’équipe » de Sève — https://missiona.eu/seve/pages/equipe.php */

require_once __DIR__ . '/_page.php';

seve_page('equipe');
