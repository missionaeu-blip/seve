<?php
declare(strict_types=1);

/* Page « aide » de Sève — https://missiona.eu/seve/pages/aide.php */

require_once __DIR__ . '/_page.php';

seve_page('aide');
