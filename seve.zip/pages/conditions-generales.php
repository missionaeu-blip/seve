<?php
declare(strict_types=1);

/* Page « conditions-generales » de Sève — https://missiona.eu/seve/pages/conditions-generales.php */

require_once __DIR__ . '/_page.php';

seve_page('conditions-generales');
