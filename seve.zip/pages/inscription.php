<?php
declare(strict_types=1);

/* Page « inscription » de Sève — https://missiona.eu/seve/pages/inscription.php */

require_once __DIR__ . '/_page.php';

seve_page('inscription');
