<?php
declare(strict_types=1);

/* Page « decouvrir » de Sève — https://missiona.eu/seve/pages/decouvrir.php */

require_once __DIR__ . '/_page.php';

seve_page('decouvrir');
