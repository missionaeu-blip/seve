<?php
declare(strict_types=1);

/* Page « cookies » de Sève — https://missiona.eu/seve/pages/cookies.php */

require_once __DIR__ . '/_page.php';

seve_page('cookies');
