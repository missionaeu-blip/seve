<?php
declare(strict_types=1);

/* Page « tableau-de-bord » de Sève — https://missiona.eu/seve/pages/tableau-de-bord.php */

require_once __DIR__ . '/_page.php';

seve_page('tableau-de-bord');
