<?php
declare(strict_types=1);

/* Page « mon-compte » de Sève — https://missiona.eu/seve/pages/mon-compte.php
   Espace créateur : compte OnlyFans relié, statistiques, publications, tarifs. */

require_once __DIR__ . '/_page.php';

seve_page('mon-compte');
