<?php
/* ==========================================================================
   SÈVE — réglages du dossier (https://missiona.eu/seve/)
   --------------------------------------------------------------------------
   C'est le seul fichier à modifier. Il n'est jamais servi au public : la règle
   du .htaccess le bloque. Une modification prend effet immédiatement (compte
   quelques secondes si le serveur garde les fichiers PHP en cache).
   ========================================================================== */

return [

    /* 1. Protection par mot de passe ---------------------------------------
       false = le site s'ouvre directement.
       true  = un écran de connexion précède le site. Mot de passe : seve2026
               (seule son empreinte est stockée ci-dessous, jamais le mot de
               passe en clair). Pour le changer, régénérez l'empreinte. */
    'protection'   => false,
    'empreinte'    => '$2y$12$dM1eDUkOOVAOnfEOqUhNeu/4ipZXu0EBpyCRHQUDdQ6m4/09DfC7e',

    /* 2. Indisponibilité temporaire ----------------------------------------
       true = toutes les pages répondent 503 « momentanément indisponible »,
              en une seconde, sans rien supprimer. */
    'maintenance'  => false,
    'message_maintenance' => 'Le site est momentanément indisponible. Merci de revenir dans quelques minutes.',

    /* 3. Référencement ------------------------------------------------------
       true = en-tête X-Robots-Tag: noindex, nofollow sur toutes les pages.
       Le dossier est de toute façon absent des liens du site Missiona. */
    'noindex'      => false,

    /* 4. Dépôt automatique des chiffres ------------------------------------
       La créatrice n'a plus à recopier ses chiffres : Sève va les chercher
       elle-même, sans jamais toucher à son compte OnlyFans (aucun mot de passe,
       aucun script sur sa page — c'est interdit par leurs conditions d'usage).

       · Par FICHIER : déjà actif, rien à régler. Elle dépose l'export de son
         tableau de bord OnlyFans dans son espace, Sève lit les lignes.
       · Par E-MAIL : elle crée un transfert automatique des messages OnlyFans
         vers une boîte que Sève relève. Renseignez les lignes ci-dessous, puis
         planifiez cron/lettres.php (hPanel → Tâches planifiées, toutes les
         heures). Laissez vide pour désactiver ce canal. */
    'depot_mail'             => '',      /* adresse montrée aux créatrices, ex. releves@missiona.eu */
    'depot_imap_hote'        => '',      /* ex. imap.hostinger.com */
    'depot_imap_utilisateur' => '',      /* la boîte entière, ex. releves@missiona.eu */
    'depot_imap_motdepasse'  => '',      /* mot de passe de cette boîte (elle, pas OnlyFans) */
    'depot_imap_dossier'     => 'INBOX',
    'depot_imap_drapeau'     => '/imap/ssl',

    /* Adresse secrète du releveur, si l'hébergeur n'offre pas de tâche
       planifiée : /seve/cron/lettres?cle=… — laissez vide pour ne l'autoriser
       qu'en ligne de commande. */
    'cron_cle'               => '',

    /* Activation au terme de l’installation sécurisée (admin + PHP GD/SQLite).
       Sur une nouvelle installation sans empreinte admin, le service reste fermé. */
    'ouverture_publique' => true,

    /* 5. Affichage ---------------------------------------------------------- */
    'titre'        => 'Sève — Trouvez le bon partenaire pour développer votre activité',
    'assiette'     => 'Créateurs & managers OFM',
];
