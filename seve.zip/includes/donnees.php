<?php
declare(strict_types=1);

/* ==========================================================================
   SÈVE — stockage des relevés du compte OnlyFans
   --------------------------------------------------------------------------
   Pas de base de données à configurer : un fichier JSON par créatrice, dans
   un dossier jamais servi au public (data/ est bloqué par le .htaccess).
   Écriture atomique (fichier temporaire + rename) et verrou pour éviter deux
   écritures simultanées. Le jour où une base MySQL est préférée, seule cette
   couche change : les routes de l'API et les vues ne bougent pas.

   Aucun identifiant OnlyFans n'est stocké : le compte est protégé par un code
   à six chiffres que la créatrice choisit, dont seule l'empreinte est gardée.
   ========================================================================== */

/** Dossier de données (créé au besoin). */
function seve_dossier_donnees(): string
{
    $dossier = dirname(__DIR__) . '/data';
    if (!is_dir($dossier)) {
        @mkdir($dossier, 0755, true);
    }
    return $dossier;
}

/** Clé de fichier à partir de l'adresse du compte (jamais l'adresse en clair). */
function seve_cle_compte(string $email): string
{
    $email = strtolower(trim($email));
    return 'of-' . substr(hash('sha256', $email . '|seve'), 0, 24) . '.json';
}

function seve_verrou(string $fichier)
{
    $fp = @fopen($fichier . '.lock', 'c');
    if ($fp) { @flock($fp, LOCK_EX); }
    return $fp;
}

function seve_deverrouiller($fp): void
{
    if ($fp) { @flock($fp, LOCK_UN); @fclose($fp); }
}

/** État vide : rien de relié, rien de saisi. */
function seve_etat_vide(): array
{
    return [
        'version'   => 1,
        'connected'   => false,   /* mêmes noms que l'application, pour éviter
        'username'    => '',         toute traduction entre le serveur et l'écran */
        'code_hash'   => '',
        'connectedAt' => null,
        'releveLe'    => null,
        'plan'        => new \stdClass(),   /* objet vide, jamais un tableau */
        'serveur'     => null,
        'posts'     => [],
        'releves'   => [],   /* une entrée par jour : {jour, abonnes, revenus, vues, likes, note} */
        'journal'   => []    /* qui a modifié quoi, et quand */
    ];
}

/** Lit l'état d'un compte ; renvoie l'état vide s'il n'existe pas encore. */
function seve_lire(string $email): array
{
    $fichier = seve_dossier_donnees() . '/' . seve_cle_compte($email);
    if (!is_file($fichier)) { return seve_etat_vide(); }
    $brut = @file_get_contents($fichier);
    if ($brut === false || $brut === '') { return seve_etat_vide(); }
    $data = json_decode($brut, true);
    if (!is_array($data)) { return seve_etat_vide(); }
    return array_merge(seve_etat_vide(), $data);
}

/** Écrit l'état de façon atomique. Renvoie false si le disque refuse. */
function seve_ecrire(string $email, array $etat): bool
{
    $fichier = seve_dossier_donnees() . '/' . seve_cle_compte($email);
    $tmp = $fichier . '.' . bin2hex(random_bytes(4)) . '.tmp';
    $json = json_encode($etat, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) { return false; }
    $fp = seve_verrou($fichier);
    $ok = @file_put_contents($tmp, $json, LOCK_EX) !== false;
    if ($ok) { $ok = @rename($tmp, $fichier); }
    if (!$ok) { @unlink($tmp); }
    seve_deverrouiller($fp);
    return $ok;
}

/** Ajoute une ligne au journal interne (limité aux 200 dernières). */
function seve_journal(array &$etat, string $action, string $detail = ''): void
{
    $etat['journal'] = array_slice(array_merge(
        $etat['journal'] ?? [],
        [['at' => gmdate('c'), 'action' => $action, 'detail' => $detail]]
    ), -200);
}

/** Le code choisi par la créatrice protège son relevé : empreinte, jamais le code. */
function seve_code_valide(array $etat, string $code): bool
{
    if (($etat['code_hash'] ?? '') === '') { return true; }   /* premier usage */
    return password_verify($code, (string) $etat['code_hash']);
}

/** Tronque un texte sans dépendre de mbstring (absent sur certains hébergements). */
function seve_tronquer(string $texte, int $max): string
{
    if (function_exists('mb_substr')) { return mb_substr($texte, 0, $max); }
    if (function_exists('iconv_substr')) { return (string) iconv_substr($texte, 0, $max, 'UTF-8'); }
    return substr($texte, 0, $max);
}

/** Nombre propre : entier positif ou zéro. */
function seve_nombre($v): int
{
    $n = (int) preg_replace('/[^0-9-]/', '', (string) $v);
    return max(0, $n);
}

/**
 * Montant écrit à la française (« 1 234,50 € ») ou à l'anglaise (« 1,234.50 »).
 * Le dernier séparateur rencontré est le séparateur décimal, l'autre sépare les
 * milliers : sans cela, « 1,234.50 » se lisait 1,23 € — un chiffre faux.
 */
function seve_montant($v): float
{
    $s = preg_replace('/[^0-9.,]/', '', seve_texte_propre((string) $v)) ?? '';
    if ($s === '') { return 0.0; }
    $point = strrpos($s, '.');
    $virgule = strrpos($s, ',');
    if ($point !== false && $virgule !== false) {
        if ($point > $virgule) { $s = str_replace(',', '', $s); }
        else { $s = str_replace('.', '', $s); $s = str_replace(',', '.', $s); }
    } elseif ($virgule !== false) {
        $apres = strlen($s) - $virgule - 1;
        $s = ($apres === 1 || $apres === 2) ? str_replace(',', '.', $s) : str_replace(',', '', $s);
    } elseif ($point !== false) {
        $apres = strlen($s) - $point - 1;
        if ($apres === 3) { $s = str_replace('.', '', $s); }   /* « 1.234 » = 1234 */
    }
    return round(max(0.0, (float) $s), 2);
}

/**
 * Normalise une ligne de relevé. Accepte « abonnes » ou « followers », etc.
 * Le jour est obligatoire ; les autres colonnes peuvent être absentes.
 */
function seve_releve_normalise(array $ligne): ?array
{
    $jour = trim((string) ($ligne['jour'] ?? $ligne['date'] ?? ''));
    /* Analyse explicite : « 2026-10-16 », « 16/10/2026 », « 16.10.2026 ».
       On ne passe pas par strtotime : selon le fuseau du serveur, une date
       saisie minuit pouvait retomber la veille en heure UTC. */
    if (preg_match('#^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})$#', $jour, $m)) {
        $jour = sprintf('%04d-%02d-%02d', (int) $m[1], (int) $m[2], (int) $m[3]);
    } elseif (preg_match('#^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})$#', $jour, $m)) {
        $jour = sprintf('%04d-%02d-%02d', (int) $m[3], (int) $m[2], (int) $m[1]);
    } else {
        $t = strtotime($jour);
        if (!$t) { return null; }
        $jour = date('Y-m-d', $t);
    }
    [$an, $mois, $jr] = array_map('intval', explode('-', $jour));
    if (!checkdate($mois, $jr, $an)) { return null; }
    if ($jour > date('Y-m-d')) { return null; }   /* pas de relevé dans le futur */
    return [
        'jour'      => $jour,
        'abonnes'   => seve_nombre($ligne['abonnes'] ?? $ligne['followers'] ?? 0),
        'revenus'   => seve_montant($ligne['revenus'] ?? $ligne['revenue'] ?? 0),
        'vues'      => seve_nombre($ligne['vues'] ?? $ligne['views'] ?? 0),
        'likes'     => seve_nombre($ligne['likes'] ?? 0),
        'nouveaux'  => seve_nombre($ligne['nouveaux'] ?? 0),
        'note'      => seve_tronquer(trim((string) ($ligne['note'] ?? '')), 200),
        'source'    => in_array(($ligne['source'] ?? ''), ['saisie', 'fichier', 'mail', 'outil'], true)
                       ? (string) $ligne['source'] : 'saisie'
    ];
}

/** Insère ou remplace un relevé (une seule ligne par jour) et trie par date. */
function seve_enregistrer_releve(array &$etat, array $releve): void
{
    $releves = $etat['releves'] ?? [];
    $releves = array_values(array_filter($releves, fn($r) => ($r['jour'] ?? '') !== $releve['jour']));
    $releves[] = $releve;
    usort($releves, fn($a, $b) => strcmp((string) $a['jour'], (string) $b['jour']));
    $etat['releves'] = array_slice($releves, -400);   /* un peu plus d'un an */
    $etat['releveLe'] = $releve['jour'];   /* jour du dernier relevé, comme dans l'application */
}

/** Dernier relevé connu, ou null. */
function seve_dernier_releve(array $etat): ?array
{
    $r = $etat['releves'] ?? [];
    return $r ? $r[count($r) - 1] : null;
}

/** Découpe un CSV collé : « date;abonnés;revenus;vues;likes » (virgule ou point-virgule). */
function seve_decouper_csv(string $texte, int $limite = 400): array
{
    $lignes = preg_split('/\r\n|\r|\n/', trim($texte));
    $out = [];
    $entetes = null;
    foreach ($lignes as $ligne) {
        $ligne = trim((string) $ligne);
        if ($ligne === '') { continue; }
        $sep = (substr_count($ligne, ';') >= substr_count($ligne, ',')) ? ';' : ',';
        $cols = array_map('trim', explode($sep, $ligne));
        /* Ligne d'en-tête : on retient l'ordre des colonnes. */
        if ($entetes === null && preg_match('#jour|date|abonn|follow#i', $ligne) && !preg_match('#\d{4}[-/]\d{2}#', $ligne)) {
            $entetes = array_map(fn($c) => strtolower(preg_replace('/[^a-z]/', '', $c)), $cols);
            continue;
        }
        $r = ['jour' => $cols[0] ?? ''];
        $noms = ['abonnes', 'revenus', 'vues', 'likes', 'nouveaux', 'note'];
        if ($entetes) {
            foreach ($entetes as $i => $nom) {
                foreach ($noms as $cible) {
                    if (str_starts_with($nom, substr($cible, 0, 4)) && isset($cols[$i])) { $r[$cible] = $cols[$i]; }
                }
            }
        } else {
            foreach ($noms as $i => $cible) { if (isset($cols[$i + 1])) { $r[$cible] = $cols[$i + 1]; } }
        }
        $propre = seve_releve_normalise($r);
        if ($propre) { $out[] = $propre; }
        if (count($out) >= $limite) { break; }
    }
    return $out;
}

/* ==========================================================================
   DÉPÔT AUTOMATIQUE DES CHIFFRES
   --------------------------------------------------------------------------
   Objectif : que la créatrice n'ait plus rien à recopier. Deux canaux, tous
   les deux fondés sur ce qu'OnlyFans met réellement à sa disposition :

     1. ses fichiers : elle dépose l'export de son tableau de bord, Sève lit ;
     2. ses e-mails OnlyFans : elle crée un transfert automatique vers une boîte
        que Sève relève toute seule (voir cron/lettres.php).

   Ce qui n'est pas fait, volontairement : aucune connexion à son compte
   OnlyFans, aucun mot de passe demandé, aucun script posé sur sa page. Les
   conditions d'usage d'OnlyFans l'interdisent et le compte risquerait la
   suspension. Ces trois choses ne seront pas ajoutées plus tard.
   ========================================================================== */

/** Nouvelle clé de dépôt : ce que porte un envoi automatique, à la place du code. */
function seve_cle_depot_neuve(): string
{
    return bin2hex(random_bytes(16));       /* 32 caractères, 128 bits */
}

/** Vérifie une clé de dépôt présentée par un envoi automatique. */
function seve_cle_depot_valide(array $etat, string $cle): bool
{
    $hash = (string) ($etat['cle_depot_hash'] ?? '');
    $cle = trim($cle);
    if ($hash === '' || $cle === '') { return false; }
    return password_verify($cle, $hash);
}

/** Retire les espaces fines et insécables qui entourent les nombres français. */
function seve_texte_propre(string $texte): string
{
    $texte = str_replace(["\xC2\xA0", "\xE2\x80\xAF", "\xE2\x80\x89", "\t"], ' ', $texte);
    return trim($texte);
}

/**
 * La valeur qu'annonce un mot-clé, dans l'ordre où on la lit habituellement :
 *   1. juste avant le mot  — « 88 000 abonnés », « 412,50 € de revenus » ;
 *   2. annoncée par « : » ou « = » après le mot — « Abonnés : 88 000 » ;
 *   3. à défaut, le nombre le plus à droite de la fenêtre qui suit le mot —
 *      « Vues des 30 derniers jours : 41 200 » donne 41 200, jamais le 30.
 * Renvoie null si rien de crédible : on n'invente jamais un chiffre.
 */
function seve_valeur_etiquetee(string $texte, array $mots, bool $argent = false): int|float|null
{
    $unites = $argent ? '(?:€|EUR|\$|USD|£)' : '';
    foreach ($mots as $mot) {
        $m = preg_quote($mot, '#');

        /* 1. le nombre juste avant le mot */
        if (preg_match('#(?:^|[^\d])([0-9][0-9 .,\']{0,16})\s*'
            . ($unites !== '' ? '(?:' . $unites . '\s*)?' : '') . $m . '#iu', $texte, $r)) {
            $v = $argent ? seve_montant(rtrim($r[1], ' .,\'')) : seve_nombre(rtrim($r[1], ' .,\''));
            if ($v > 0) { return $v; }
        }

        /* 2 et 3. la fenêtre qui suit le mot */
        if (!preg_match('#(?:^|[^\p{L}])' . $m . '#iu', $texte, $r, PREG_OFFSET_CAPTURE)) { continue; }
        $fenetre = substr($texte, (int) $r[0][1] + strlen((string) $r[0][0]), 70);
        if (!preg_match_all('#([0-9][0-9 .,\']{0,16})#', $fenetre, $nums, PREG_OFFSET_CAPTURE) || !$nums[1]) { continue; }
        $meilleur = null;
        $score = -1.0;
        foreach ($nums[1] as $i => $num) {
            $brut = (string) $num[0];
            $avant = substr($fenetre, 0, (int) $num[1]);
            $s = 0.0;
            if (preg_match('#[:=]\s*$#', $avant)) { $s += 3; }                       /* annoncé : « … : 88 000 » */
            if ($argent && preg_match('#(?:€|EUR|\$|USD|£)#iu', $brut)) { $s += 2; }  /* somme : « … 412,50 € » */
            $s += 1 - ($i / 100);                                                    /* à égalité, le plus à droite */
            if ($s > $score) { $score = $s; $meilleur = rtrim($brut, ' .,\''); }
        }
        if ($meilleur !== null && $meilleur !== '') {
            $v = $argent ? seve_montant($meilleur) : seve_nombre($meilleur);
            if ($v > 0) { return $v; }
        }
    }
    return null;
}

/** Un nombre d'abonnés, de vues ou de j'aime. */
function seve_chiffre_etiquete(string $texte, array $mots): ?int
{
    $v = seve_valeur_etiquetee($texte, $mots, false);
    return $v === null ? null : (int) $v;
}

/** Une somme d'argent. */
function seve_montant_etiquete(string $texte, array $mots): ?float
{
    $v = seve_valeur_etiquetee($texte, $mots, true);
    return $v === null ? null : (float) $v;
}

/**
 * Texte libre (corps d'e-mail OnlyFans, export collé, note de l'équipe) → relevés.
 * Trois lectures, dans cet ordre : tableau de jours, chiffres étiquetés, rien.
 * Si rien n'est lisible, la fonction renvoie un tableau vide : elle n'invente
 * jamais un chiffre.
 */
function seve_texte_en_releves(string $texte, string $jour = '', string $source = 'mail'): array
{
    $texte = seve_texte_propre($texte);
    if ($texte === '') { return []; }

    /* 1. Un export collé dans le message : une ligne par jour. */
    if (preg_match('#\d{4}[-/.]\d{1,2}[-/.]\d{1,2}#', $texte) || preg_match('#\d{1,2}[-/.]\d{1,2}[-/.]\d{4}#', $texte)) {
        $lignes = seve_decouper_csv($texte, 400);
        if ($lignes) {
            foreach ($lignes as $i => $l) { $lignes[$i]['source'] = $source; }
            return $lignes;
        }
    }

    /* 2. Un message qui annonce des chiffres : « Tu as 88 000 abonnés », etc. */
    $abonnes = seve_chiffre_etiquete($texte, ['abonn', 'fans', 'subscribers', 'followers']);
    $vues    = seve_chiffre_etiquete($texte, ['vue', 'views', 'reach', 'impressions']);
    $likes   = seve_chiffre_etiquete($texte, ['like', 'j’aime', 'j\'aime', 'aime']);
    $revenus = seve_montant_etiquete($texte, ['revenu', 'earnings', 'revenue', 'paiement', 'payment',
        'payout', 'solde', 'balance', 'chiffre d', 'brut', 'net']);
    if ($abonnes === null && $vues === null && $likes === null && $revenus === null) { return []; }

    $propre = seve_releve_normalise([
        'jour'    => $jour !== '' ? $jour : date('Y-m-d'),
        'abonnes' => $abonnes ?? 0,
        'revenus' => $revenus ?? 0,
        'vues'    => $vues ?? 0,
        'likes'   => $likes ?? 0,
        'note'    => 'dépôt automatique',
        'source'  => $source
    ]);
    return $propre ? [$propre] : [];
}

/**
 * Découpe une lettre brute (.eml, flux IMAP, corps collé) : expéditeur, jour, et
 * toutes les versions lisibles du texte. Les lettres OnlyFans arrivent tantôt en
 * texte simple, tantôt en HTML, souvent en multipart : on les décode toutes, et
 * c'est celle qui contient des chiffres qui sera lue.
 */
function seve_lettre_parties(string $brut): array
{
    $ents = '';
    $corps = $brut;
    if (preg_match("#\r?\n\r?\n#", $brut, $m, PREG_OFFSET_CAPTURE)) {
        $ents = substr($brut, 0, (int) $m[0][1]);
        $corps = substr($brut, (int) $m[0][1] + strlen((string) $m[0][0]));
    }

    $de = '';
    if (preg_match('#^From:\s*(.+)$#mi', $ents, $x) && preg_match('#[\w.+-]+@[\w.-]+\.\w+#', $x[1], $a)) {
        $de = strtolower($a[0]);
    }
    $jour = '';
    if (preg_match('#^Date:\s*(.+)$#mi', $ents, $x)) {
        /* « Wed, 15 Oct 2026 … » : le nom du jour est écarté, sinon PHP recalcule
           la date sur cette base et décale la journée de plusieurs jours. */
        $brute = trim((string) preg_replace('#^[A-Za-z]{3},\s*#', '', trim($x[1])));
        $t = strtotime($brute);
        if ($t) { $jour = date('Y-m-d', $t); }
    }

    /* Message à plusieurs parties : chaque partie est décodée séparément. */
    $blocs = [];
    if (preg_match('#boundary="?([^";\r\n]+)#i', $ents, $b)) {
        foreach ((array) preg_split('#-{2}' . preg_quote($b[1], '#') . '#', $corps) as $partie) {
            if (trim((string) $partie) === '' || trim((string) $partie) === '--') { continue; }
            $type = preg_match('#Content-Type:\s*([^;\r\n]+)#i', (string) $partie, $t) ? strtolower(trim($t[1])) : '';
            if ($type !== '' && !str_starts_with($type, 'text/')) { continue; }   /* pièces jointes ignorées */
            $blocs[] = ['type' => $type, 'texte' => (string) $partie];
        }
    }
    if (!$blocs) { $blocs[] = ['type' => '', 'texte' => $corps]; }
    /* Le texte simple d'abord : c'est celui qui se recopie sans balise. */
    usort($blocs, fn($a, $b) => (int) ($b['type'] === 'text/html') <=> (int) ($a['type'] === 'text/html'));

    $parties = [];
    foreach ($blocs as $bloc) {
        $parties[] = seve_lettre_texte($bloc['texte'], $bloc['type'] === 'text/html' || stripos($bloc['texte'], '<html') !== false, $ents);
    }
    return ['de' => $de, 'jour' => $jour, 'parties' => array_values(array_filter($parties, fn($p) => trim($p) !== ''))];
}

/** Décode une partie de lettre en texte lisible (quoted-printable, base64, HTML). */
function seve_lettre_texte(string $partie, bool $html, string $entetes = ''): string
{
    if (preg_match('#Content-Transfer-Encoding:\s*base64#i', $partie . "\n" . $entetes)) {
        $corps = substr($partie, (int) strpos($partie, "\n"));
        $propre = preg_replace('#[^A-Za-z0-9+/=]#', '', $corps) ?? '';
        $decode = base64_decode($propre, true);
        if ($decode !== false && $decode !== '') { $partie = $decode; }
    } else {
        $partie = quoted_printable_decode($partie);
    }
    if ($html) {
        $partie = preg_replace('#<(script|style)\b.*?</\1>#is', ' ', $partie) ?? $partie;
        $partie = preg_replace('#<br\s*/?>|</p>|</div>|</tr>#i', "\n", $partie) ?? $partie;
        $partie = html_entity_decode(strip_tags($partie), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    } else {
        /* en-têtes de la partie : ils ne sont pas des chiffres du compte */
        $partie = (string) preg_replace('#^[A-Za-z-]+:\s*.*$#m', '', $partie);
    }
    return trim((string) preg_replace("#\n{3,}#", "\n\n", $partie));
}

/** Une lettre complète → relevés. */
function seve_lettre_en_releves(string $brut, string $source = 'mail'): array
{
    $lettre = seve_lettre_parties($brut);
    foreach ($lettre['parties'] as $texte) {
        $releves = seve_texte_en_releves($texte, $lettre['jour'], $source);
        if ($releves) {
            foreach ($releves as $i => $r) {
                $releves[$i]['note'] = $source === 'mail' ? 'depuis un e-mail OnlyFans' : 'dépôt automatique';
            }
            return $releves;
        }
    }
    return [];   /* rien de lisible : on ne devine pas */
}
