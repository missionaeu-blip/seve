<?php
declare(strict_types=1);

/* Identités et nouveaux textes du refuge dans une base privée.
   La messagerie reste verrouillée en préouverture ; aucun contenu explicite
   ou document de vérification n'est accepté par ce module. */
function seve_refuge_db(): PDO
{
    static $db = null;
    if ($db) { return $db; }
    if (!extension_loaded('pdo_sqlite')) { seve_api_erreur('Comptes indisponibles sur cet hébergement.', 503); }
    $f = seve_dossier_donnees() . '/refuge-comptes.sqlite';
    try {
        $db = new PDO('sqlite:' . $f, null, null, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        $db->exec('PRAGMA busy_timeout=5000');
        $db->exec('CREATE TABLE IF NOT EXISTS femmes (
            id TEXT PRIMARY KEY, email TEXT NOT NULL UNIQUE, nom TEXT NOT NULL,
            hash TEXT NOT NULL, date_creation TEXT NOT NULL,
            age_verifie_le TEXT, age_preuve_ref TEXT, age_verifie_par TEXT
        )');
        $db->exec('CREATE TABLE IF NOT EXISTS refuge_messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT, femme_id TEXT NOT NULL, auteur TEXT NOT NULL,
            texte TEXT NOT NULL, cree_le TEXT NOT NULL, FOREIGN KEY(femme_id) REFERENCES femmes(id)
        )');
        $db->exec('CREATE INDEX IF NOT EXISTS refuge_messages_fil ON refuge_messages(femme_id,id)');
        $db->exec('CREATE TABLE IF NOT EXISTS refuge_images (
            id TEXT PRIMARY KEY, femme_id TEXT NOT NULL, fichier TEXT NOT NULL, statut TEXT NOT NULL,
            consent_le TEXT NOT NULL, cree_le TEXT NOT NULL, modere_le TEXT,
            FOREIGN KEY(femme_id) REFERENCES femmes(id)
        )');
        $db->exec('CREATE INDEX IF NOT EXISTS refuge_images_fil ON refuge_images(femme_id,cree_le)');
        foreach (['age_verifie_le TEXT', 'age_preuve_ref TEXT', 'age_verifie_par TEXT'] as $col) {
            try { $db->exec('ALTER TABLE femmes ADD COLUMN ' . $col); }
            catch (PDOException $e) { if (!str_contains($e->getMessage(), 'duplicate column')) throw $e; }
        }
        $db->exec('CREATE TABLE IF NOT EXISTS tentatives (
            cle TEXT PRIMARY KEY, nombre INTEGER NOT NULL, depuis INTEGER NOT NULL
        )');
        @chmod($f, 0600);
    } catch (Throwable $e) {
        error_log('Sève refuge : base de comptes indisponible (' . get_class($e) . ')');
        seve_api_erreur('Comptes temporairement indisponibles.', 503);
    }
    return $db;
}

function seve_refuge_origine(): void
{
    $o = (string) ($_SERVER['HTTP_ORIGIN'] ?? '');
    $h = (string) ($_SERVER['HTTP_HOST'] ?? '');
    if ($o !== '' && $h !== '' && !hash_equals($o, (seve_is_https() ? 'https://' : 'http://') . $h)) {
        seve_api_erreur('Origine refusée.', 403);
    }
    $type = (string) ($_SERVER['CONTENT_TYPE'] ?? '');
    if (stripos($type, 'application/json') === false) { seve_api_erreur('Requête JSON attendue.', 415); }
}

function seve_refuge_limite(PDO $db): void
{
    $cle = hash('sha256', (string) ($_SERVER['REMOTE_ADDR'] ?? 'inconnue'));
    $maintenant = time();
    $st = $db->prepare('SELECT nombre, depuis FROM tentatives WHERE cle=?');
    $st->execute([$cle]); $ligne = $st->fetch(PDO::FETCH_ASSOC);
    if ($ligne && $maintenant - (int)$ligne['depuis'] < 900 && (int)$ligne['nombre'] >= 8) {
        seve_api_erreur('Trop de tentatives. Réessayez dans quinze minutes.', 429);
    }
    if (!$ligne || $maintenant - (int)$ligne['depuis'] >= 900) {
        $db->prepare('INSERT OR REPLACE INTO tentatives(cle,nombre,depuis) VALUES(?,1,?)')->execute([$cle,$maintenant]);
    } else {
        $db->prepare('UPDATE tentatives SET nombre=nombre+1 WHERE cle=?')->execute([$cle]);
    }
}

function seve_refuge_public(array $row): array
{
    return ['id' => $row['id'], 'email' => $row['email'], 'name' => $row['nom'], 'role' => 'creator',
        'age_verifie' => !empty($row['age_verifie_le'])];
}

function seve_refuge_auth(string $route, string $method, array $corps): void
{
    if (str_starts_with($route, '/refuge/chat/image')) { seve_refuge_image_api($route, $method, $corps); }
    if ($route === '/refuge/chat' || $route === '/refuge/chat/fils') {
        seve_refuge_chat($route, $method, $corps);
    }
    if ($method === 'GET' && $route === '/refuge/session') {
        if (!isset($_COOKIE[SEVE_SESSION]) && session_status() !== PHP_SESSION_ACTIVE) {
            seve_api_json(['ok' => true, 'user' => null]);
        }
        seve_session();
        $id = (string) ($_SESSION['refuge_femme'] ?? '');
        if ($id === '') { seve_api_json(['ok' => true, 'user' => null]); }
        $st = seve_refuge_db()->prepare('SELECT id,email,nom,age_verifie_le FROM femmes WHERE id=?');
        $st->execute([$id]); $row = $st->fetch(PDO::FETCH_ASSOC);
        if (empty($_SESSION['refuge_csrf'])) { $_SESSION['refuge_csrf'] = bin2hex(random_bytes(24)); }
        seve_api_json(['ok' => true, 'user' => $row ? seve_refuge_public($row) : null,
            'csrf' => $row ? $_SESSION['refuge_csrf'] : null]);
    }
    if ($method !== 'POST') { seve_api_erreur('Méthode refusée.', 405); }
    seve_refuge_origine();
    if ($route === '/refuge/sortir') {
        seve_session();
        unset($_SESSION['refuge_femme']);
        session_regenerate_id(true);
        seve_api_json(['ok' => true]);
    }
    if (!in_array($route, ['/refuge/inscription', '/refuge/connexion'], true)) { seve_api_erreur('Page introuvable.', 404); }
    $email = strtolower(trim((string)($corps['email'] ?? '')));
    $passe = (string)($corps['password'] ?? '');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190 || strlen($passe) > 1024) {
        seve_api_erreur('Vérifiez votre adresse et votre mot de passe.', 400);
    }
    if ($route === '/refuge/inscription' && !seve_service_ouvert()) {
        seve_api_erreur('Les inscriptions sont suspendues pendant la préparation du service. Aucune donnée n’a été enregistrée.', 503);
    }
    $db = seve_refuge_db();
    seve_refuge_limite($db);
    if ($route === '/refuge/inscription') {
        if (($corps['majeure_declaree'] ?? null) !== true) {
            seve_api_erreur('Déclaration de majorité requise ; elle ne remplace pas le contrôle de pièce.', 400);
        }
        $nom = trim((string)($corps['name'] ?? ''));
        if (strlen($nom) < 2 || strlen($nom) > 180 || strlen($passe) < 10) {
            seve_api_erreur('Indiquez un nom et un mot de passe d’au moins dix caractères.', 400);
        }
        $row = ['id' => 'rf_' . bin2hex(random_bytes(12)), 'email' => $email, 'nom' => $nom, 'age_verifie_le' => null];
        try {
            $db->prepare('INSERT INTO femmes(id,email,nom,hash,date_creation) VALUES(?,?,?,?,?)')
                ->execute([$row['id'], $email, $nom, password_hash($passe, PASSWORD_DEFAULT), gmdate('c')]);
        } catch (PDOException $e) {
            if (str_contains($e->getMessage(), 'UNIQUE')) { seve_api_erreur('Cette adresse possède déjà un compte. Connectez-vous.', 409); }
            error_log('Sève refuge : inscription indisponible (' . get_class($e) . ')');
            seve_api_erreur('Inscription temporairement indisponible.', 503);
        }
    } else {
        $st = $db->prepare('SELECT id,email,nom,hash,age_verifie_le FROM femmes WHERE email=?');
        $st->execute([$email]); $row = $st->fetch(PDO::FETCH_ASSOC);
        if (!$row || !password_verify($passe, (string)$row['hash'])) {
            seve_api_erreur('Adresse ou mot de passe incorrect.', 401);
        }
    }
    seve_session();
    session_regenerate_id(true);
    $_SESSION['refuge_femme'] = $row['id'];
    $_SESSION['refuge_csrf'] = bin2hex(random_bytes(24));
    seve_api_json(['ok' => true, 'user' => seve_refuge_public($row), 'csrf' => $_SESSION['refuge_csrf']]);
}
