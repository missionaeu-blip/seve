<?php
declare(strict_types=1);

/* ==========================================================================
   SÈVE — écran de vérification de l'installation
   --------------------------------------------------------------------------
   Adresse : /seve/verification  (ou /seve/verification.php)

   À ouvrir juste après avoir extrait le paquet : la page vérifie que les
   fichiers sont bien en place, que le dossier de données est accessible en
   écriture et que l'API répond. Chaque ligne rouge dit quoi faire.

   Elle ne montre aucun secret : ni mot de passe, ni empreinte, ni chemin
   absolu du serveur — seulement des oui/non. À supprimer si vous préférez.
   ========================================================================== */

require_once __DIR__ . '/donnees.php';

/** Une ligne de contrôle : [titre, ok, ce que ça signifie, quoi faire sinon]. */
/**
 * Une ligne de contrôle.
 * $bloquant = false : la ligne est utile mais facultative (par exemple le
 * dépôt par e-mail, qui n'est pas installé par défaut). Elle s'affiche en
 * orange et ne met jamais toute la page en échec — sinon un site parfaitement
 * fonctionnel répondrait 500, ce qui fait croire à une panne.
 */
function seve_vc(string $titre, bool $ok, string $bon, string $aide, bool $bloquant = true): array
{
    return ['titre' => $titre, 'ok' => $ok, 'bon' => $bon, 'aide' => $aide, 'bloquant' => $bloquant];
}

function seve_verification(): never
{
    $racine = dirname(__DIR__);
    $base = seve_base_path();
    $controles = [];

    /* ---------------------------------------------------------------- PHP --- */
    $version = PHP_VERSION;
    $controles[] = seve_vc('Version de PHP', version_compare($version, '7.4', '>='),
        'PHP ' . $version . ' est installé.', 'Demandez PHP 7.4 ou plus à votre hébergeur.');

    $controles[] = seve_vc('Extension JSON', extension_loaded('json'),
        'Présente (indispensable aux relevés).', 'Activez l’extension json dans hPanel → PHP.');

    $controles[] = seve_vc('Extension mbstring (facultative)', extension_loaded('mbstring'),
        extension_loaded('mbstring') ? 'Présente.' : 'Absente — sans conséquence, Sève s’en passe.',
        'Rien à faire : Sève fonctionne sans.');

    /* ------------------------------------------------------------ Fichiers --- */
    $fichiers = [
        'index.php' => 'le contrôleur frontal',
        'app.html' => 'le squelette de l’application',
        'includes/api.php' => 'l’API des relevés',
        'includes/donnees.php' => 'le stockage des relevés',
        'assets/js/lib/api.js' => 'le lien entre l’application et l’API',
        'assets/js/views/of.js' => 'les écrans du compte OnlyFans',
        'assets/css/warm.css' => 'la feuille de style',
        'config.php' => 'les réglages'
    ];
    $manquants = [];
    foreach ($fichiers as $f => $quoi) {
        if (!is_readable($racine . '/' . $f)) { $manquants[] = $f; }
    }
    $controles[] = seve_vc('Fichiers du site complets', !$manquants,
        count($fichiers) . ' fichiers essentiels vérifiés (' . implode(', ', array_values($fichiers)) . ').',
        'Manquant(s) : ' . implode(', ', $manquants) . ' — réextrayez le paquet à la racine de public_html (voir ci-dessous).');

    $pages = array_values(array_filter(glob($racine . '/pages/*.php') ?: [], fn($f) => basename($f)[0] !== '_'));
    $controles[] = seve_vc('Les 23 pages PHP', count($pages) >= 23,
        count($pages) . ' pages livrées (+ le modèle commun _page.php).',
        'Seulement ' . count($pages) . ' page(s) trouvée(s) : l’extraction est incomplète.');

    $controles[] = seve_vc('Fichier .htaccess', is_readable($racine . '/.htaccess'),
        'Présent : adresses propres et protections actives.',
        'Absent : réextrayez le paquet (les fichiers commençant par un point sont masqués dans le gestionnaire de fichiers).');

    /* -------------------------------------------------------------- Données --- */
    $dossier = seve_dossier_donnees();
    $controles[] = seve_vc('Dossier data/', is_dir($dossier),
        'Il existe : les relevés des créatrices y seront conservés.',
        'Créez un dossier « data » dans le dossier de Sève, avec les droits 755.');

    $ecriture = false;
    $detailEcriture = '';
    if (is_dir($dossier)) {
        $essai = $dossier . '/verification-' . bin2hex(random_bytes(3)) . '.json';
        $ecriture = @file_put_contents($essai, '{"essai":true}') !== false;
        if ($ecriture) {
            $relu = @file_get_contents($essai);
            $ecriture = ($relu === '{"essai":true}');
            @unlink($essai);
            $detailEcriture = 'Écriture, relecture et suppression réussies.';
        } else {
            $detailEcriture = 'Le serveur n’a pas pu écrire dans data/.';
        }
    }
    $controles[] = seve_vc('Dossier data/ accessible en écriture', $ecriture,
        $detailEcriture,
        'Dans le gestionnaire de fichiers : clic droit sur « data » → Permissions → 755, et vérifiez qu’aucun verrou n’est posé sur le dossier.');

    /* ------------------------------------------------------------------ API --- */
    require_once __DIR__ . '/api.php';
    $apiOk = function_exists('seve_api_repondre') && function_exists('seve_lire') && function_exists('seve_ecrire');
    $controles[] = seve_vc('API des relevés disponible', $apiOk,
        'Points d’entrée chargés : /api/sante, /api/releve, /api/import…',
        'Fichiers includes/api.php ou includes/donnees.php absents ou illisibles.');

    /* ---------------------------------------------------------- Environnement --- */
    /* Dépôt automatique : les deux voies par lesquelles les chiffres arrivent
       sans que la créatrice ait à les recopier. Aucune ne passe par le compte
       OnlyFans (pas de mot de passe, pas de script sur sa page). */
    $controles[] = seve_vc('Dépôt de fichiers (export OnlyFans)', true,
        'La créatrice dépose son export dans son espace : les lignes sont lues et les journées remplies.',
        'Rien à installer. La zone de dépôt se trouve dans « Mon compte OnlyFans ».');
    $boite = (string) seve_cfg('depot_mail', '');
    $imap = (string) seve_cfg('depot_imap_hote', '');
    $controles[] = seve_vc('Dépôt par e-mail' . ($boite !== '' ? ' (' . $boite . ')' : ''), $imap !== '',
        'Sève relève la boîte et lit les lettres OnlyFans toutes les heures.',
        'Facultatif. Pour l’activer : renseignez depot_mail, depot_imap_hote, depot_imap_utilisateur et '
        . 'depot_imap_motdepasse dans config.php, puis planifiez cron/lettres.php (hPanel → Tâches planifiées). '
        . 'En attendant, le dépôt de fichiers et la lecture d’une lettre .eml fonctionnent déjà.', false);

    $controles[] = seve_vc('Adresse détectée', true,
        'Sève se voit dans le dossier « ' . ($base === '' ? 'racine du domaine' : $base) . '/ ».',
        '');

    $garde = (bool) seve_cfg('protection', false);
    $controles[] = seve_vc('Accès protégé par mot de passe', true,
        $garde ? 'Oui — le site demande le mot de passe de config.php.' : 'Non — le site est ouvert (c’est le réglage livré).',
        'Pour le fermer : « protection » => true dans config.php.');

    $maintenance = (bool) seve_cfg('maintenance', false);
    $controles[] = seve_vc('Mode maintenance', !$maintenance,
        $maintenance ? 'ACTIF : les visiteurs voient la page de maintenance, et l’API répond 503.' : 'Inactif : le site répond normalement.',
        'Remettez « maintenance » => false dans config.php quand vous avez terminé.');

    /* Intégrité complète : chaque fichier listé dans MANIFESTE.txt doit être là.
       C'est ce contrôle qui repère une extraction interrompue en cours de route. */
    $manifeste = $racine . '/MANIFESTE.txt';
    $manquants = [];
    $attendus = 0;
    if (is_readable($manifeste)) {
        $brut = (string) @file_get_contents($manifeste);
        foreach (preg_split('/\R/', $brut) as $ligne) {
            $rel = trim((string) $ligne);
            if ($rel === '' || str_starts_with($rel, 'data/')) { continue; }   /* data/ se remplit tout seul */
            $attendus++;
            if (!is_readable($racine . '/' . $rel)) { $manquants[] = $rel; }
        }
    }
    $controles[] = seve_vc('Intégrité du paquet (tous les fichiers)',
        $attendus > 0 && !$manquants,
        $attendus > 0
            ? $attendus . ' fichiers attendus : tous présents.'
            : 'MANIFESTE.txt absent : impossible de faire le contrôle complet.',
        $attendus === 0
            ? 'MANIFESTE.txt manque : l’extraction est incomplète. Réextrayez le paquet complet.'
            : count($manquants) . ' fichier(s) manquant(s) : ' . implode(', ', array_slice($manquants, 0, 8))
              . (count($manquants) > 8 ? '…' : '') . ' — l’extraction s’est arrêtée en route. Réextrayez le paquet complet (ou le paquet de réparation) dans public_html.');

    $marqueur = $racine . '/VERSION';
    $versionPaquet = '';
    if (is_readable($marqueur)) {
        $lignesVersion = preg_split('/\R/', (string) @file_get_contents($marqueur));
        $versionPaquet = trim((string) ($lignesVersion[0] ?? ''));
    }
    $controles[] = seve_vc('Version du paquet installé', $versionPaquet !== '',
        $versionPaquet !== '' ? $versionPaquet : 'Fichier VERSION absent.',
        'Fichier VERSION absent : le paquet extrait est ancien (ou l’extraction est incomplète). Reprenez le dernier ZIP.');

    /* ------------------------------------------------------------- Rendu --- */
    /* Seules les lignes obligatoires décident du résultat de la page. */
    $echecs = array_values(array_filter($controles, fn($c) => !$c['ok'] && ($c['bloquant'] ?? true)));
    $facultatifs = array_values(array_filter($controles, fn($c) => !$c['ok'] && !($c['bloquant'] ?? true)));
    $ok = count($echecs) === 0;

    http_response_code($ok ? 200 : 500);
    header('X-Robots-Tag: noindex, nofollow');

    $lignes = '';
    foreach ($controles as $c) {
        $etat = $c['ok'] ? 'ok' : (($c['bloquant'] ?? true) ? 'ko' : 'facultatif');
        $signe = $c['ok'] ? '✓' : (($c['bloquant'] ?? true) ? '✗' : '·');
        $lignes .= '<li class="' . $etat . '">' .
            '<span class="marque">' . $signe . '</span>' .
            '<span class="corps"><b>' . page_h($c['titre']) . '</b>' .
            '<em>' . page_h($c['ok'] ? $c['bon'] : $c['aide']) . '</em></span></li>';
    }

    $titre = $ok ? 'Installation vérifiée : tout est en place.' : 'Il reste ' . count($echecs) . ' point(s) à corriger.';
    if ($ok && $facultatifs) {
        $titre .= ' (' . count($facultatifs) . ' réglage(s) facultatif(s) non activé(s))';
    }
    $sous = $ok
        ? 'Ouvrez <b>' . page_h(($base === '' ? '' : $base) . '/') . '</b> : le site doit s’afficher. Ce diagnostic ne montre aucun secret et peut être supprimé.'
        : 'Chaque ligne rouge indique la marche à suivre. Si le dossier « pages » ou « assets » est incomplet, le ZIP a été extrait au mauvais endroit : il doit être déposé dans <b>public_html</b>, pas à l’intérieur du dossier « seve ».';

    echo '<!doctype html><html lang="fr"><head><meta charset="utf-8">' .
        '<meta name="viewport" content="width=device-width,initial-scale=1">' .
        '<meta name="robots" content="noindex,nofollow">' .
        '<title>Vérification de l’installation — Sève</title><style>' .
        ':root{--vert:#0B2A20;--vert2:#15624B;--ok:#3D9770;--ko:#B23B32;--ligne:#E7E1D6;--fond:#FDFBF7;--texte:#221F1B;--doux:#6C665D}' .
        '*{box-sizing:border-box}body{margin:0;background:var(--fond);color:var(--texte);font:16px/1.55 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}' .
        '.wrap{max-width:760px;margin:0 auto;padding:34px 20px 60px}' .
        'h1{font-size:26px;margin:0 0 6px;letter-spacing:-.02em}' .
        'p.lede{margin:0 0 22px;color:var(--doux)}' .
        '.banniere{border-radius:14px;padding:16px 18px;margin-bottom:20px;font-size:15px;border:1px solid transparent}' .
        '.banniere.ok{background:#EAF6EF;border-color:#BFE3CE;color:#14503A}' .
        '.banniere.ko{background:#FBEDEB;border-color:#F0CFCB;color:#7C2C25}' .
        'ul{list-style:none;margin:0;padding:0;background:#fff;border:1px solid var(--ligne);border-radius:16px;overflow:hidden}' .
        'li{display:flex;gap:12px;padding:13px 16px;border-bottom:1px solid var(--ligne)}li:last-child{border-bottom:0}' .
        '.marque{flex:0 0 24px;height:24px;border-radius:50%;display:grid;place-items:center;font-weight:700;font-size:14px;color:#fff}' .
        'li.ok .marque{background:var(--ok)}li.ko .marque{background:var(--ko)}' .
        'li.facultatif .marque{background:#C79A3F}li.facultatif .corps em{color:#8A6A25}' .
        '.corps{min-width:0}.corps b{display:block;font-weight:600}' .
        '.corps em{display:block;font-style:normal;font-size:14px;color:var(--doux);margin-top:2px}' .
        'li.ko .corps b{color:#8E2F27}' .
        'footer{margin-top:24px;font-size:13px;color:var(--doux)}a{color:var(--vert2)}' .
        '</style></head><body><div class="wrap">' .
        '<h1>Vérification de l’installation</h1>' .
        '<p class="lede">Contrôle de Sève, dossier par dossier. Aucun mot de passe ni chemin du serveur n’apparaît ici.</p>' .
        '<div class="banniere ' . ($ok ? 'ok' : 'ko') . '"><b>' . $titre . '</b><br>' . $sous . '</div>' .
        '<ul>' . $lignes . '</ul>' .
        '<footer>Sève — page de diagnostic. Vous pouvez la supprimer après vérification : rien d’autre ne l’utilise. ' .
        'Rappel des adresses : le site <b>' . page_h(($base === '' ? '' : $base) . '/') . '</b> · l’API <b>' . page_h(($base === '' ? '' : $base) . '/api/sante') . '</b>.</footer>' .
        '</div></body></html>';
    exit;
}
