<?php
declare(strict_types=1);

function seve_admin_local_config(): array
{
    $path = SEVE_ROOT . '/config-local-seve.php';
    return is_file($path) ? (array) require $path : [];
}

function seve_admin_session(): bool
{
    if (session_status() === PHP_SESSION_ACTIVE) { return session_name() === 'seve_admin_sid'; }
    if (!isset($_COOKIE['seve_admin_sid'])) { return false; }
    session_name('seve_admin_sid');
    session_set_cookie_params(['path' => (seve_base_path() ?: '') . '/', 'secure' => seve_is_https(),
        'httponly' => true, 'samesite' => 'Lax']);
    session_start();
    return true;
}

/** Autorisation serveur de toutes les commandes d'administration Sève. */
function seve_api_admin_seve(): bool
{
    if (!seve_admin_session()) { return false; }
    $cfg = seve_admin_local_config();
    $hash = (string)($cfg['admin_hash'] ?? '');
    return !empty($_SESSION['seve_admin_ok']) && $hash !== '' &&
        !empty($_SESSION['seve_admin_hash_id']) &&
        hash_equals((string)$_SESSION['seve_admin_hash_id'], hash('sha256', $hash));
}

function seve_admin_local_ip_limite(): void
{
    $ip = hash('sha256', (string) ($_SERVER['REMOTE_ADDR'] ?? 'inconnue'));
    $file = seve_dossier_donnees() . '/admin-login-' . $ip . '.json';
    $now = time();
    $entry = is_file($file) ? json_decode((string) file_get_contents($file), true) : null;
    $entry = is_array($entry) && $now - (int)($entry['depuis'] ?? 0) < 900 ? $entry : ['depuis' => $now, 'essais' => 0];
    if ((int)$entry['essais'] >= 6) { seve_api_erreur('Trop de tentatives. Réessayez dans quinze minutes.', 429); }
    $entry['essais']++;
    file_put_contents($file, json_encode($entry), LOCK_EX);
    @chmod($file, 0600);
}

function seve_admin_local_api(string $route, string $method, array $body): void
{
    if ($route === '/admin/session' && $method === 'GET') {
        $ok = seve_api_admin_seve();
        if ($ok && empty($_SESSION['seve_mode_csrf'])) { $_SESSION['seve_mode_csrf'] = bin2hex(random_bytes(24)); }
        seve_api_json(['ok' => true, 'admin' => $ok, 'csrf' => $ok ? $_SESSION['seve_mode_csrf'] : null]);
    }
    if ($route === '/admin/comptes' && $method === 'GET') {
        if (!seve_api_admin_seve()) { seve_api_erreur('Connexion administrateur requise.', 403); }
        $rows = seve_refuge_db()->query('SELECT id,nom,email,age_verifie_le FROM femmes ORDER BY date_creation DESC LIMIT 100')->fetchAll(PDO::FETCH_ASSOC);
        seve_api_json(['ok' => true, 'comptes' => $rows]);
    }
    if ($method !== 'POST') { seve_api_erreur('Méthode non autorisée.', 405); }
    seve_refuge_origine(); // JSON + origine identique
    if ($route === '/admin/connexion') {
        $cfg = seve_admin_local_config();
        $hash = (string)($cfg['admin_hash'] ?? '');
        if ($hash === '') { seve_api_erreur('Définissez l’empreinte admin dans config-local-seve.php.', 503); }
        seve_admin_local_ip_limite();
        $identifiant = (string)($body['identifiant'] ?? '');
        $mdp = (string)($body['mot_de_passe'] ?? '');
        if (strlen($mdp) > 1024 || !hash_equals((string)($cfg['admin_identifiant'] ?? 'admin'), $identifiant)
            || !password_verify($mdp, $hash)) {
            seve_api_erreur('Identifiant ou mot de passe incorrect.', 401);
        }
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_name('seve_admin_sid');
            session_set_cookie_params(['path' => (seve_base_path() ?: '') . '/', 'secure' => seve_is_https(),
                'httponly' => true, 'samesite' => 'Lax']);
            session_start();
        }
        session_regenerate_id(true);
        $_SESSION['seve_admin_ok'] = true;
        $_SESSION['seve_admin_hash_id'] = hash('sha256', $hash);
        $_SESSION['seve_mode_csrf'] = bin2hex(random_bytes(24));
        seve_api_json(['ok' => true, 'admin' => true, 'csrf' => $_SESSION['seve_mode_csrf']]);
    }
    if (!seve_api_admin_seve()) { seve_api_erreur('Administration Sève : connexion requise.', 403); }
    if ($route === '/admin/deconnexion') {
        $csrf = (string) ($body['csrf'] ?? '');
        if ($csrf === '' || !hash_equals((string)($_SESSION['seve_mode_csrf'] ?? ''), $csrf)) {
            seve_api_erreur('Session expirée.', 403);
        }
        unset($_SESSION['seve_admin_ok'], $_SESSION['seve_admin_hash_id'], $_SESSION['seve_mode_csrf']);
        session_regenerate_id(true);
        seve_api_json(['ok' => true]);
    }
    if ($route === '/admin/majorite') {
        $csrf = (string)($body['csrf'] ?? '');
        if ($csrf === '' || !hash_equals((string)($_SESSION['seve_mode_csrf'] ?? ''), $csrf)) { seve_api_erreur('Session expirée.', 403); }
        $id = (string)($body['id'] ?? '');
        $reference = trim((string)($body['reference'] ?? ''));
        if (!preg_match('/^rf_[a-f0-9]{24}$/', $id) || strlen($reference) < 8 || strlen($reference) > 160 ||
            ($body['piece_examinee'] ?? null) !== true) {
            seve_api_erreur('Examen réel de pièce et référence du contrôle obligatoires.', 400);
        }
        $db = seve_refuge_db();
        $st = $db->prepare('UPDATE femmes SET age_verifie_le=?, age_preuve_ref=?, age_verifie_par=? WHERE id=?');
        $st->execute([gmdate('c'), $reference, (string)(seve_admin_local_config()['admin_identifiant'] ?? 'admin'), $id]);
        if ($st->rowCount() !== 1) { seve_api_erreur('Compte introuvable.', 404); }
        seve_api_json(['ok' => true, 'verifie' => true]);
    }
    seve_api_erreur('Route admin introuvable.', 404);
}
