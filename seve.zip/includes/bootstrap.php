<?php
declare(strict_types=1);

/* ==========================================================================
   SÈVE — socle commun (PHP)
   Chargé par index.php et par chaque fichier de pages/.
   Même architecture que /pannacotaclub déjà en ligne sur le même hébergement :
       index.php      contrôleur frontal : toutes les adresses du dossier
       includes/      socle et rendu (jamais servi au public)
       pages/         une page par fichier, appelable directement
       assets/        css, js, img
       config.php     réglages (jamais servi au public)
   ========================================================================== */

/* Un fichier de pages/ peut être appelé directement alors que index.php a déjà
   chargé le socle : cette garde évite une double déclaration des fonctions. */
if (defined('SEVE_ROOT')) { return; }

date_default_timezone_set('Europe/Paris');

define('SEVE_ROOT', dirname(__DIR__));
define('SEVE_CONFIG_FILE', SEVE_ROOT . '/config.php');
define('SEVE_VERSION', '1.0');
define('SEVE_SESSION', 'seve_sid');

$GLOBALS['SEVE_CFG'] = is_readable(SEVE_CONFIG_FILE) ? (array) require SEVE_CONFIG_FILE : [];

/** Réglage : seve_cfg('protection'), seve_cfg('titre')… */
function seve_cfg(?string $key = null, mixed $default = null): mixed
{
    $config = $GLOBALS['SEVE_CFG'];
    if ($key === null) { return $config; }
    foreach (explode('.', $key) as $part) {
        if (!is_array($config) || !array_key_exists($part, $config)) { return $default; }
        $config = $config[$part];
    }
    return $config;
}

/** Ouverture effective seulement avec administration indépendante configurée et
 * dépendances de l'inscription, du chat et des PNG présentes sur le serveur. */
function seve_service_ouvert(): bool
{
    if (!seve_cfg('ouverture_publique', false) || !extension_loaded('pdo_sqlite') || !extension_loaded('gd')) return false;
    $local = SEVE_ROOT . '/config-local-seve.php';
    if (!is_file($local)) return false;
    $cfg = (array)require $local;
    $hash = (string)($cfg['admin_hash'] ?? '');
    return $hash !== '' && !empty(password_get_info($hash)['algo']);
}

/* -------------------------------------------------------------- utilitaires
   Mêmes noms que dans pannacotaclub : page_h(), page_url(), page_redirect(). */

function page_h(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** Adresse du site : '' à la racine du domaine, '/seve' dans un sous-dossier.
    Les trois méthodes se complètent, comme pour pannacotaclub, car selon la
    configuration de l'hébergeur l'information n'est pas au même endroit. */
function seve_base_path(): string
{
    static $base = null;
    if ($base !== null) { return $base; }

    // 1) méthode la plus fiable : position du dossier dans la racine publique
    $docroot = rtrim(str_replace('\\', '/', (string) ($_SERVER['DOCUMENT_ROOT'] ?? '')), '/');
    if ($docroot !== '' && str_starts_with(SEVE_ROOT, $docroot)) {
        $rel = str_replace('\\', '/', substr(SEVE_ROOT, strlen($docroot)));
        return $base = ($rel === '/' ? '' : rtrim($rel, '/'));
    }

    // 2) cas courant : /index.php, /seve/index.php ou /seve/pages/….php
    $script = str_replace('\\', '/', (string) ($_SERVER['SCRIPT_NAME'] ?? ''));
    $dir = rtrim(dirname($script), '/');
    $dir = (string) preg_replace('#/pages$#', '', $dir);
    if ($dir !== '' && $dir !== '.' && $dir !== '/') { return $base = $dir; }

    // 3) dernier recours : on déduit le préfixe de l'adresse demandée
    $uri = (string) (parse_url((string) ($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH) ?: '/');
    if (preg_match('#^(.*?)/(?:index\.php|pages/[a-z0-9-]+\.php|createurs?|creators?|managers?|decouvrir|discover|inscription|signup|connexion|login|messages|demandes|requests|parametres|settings|paiements|payouts|aide|matching-help|tableau-de-bord|dashboard|administration|admin|profil|api|mon-compte|compte-of|of|publications|tarifs)/?#i', $uri, $m)) {
        return $base = rtrim($m[1], '/');
    }
    return $base = '';
}

/** Adresse complète d'une route de l'application : page_url('/creators'). */
function page_url(string $route = '/'): string
{
    $url = seve_base_path() . '/' . seve_src();
    if ($route !== '' && $route !== '/') {
        $url .= '#' . (str_starts_with($route, '/') ? $route : '/' . $route);
    }
    return $url;
}

function page_redirect(string $url, int $code = 301): never
{
    seve_headers();
    if (!headers_sent()) { header('Location: ' . $url, true, $code); }
    echo '<!doctype html><html lang="fr"><head><meta charset="utf-8">'
        . '<meta http-equiv="refresh" content="0;url=' . page_h($url) . '">'
        . '<meta name="robots" content="noindex, nofollow">'
        . '<title>Redirection</title></head><body style="font-family:system-ui,sans-serif;padding:40px;color:#181c19">'
        . '<p>Redirection vers <a href="' . page_h($url) . '">' . page_h($url) . '</a>…</p></body></html>';
    exit;
}

/** Canal d'arrivée (?src=…), conservé à travers les redirections. */
function seve_src(): string
{
    $src = isset($_GET['src']) ? (string) preg_replace('/[^A-Za-z0-9_-]/', '', (string) $_GET['src']) : '';
    return $src === '' ? '' : '?src=' . substr($src, 0, 40);
}

function seve_is_https(): bool
{
    return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
}

/* ---------------------------------------------------------------- en-têtes */

function seve_headers(): void
{
    if (headers_sent()) { return; }
    header('Content-Type: text/html; charset=UTF-8');
    if (seve_cfg('noindex', true)) {
        header('X-Robots-Tag: noindex, nofollow, noarchive, nosnippet');
    }
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Permissions-Policy: geolocation=(), microphone=(), camera=()');
    header("Content-Security-Policy: default-src 'self'; base-uri 'self'; object-src 'none'; frame-ancestors 'self'; form-action 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; connect-src 'self'; font-src 'self' data:");
    header('Referrer-Policy: no-referrer');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
}

function seve_session(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) { return; }
    session_name(SEVE_SESSION);
    session_set_cookie_params([
        'path'     => (seve_base_path() === '' ? '/' : seve_base_path() . '/'),
        'httponly' => true,
        'secure'   => seve_is_https(),
        'samesite' => 'Lax',
    ]);
    session_start();
}

/* ------------------------------------------------- protection / maintenance */

function seve_gate(): void
{
    if (!seve_cfg('protection', false)) { return; }
    seve_session();

    if (isset($_GET['deconnexion'])) {
        $_SESSION = [];
        session_destroy();
        page_redirect(seve_base_path() . '/', 302);
    }
    if (!empty($_SESSION['seve_ok'])) { return; }

    $erreur = '';
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' && isset($_POST['mot_de_passe'])) {
        $jeton = (string) ($_POST['jeton'] ?? '');
        /* le jeton n'est vérifié que s'il existe en session : un navigateur qui
           bloque les cookies ne doit pas bloquer un accès légitime */
        $jetonOk = empty($_SESSION['jeton']) || hash_equals((string) $_SESSION['jeton'], $jeton);
        if (!$jetonOk) {
            $erreur = 'Session expirée, merci de réessayer.';
        } elseif (password_verify((string) $_POST['mot_de_passe'], (string) seve_cfg('empreinte', ''))) {
            session_regenerate_id(true);
            $_SESSION['seve_ok'] = true;
            page_redirect(seve_base_path() . '/', 302);
        } else {
            $erreur = 'Mot de passe incorrect.';
        }
    }
    if (empty($_SESSION['jeton'])) { $_SESSION['jeton'] = bin2hex(random_bytes(16)); }

    seve_ecran_connexion((string) seve_cfg('titre', 'Sève'), (string) $_SESSION['jeton'], $erreur);
}

function seve_maintenance(): void
{
    if (!seve_cfg('maintenance', false)) { return; }
    seve_ecran_maintenance((string) seve_cfg('message_maintenance', 'Le site est momentanément indisponible.'));
}

/* ---------------------------------------------------------- écrans système */

function seve_ecran(string $titre, string $contenu, int $code = 200): never
{
    seve_headers();
    http_response_code($code);
    $t = page_h($titre);
    echo <<<HTML
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{$t}</title>
<meta name="robots" content="noindex, nofollow">
<style>
  :root { --bg:#f7f8f6; --ink:#141814; --muted:#5d6760; --green:#1f5c3d; --green-100:#e3efe7; --line:#e4e7e2; }
  * { box-sizing:border-box }
  body { margin:0; min-height:100vh; display:grid; place-items:center; padding:24px; background:var(--bg); color:var(--ink);
         font:16px/1.55 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif; }
  .box { width:100%; max-width:420px; background:#fff; border:1px solid var(--line); border-radius:18px; padding:32px;
         box-shadow:0 1px 2px rgba(20,24,20,.04) }
  .marque { display:flex; align-items:center; gap:10px; font-weight:600; letter-spacing:-.01em }
  .marque span { width:26px; height:26px; border-radius:8px; background:var(--green-100); display:grid; place-items:center; color:var(--green) }
  h1 { font-size:21px; margin:22px 0 6px; letter-spacing:-.02em }
  p { color:var(--muted); font-size:14.5px; margin:0 0 20px }
  label { display:block; font-size:13px; font-weight:600; margin-bottom:6px }
  input[type=password] { width:100%; height:46px; padding:0 14px; border:1px solid var(--line); border-radius:11px; font-size:15px; background:#fff; color:var(--ink) }
  input[type=password]:focus { outline:none; border-color:var(--green); box-shadow:0 0 0 3px var(--green-100) }
  button { margin-top:16px; width:100%; height:46px; border:0; border-radius:11px; background:var(--green); color:#fff; font-size:15px; font-weight:600; cursor:pointer }
  button:hover { background:#184a31 }
  .erreur { margin-top:14px; background:#fdecea; color:#8c2d22; border:1px solid #f5c9c3; border-radius:11px; padding:11px 13px; font-size:13.5px }
  .pied { margin-top:22px; padding-top:18px; border-top:1px solid var(--line); font-size:12.5px; color:var(--muted) }
  a { color:var(--green) }
</style>
</head>
<body>
  <main class="box">
    <div class="marque"><span>◆</span> Sève</div>
    {$contenu}
  </main>
</body>
</html>
HTML;
    exit;
}

function seve_ecran_connexion(string $titre, string $jeton, string $erreur = ''): never
{
    $bloc = $erreur !== '' ? '<div class="erreur">' . page_h($erreur) . '</div>' : '';
    seve_ecran($titre, '<h1>Aperçu privé</h1>'
        . '<p>Ce site n’est pas public. Merci de saisir le mot de passe communiqué par l’équipe.</p>'
        . '<form method="post" action="' . page_h(seve_base_path() . '/') . '">'
        . '<label for="mot_de_passe">Mot de passe</label>'
        . '<input type="password" id="mot_de_passe" name="mot_de_passe" autocomplete="current-password" autofocus required>'
        . '<input type="hidden" name="jeton" value="' . page_h($jeton) . '">'
        . '<button type="submit">Ouvrir le site</button></form>' . $bloc
        . '<div class="pied">Sève — mise en relation créateurs ↔ managers. Aucun frais pour les créateurs, '
        . 'aucune commission prélevée par la plateforme.</div>', 401);
}

function seve_ecran_maintenance(string $message): never
{
    seve_ecran('Site momentanément indisponible',
        '<h1>De retour très vite</h1><p>' . page_h($message) . '</p>', 503);
}
