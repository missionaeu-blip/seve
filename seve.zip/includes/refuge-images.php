<?php
declare(strict_types=1);

/* PNG déposés hors accès web, réencodés sans métadonnées, puis retenus jusqu'à
   la modération par l'administrateur. Tous les PNG sont traités comme pouvant
   être explicites : jamais de classification automatique supposée fiable. */
function seve_refuge_image_api(string $route, string $method, array $body): void
{
    if (!seve_service_ouvert()) {
        seve_api_erreur('Envoi d’images fermé pendant la préouverture.', 503);
    }
    $admin = seve_api_admin_seve();
    if ($admin) {
        $csrf = (string)($_SESSION['seve_mode_csrf'] ?? '');
    } else {
        if (!isset($_COOKIE[SEVE_SESSION]) && session_status() !== PHP_SESSION_ACTIVE) {
            seve_api_erreur('Compte refuge requis.', 401);
        }
        seve_session();
        $femme = (string)($_SESSION['refuge_femme'] ?? '');
        if (!preg_match('/^rf_[a-f0-9]{24}$/', $femme)) { seve_api_erreur('Compte refuge requis.', 401); }
        $csrf = (string)($_SESSION['refuge_csrf'] ?? '');
    }
    $db = seve_refuge_db();
    $dossier = seve_dossier_donnees() . '/images';
    if ($route === '/refuge/chat/images' && $method === 'GET') {
        if ($admin) {
            $liste = $db->query("SELECT i.id,i.femme_id,i.statut,i.cree_le,f.nom,f.email FROM refuge_images i
                JOIN femmes f ON f.id=i.femme_id WHERE i.statut IN ('attente','approuvee') ORDER BY i.cree_le DESC LIMIT 100")
                ->fetchAll(PDO::FETCH_ASSOC);
        } else {
            $st = $db->prepare('SELECT id,statut,cree_le FROM refuge_images WHERE femme_id=? ORDER BY cree_le DESC LIMIT 100');
            $st->execute([$femme]); $liste = $st->fetchAll(PDO::FETCH_ASSOC);
        }
        seve_api_json(['ok' => true, 'images' => $liste]);
    }
    if ($route === '/refuge/chat/image' && $method === 'GET') {
        $id = (string)($_GET['id'] ?? '');
        if (!preg_match('/^[a-f0-9]{32}$/', $id)) { seve_api_erreur('Image introuvable.', 404); }
        $st = $db->prepare('SELECT fichier,femme_id,statut FROM refuge_images WHERE id=?');
        $st->execute([$id]); $row = $st->fetch(PDO::FETCH_ASSOC);
        if (!$row || (!$admin && ($row['femme_id'] !== $femme || $row['statut'] !== 'approuvee'))) {
            seve_api_erreur('Image indisponible.', 404);
        }
        $path = $dossier . '/' . basename((string)$row['fichier']);
        if (!is_file($path)) { seve_api_erreur('Image retirée.', 404); }
        header('Content-Type: image/png');
        header('Content-Disposition: inline; filename="image-seve.png"');
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: private, no-store');
        header("Content-Security-Policy: default-src 'none'; sandbox");
        readfile($path);
        exit;
    }
    if ($method !== 'POST') { seve_api_erreur('Méthode refusée.', 405); }
    $origin = (string)($_SERVER['HTTP_ORIGIN'] ?? '');
    $host = (string)($_SERVER['HTTP_HOST'] ?? '');
    if ($origin !== '' && $host !== '' && !hash_equals($origin, (seve_is_https() ? 'https://' : 'http://') . $host)) {
        seve_api_erreur('Origine refusée.', 403);
    }
    $jeton = (string)($body['csrf'] ?? '');
    if ($jeton === '' || $csrf === '' || !hash_equals($csrf, $jeton)) { seve_api_erreur('Session expirée.', 403); }
    if ($route === '/refuge/chat/image/moderer') {
        if (!$admin) { seve_api_erreur('Réservé à la modération.', 403); }
        $id = (string)($body['id'] ?? ''); $decision = (string)($body['decision'] ?? '');
        if (!preg_match('/^[a-f0-9]{32}$/', $id) || !in_array($decision, ['approuver','retirer'], true)) {
            seve_api_erreur('Décision invalide.', 400);
        }
        $st = $db->prepare('SELECT fichier,statut FROM refuge_images WHERE id=?');
        $st->execute([$id]); $image = $st->fetch(PDO::FETCH_ASSOC);
        if (!$image || ($decision === 'approuver' && $image['statut'] !== 'attente') ||
            ($decision === 'retirer' && !in_array($image['statut'], ['attente','approuvee'], true))) {
            seve_api_erreur('Image introuvable ou déjà retirée.', 404);
        }
        $statut = $decision === 'approuver' ? 'approuvee' : 'retiree';
        $db->prepare('UPDATE refuge_images SET statut=?,modere_le=? WHERE id=?')
            ->execute([$statut, gmdate('c'), $id]);
        $fichier = $image['fichier'];
        if ($decision === 'retirer') { @unlink($dossier . '/' . basename((string)$fichier)); }
        seve_api_json(['ok' => true, 'statut' => $statut]);
    }
    if ($route !== '/refuge/chat/image' || $admin) { seve_api_erreur('Envoi non autorisé.', 403); }
    $st = $db->prepare('SELECT age_verifie_le FROM femmes WHERE id=?');
    $st->execute([$femme]);
    if (!$st->fetchColumn()) { seve_api_erreur('Contrôle réel de majorité requis avant tout PNG.', 403); }
    if (($body['accord_envoi'] ?? '') !== 'oui' || ($body['droits_consentements'] ?? '') !== 'oui') {
        seve_api_erreur('Accord d’envoi et droits des personnes représentées requis à chaque PNG.', 400);
    }
    $st = $db->prepare("SELECT COUNT(*) FROM refuge_images WHERE femme_id=? AND statut='attente'");
    $st->execute([$femme]);
    if ((int)$st->fetchColumn() >= 3) { seve_api_erreur('Trois PNG déjà en attente de modération.', 429); }
    $st = $db->prepare('SELECT COUNT(*) FROM refuge_images WHERE femme_id=? AND cree_le>=?');
    $st->execute([$femme, gmdate('c', time()-86400)]);
    if ((int)$st->fetchColumn() >= 10) { seve_api_erreur('Limite de dix PNG par jour atteinte.', 429); }
    $f = $_FILES['image'] ?? null;
    if (!is_array($f) || ($f['error'] ?? 1) !== UPLOAD_ERR_OK || (int)($f['size'] ?? 0) > 4 * 1024 * 1024 ||
        (int)($f['size'] ?? 0) < 30 || !is_uploaded_file((string)($f['tmp_name'] ?? ''))) {
        seve_api_erreur('PNG absent ou trop volumineux (4 Mo maximum).', 400);
    }
    $info = @getimagesize((string)$f['tmp_name']);
    if (!$info || ($info[2] ?? 0) !== IMAGETYPE_PNG || $info[0] < 1 || $info[1] < 1 || $info[0] > 2048 || $info[1] > 2048) {
        seve_api_erreur('PNG invalide ou dimensions supérieures à 2048 px.', 400);
    }
    if (!function_exists('imagecreatefrompng')) { seve_api_erreur('Traitement PNG indisponible sur le serveur.', 503); }
    $image = @imagecreatefrompng((string)$f['tmp_name']);
    if (!$image) { seve_api_erreur('Image PNG illisible.', 400); }
    if (!is_dir($dossier) && !@mkdir($dossier, 0700, true)) { imagedestroy($image); seve_api_erreur('Stockage indisponible.', 503); }
    $id = bin2hex(random_bytes(16)); $nom = $id . '.png';
    $path = $dossier . '/' . $nom;
    $saved = imagepng($image, $path, 8); imagedestroy($image);
    if (!$saved) { seve_api_erreur('PNG non enregistré.', 503); }
    @chmod($path, 0600);
    try {
        $db->prepare('INSERT INTO refuge_images(id,femme_id,fichier,statut,consent_le,cree_le) VALUES(?,?,?,?,?,?)')
            ->execute([$id,$femme,$nom,'attente',gmdate('c'),gmdate('c')]);
    } catch (Throwable $e) { @unlink($path); seve_api_erreur('PNG non enregistré.', 503); }
    seve_api_json(['ok' => true, 'id' => $id, 'statut' => 'attente']);
}
