<?php
declare(strict_types=1);

/* Messagerie serveur en préparation. Pas de faux accusé humain : la réponse
   est insérée seulement par un vrai administrateur Sève authentifié. */
function seve_refuge_chat(string $route, string $method, array $body): void
{
    if (!seve_service_ouvert()) {
        seve_api_erreur('Messagerie fermée pendant la préparation du service. Aucun message transmis.', 503);
    }
    /* Tester la session Sève AVANT d'ouvrir la session séparée de la membre. */
    $admin = seve_api_admin_seve();
    if ($admin) {
        $csrf = (string) ($_SESSION['seve_mode_csrf'] ?? '');
        if ($csrf === '') { $_SESSION['seve_mode_csrf'] = $csrf = bin2hex(random_bytes(24)); }
    } else {
        if (!isset($_COOKIE[SEVE_SESSION]) && session_status() !== PHP_SESSION_ACTIVE) {
            seve_api_erreur('Connectez-vous avec un compte refuge serveur.', 401);
        }
        seve_session();
        $idSession = (string) ($_SESSION['refuge_femme'] ?? '');
        if (!preg_match('/^rf_[a-f0-9]{24}$/', $idSession)) { seve_api_erreur('Connexion requise.', 401); }
        $csrf = (string) ($_SESSION['refuge_csrf'] ?? '');
    }
    $db = seve_refuge_db();
    if ($route === '/refuge/chat/fils') {
        if (!$admin || $method !== 'GET') { seve_api_erreur('Réservé à l’administration Sève.', 403); }
        $rows = $db->query('SELECT f.id, f.nom, f.email, COUNT(m.id) AS messages, MAX(m.cree_le) AS dernier
            FROM femmes f JOIN refuge_messages m ON m.femme_id=f.id GROUP BY f.id
            ORDER BY dernier DESC LIMIT 100')->fetchAll(PDO::FETCH_ASSOC);
        seve_api_json(['ok' => true, 'fils' => $rows]);
    }
    $id = $admin ? (string) ($method === 'GET' ? ($_GET['id'] ?? '') : ($body['id'] ?? '')) : $idSession;
    if (!preg_match('/^rf_[a-f0-9]{24}$/', $id)) { seve_api_erreur('Conversation introuvable.', 404); }
    $st = $db->prepare('SELECT id FROM femmes WHERE id=?'); $st->execute([$id]);
    if (!$st->fetchColumn()) { seve_api_erreur('Conversation introuvable.', 404); }
    if ($method === 'GET') {
        $st = $db->prepare('SELECT id, auteur, texte, cree_le FROM refuge_messages WHERE femme_id=? ORDER BY id DESC LIMIT 100');
        $st->execute([$id]);
        seve_api_json(['ok' => true, 'messages' => array_reverse($st->fetchAll(PDO::FETCH_ASSOC))]);
    }
    if ($method !== 'POST') { seve_api_erreur('Méthode refusée.', 405); }
    seve_refuge_origine();
    $token = (string) ($body['csrf'] ?? '');
    if ($csrf === '' || $token === '' || !hash_equals($csrf, $token)) {
        seve_api_erreur('Session expirée. Rechargez la page.', 403);
    }
    $texte = trim((string) ($body['texte'] ?? ''));
    if ($texte === '' || strlen($texte) > 4000 || !preg_match('//u', $texte)) {
        seve_api_erreur('Écrivez un message de 1 à 4 000 caractères.', 400);
    }
    if (!$admin) {
        $st = $db->prepare("SELECT COUNT(*) FROM refuge_messages WHERE femme_id=? AND auteur='membre' AND cree_le>=?");
        $st->execute([$id, gmdate('c', time()-300)]);
        if ((int)$st->fetchColumn() >= 20) { seve_api_erreur('Trop de messages : patientez quelques minutes.', 429); }
    }
    $auteur = $admin ? 'equipe' : 'membre';
    $db->prepare('INSERT INTO refuge_messages(femme_id,auteur,texte,cree_le) VALUES(?,?,?,?)')
        ->execute([$id, $auteur, $texte, gmdate('c')]);
    seve_api_json(['ok' => true, 'message' => ['id' => (int)$db->lastInsertId(),
        'auteur' => $auteur, 'texte' => $texte, 'cree_le' => gmdate('c')]]);
}
