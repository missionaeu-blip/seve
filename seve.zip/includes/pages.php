<?php
declare(strict_types=1);

/* ==========================================================================
   SÈVE — table des pages, adresses lisibles et rendu
   Chargé par index.php et par chaque fichier de pages/.
   ========================================================================== */

/** Une page = une adresse lisible, une route de l'application, un fichier PHP. */
if (defined('SEVE_PAGES_CHARGE')) { return; }
define('SEVE_PAGES_CHARGE', 1);

function seve_pages(): array
{
    return [
        'accueil'              => ['route' => '/',              'titre' => 'Sève — Trouvez le bon partenaire pour développer votre activité'],
        'decouvrir'            => ['route' => '/discover',      'titre' => 'Découvrir — Sève'],
        'createurs'            => ['route' => '/creators',      'titre' => 'Créatrices et créateurs — Sève'],
        'managers'             => ['route' => '/managers',      'titre' => 'Managers et agences — Sève'],
        'profil'               => ['route' => '/discover',      'titre' => 'Fiche profil — Sève'],
        'avant-ouverture'      => ['route' => '/avant-ouverture', 'titre' => 'Service en préparation — Sève'],
        'inscription'          => ['route' => '/signup',        'titre' => 'Créer un compte — Sève'],
        'connexion'            => ['route' => '/login',         'titre' => 'Connexion — Sève'],
        'comment-ca-marche'    => ['route' => '/how-it-works',  'titre' => 'Comment ça marche — Sève'],
        'aide'                 => ['route' => '/matching-help', 'titre' => 'Aide au matching — Sève'],
        'litiges'              => ['route' => '/chargebacks',   'titre' => 'Remboursements et litiges — Sève'],
        'equipe'               => ['route' => '/app/team',      'titre' => 'Parler à l’équipe — Sève'],
        'tranquille'           => ['route' => '/app/care',      'titre' => 'Mon espace tranquille — Sève'],
        'tableau-de-bord'      => ['route' => '/app',           'titre' => 'Tableau de bord — Sève'],
        'messages'             => ['route' => '/app/messages',  'titre' => 'Messages — Sève'],
        'demandes'             => ['route' => '/app/requests',  'titre' => 'Demandes de collaboration — Sève'],
        'parametres'           => ['route' => '/app/settings',  'titre' => 'Paramètres — Sève'],
        'mon-compte'           => ['route' => '/app/of',        'titre' => 'Mon compte OnlyFans — Sève'],
        'paiements'            => ['route' => '/app/payouts',   'titre' => 'Paiements et RIB — Sève'],
        'conditions-generales' => ['route' => '/legal/terms',   'titre' => 'Conditions générales — Sève'],
        'confidentialite'      => ['route' => '/legal/privacy', 'titre' => 'Politique de confidentialité — Sève'],
        'regles'               => ['route' => '/legal/rules',   'titre' => 'Règles de la plateforme — Sève'],
        'cookies'              => ['route' => '/legal/cookies', 'titre' => 'Cookies et consentement — Sève'],
        'administration'       => ['route' => '/admin',         'titre' => 'Administration — Sève'],
    ];
}

function seve_page_def(string $id): ?array
{
    $pages = seve_pages();
    return isset($pages[$id]) ? array_merge($pages[$id], ['id' => $id]) : null;
}

/** Adresses lisibles acceptées : français, anglais, abréviations. */
function seve_alias(string $chemin): ?string
{
    $c = strtolower(trim($chemin, '/'));
    $c = (string) preg_replace('/\.php$/', '', $c);

    if (str_contains($c, '/')) {
        $parts = explode('/', $c);
        return ($parts[0] === 'profil' && isset($parts[1]) && preg_match('/^[a-z0-9_-]{1,40}$/', (string) $parts[1])) ? 'profil' : null;
    }

    $carte = [
        '' => 'accueil', 'index' => 'accueil', 'accueil' => 'accueil', 'home' => 'accueil',
        'decouvrir' => 'decouvrir', 'discover' => 'decouvrir', 'recherche' => 'decouvrir',
        'createurs' => 'createurs', 'creators' => 'createurs',
        'managers' => 'managers', 'agences' => 'managers',
        'inscription' => 'inscription', 'signup' => 'inscription', 'register' => 'avant-ouverture',
        'avant-ouverture' => 'avant-ouverture',
        'connexion' => 'connexion', 'login' => 'connexion',
        'comment-ca-marche' => 'comment-ca-marche', 'how-it-works' => 'comment-ca-marche',
        'aide' => 'aide', 'matching' => 'aide', 'matching-help' => 'aide',
        'litiges' => 'litiges', 'chargebacks' => 'litiges', 'chargeback' => 'litiges',
        'remboursements' => 'litiges', 'refunds' => 'litiges',
        'equipe' => 'equipe', 'team' => 'equipe', 'parler-a-l-equipe' => 'equipe',
        'tranquille' => 'tranquille', 'espace-tranquille' => 'tranquille', 'care' => 'tranquille',
        'tableau-de-bord' => 'tableau-de-bord', 'dashboard' => 'tableau-de-bord', 'app' => 'tableau-de-bord',
        'messages' => 'messages', 'messagerie' => 'messages',
        'demandes' => 'demandes', 'requests' => 'demandes',
        'parametres' => 'parametres', 'settings' => 'parametres',
        'mon-compte' => 'mon-compte', 'compte-of' => 'mon-compte', 'of' => 'mon-compte',
        'onlyfans' => 'mon-compte', 'publications' => 'mon-compte', 'tarifs' => 'mon-compte',
        'paiements' => 'paiements', 'rib' => 'paiements', 'payouts' => 'paiements',
        'mentions-legales' => 'conditions-generales', 'politique-confidentialite' => 'confidentialite',
        'financement' => 'comment-ca-marche', 'cgu' => 'conditions-generales', 'conditions-generales' => 'conditions-generales', 'terms' => 'conditions-generales',
        'confidentialite' => 'confidentialite', 'privacy' => 'confidentialite',
        'regles' => 'regles', 'rules' => 'regles',
        'cookies' => 'cookies',
        'administration' => 'administration', 'admin' => 'administration',
        'profil' => 'profil', 'profils' => 'profil', 'profile' => 'profil',
    ];
    return $carte[$c] ?? null;
}

/** Adresse lisible → route de l'application : « createurs » → « /creators ». */
function seve_route_pour(string $chemin): ?string
{
    $c = strtolower(trim($chemin, '/'));
    $c = (string) preg_replace('/\.php$/', '', $c);
    if (preg_match('#^profil/([a-z0-9_-]{1,40})$#', $c, $m)) { return '/profiles/' . $m[1]; }
    $id = seve_alias($chemin);
    if ($id === null) { return null; }
    $page = seve_page_def($id);
    return $page === null ? null : (string) $page['route'];
}

/* ------------------------------------------------------------------ rendu -- */

/**
 * Sert app.html (le squelette de l'application) en y ajoutant :
 *   - le titre de la page demandée,
 *   - <base href> : indispensable pour que les chemins assets/… restent justes
 *     aussi bien depuis /seve/ que depuis /seve/pages/createurs.php,
 *   - la route à ouvrir quand l'adresse appelée n'est pas l'accueil.
 */
function seve_render(array $page, array $options = []): never
{
    $fichier = SEVE_ROOT . '/app.html';

    if (!is_readable($fichier)) {
        http_response_code(500);
        echo '<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>Sève</title></head>'
            . '<body style="font-family:system-ui,sans-serif;padding:40px">'
            . '<h1>Installation incomplète</h1><p>Le fichier <code>app.html</code> est absent du dossier : '
            . 'il doit se trouver à côté de <code>index.php</code>.</p></body></html>';
        exit;
    }

    $html  = (string) file_get_contents($fichier);
    $base  = seve_base_path() . '/';
    $titre = (string) ($options['titre'] ?? $page['titre'] ?? seve_cfg('titre', 'Sève'));

    $html = (string) preg_replace('#<title>.*?</title>#s', '<title>' . page_h($titre) . '</title>', $html, 1);

    $entete = '<base href="' . page_h($base) . '">'
        . "\n" . '<link rel="manifest" href="' . page_h($base) . 'manifest.webmanifest">'
        . "\n" . '<meta name="theme-color" content="#1f5c3d">';

    if (preg_match('#<head>#i', $html)) {
        $html = (string) preg_replace('#<head>#i', '<head>' . "\n" . $entete, $html, 1);
    } else {
        $html = $entete . "\n" . $html;
    }

    $hash = (string) ($options['hash'] ?? '');
    if ($hash !== '' && $hash !== '/') {
        $html = str_replace('</head>',
            "\n" . '<script>/* page demandée */try{if(!location.hash){location.hash=' . json_encode($hash) . ';}}catch(e){}</script>' . "\n" . '</head>',
            $html);
    }

    echo $html;
    exit;
}

/* -------------------------------------------------------------- aiguillage -- */

/** Appelé par index.php pour toute adresse reçue. */
function render_php_page(string $path, string $method = 'GET', array $body = []): never
{
    seve_headers();
    seve_maintenance();
    seve_gate();

    $chemin = trim($path, '/');

    /* 1. accueil — servi à l'identique avec ou sans slash final (/seve,
       /seve/, /seve/index.php). Aucune redirection ici : c'est ce qui évite
       toute boucle quand une redirection ancienne dort dans le cache d'un
       navigateur ou d'un CDN. */
    if ($chemin === '' || $chemin === 'index.php' || $chemin === 'index') {
        seve_render((array) seve_page_def('accueil'));
    }

    /* 2. fiche d'un profil : /seve/profil/c9 */
    if (preg_match('#^profil/([A-Za-z0-9_-]{1,40})#', $chemin, $m)) {
        page_redirect(page_url('/profiles/' . $m[1]), 301);
    }

    /* 3. fichier de page appelé par son chemin : /seve/pages/createurs.php */
    if (preg_match('#^pages/([a-z0-9-]+)(?:\.php)?$#', $chemin, $m)) {
        $fichier = SEVE_ROOT . '/pages/' . $m[1] . '.php';
        if (is_readable($fichier)) { require $fichier; }
        http_response_code(404);
        seve_render((array) seve_page_def('accueil'), ['titre' => 'Page introuvable — Sève', 'hash' => '/' . $chemin]);
    }

    if (in_array($chemin, ['mentions-legales','politique-confidentialite','cgu','financement'], true)) {
        page_redirect(page_url('/' . $chemin), 302);
    }
    if ($chemin === 'register') { page_redirect(page_url('/avant-ouverture'), 302); }

    /* 4. adresse lisible → route de l'application */
    $route = seve_route_pour($chemin);
    if ($route !== null) { page_redirect(page_url($route), 301); }

    /* 5. adresse inconnue : page introuvable, rendue par l'application */
    http_response_code(404);
    seve_render((array) seve_page_def('accueil'), [
        'titre' => 'Page introuvable — Sève',
        'hash'  => '/' . $chemin,
    ]);
}

/** Appelé par un fichier de pages/ pour afficher une page précise. */
function seve_page(string $id): never
{
    seve_headers();
    seve_maintenance();
    seve_gate();

    $page = seve_page_def($id);
    if ($page === null) {
        http_response_code(404);
        seve_render((array) seve_page_def('accueil'), ['titre' => 'Page introuvable — Sève', 'hash' => '/introuvable']);
    }
    if ($id === 'profil') {
        $pid = isset($_GET['id']) ? (string) preg_replace('/[^A-Za-z0-9_-]/', '', (string) $_GET['id']) : '';
        page_redirect(page_url($pid !== '' ? '/profiles/' . substr($pid, 0, 40) : '/discover'), 301);
    }
    if ($id === 'accueil') { seve_render((array) $page); }
    page_redirect(page_url((string) $page['route']), 301);
}
