<?php
declare(strict_types=1);

/* ==========================================================================
   SÈVE — API JSON du compte OnlyFans (relevés saisis par la créatrice)
   --------------------------------------------------------------------------
   Appelée par l'application (mêmes origines) : /seve/api/…

       GET  api/sante                        → l'API répond-elle ?
       GET  api/etat?email=…&code=…           → le compte et ses relevés
       POST api/connexion                     → relier son compte (code à 6 chiffres)
       POST api/deconnexion                   → tout décrocher (les relevés restent)
       POST api/plan                          → enregistrer les tarifs
       POST api/publication                   → enregistrer une publication (locale)
       POST api/publication/supprimer         → retirer une publication
       POST api/releve                        → saisir les chiffres d'un jour
       POST api/import                        → coller un CSV de plusieurs jours

   Ce que cette API ne fait pas, et ne fera pas : se connecter à OnlyFans.
   OnlyFans n'expose pas d'API publique ; Sève ne demande donc aucun identifiant
   OnlyFans, ne stocke aucun mot de passe et n'a recours à aucun procédé
   détourné. Les chiffres viennent de ce que la créatrice saisit ou importe.
   ========================================================================== */

require_once __DIR__ . '/donnees.php';
require_once __DIR__ . '/refuge-auth.php';
require_once __DIR__ . '/refuge-chat.php';
require_once __DIR__ . '/refuge-images.php';
require_once __DIR__ . '/admin-local.php';

/** Réponse JSON puis arrêt. */
function seve_api_json(array $donnees, int $code = 200): void
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header("Content-Security-Policy: default-src 'none'; frame-ancestors 'self'");
    echo json_encode($donnees, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function seve_api_erreur(string $message, int $code = 400): void
{
    seve_api_json(['ok' => false, 'erreur' => $message], $code);
}

/** Corps de la requête : JSON accepté, formulaire classique aussi. */
function seve_api_corps(): array
{
    $type = (string) ($_SERVER['CONTENT_TYPE'] ?? '');
    if (stripos($type, 'application/json') !== false) {
        $brut = file_get_contents('php://input') ?: '';
        if (strlen($brut) > 512000) { seve_api_erreur('Envoi trop volumineux (512 Ko maximum).', 413); }
        $data = json_decode($brut, true);
        return is_array($data) ? $data : [];
    }
    return array_merge($_GET, $_POST);
}

/** Ce que l'application peut voir : jamais l'empreinte du code, jamais le journal. */
function seve_api_etat_public(array $etat): array
{
    unset($etat['code_hash'], $etat['journal']);
    /* Un tableau vide se sérialise en « [] » alors que l'application attend un
       objet pour les tarifs : on le renvoie explicitement comme objet vide. */
    if (!isset($etat['plan']) || !is_array($etat['plan']) || !$etat['plan']) {
        $etat['plan'] = new \stdClass();
    }
    return $etat;
}

/**
 * Vérifie l'adresse et le code. Le premier code fourni devient celui du compte.
 * Renvoie [email, etat] ou arrête la requête.
 */
function seve_api_identite(array $corps, bool $creation = false): array
{
    $email = strtolower(trim((string) ($corps['email'] ?? '')));
    $code  = trim((string) ($corps['code'] ?? ''));
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        seve_api_erreur('Adresse du compte manquante ou invalide.', 400);
    }
    $etat = seve_lire($email);

    if (!preg_match('/^\d{4,8}$/', $code)) {
        seve_api_erreur('Code de relevé manquant : il compte de 4 à 8 chiffres.', 401);
    }
    if (!$creation && ($etat['code_hash'] ?? '') !== '' && !seve_code_valide($etat, $code)) {
        seve_api_erreur('Code incorrect.', 401);
    }
    return [$email, $etat, $code];
}

/** Les écritures exigent un compte relié : sinon on ne sait pas à qui on écrit. */
function seve_api_compte_lie(array $etat): void
{
    if (empty($etat['connected'])) {
        seve_api_erreur('Compte non relié : relie ton compte OnlyFans avant de saisir des chiffres.', 409);
    }
}

/**
 * Mêmes règles d'accès que le site : si l'accès est protégé par mot de passe
 * (protection => true dans config.php) ou en maintenance, l'API ne répond pas
 * aux visiteurs qui n'ont pas franchi la porte. Sans cela, la protection du
 * site serait contournable par /api/…
 */
function seve_api_ouvrir(): void
{
    if (seve_cfg('maintenance', false)) {
        seve_api_erreur('Le site est momentanément indisponible.', 503);
    }
    if (!seve_cfg('protection', false)) { return; }
    seve_session();
    if (empty($_SESSION['seve_ok'])) {
        seve_api_erreur('Site protégé : entre d’abord le mot de passe du site.', 403);
    }
}

/** Aiguillage. */
function seve_api_repondre(string $path, string $method, array $corps): void
{
    seve_api_ouvrir();

    $route = '/' . trim(preg_replace('#^/api#', '', $path), '/');
    $route = preg_replace('#/+$#', '', $route) ?: '/';
    $route = str_replace('relevés', 'releves', $route);

    if ($route === '/statut' && $method === 'GET') {
        seve_api_json(['ok' => true, 'ouvert' => (bool) seve_service_ouvert(),
            'profils_reels' => false, 'messagerie_equipe' => (bool) seve_service_ouvert()]);
    }
    if (str_starts_with($route, '/admin/')) { seve_admin_local_api($route, $method, $corps); }
    if (str_starts_with($route, '/refuge/')) { seve_refuge_auth($route, $method, $corps); }

    /* Mode global : GET public, POST réservé à la session admin Missiona.
       Un jeton CSRF lié à cette session est exigé pour la mutation. */
    if ($route === '/mode' && $method === 'GET') {
        $fichier = seve_dossier_donnees() . '/mode.json';
        $mode = is_file($fichier) ? json_decode((string) file_get_contents($fichier), true) : [];
        $admin = seve_api_admin_seve();
        if ($admin && empty($_SESSION['seve_mode_csrf'])) {
            $_SESSION['seve_mode_csrf'] = bin2hex(random_bytes(24));
        }
        seve_api_json(['ok' => true, 'ouvert' => (bool)seve_service_ouvert(), 'refuge' => !empty($mode['refuge']),
            'admin_seve' => $admin, 'csrf' => $admin ? $_SESSION['seve_mode_csrf'] : null]);
    }
    if ($route === '/mode' && $method === 'POST') {
        if (!seve_api_admin_seve()) { seve_api_erreur('Connectez-vous comme administrateur Sève.', 403); }
        $jeton = (string) ($corps['csrf'] ?? '');
        if ($jeton === '' || empty($_SESSION['seve_mode_csrf']) ||
            !hash_equals((string) $_SESSION['seve_mode_csrf'], $jeton)) {
            seve_api_erreur('Session expirée. Rechargez Sève et réessayez.', 403);
        }
        /* Refuse une écriture issue d'un autre site. La vérification du jeton
           reste impérative (Origin peut être absent dans certains navigateurs). */
        $origine = (string) ($_SERVER['HTTP_ORIGIN'] ?? '');
        $hote = (string) ($_SERVER['HTTP_HOST'] ?? '');
        if ($origine !== '' && $hote !== '' && !hash_equals($origine, (seve_is_https() ? 'https://' : 'http://') . $hote)) {
            seve_api_erreur('Origine de la requête refusée.', 403);
        }
        if (!isset($corps['refuge']) || !is_bool($corps['refuge'])) {
            seve_api_erreur('Choisissez le mode à appliquer.', 400);
        }
        $dossier = seve_dossier_donnees();
        $fichier = $dossier . '/mode.json';
        $verrou = fopen($dossier . '/mode.lock', 'c');
        if (!$verrou || !flock($verrou, LOCK_EX)) { seve_api_erreur('Réglage temporairement indisponible.', 503); }
        $temp = tempnam($dossier, '.mode-');
        if (!$temp) { flock($verrou, LOCK_UN); fclose($verrou); seve_api_erreur('Dossier non accessible.', 503); }
        $ecrit = file_put_contents($temp, json_encode(['refuge' => $corps['refuge'], 'maj' => gmdate('c')])) !== false
            && rename($temp, $fichier);
        if (file_exists($temp)) { unlink($temp); }
        flock($verrou, LOCK_UN); fclose($verrou);
        if (!$ecrit) { seve_api_erreur('Mode non enregistré.', 503); }
        seve_api_json(['ok' => true, 'refuge' => $corps['refuge']]);
    }

    if (!seve_service_ouvert() && $route !== '/sante') {
        seve_api_erreur('Service en préparation : dépôt et transmission de données suspendus.', 503);
    }

    /* --- Santé : sert aussi à l'application pour savoir si l'API est là ----- */
    if ($route === '/sante') {
        seve_api_json([
            'ok' => true,
            'version' => 1,
            'stockage' => 'fichiers',
            'dossier_ecriture' => is_writable(seve_dossier_donnees()),
            /* Dépôt par e-mail : la boîte que Sève relève elle-même, si l'hébergeur
               est configuré pour (voir INSTALLATION-HOSTINGER.md). */
            'depot_mail' => (string) seve_cfg('depot_mail', ''),
            'depot_pret' => ((string) seve_cfg('depot_imap_hote', '') !== ''),
            'date' => gmdate('c')
        ]);
    }

    /* --------------------------------- Lire -------------------------------- */
    if ($route === '/etat' && $method === 'GET') {
        $corps['email'] = $_GET['email'] ?? '';
        $corps['code']  = $_GET['code'] ?? '';
        [$email, $etat] = seve_api_identite($corps);
        /* Un compte jamais utilisé, ou un code erroné : on ne dit rien de plus. */
        if (($etat['code_hash'] ?? '') === '' && !$etat['connected']) {
            seve_api_json(['ok' => true, 'etat' => null]);
        }
        seve_api_json(['ok' => true, 'etat' => seve_api_etat_public($etat)]);
    }

    if ($method !== 'POST') { seve_api_erreur('Méthode non autorisée.', 405); }

    /* ------------------------------- Relier -------------------------------- */
    if ($route === '/connexion') {
        [$email, $etat, $code] = seve_api_identite($corps, true);
        $pseudo = trim((string) ($corps['username'] ?? ''));
        if ($pseudo === '') { seve_api_erreur('Identifiant OnlyFans manquant.', 400); }
        $pseudo = ltrim(preg_replace('/[^A-Za-z0-9._-]/', '', $pseudo), '@');

        if (($etat['code_hash'] ?? '') === '') {
            $etat['code_hash'] = password_hash($code, PASSWORD_DEFAULT);
        }
        $etat['connected']  = true;
        $etat['username']   = $pseudo;
        $etat['connectedAt'] = gmdate('c');
        if (!is_object($etat['plan'] ?? null) && empty($etat['plan'])) { $etat['plan'] = new \stdClass(); }
        seve_journal($etat, 'connexion', 'compte relié pour le relevé');
        seve_ecrire($email, $etat) || seve_api_erreur('Le serveur n’a pas pu enregistrer (dossier data/ non accessible en écriture).', 500);
        seve_api_json(['ok' => true, 'etat' => seve_api_etat_public($etat)]);
    }

    /* ----------------------------- Décrocher ------------------------------- */
    if ($route === '/deconnexion') {
        [$email, $etat] = seve_api_identite($corps);
        $etat['connected'] = false;
        $etat['username'] = '';
        seve_journal($etat, 'deconnexion');
        seve_ecrire($email, $etat) || seve_api_erreur('Écriture impossible.', 500);
        seve_api_json(['ok' => true, 'etat' => seve_api_etat_public($etat)]);
    }

    /* ------------------------------- Tarifs -------------------------------- */
    if ($route === '/plan') {
        [$email, $etat] = seve_api_identite($corps);
        seve_api_compte_lie($etat);
        $plan = $corps['plan'] ?? [];
        if (!is_array($plan)) { seve_api_erreur('Tarifs illisibles.', 400); }
        $bornes = ['monthly' => [3, 49], 'ppv' => [3, 200], 'custom' => [10, 500], 'tip' => [1, 100], 'promo' => [0, 70], 'promoMonths' => [1, 12], 'bundle3' => [5, 150]];
        $propre = [];
        foreach ($bornes as $cle => $b) {
            if (!array_key_exists($cle, $plan)) { continue; }
            $v = seve_montant($plan[$cle]);
            $propre[$cle] = min($b[1], max($b[0], $v));
        }
        if (array_key_exists('welcomeOffer', $plan)) { $propre['welcomeOffer'] = (bool) $plan['welcomeOffer']; }
        if (array_key_exists('freeTrialDays', $plan)) { $propre['freeTrialDays'] = min(30, seve_nombre($plan['freeTrialDays'])); }
        $etat['plan'] = array_merge($etat['plan'] ?? [], $propre);
        seve_journal($etat, 'plan', json_encode($propre, JSON_UNESCAPED_UNICODE));
        seve_ecrire($email, $etat) || seve_api_erreur('Écriture impossible.', 500);
        seve_api_json(['ok' => true, 'plan' => $etat['plan']]);
    }

    /* ---------------------------- Publications ----------------------------- */
    if ($route === '/publication') {
        [$email, $etat] = seve_api_identite($corps);
        seve_api_compte_lie($etat);
        $legende = seve_tronquer(trim((string) ($corps['caption'] ?? '')), 600);
        $vis = in_array(($corps['visibility'] ?? ''), ['abonnes', 'ppv', 'custom', 'gratuit', 'brouillon'], true) ? $corps['visibility'] : 'abonnes';
        $pub = [
            'id'        => 'srv' . bin2hex(random_bytes(5)),
            'at'        => gmdate('c'),
            'caption'   => $legende,
            'visibility' => $vis,
            'price'     => seve_montant($corps['price'] ?? 0),
            'type'      => 'photo',
            'vues' => 0, 'likes' => 0, 'commentaires' => 0, 'revenus' => 0,
            'local' => true,
            'statut'    => $vis === 'brouillon' ? 'brouillon' : 'publie'
        ];
        $etat['posts'] = array_slice(array_merge([$pub], $etat['posts'] ?? []), 0, 200);
        seve_journal($etat, 'publication', $legende);
        seve_ecrire($email, $etat) || seve_api_erreur('Écriture impossible.', 500);
        seve_api_json(['ok' => true, 'publication' => $pub, 'total' => count($etat['posts'])]);
    }

    if ($route === '/publication/supprimer') {
        [$email, $etat] = seve_api_identite($corps);
        seve_api_compte_lie($etat);
        $id = (string) ($corps['id'] ?? '');
        $avant = count($etat['posts'] ?? []);
        $etat['posts'] = array_values(array_filter($etat['posts'] ?? [], fn($p) => ($p['id'] ?? '') !== $id));
        seve_ecrire($email, $etat) || seve_api_erreur('Écriture impossible.', 500);
        seve_api_json(['ok' => true, 'supprimee' => count($etat['posts']) < $avant, 'total' => count($etat['posts'])]);
    }

    /* ------------------------------- Relevés ------------------------------- */
    if ($route === '/releve') {
        [$email, $etat] = seve_api_identite($corps);
        seve_api_compte_lie($etat);
        $releve = seve_releve_normalise($corps);
        if (!$releve) { seve_api_erreur('Date du relevé illisible (attendu : AAAA-MM-JJ).', 400); }
        seve_enregistrer_releve($etat, $releve);
        seve_journal($etat, 'releve', $releve['jour']);
        seve_ecrire($email, $etat) || seve_api_erreur('Écriture impossible.', 500);
        seve_api_json(['ok' => true, 'releve' => $releve, 'total' => count($etat['releves'])]);
    }

    /* ------------------------- Dépôt automatique ---------------------------
       Un envoi automatique (relevé de boîte e-mail, outil choisi par la
       créatrice, dépôt de fichier) n'a pas son code : il présente la clé de
       dépôt de son compte. La clé n'ouvre que l'écriture de relevés, jamais la
       lecture de quoi que ce soit. */
    if ($route === '/depot/cle') {
        [$email, $etat] = seve_api_identite($corps);
        $cle = seve_cle_depot_neuve();
        $etat['cle_depot_hash'] = password_hash($cle, PASSWORD_DEFAULT);
        $etat['cle_depot_fin'] = substr($cle, -4);
        $etat['cle_depot_le'] = gmdate('c');
        seve_journal($etat, 'cle-depot', 'nouvelle clé');
        seve_ecrire($email, $etat) || seve_api_erreur('Écriture impossible.', 500);
        /* La clé n'est montrée qu'une fois : elle est vérifiée par empreinte. */
        seve_api_json(['ok' => true, 'cle' => $cle, 'fin' => $etat['cle_depot_fin']]);
    }

    if ($route === '/depot') {
        $email = strtolower(trim((string) ($corps['email'] ?? '')));
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            seve_api_erreur('Adresse du compte manquante ou invalide.', 400);
        }
        $etat = seve_lire($email);
        /* Deux façons de déposer, selon qui dépose :
           · la créatrice elle-même, depuis son espace : son code suffit ;
           · un envoi automatique (outil extérieur) : la clé de dépôt, qui
             n'ouvre que l'écriture de relevés. */
        if (trim((string) ($corps['cle'] ?? '')) !== '') {
            if (!seve_cle_depot_valide($etat, (string) $corps['cle'])) {
                seve_api_erreur('Clé de dépôt refusée.', 401);
            }
        } else {
            [$email, $etat] = seve_api_identite($corps);
        }
        seve_api_compte_lie($etat);
        $texte = (string) ($corps['texte'] ?? $corps['csv'] ?? '');
        if (trim($texte) === '') { seve_api_erreur('Dépôt vide : rien à lire.', 400); }
        $source = in_array(($corps['source'] ?? ''), ['fichier', 'mail', 'outil'], true) ? (string) $corps['source'] : 'fichier';
        /* Une lettre complète porte ses propres en-têtes : c'est de là que
           vient le jour du relevé, jamais du jour de réception. Un export
           déposé, lui, porte une ligne par jour. */
        $estLettre = (bool) preg_match('#^(From|Date|Subject|MIME-Version|Content-Type):#mi', $texte);
        $lignes = $estLettre
            ? seve_lettre_en_releves($texte, $source)
            : seve_texte_en_releves($texte, (string) ($corps['jour'] ?? ''), $source);
        if (!$lignes) {
            seve_journal($etat, 'depot-vide', 'aucun chiffre lisible');
            seve_ecrire($email, $etat);
            seve_api_erreur('Aucun chiffre lisible dans ce dépôt : rien n’a été enregistré.', 400);
        }
        foreach ($lignes as $l) { seve_enregistrer_releve($etat, $l); }
        seve_journal($etat, 'depot-' . $source, count($lignes) . ' jour(s)');
        seve_ecrire($email, $etat) || seve_api_erreur('Écriture impossible.', 500);
        seve_api_json([
            'ok' => true, 'source' => $source, 'jours' => count($lignes),
            'total' => count($etat['releves'] ?? []),
            'le' => $etat['releveLe'] ?? null
        ]);
    }

    if ($route === '/import') {
        [$email, $etat] = seve_api_identite($corps);
        seve_api_compte_lie($etat);
        $csv = (string) ($corps['csv'] ?? '');
        if (trim($csv) === '') { seve_api_erreur('Aucune ligne à importer.', 400); }
        $lignes = seve_decouper_csv($csv);
        if (!$lignes) { seve_api_erreur('Aucune date reconnue. Format attendu : 2026-10-16;88000;412,50;41800;7320', 400); }
        foreach ($lignes as $l) { seve_enregistrer_releve($etat, $l); }
        seve_journal($etat, 'import', count($lignes) . ' jour(s)');
        seve_ecrire($email, $etat) || seve_api_erreur('Écriture impossible.', 500);
        seve_api_json(['ok' => true, 'jours' => count($lignes), 'total' => count($etat['releves'])]);
    }

    seve_api_erreur('Route inconnue : ' . $route, 404);
}
