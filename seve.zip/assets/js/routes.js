/* ==========================================================================
   Sève — table de routage
   --------------------------------------------------------------------------
   shell : public | auth | app | bare
   role  : rôle requis (aucun = public)
   nav   : clé de menu à surligner dans la coquille connectée
   ========================================================================== */
(function () {
  const R = SEVE.router;
  const V = SEVE.views;

  /* ----------------------------- Public ----------------------------- */
  R.add('/', 'home', { title: 'Trouvez le bon partenaire' });
  R.add('/discover', 'discover', { title: 'Découvrir' });
  R.add('/creators', 'creators', { title: 'Créateurs' });
  R.add('/managers', 'managers', { title: 'Managers & agences' });
  R.add('/how-it-works', 'how-it-works', { title: 'Comment ça marche' });
  R.add('/matching-help', 'matching-help', { title: 'Aide au matching' });
  R.add('/chargebacks', 'chargebacks', { shell: 'public', title: 'Remboursements & litiges' });
  R.add('/profiles/:id', 'profile', { title: 'Profil' });

  /* Adresses d'appui : celles qui circulent dans les liens du site, dans les
     favoris ou dans les messages de l'équipe. Elles doivent ouvrir une vraie
     page, jamais la page introuvable. */
  R.add('/chez-vous', 'chez-vous', { title: 'Chez vous' });
  R.add('/care', 'chez-vous', { title: 'Chez vous' });
  R.add('/help', 'matching-help', { title: 'Besoin d’aide ?' });
  R.add('/aide', 'matching-help', { title: 'Besoin d’aide ?' });
  R.add('/about', 'how-it-works', { title: 'À propos' });
  R.add('/a-propos', 'how-it-works', { title: 'À propos' });
  R.add('/legal/:doc', 'legal', { title: 'Informations légales' });

  /* --------------------------- Authentification --------------------- */
  R.add('/avant-ouverture', 'avantOuverture', { title: 'Service en préparation' });
  R.add('/register', 'avantOuverture', { title: 'Inscription suspendue' });
  R.add('/mentions-legales', 'legal', { title: 'Mentions légales' });
  R.add('/politique-confidentialite', 'legal', { title: 'Confidentialité' });
  R.add('/cgu', 'legal', { title: 'CGU' });
  R.add('/financement', 'legal', { title: 'Financement' });
  R.add('/login', 'login', { shell: 'auth', title: 'Connexion' });
  R.add('/signup', 'signup', { shell: 'auth', title: 'Inscription' });

  /* ------------------------------ Espace ---------------------------- */
  R.add('/app', 'dashboard', { shell: 'app', role: ['creator', 'manager'], nav: 'dashboard', title: 'Tableau de bord' });
  R.add('/app/discover', 'appDiscover', { shell: 'app', role: ['creator', 'manager'], nav: 'discover', title: 'Rechercher' });
  R.add('/app/matching', 'matching', { shell: 'app', role: ['creator', 'manager'], nav: 'matching', title: 'Recommandations' });
  R.add('/app/requests', 'requests', { shell: 'app', role: ['creator', 'manager'], nav: 'requests', title: 'Mes demandes' });
  R.add('/app/messages', 'messages', { shell: 'app', role: ['creator', 'manager'], nav: 'messages', title: 'Messages' });
  R.add('/app/messages/:id', 'messages', { shell: 'app', role: ['creator', 'manager'], nav: 'messages', title: 'Messages' });
  R.add('/app/of', 'ofAccount', { shell: 'app', role: ['creator'], nav: 'of', title: 'Mon compte OnlyFans' });
  R.add('/app/of/publications', 'ofPosts', { shell: 'app', role: ['creator'], nav: 'of', title: 'Publications OnlyFans' });
  R.add('/app/of/tarifs', 'ofPricing', { shell: 'app', role: ['creator'], nav: 'of', title: 'Tarifs OnlyFans' });
  R.add('/app/profile', 'appProfile', { shell: 'app', role: ['creator', 'manager'], nav: 'profile', title: 'Mon profil' });
  R.add('/app/settings', 'settings', { shell: 'app', role: ['creator', 'manager'], nav: 'settings', title: 'Paramètres' });
  R.add('/app/roster', 'roster', { shell: 'app', role: ['manager'], nav: 'roster', title: 'Mes créateurs' });
  R.add('/app/payouts', 'payouts', { shell: 'app', role: ['creator', 'manager'], nav: 'payouts', title: 'Coordonnées de paiement' });
  R.add('/app/disputes', 'disputes', { shell: 'app', role: ['creator', 'manager'], nav: 'disputes', title: 'Litiges & remboursements' });
  R.add('/app/team', 'teamHelp', { shell: 'app', role: ['creator', 'manager'], nav: 'team', title: 'Parler à l’équipe' });
  R.add('/app/care', 'care', { shell: 'app', role: ['creator', 'manager'], nav: 'care', title: 'Mon coin bien-être' });
  R.add('/app/help', 'appHelp', { shell: 'app', role: ['creator', 'manager'], nav: 'help', title: 'Besoin d’aide ?' });

  /* -------------------------- Administration ------------------------ */
  R.add('/admin/connexion', 'adminConnexion', { shell: 'auth', title: 'Connexion admin Sève' });
  R.add('/admin/images', 'adminImages', { shell: 'app', role: 'admin', nav: 'helpdesk', title: 'Images à modérer' });
  R.add('/admin/majorite', 'adminMajorite', { shell: 'app', role: 'admin', nav: 'users', title: 'Contrôle de majorité' });
  R.add('/admin/refuge', 'adminRefuge', { shell: 'app', role: 'admin', nav: 'helpdesk', title: 'Conversations refuge' });
  R.add('/admin', 'adminDashboard', { shell: 'app', role: 'admin', nav: 'dashboard', title: 'Administration' });
  R.add('/admin/users', 'adminUsers', { shell: 'app', role: 'admin', nav: 'users', title: 'Utilisateurs' });
  R.add('/admin/creators', 'adminCreators', { shell: 'app', role: 'admin', nav: 'creators', title: 'Créateurs' });
  R.add('/admin/managers', 'adminManagers', { shell: 'app', role: 'admin', nav: 'managers', title: 'Managers' });
  R.add('/admin/requests', 'adminRequests', { shell: 'app', role: 'admin', nav: 'requests', title: 'Demandes' });
  R.add('/admin/reports', 'adminReports', { shell: 'app', role: 'admin', nav: 'reports', title: 'Signalements' });
  R.add('/admin/messages', 'adminMessages', { shell: 'app', role: 'admin', nav: 'messages', title: 'Messages signalés' });
  R.add('/admin/profiles', 'adminProfiles', { shell: 'app', role: 'admin', nav: 'profiles', title: 'Gestion des profils' });
  R.add('/admin/payouts', 'adminPayouts', { shell: 'app', role: 'admin', nav: 'payouts', title: 'Coordonnées de paiement' });
  R.add('/admin/disputes', 'adminDisputes', { shell: 'app', role: 'admin', nav: 'disputes', title: 'Litiges & vagues' });
  R.add('/admin/help', 'adminHelp', { shell: 'app', role: 'admin', nav: 'helpdesk', title: 'Messages à l’équipe' });
  R.add('/admin/applications', 'adminApplications', { shell: 'app', role: 'admin', nav: 'applications', title: 'Accompagnement' });
  R.add('/admin/stats', 'adminStats', { shell: 'app', role: 'admin', nav: 'stats', title: 'Statistiques' });

  /* Action globale : recherche depuis le panneau d’accueil ------------- */
  SEVE.act('quick-search', function () {
    const q = document.getElementById('q');
    const type = document.getElementById('hf-type');
    const region = document.getElementById('hf-region');
    const spec = document.getElementById('hf-spec');
    const av = document.getElementById('hf-av');
    const values = {
      q: q ? q.value : '',
      type: type && type.value !== 'all' ? type.value : '',
      region: region && region.value !== 'all' ? region.value : '',
      specialty: spec && spec.value !== 'all' ? spec.value : '',
      availability: av && av.value !== 'all' ? av.value : ''
    };
    SEVE.router.navigate('/discover' + SEVE.util.query(values));
  });
})();
