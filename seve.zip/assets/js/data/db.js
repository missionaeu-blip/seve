/* ==========================================================================
   Sève — couche de données (démonstration)
   --------------------------------------------------------------------------
   Toutes les données sont fictives et vivent dans un seul module (SEVE.db).
   La même API (SEVE.store) sera branchée sur une vraie base de données :
   remplacez les lectures/écritures ci-dessous par des appels API sans
   toucher aux vues.
   ========================================================================== */
SEVE.taxo = {
  SPECIALTIES: [
    { id: 'chatting', label: 'Chatting & vente', group: 'Monétisation' },
    { id: 'ppv', label: 'Campagnes PPV / mass DM', group: 'Monétisation' },
    { id: 'pricing', label: 'Stratégie de prix & abonnements', group: 'Monétisation' },
    { id: 'fanvue', label: 'Fanvue & newsletters', group: 'Monétisation' },
    { id: 'content_photo', label: 'Direction photo', group: 'Contenu' },
    { id: 'content_video', label: 'Production vidéo', group: 'Contenu' },
    { id: 'lives', label: 'Lives & streams', group: 'Contenu' },
    { id: 'customs', label: 'Contenus sur-mesure', group: 'Contenu' },
    { id: 'branding', label: 'Persona & branding', group: 'Contenu' },
    { id: 'growth_ig', label: 'Croissance Instagram', group: 'Croissance' },
    { id: 'growth_tt', label: 'Croissance TikTok', group: 'Croissance' },
    { id: 'growth_x', label: 'Croissance X / Twitter', group: 'Croissance' },
    { id: 'reddit', label: 'Communautés & Reddit', group: 'Croissance' },
    { id: 'media_buying', label: 'Acquisition payante', group: 'Croissance' },
    { id: 'collabs', label: 'Collabs & shoutouts', group: 'Croissance' },
    { id: 'planning', label: 'Programmation & planning', group: 'Opérations' },
    { id: 'moderation', label: 'Modération de communauté', group: 'Opérations' },
    { id: 'analytics', label: 'Analytics & reporting', group: 'Opérations' },
    { id: 'legal', label: 'Administration & conformité', group: 'Opérations' }
  ],
  EXPERIENCE: [
    { id: 'e1', label: 'Débutant (moins d’1 an)', years: 0.5, rank: 1 },
    { id: 'e2', label: '1 – 2 ans', years: 1.5, rank: 2 },
    { id: 'e3', label: '2 – 4 ans', years: 3, rank: 3 },
    { id: 'e4', label: '4 – 6 ans', years: 5, rank: 4 },
    { id: 'e5', label: '6 ans et plus', years: 7, rank: 5 }
  ],
  NETWORK: [
    { id: 'n1', label: 'Moins de 5 k abonnés', avg: 3000, rank: 1 },
    { id: 'n2', label: '5 k – 20 k abonnés', avg: 12000, rank: 2 },
    { id: 'n3', label: '20 k – 100 k abonnés', avg: 60000, rank: 3 },
    { id: 'n4', label: '100 k – 500 k abonnés', avg: 280000, rank: 4 },
    { id: 'n5', label: '500 k abonnés et plus', avg: 800000, rank: 5 }
  ],
  TEAMSIZE: [
    { id: 't1', label: 'Solo', avg: 1, rank: 1 },
    { id: 't2', label: '2 – 5 personnes', avg: 3, rank: 2 },
    { id: 't3', label: '6 – 15 personnes', avg: 10, rank: 3 },
    { id: 't4', label: '16 – 40 personnes', avg: 26, rank: 4 },
    { id: 't5', label: 'Plus de 40 personnes', avg: 55, rank: 5 }
  ],
  AVAILABILITY: [
    { id: 'active', label: 'Disponible', rank: 4, tone: 'ok' },
    { id: 'open', label: 'Ouvert aux propositions', rank: 3, tone: 'ok' },
    { id: 'busy', label: 'Peu disponible', rank: 2, tone: 'warn' },
    { id: 'booked', label: 'Complet', rank: 1, tone: 'info' }
  ],
  MANAGER_KINDS: ['Manager indépendant', 'Agence de management', 'Équipe de chatting', 'Studio de production'],
  REGIONS: ['Europe', 'Amérique du Nord', 'Amérique latine', 'Moyen-Orient', 'Afrique', 'Asie-Pacifique', 'Océanie'],
  GOALS_CREATOR: [
    'Stabiliser mes revenus', 'Doubler mon chiffre mensuel', 'Structurer mon planning de publication',
    'Déléguer le chatting', 'Ouvrir un nouveau marché', 'Lancer une seconde plateforme',
    'Sortir du tout-DM et poser un persona', 'Passer à un rythme soutenable'
  ],
  GOALS_MANAGER: [
    'Lancer une nouvelle créatrice / un nouveau créateur', 'Structurer un compte en croissance',
    'Scaler un compte établi', 'Recruter pour notre équipe chatting',
    'Développer une offre premium', 'Tisser une relation long terme'
  ],
  COLLAB: [
    { id: 'split', label: 'Split sur commissions' },
    { id: 'retainer', label: 'Retainer + commission' },
    { id: 'flat', label: 'Facturation mensuelle' },
    { id: 'mission', label: 'Mission ponctuelle' },
    { id: 'exclu', label: 'Contrat d’exclusivité' }
  ],
  PLATFORMS: [
    { id: 'onlyfans', label: 'OnlyFans' },
    { id: 'fanvue', label: 'Fanvue' },
    { id: 'fansly', label: 'Fansly' },
    { id: 'patreon', label: 'Patreon' },
    { id: 'instagram', label: 'Instagram' },
    { id: 'tiktok', label: 'TikTok' },
    { id: 'x', label: 'X / Twitter' },
    { id: 'reddit', label: 'Reddit' }
  ],
  LANGUAGES: ['Français', 'Anglais', 'Espagnol', 'Portugais', 'Italien', 'Allemand', 'Néerlandais', 'Arabe', 'Russe', 'Ukrainien', 'Polonais', 'Turc'],
  AVAILABILITY_FILTERS: [
    { id: 'all', label: 'Toutes disponibilités' },
    { id: 'active', label: 'Disponible maintenant' },
    { id: 'open', label: 'Ouvert aux propositions' },
    { id: 'busy', label: 'Peu disponible' },
    { id: 'booked', label: 'Complet / en pause' }
  ]
};

SEVE.taxo.DISPUTE_TYPES = [
  { id: 'abo', label: 'Abonnement', hint: 'Rejet d’un abonnement (renouvellement inclus).' },
  { id: 'ppv', label: 'Contenu PPV', hint: 'Contenu payant débloqué puis contesté.' },
  { id: 'custom', label: 'Contenu sur-mesure', hint: 'Commande personnalisée livrée puis contestée.' },
  { id: 'session', label: 'Session / live', hint: 'Session privée ou live payant contesté.' },
  { id: 'pourboire', label: 'Pourboire', hint: 'Tip contesté a posteriori.' }
];
SEVE.taxo.DISPUTE_STATUS = [
  { id: 'nouveau', label: 'À documenter', variant: 'pending', hint: 'Litige enregistré, preuves à réunir.' },
  { id: 'conteste', label: 'Contesté', variant: 'info', hint: 'Dossier transmis au support / à la banque.' },
  { id: 'recupere', label: 'Récupéré', variant: 'accepted', hint: 'Chargeback annulé en faveur de la créatrice.' },
  { id: 'perdu', label: 'Perdu', variant: 'declined', hint: 'La banque a maintenu le remboursement.' }
];
SEVE.taxo.DISPUTE_CHANNELS = [
  { id: 'direct', label: 'Arrivée directe' },
  { id: 'reddit', label: 'Reddit' },
  { id: 'dm', label: 'Message privé (X / Instagram)' },
  { id: 'tiktok', label: 'TikTok' },
  { id: 'twitter', label: 'X / Twitter' },
  { id: 'autre', label: 'Autre canal' }
];
/* Signaux de risque : des faits observables dans la conversation ou la commande,
   jamais des données bancaires. Chaque signal est expliqué en une phrase. */
SEVE.taxo.DISPUTE_SIGNALS = [
  { id: 'premier_gros_achat', label: 'Premier achat important en moins de 24 h', hint: 'Un compte neuf qui achète plusieurs centaines d’euros avant tout échange est le profil type du chargeback organisé.' },
  { id: 'custom_seul', label: 'Demande de sur-mesure sans aucun historique', hint: 'Commande personnalisée dès l’arrivée, sans conversation préalable.' },
  { id: 'silence_apres_reception', label: 'Silence total après réception du contenu', hint: 'Contenu livré, aucune réponse, aucune interaction : le signal classique avant contestation.' },
  { id: 'lieu_achat_seul', label: 'Aucun message avant l’achat', hint: 'Abonnement ou PPV débloqué sans un mot, puis litige.' },
  { id: 'arrivee_campagne', label: 'Arrivée pendant une campagne publique', hint: 'Le compte apparaît dans les 48 h suivant une publication ou un post qui a fait du bruit.' },
  { id: 'comptes_multiples', label: 'Plusieurs comptes le même jour', hint: 'Trois comptes ou plus créés le même jour, même vocabulaire, mêmes demandes.' },
  { id: 'litige_anterieur', label: 'Litige déjà enregistré sur ce contact', hint: 'Le même identifiant revient : blocage immédiat.' },
  { id: 'session_longue', label: 'Demande de session longue ou d’appel privé', hint: 'Les sessions longues sont les plus difficiles à défendre en cas de contestation.' }
];

/* Sujets proposés quand un membre écrit directement à l'équipe.
   Chaque sujet indique le délai de réponse annoncé : la promesse doit être tenue. */
SEVE.taxo.TEAM_TOPICS = [
  { id: 'soutien', label: 'J’ai besoin de parler, d’être soutenue', icon: 'heart', urgent: true, hint: 'Vous vous sentez seule, dépassée, ou vous avez simplement besoin de parler à quelqu’un. Réponse sous 1 heure ouvrée, par une personne — pas un robot, et sans jugement.' },
  { id: 'malaise', label: 'Un échange qui m’a mise mal à l’aise', icon: 'shield', urgent: true, hint: 'Insistance, remarques déplacées, pression pour aller vite, demande de photos ou d’argent hors plateforme. Réponse sous 1 heure ouvrée.' },
  { id: 'collab', label: 'Une collaboration qui se passe mal', icon: 'flag', urgent: true, hint: 'Retards, silences, promesses non tenues, désaccord sur le contrat : nous reprenons le dossier avec vous.' },
  { id: 'litige', label: 'Une contestation bancaire', icon: 'alert', hint: 'Chargebacks, remboursements, dossier de preuves : nous vous aidons à construire la réponse.' },
  { id: 'appel', label: 'Je préfère être appelée', icon: 'phone', hint: 'Un créneau de 20 minutes, en visio ou au téléphone, avec une personne de l’équipe. Aucune obligation de montrer quoi que ce soit.' },
  { id: 'visibilite', label: 'Ma visibilité et mes données', icon: 'lock', hint: 'Je veux disparaître des résultats, mettre en pause, savoir qui a vu mon profil, ou faire effacer des informations.' },
  { id: 'question', label: 'Une simple question', icon: 'question', hint: 'Fonctionnement de la plateforme, contrat, tarifs, vérification. Aucune question n’est trop petite.' },
  { id: 'autre', label: 'Autre chose', icon: 'message', hint: 'Dites-le avec vos mots. Nous lisons tout, et nous répondons à une personne, pas à un dossier.' }
];

SEVE.taxo.byId = function (list, id) {
  return SEVE.taxo[list].filter((x) => x.id === id)[0];
};
SEVE.taxo.labels = function (ids, list) {
  const src = SEVE.taxo[list || 'SPECIALTIES'] || [];
  return (ids || []).map((id) => {
    const f = src.filter((x) => x.id === id)[0];
    return f ? f.label : id;
  });
};

/* -------------------------------------------------------------------------- */
/* Profils                                                                     */
/* -------------------------------------------------------------------------- */
SEVE.db = (function () {
  const T = SEVE.taxo;

  const to = (days, hours) => new Date(Date.now() - days * 864e5 - (hours || 0) * 36e5).toISOString();

  const creators = [
    {
      id: 'c1', role: 'creator', name: 'Léa Monteiro', handle: '@leamonti', tone: 't-sage', verified: true, demo: false,
      city: 'Lisbonne', country: 'Portugal', region: 'Europe', joined: '2025-03-04', availability: 'active',
      exp: 'e4', network: 'n4', subs: 284000, status: 'active', featured: true,
      specialties: ['chatting', 'growth_ig', 'branding', 'ppv'], languages: ['Français', 'Anglais', 'Portugais'],
      platforms: ['onlyfans', 'fanvue', 'instagram', 'tiktok'],
      bio: 'Compte lifestyle et lingerie haut de gamme, entièrement en anglais et français. Je cherche un partenaire capable de tenir la relation abonnés au niveau attendu par une audience internationale.',
      goals: ['Doubler mon chiffre mensuel', 'Déléguer le chatting', 'Ouvrir un nouveau marché'],
      metrics: { revenue: '24 – 38 k€ / mois', growth: '+18 % sur 90 jours', response: 'Réponse < 2 h', retention: '68 % d’abonnés récurrents' },
      timeline: [
        { period: '2024 — aujourd’hui', title: 'Créatrice indépendante', org: 'OnlyFans & Fanvue', note: 'Passée de 60 k à 284 k d’abonnés cumulés en 18 mois, gestion complète du chatting en solo.' },
        { period: '2022 — 2024', title: 'Assistante marketing', org: 'Studio photo, Lisbonne', note: 'Contenus de marque et community management : base solide en production visuelle.' },
        { period: '2021 — 2022', title: 'Création du compte', org: 'Auto-produit', note: 'Démarrage assistée d’une amie créatrice, apprentissage du pricing et des rythmes de publication.' }
      ],
      portfolio: [
        { title: 'Lancement du compte Fanvue', type: 'Lancement', meta: '0 → 4 200 abonnés payants en 5 mois' },
        { title: 'Plan de contenu « Slow luxury »', type: 'Direction artistique', meta: '12 shootings, 3 thèmes récurrents' },
        { title: 'Séquence de bienvenue automatisée', type: 'Monétisation', meta: '+31 % de conversion sur les nouveaux abonnés' }
      ],
      pro: { statut: 'Photographe attitré', tarif: '20 – 25 % de commission', outils: 'OnlyFans, Fanvue, Notion, Canva', dispo: '45 h / semaine', paiement: 'Virement SEPA' },
      looking: {
        title: 'Manager individuel ou petite agence (FR / EN)',
        split: '20 – 30 % de commission',
        notes: 'Je cherche une personne fiable, qui répond vite et qui sait tenir un calendrier. Je veux garder la main sur la direction artistique.',
        must: ['Expérience du chatting en anglais', 'Capacité à travailler en autonomie 4 jours / semaine', 'Reporting mensuel clair', 'Aucune diffusion de mes contenus hors plateformes connues']
      }
    },
    {
      id: 'c2', role: 'creator', name: 'Maya Duarte', handle: '@mayaduart', tone: 't-blush', verified: true,
      city: 'Bordeaux', country: 'France', region: 'Europe', joined: '2025-04-18', availability: 'open',
      exp: 'e3', network: 'n3', subs: 76000, status: 'active',
      specialties: ['chatting', 'content_video', 'lives', 'growth_tt'],
      languages: ['Français', 'Anglais'], platforms: ['onlyfans', 'tiktok', 'instagram'],
      bio: 'Univers doux et naturel, audience très réactive en DM. J’ai besoin d’un partenaire pour structurer la vente plutôt que pour produire du contenu.',
      goals: ['Stabiliser mes revenus', 'Structurer mon planning de publication', 'Passer à un rythme soutenable'],
      metrics: { revenue: '7 – 12 k€ / mois', growth: '+9 % sur 90 jours', response: 'Réponse < 4 h', retention: '54 % d’abonnés récurrents' },
      timeline: [
        { period: '2024 — aujourd’hui', title: 'Créatrice OnlyFans', org: 'Indépendante', note: 'Communauté fidèle construite sur TikTok, 76 k abonnés cumulés.' },
        { period: '2023 — 2024', title: 'Serveuse & créatrice TikTok', org: 'Bordeaux', note: 'Premiers pas dans la création de contenu, 40 k abonnés en six mois.' }
      ],
      portfolio: [
        { title: 'Séquence live hebdomadaire', type: 'Lives', meta: 'Pic à 340 spectateurs simultanés' },
        { title: 'Catalogue « 30 jours de DM »', type: 'Chatting', meta: '+22 % de revenus mensuels' }
      ],
      pro: { statut: 'Indépendante', tarif: 'Ouverte aux splits', outils: 'OnlyFans, CapCut, Notion', dispo: '30 h / semaine', paiement: 'Virement SEPA / Revolut' },
      looking: {
        title: 'Manager francophone, relation de confiance',
        split: '25 % de commission',
        notes: 'Je cherche quelqu’un qui prendra le temps de comprendre mon univers avant de vouloir accélérer les ventes.',
        must: ['Francophone natif', 'Disponibilité en soirée', 'Zéro pression sur les contenus extrêmes', 'Point hebdomadaire de 30 minutes']
      }
    },
    {
      id: 'c3', role: 'creator', name: 'Nour El Amrani', handle: '@nourela', tone: 't-sand', verified: true,
      city: 'Marseille', country: 'France', region: 'Europe', joined: '2025-01-22', availability: 'active',
      exp: 'e3', network: 'n3', subs: 112000, status: 'active', featured: true,
      specialties: ['customs', 'chatting', 'media_buying', 'analytics'],
      languages: ['Français', 'Anglais', 'Arabe'], platforms: ['onlyfans', 'instagram', 'x'],
      bio: 'Compte fitness et lifestyle très demandé en sur-mesure. Mon enjeu : industrialiser le chatting sans perdre le ton très personnel de mes réponses.',
      goals: ['Doubler mon chiffre mensuel', 'Déléguer le chatting', 'Sortir du tout-DM et poser un persona'],
      metrics: { revenue: '18 – 27 k€ / mois', growth: '+26 % sur 90 jours', response: 'Réponse < 1 h', retention: '72 % d’abonnés récurrents' },
      timeline: [
        { period: '2023 — aujourd’hui', title: 'Créatrice & coach fitness', org: 'Indépendante', note: '112 k abonnés, forte demande de contenus personnalisés et de coaching.' },
        { period: '2020 — 2023', title: 'Créatrice Instagram', org: 'Marseille', note: 'Construction d’une audience fitness avant le lancement de l’abonnement.' }
      ],
      portfolio: [
        { title: 'Offre coaching + abonnement', type: 'Pricing', meta: 'Panier moyen +38 %' },
        { title: 'Tunnel Instagram → OF', type: 'Acquisition', meta: '1 100 abonnés payants / mois' }
      ],
      pro: { statut: 'Photographe partenaire', tarif: '20 – 28 % de commission', outils: 'OnlyFans, Later, Notion, Zapier', dispo: '50 h / semaine', paiement: 'Virement SEPA' },
      looking: {
        title: 'Équipe de chatting expérimentée',
        split: '22 – 30 % de commission partagée',
        notes: 'Je souhaite déléguer 60 % des messages en gardant un accès direct à la relation abonnés.',
        must: ['Équipe de 4 personnes minimum', 'Formation au persona documentée', 'Accès aux statistiques en temps réel', 'Créneaux d’astreinte le week-end']
      }
    },
    {
      id: 'c4', role: 'creator', name: 'Sofía Herrera', handle: '@sofia.herrera', tone: 't-lilac', verified: true,
      city: 'Valence', country: 'Espagne', region: 'Europe', joined: '2024-11-09', availability: 'busy',
      exp: 'e2', network: 'n3', subs: 58000, status: 'active',
      specialties: ['content_photo', 'lives', 'growth_tt', 'branding'],
      languages: ['Espagnol', 'Français', 'Italien'], platforms: ['onlyfans', 'fanvue', 'tiktok'],
      bio: 'Contenu photo éditorial, esthétique très travaillée. Je vends peu en messages : mon levier est la qualité et la régularité de mes séries.',
      goals: ['Ouvrir un nouveau marché', 'Lancer une seconde plateforme', 'Stabiliser mes revenus'],
      metrics: { revenue: '6 – 11 k€ / mois', growth: '+7 % sur 90 jours', response: 'Réponse < 6 h', retention: '61 % d’abonnés récurrents' },
      timeline: [
        { period: '2024 — aujourd’hui', title: 'Créatrice indépendante', org: 'OnlyFans & Fanvue', note: 'Deux plateformes menées en parallèle, 58 k abonnés.' },
        { period: '2022 — 2024', title: 'Photographe de mode', org: 'Agence locale', note: 'Direction artistique de shootings, retouche professionnelle.' }
      ],
      portfolio: [
        { title: 'Série « Intérieur Valencia »', type: 'Production', meta: '8 shootings, 640 visuels livrés' },
        { title: 'Newsletter Fanvue', type: 'Fanvue', meta: '1 400 abonnés, 44 % d’ouverture' }
      ],
      pro: { statut: 'Studio partenaire à Valence', tarif: 'Ouverte aux splits', outils: 'Lightroom, Photoshop, Fanvue, Notion', dispo: '25 h / semaine', paiement: 'Wise / SEPA' },
      looking: {
        title: 'Manager bilingue ES/EN, spécialisé visuel',
        split: '20 % de commission',
        notes: 'Je produis déjà beaucoup. Ce qu’il me manque, c’est la régularité et la relance des abonnés dormants.',
        must: ['Espagnol et anglais courants', 'Goût pour l’image soignée', 'Campagnes de réactivation documentées']
      }
    },
    {
      id: 'c5', role: 'creator', name: 'Jade Lefèvre', handle: '@jadelfv', tone: 't-mist', verified: false,
      city: 'Lille', country: 'France', region: 'Europe', joined: '2025-06-02', availability: 'active',
      exp: 'e1', network: 'n2', subs: 14000, status: 'active',
      specialties: ['chatting', 'growth_tt', 'customs'],
      languages: ['Français'], platforms: ['onlyfans', 'tiktok', 'x'],
      bio: 'Je débute sérieusement après un an de test. J’ai une audience jeune et très engageante sur TikTok, mais je manque de méthode sur le pricing.',
      goals: ['Stabiliser mes revenus', 'Structurer mon planning de publication', 'Déléguer le chatting'],
      metrics: { revenue: '1,2 – 2,4 k€ / mois', growth: '+41 % sur 90 jours', response: 'Réponse < 3 h', retention: '39 % d’abonnés récurrents' },
      timeline: [
        { period: '2024 — aujourd’hui', title: 'Créatrice TikTok & OnlyFans', org: 'Indépendante', note: '14 k abonnés, première année complète d’activité.' },
        { period: '2021 — 2024', title: 'Étudiante en communication', org: 'Lille', note: 'Bases en montage vidéo et rédaction.' }
      ],
      portfolio: [
        { title: 'Format TikTok « coulisses »', type: 'Croissance', meta: '3 vidéos à plus de 500 k vues' }
      ],
      pro: { statut: 'Indépendante', tarif: 'Splits à partir de 20 %', outils: 'OnlyFans, CapCut, Linktree', dispo: '35 h / semaine', paiement: 'Virement SEPA' },
      looking: {
        title: 'Premier manager, pédagogie bienvenue',
        split: '20 – 25 % de commission',
        notes: 'Je cherche quelqu’un qui accepte un compte en construction et qui m’explique ses choix.',
        must: ['Francophone', 'Suivi hebdomadaire', 'Aucune prise de risque juridique', 'Contrat clair dès le départ']
      }
    },
    {
      id: 'c6', role: 'creator', name: 'Elena Volkova', handle: '@elenavk', tone: 't-stone', verified: true,
      city: 'Barcelone', country: 'Espagne', region: 'Europe', joined: '2024-08-15', availability: 'open',
      exp: 'e4', network: 'n4', subs: 320000, status: 'active', featured: true,
      specialties: ['growth_x', 'reddit', 'media_buying', 'analytics'],
      languages: ['Anglais', 'Russe', 'Espagnol'], platforms: ['onlyfans', 'x', 'reddit', 'instagram'],
      bio: 'Compte anglophone établi, forte acquisition via X et Reddit. Je cherche un partenaire de croissance, pas un producteur de contenu.',
      goals: ['Doubler mon chiffre mensuel', 'Ouvrir un nouveau marché', 'Scaler un système d’acquisition'],
      metrics: { revenue: '32 – 52 k€ / mois', growth: '+12 % sur 90 jours', response: 'Réponse < 3 h', retention: '64 % d’abonnés récurrents' },
      timeline: [
        { period: '2022 — aujourd’hui', title: 'Créatrice & entrepreneuse', org: 'Indépendante', note: '320 k abonnés, système d’acquisition maîtrisé de bout en bout.' },
        { period: '2019 — 2022', title: 'Traffic manager', org: 'Agence performance', note: 'SEO, social ads, création de tunnels de conversion.' }
      ],
      portfolio: [
        { title: 'Machine Reddit', type: 'Acquisition', meta: '42 k visiteurs qualifiés / mois' },
        { title: 'X → OnlyFans funnel', type: 'Croissance', meta: 'Coût par abonné payant : 1,80 €' }
      ],
      pro: { statut: 'Studio à Barcelone', tarif: 'Retainer + 15 % de commission', outils: 'Reddit, X, GA4, Looker Studio', dispo: '20 h / semaine', paiement: 'Virement international' },
      looking: {
        title: 'Manager orienté performance et données',
        split: 'Retainer + bonus sur objectif',
        notes: 'Je veux des tests chiffrés, pas des promesses. Un partenaire capable de gérer 3 marchés à la fois.',
        must: ['Anglais courant', 'Culture de la donnée', 'Capacité à opérer sur Reddit et X', 'Reporting hebdomadaire']
      }
    },
    {
      id: 'c7', role: 'creator', name: 'Camille Roy', handle: '@camilleroy', tone: 't-clay', verified: true,
      city: 'Lyon', country: 'France', region: 'Europe', joined: '2025-02-27', availability: 'busy',
      exp: 'e3', network: 'n3', subs: 94000, status: 'active',
      specialties: ['content_photo', 'content_video', 'chatting', 'planning'],
      languages: ['Français', 'Anglais'], platforms: ['onlyfans', 'fansly', 'instagram'],
      bio: 'Duo de créatrices géré à deux. Nous cherchons un manager de confiance pour reprendre la vente et le planning, nous gardons la production.',
      goals: ['Stabiliser mes revenus', 'Déléguer le chatting', 'Passer à un rythme soutenable'],
      metrics: { revenue: '12 – 19 k€ / mois', growth: '+15 % sur 90 jours', response: 'Réponse < 5 h', retention: '58 % d’abonnés récurrents' },
      timeline: [
        { period: '2024 — aujourd’hui', title: 'Duo de créatrices', org: 'OnlyFans & Fansly', note: '94 k abonnés cumulés, production en binôme.' },
        { period: '2020 — 2024', title: 'Danseuse professionnelle', org: 'Compagnie lyonnaise', note: 'Discipline de répétition et gestion du corps.' }
      ],
      portfolio: [
        { title: 'Formats courts « duo »', type: 'Production', meta: 'Catalogue de 60 vidéos' },
        { title: 'Offre abonnement 6 mois', type: 'Pricing', meta: '23 % des abonnés souscrivent' }
      ],
      pro: { statut: 'Studio partenaire à Lyon', tarif: '22 – 27 % de commission', outils: 'Fansly, OnlyFans, Frame.io', dispo: '40 h / semaine', paiement: 'Virement SEPA' },
      looking: {
        title: 'Manager expérimenté, relation durable',
        split: '22 – 27 % de commission',
        notes: 'Nous voulons quelqu’un qui s’inscrive dans la durée et qui aime travailler en équipe.',
        must: ['Francophone', 'Expérience des comptes en duo', 'Confidentialité absolue']
      }
    },
    {
      id: 'c8', role: 'creator', name: 'Amira Haddad', handle: '@amira.hdd', tone: 't-moss', verified: true,
      city: 'Bruxelles', country: 'Belgique', region: 'Europe', joined: '2025-05-06', availability: 'active',
      exp: 'e2', network: 'n3', subs: 47000, status: 'active',
      specialties: ['lives', 'customs', 'growth_ig', 'moderation'],
      languages: ['Français', 'Anglais', 'Arabe'], platforms: ['onlyfans', 'instagram', 'tiktok'],
      bio: 'Les lives sont mon canal principal : je vends surtout pendant les diffusions. Je cherche un manager à l’aise avec ce format.',
      goals: ['Doubler mon chiffre mensuel', 'Ouvrir un nouveau marché', 'Structurer mon planning de publication'],
      metrics: { revenue: '5 – 9 k€ / mois', growth: '+33 % sur 90 jours', response: 'Réponse < 2 h', retention: '57 % d’abonnés récurrents' },
      timeline: [
        { period: '2024 — aujourd’hui', title: 'Créatrice live', org: 'Indépendante', note: '3 lives par semaine, communauté très fidèle.' },
        { period: '2023 — 2024', title: 'Animée une communauté Discord', org: 'Projet personnel', note: '8 000 membres animés et modérés.' }
      ],
      portfolio: [
        { title: 'Live du vendredi', type: 'Lives', meta: 'Revenu moyen : 900 € / session' },
        { title: 'Programme VIP', type: 'Monétisation', meta: '180 abonnés à 49 € / mois' }
      ],
      pro: { statut: 'Indépendante', tarif: 'Splits dès 20 %', outils: 'OnlyFans, OBS, Streamlabs', dispo: '35 h / semaine', paiement: 'Virement SEPA' },
      looking: {
        title: 'Manager spécialisé lives & modération',
        split: '20 – 26 % de commission',
        notes: 'Je cherche quelqu’un qui saura monétiser l’avant / après live et gérer la modération des chats.',
        must: ['Goût pour le live', 'Anglais correct', 'Disponibilité le week-end en soirée']
      }
    },
    {
      id: 'c9', role: 'creator', name: 'Lya Moreau', handle: '@lyamoreau', tone: 't-sage', verified: true, demo: true,
      city: 'Paris', country: 'France', region: 'Europe', joined: '2025-01-14', availability: 'active',
      exp: 'e3', network: 'n3', subs: 88000, status: 'active',
      specialties: ['chatting', 'content_photo', 'growth_tt', 'pricing'],
      languages: ['Français', 'Anglais'], platforms: ['onlyfans', 'tiktok', 'instagram', 'fanvue'],
      bio: 'Compte lifestyle parisien, audience majoritairement francophone et anglophone. J’ai atteint un palier : je publie beaucoup mais je perds du chiffre sur la vente en messages.',
      goals: ['Doubler mon chiffre mensuel', 'Déléguer le chatting', 'Structurer mon planning de publication'],
      metrics: { revenue: '9 – 15 k€ / mois', growth: '+11 % sur 90 jours', response: 'Réponse < 3 h', retention: '59 % d’abonnés récurrents' },
      timeline: [
        { period: '2024 — aujourd’hui', title: 'Créatrice indépendante', org: 'OnlyFans & Fanvue', note: '88 k abonnés, 4 publications par semaine, chatting réalisé par moi-même.' },
        { period: '2022 — 2024', title: 'Chargée de communication', org: 'Agence digitale, Paris', note: 'Rédaction, community management, analyse de performance.' }
      ],
      portfolio: [
        { title: 'Séquence de bienvenue', type: 'Monétisation', meta: 'Conversion des nouveaux abonnés : 34 %' },
        { title: 'Série « Rive gauche »', type: 'Production', meta: '14 shootings, 320 visuels' }
      ],
      pro: { statut: 'Photographe régulier à Paris', tarif: 'Cible : 20 – 25 % de commission', outils: 'OnlyFans, Fanvue, Notion, Lightroom', dispo: '40 h / semaine', paiement: 'Virement SEPA' },
      looking: {
        title: 'Manager francophone, structure et méthode',
        split: '20 – 25 % de commission',
        notes: 'Je veux un partenaire qui m’aide à prioriser : moins de publications, mieux monétisées, et une vraie délégation du chatting à partir de janvier.',
        must: ['Francophone natif', 'Reporting mensuel lisible', 'Respect strict des limites définies ensemble', 'Réactivité sous 24 h']
      }
    },
    {
      id: 'c10', role: 'creator', name: 'Nina Okafor', handle: '@ninaokafor', tone: 't-blush', verified: true,
      city: 'Londres', country: 'Royaume-Uni', region: 'Europe', joined: '2024-12-01', availability: 'open',
      exp: 'e4', network: 'n5', subs: 640000, status: 'active',
      specialties: ['branding', 'growth_tt', 'ppv', 'analytics'],
      languages: ['Anglais', 'Français'], platforms: ['onlyfans', 'tiktok', 'instagram', 'x'],
      bio: 'Marque personnelle établie, plus de 600 k abonnés. J’ai besoin d’un partenaire capable de gérer une équipe et de parler monétisation.',
      goals: ['Doubler mon chiffre mensuel', 'Sortir du tout-DM et poser un persona', 'Ouvrir un nouveau marché'],
      metrics: { revenue: '45 – 70 k€ / mois', growth: '+16 % sur 90 jours', response: 'Réponse < 4 h', retention: '71 % d’abonnés récurrents' },
      timeline: [
        { period: '2021 — aujourd’hui', title: 'Créatrice & marque', org: 'Indépendante', note: '640 k abonnés, équipe de 4 personnes déjà en place.' },
        { period: '2018 — 2021', title: 'Mannequin', org: 'Agence internationale', note: 'Direction artistique et travail d’image.' }
      ],
      portfolio: [
        { title: 'Programme VIP 199 $', type: 'Monétisation', meta: '260 membres actifs' },
        { title: 'Lancement TikTok UK', type: 'Croissance', meta: '0 → 120 k en 7 mois' }
      ],
      pro: { statut: 'Équipe interne partielle', tarif: 'Retainer + 12 % de commission', outils: 'Notion, Looker, ManyChat', dispo: '15 h / semaine', paiement: 'Virement international' },
      looking: {
        title: 'Directeur/trice de compte expérimenté(e)',
        split: 'Retainer + bonus',
        notes: 'Je cherche une personne capable de piloter mon équipe existante et de négocier des partenariats.',
        must: ['Anglais natif', 'Management d’équipe', 'Expérience de comptes à plus de 500 k €', 'Discrétion totale']
      }
    },
    {
      id: 'c11', role: 'creator', name: 'Chloé Bertrand', handle: '@chloebrt', tone: 't-mist', verified: false,
      city: 'Nantes', country: 'France', region: 'Europe', joined: '2025-07-19', availability: 'active',
      exp: 'e1', network: 'n1', subs: 4200, status: 'active',
      specialties: ['customs', 'growth_tt', 'content_video'],
      languages: ['Français'], platforms: ['onlyfans', 'tiktok'],
      bio: 'Je lance mon compte dans quelques semaines. Je cherche un accompagnement dès le départ : positionnement, pricing, rythme de publication.',
      goals: ['Stabiliser mes revenus', 'Structurer mon planning de publication'],
      metrics: { revenue: 'en lancement', growth: '—', response: 'Réponse < 2 h', retention: '—' },
      timeline: [
        { period: '2025 — aujourd’hui', title: 'Préparation de lancement', org: 'Indépendante', note: '4 200 abonnés TikTok avant ouverture du compte payant.' }
      ],
      portfolio: [{ title: 'Contenu TikTok de lancement', type: 'Croissance', meta: '28 vidéos publiées, 1 à 400 k vues' }],
      pro: { statut: 'Indépendante', tarif: 'À définir ensemble', outils: 'CapCut, TikTok, Notion', dispo: '30 h / semaine', paiement: 'Virement SEPA' },
      looking: {
        title: 'Manager pédagogue pour un lancement',
        split: '15 – 20 % de commission la première année',
        notes: 'Je souhaite un vrai cadre : objectifs mensuels, plan de contenu, formation au pricing.',
        must: ['Pédagogie', 'Aucun engagement long avant résultats', 'Transparence sur les commissions']
      }
    },
    {
      id: 'c12', role: 'creator', name: 'Inès Da Silva', handle: '@inesdsilva', tone: 't-moss', verified: true,
      city: 'Porto', country: 'Portugal', region: 'Europe', joined: '2025-03-30', availability: 'busy',
      exp: 'e2', network: 'n2', subs: 18500, status: 'active',
      specialties: ['lives', 'moderation', 'chatting', 'content_photo'],
      languages: ['Portugais', 'Français', 'Anglais'], platforms: ['onlyfans', 'instagram'],
      bio: 'Communauté locale très engagée, petit volume mais forte valeur par abonné. Je cherche à élargir au public francophone.',
      goals: ['Ouvrir un nouveau marché', 'Stabiliser mes revenus', 'Doubler mon chiffre mensuel'],
      metrics: { revenue: '2,4 – 4,1 k€ / mois', growth: '+24 % sur 90 jours', response: 'Réponse < 1 h', retention: '66 % d’abonnés récurrents' },
      timeline: [
        { period: '2024 — aujourd’hui', title: 'Créatrice indépendante', org: 'Porto', note: '18,5 k abonnés, panier moyen élevé.' }
      ],
      portfolio: [{ title: 'Offre 1:1', type: 'Monétisation', meta: 'Panier moyen : 78 €' }],
      pro: { statut: 'Indépendante', tarif: 'Splits dès 20 %', outils: 'OnlyFans, Canva, Notion', dispo: '30 h / semaine', paiement: 'SEPA / Wise' },
      looking: {
        title: 'Manager francophone ou lusophone',
        split: '20 – 25 % de commission',
        notes: 'Je veux ouvrir la France et le Benelux avec quelqu’un qui connaît ces marchés.',
        must: ['Français ou portugais', 'Connaissance du marché français', 'Respect du rythme de travail']
      }
    },
    {
      id: 'c13', role: 'creator', name: 'Chloé Berger', handle: '@chloeberger', tone: 't-blush', verified: true,
      city: 'Lyon', country: 'France', region: 'Europe', joined: '2026-10-04', availability: 'active',
      exp: 'e3', network: 'n3', subs: 64000, status: 'active',
      specialties: ['chatting', 'ppv', 'planning', 'analytics'],
      languages: ['Français', 'Anglais'], platforms: ['onlyfans', 'instagram', 'tiktok'],
      bio: 'Compte lifestyle lyonnais, audience 70 % francophone. Je produis régulièrement mais la vente en messages repose entièrement sur moi et plafonne depuis trois mois.',
      goals: ['Déléguer le chatting', 'Doubler mon chiffre mensuel', 'Stabiliser mes revenus'],
      metrics: { revenue: '6 – 9 k€ / mois', growth: '+8 % sur 90 jours', response: 'Réponse < 6 h', retention: '54 % d’abonnés récurrents' },
      timeline: [
        { period: '2023 — aujourd’hui', title: 'Créatrice indépendante', org: 'OnlyFans, Instagram', note: '64 k abonnés, 3 publications par semaine, aucune délégation.' },
        { period: '2020 — 2023', title: 'Assistante commerciale', org: 'PME lyonnaise', note: 'Relation client, reporting, gestion des priorités.' }
      ],
      portfolio: [
        { title: 'Campagne d’abonnement d’octobre', type: 'Monétisation', meta: '112 nouveaux abonnés en 9 jours' },
        { title: 'Série « Presqu’île »', type: 'Production', meta: '9 shootings, 240 visuels' }
      ],
      pro: { statut: 'Micro-entreprise', tarif: 'Cible : 20 – 25 % de commission', outils: 'OnlyFans, Notion, CapCut', dispo: '35 h / semaine', paiement: 'Virement SEPA' },
      looking: {
        title: 'Manager francophone pour reprendre la vente',
        split: '20 – 25 % de commission',
        notes: 'Je souhaite garder la création et confier la vente à quelqu’un de fiable, avec un point hebdomadaire court et des chiffres clairs.',
        must: ['Francophone', 'Reporting hebdomadaire', 'Démarrage sous 3 semaines', 'Respect strict des limites définies ensemble']
      }
    },
    {
      id: 'c14', role: 'creator', name: 'Amandine Ross', handle: '@amandineroos', tone: 't-lilac', verified: true,
      city: 'Bruxelles', country: 'Belgique', region: 'Europe', joined: '2026-08-19', availability: 'open',
      exp: 'e4', network: 'n4', subs: 176000, status: 'active',
      specialties: ['branding', 'pricing', 'collabs', 'media_buying'],
      languages: ['Français', 'Néerlandais', 'Anglais'], platforms: ['onlyfans', 'fanvue', 'x'],
      bio: 'Compte fitness belge construit sur une audience bilingue. Mon problème n’est plus le volume mais la rentabilité : trop de promotions, un prix d’abonnement trop bas et peu de contenu sur-mesure.',
      goals: ['Passer à un rythme soutenable', 'Structurer mon planning de publication', 'Lancer une seconde plateforme'],
      metrics: { revenue: '18 – 26 k€ / mois', growth: '+4 % sur 90 jours', response: 'Réponse < 12 h', retention: '61 % d’abonnés récurrents' },
      timeline: [
        { period: '2021 — aujourd’hui', title: 'Créatrice fitness', org: 'OnlyFans, Fanvue', note: '176 k abonnés, deux marques partenaires récurrentes.' },
        { period: '2018 — 2021', title: 'Coach sportive indépendante', org: 'Bruxelles', note: 'Suivi de 40 clients, création de programmes.' }
      ],
      portfolio: [
        { title: 'Refonte de la grille tarifaire', type: 'Pricing', meta: 'Panier moyen +38 % en 60 jours' },
        { title: 'Programme « 8 semaines »', type: 'Contenu', meta: 'Série payante, 2 400 ventes' },
        { title: 'Collab créatrice fitness NL', type: 'Croissance', meta: '4 100 abonnés croisés' }
      ],
      pro: { statut: 'SRL enregistrée', tarif: 'Ouverte aux retainers', outils: 'OnlyFans, Fanvue, Metricool, Notion', dispo: '45 h / semaine', paiement: 'SEPA / Wise' },
      looking: {
        title: 'Agence capable de remonter la rentabilité sans produire plus',
        split: 'Retainer + 10 à 15 %',
        notes: 'Je cherche un partenaire analytique : prix, offres, relances, marketing. Je ne veux pas d’un pôle chatting à 40 personnes sur mon compte.',
        must: ['Expérience pricing / CRM', 'Bilingue FR-NL apprécié', 'Reporting mensuel lisible', 'Aucun achat de trafic opaque']
      }
    },
    {
      id: 'c15', role: 'creator', name: 'Sofia Marchetti', handle: '@sofiamarchetti', tone: 't-clay', verified: true,
      city: 'Milan', country: 'Italie', region: 'Europe', joined: '2025-11-22', availability: 'active',
      exp: 'e3', network: 'n3', subs: 92000, status: 'active',
      specialties: ['content_photo', 'content_video', 'branding', 'growth_ig'],
      languages: ['Italien', 'Anglais', 'Français'], platforms: ['onlyfans', 'instagram'],
      bio: 'Direction artistique très travaillée, esthétique mode milanaise. Je veux dupliquer ma méthode sur une seconde plateforme et déléguer les échanges du quotidien.',
      goals: ['Lancer une seconde plateforme', 'Déléguer le chatting', 'Ouvrir un nouveau marché'],
      metrics: { revenue: '12 – 17 k€ / mois', growth: '+16 % sur 90 jours', response: 'Réponse < 8 h', retention: '63 % d’abonnés récurrents' },
      timeline: [
        { period: '2022 — aujourd’hui', title: 'Créatrice indépendante', org: 'Milan', note: '92 k abonnés, identité visuelle cohesive, production assurée par un studio partenaire.' }
      ],
      portfolio: [
        { title: 'Direction artistique 2026', type: 'Branding', meta: 'Palette, ton, charte photo validés' },
        { title: 'Série éditoriale « Brera »', type: 'Production', meta: '6 chapitres, 480 visuels' }
      ],
      pro: { statut: 'Partita IVA', tarif: 'Cible : 18 – 22 % de commission', outils: 'OnlyFans, Lightroom, Notion', dispo: '30 h / semaine', paiement: 'Virement SEPA' },
      looking: {
        title: 'Manager italophone ou francophone, orientation contenu',
        split: '18 – 22 % de commission',
        notes: 'Priorité à la qualité editoriale et à la régularité. Je cherche quelqu’un qui comprend un univers visuel et ne casse pas la ligne.',
        must: ['Sensibilité esthétique', 'Italien ou français', 'Aucun contenu généré à ma place', 'Réactivité sous 24 h']
      }
    },
    {
      id: 'c16', role: 'creator', name: 'Nadia Bensalem', handle: '@nadiabensalem', tone: 't-sand', verified: true,
      city: 'Casablanca', country: 'Maroc', region: 'Afrique', joined: '2025-06-11', availability: 'open',
      exp: 'e2', network: 'n2', subs: 14500, status: 'active',
      specialties: ['growth_tt', 'growth_ig', 'moderation', 'customs'],
      languages: ['Arabe', 'Français', 'Anglais'], platforms: ['onlyfans', 'tiktok', 'instagram'],
      bio: 'Audience TikTok marocaine et diaspora, croissance rapide depuis un an. Besoin d’aide sur la conversion et la modération, que je gère seule jusque tard le soir.',
      goals: ['Stabiliser mes revenus', 'Déléguer le chatting', 'Sortir du tout-DM et poser un persona'],
      metrics: { revenue: '2,8 – 4,6 k€ / mois', growth: '+37 % sur 90 jours', response: 'Réponse < 2 h', retention: '48 % d’abonnés récurrents' },
      timeline: [
        { period: '2024 — aujourd’hui', title: 'Créatrice indépendante', org: 'OnlyFans, TikTok', note: '14,5 k abonnés, 190 k sur TikTok.' }
      ],
      portfolio: [
        { title: 'Séquence TikTok virale', type: 'Croissance', meta: '1,1 M de vues, 3 900 abonnés gagnés' }
      ],
      pro: { statut: 'Auto-entrepreneure (statut local)', tarif: 'Ouverte aux splits', outils: 'OnlyFans, CapCut, Canva', dispo: '25 h / semaine', paiement: 'Virement international' },
      looking: {
        title: 'Manager trilingue, patient et structuré',
        split: '20 – 25 % de commission',
        notes: 'Je cherche une structure fiable, pas un promesse de revenus. Le respect du cadre et la discrétion passent avant tout.',
        must: ['Arabe ou français', 'Discrétion totale', 'Modération incluse', 'Paiement clair et daté']
      }
    },
    {
      id: 'c17', role: 'creator', name: 'Julie Lambert', handle: '@julielambert', tone: 't-mist', verified: true,
      city: 'Montréal', country: 'Canada', region: 'Amérique du Nord', joined: '2026-07-08', availability: 'active',
      exp: 'e3', network: 'n3', subs: 41000, status: 'active',
      specialties: ['ppv', 'fanvue', 'planning', 'legal'],
      languages: ['Français', 'Anglais'], platforms: ['onlyfans', 'fanvue', 'patreon'],
      bio: 'Compte québécois avec une audience très fidèle et un créneau newsletter bien installé. J’ai besoin d’un cadre clair : contrats, fiscalité, et quelqu’un pour mes campagnes.',
      goals: ['Doubler mon chiffre mensuel', 'Lancer une seconde plateforme', 'Passer à un rythme soutenable'],
      metrics: { revenue: '7 – 11 k€ / mois', growth: '+13 % sur 90 jours', response: 'Réponse < 4 h', retention: '67 % d’abonnés récurrents' },
      timeline: [
        { period: '2023 — aujourd’hui', title: 'Créatrice indépendante', org: 'OnlyFans, Fanvue, Patreon', note: '41 k abonnés, 1 900 abonnés newsletter payante.' },
        { period: '2019 — 2023', title: 'Chargée de projet marketing', org: 'Agence, Montréal', note: 'Campagnes, budget média, suivi de performance.' }
      ],
      portfolio: [
        { title: 'Newsletter payante « Le dimanche »', type: 'Monétisation', meta: '1 900 abonnés, 24 % de rétention annuelle' }
      ],
      pro: { statut: 'Travailleuse autonome', tarif: 'Cible : 15 – 20 % de commission', outils: 'OnlyFans, Fanvue, Beehiiv, Notion', dispo: '32 h / semaine', paiement: 'Virement canadien / Wise' },
      looking: {
        title: 'Manager FR-CA, contrat et conformité d’abord',
        split: '15 – 20 % de commission',
        notes: 'Je veux un partenaire qui formalise tout par écrit, respecte les règles des plateformes et m’aide à tenir un rythme de vie normal.',
        must: ['Contrat écrit dès le départ', 'Français québécois ou européen', 'Conformité plateforme maîtrisée', 'Aucune heure de travail imposée le week-end']
      }
    },
    {
      id: 'c18', role: 'creator', name: 'Kelly Nguyen', handle: '@kellynguyen', tone: 't-moss', verified: false,
      city: 'Sydney', country: 'Australie', region: 'Océanie', joined: '2026-10-11', availability: 'active',
      exp: 'e2', network: 'n3', subs: 58000, status: 'active',
      specialties: ['growth_tt', 'lives', 'collabs', 'moderation'],
      languages: ['Anglais', 'Français'], platforms: ['onlyfans', 'tiktok', 'x'],
      bio: 'Compte de danse et lifestyle à Sydney, sessions live très suivies. Nouvelle sur Sève, je cherche une équipe qui couvre les heures européennes et nord-américaines.',
      goals: ['Ouvrir un nouveau marché', 'Déléguer le chatting', 'Doubler mon chiffre mensuel'],
      metrics: { revenue: '9 – 14 k€ / mois', growth: '+22 % sur 90 jours', response: 'Réponse < 5 h', retention: '52 % d’abonnés récurrents' },
      timeline: [
        { period: '2022 — aujourd’hui', title: 'Créatrice indépendante', org: 'OnlyFans, TikTok', note: '58 k abonnés, 3 lives par semaine.' },
        { period: '2019 — 2022', title: 'Danseuse professionnelle', org: 'Compagnies indépendantes, Sydney', note: 'Tournées et représentation.' }
      ],
      portfolio: [
        { title: 'Format live « vingt minutes »', type: 'Contenu', meta: 'Panier moyen 3,4 × les ventes hors live' },
        { title: 'Collab créatrice NZ', type: 'Croissance', meta: '2 800 abonnés croisés' }
      ],
      pro: { statut: 'ABN enregistré', tarif: 'Ouverte aux retainers', outils: 'OnlyFans, OBS, Notion', dispo: '40 h / semaine', paiement: 'Virement international' },
      looking: {
        title: 'Agence avec couverture de fuseaux horaires',
        split: '20 % de commission',
        notes: 'Mon audience est australienne et américaine : je cherche une équipe active sur ces créneaux, avec un reporting simple.',
        must: ['Couverture 6 h – 2 h (heure de Paris)', 'Anglais courant', 'Modération des lives incluse', 'Aucun achat d’abonnés']
      }
    },
    {
      id: 'c19', role: 'creator', name: 'Priscilla Abo', handle: '@priscillaabo', tone: 't-stone', verified: true,
      city: 'Abidjan', country: 'Côte d’Ivoire', region: 'Afrique', joined: '2026-09-02', availability: 'open',
      exp: 'e1', network: 'n2', subs: 8600, status: 'active',
      specialties: ['growth_ig', 'chatting', 'customs', 'pricing'],
      languages: ['Français', 'Anglais'], platforms: ['onlyfans', 'instagram'],
      bio: 'Début dans la création de contenu, audience ivoirienne et française. Je cherche un accompagnement pédagogique plutôt qu’un contrat ambitieux.',
      goals: ['Stabiliser mes revenus', 'Structurer mon planning de publication', 'Sortir du tout-DM et poser un persona'],
      metrics: { revenue: '900 – 1 800 € / mois', growth: '+41 % sur 90 jours', response: 'Réponse < 1 h', retention: '44 % d’abonnés récurrents' },
      timeline: [
        { period: '2025 — aujourd’hui', title: 'Créatrice indépendante', org: 'OnlyFans, Instagram', note: '8,6 k abonnés, démarrage autodidacte.' }
      ],
      portfolio: [{ title: 'Premier mois de monétisation', type: 'Monétisation', meta: 'Passage de 180 € à 1 100 € mensuels' }],
      pro: { statut: 'Indépendante', tarif: 'Splits dès 15 %', outils: 'OnlyFans, Canva, Google Sheets', dispo: '20 h / semaine', paiement: 'Mobile money / virement' },
      looking: {
        title: 'Mentor francophone, pédagogie avant tout',
        split: '15 – 20 % de commission',
        notes: 'Je préfère grandir lentement avec quelqu’un qui explique, plutôt qu’un gros contrat que je ne saurais pas tenir.',
        must: ['Francophone', 'Point hebdomadaire pédagogique', 'Pas d’avance de frais', 'Bienveillance et patience']
      }
    },
    {
      id: 'c20', role: 'creator', name: 'Mariana Duarte', handle: '@marianaduarte', tone: 't-sage', verified: true,
      city: 'São Paulo', country: 'Brésil', region: 'Amérique latine', joined: '2025-09-30', availability: 'busy',
      exp: 'e4', network: 'n4', subs: 238000, status: 'active',
      specialties: ['ppv', 'media_buying', 'analytics', 'chatting'],
      languages: ['Portugais', 'Espagnol', 'Anglais'], platforms: ['onlyfans', 'fansly', 'x'],
      bio: 'Compte à forte volumétrie, acquisition payante déjà en place. Je cherche une équipe capable de tenir la charge sans dégrader la qualité de réponse.',
      goals: ['Stabiliser mes revenus', 'Passer à un rythme soutenable', 'Déléguer le chatting'],
      metrics: { revenue: '31 – 44 k€ / mois', growth: '+9 % sur 90 jours', response: 'Réponse < 3 h', retention: '58 % d’abonnés récurrents' },
      timeline: [
        { period: '2020 — aujourd’hui', title: 'Créatrice indépendante', org: 'OnlyFans, Fansly', note: '238 k abonnés, budget média mensuel délégué.' },
        { period: '2017 — 2020', title: 'Community manager', org: 'E-commerce, São Paulo', note: 'Gestion de communautés larges, modération.' }
      ],
      portfolio: [
        { title: 'Pôle chatting 4 personnes', type: 'Organisation', meta: 'Temps de réponse moyen : 7 minutes' },
        { title: 'Campagne PPV de septembre', type: 'Monétisation', meta: '218 k€ de revenus sur le mois' }
      ],
      pro: { statut: 'MEI enregistrée', tarif: 'Retainer + commission', outils: 'OnlyFans, Fansly, Metabase, Slack', dispo: '50 h / semaine', paiement: 'Virement international' },
      looking: {
        title: 'Agence solide, capable de tenir 200 k+ abonnés',
        split: 'Retainer + 8 à 12 %',
        notes: 'Je ne cherche pas de croissance rapide mais de la fiabilité : continuité du service, équipe stable, indicateurs suivis.',
        must: ['Équipe de 5 personnes minimum', 'Expérience sur comptes 200 k+', 'Reporting hebdomadaire', 'Accord de confidentialité signé']
      }
    },
    {
      id: 'c21', role: 'creator', name: 'Elena Volkova', handle: '@elenavolkova', tone: 't-mist', verified: true,
      city: 'Varsovie', country: 'Pologne', region: 'Europe', joined: '2026-04-17', availability: 'open',
      exp: 'e3', network: 'n3', subs: 53000, status: 'active',
      specialties: ['content_video', 'customs', 'pricing', 'fanvue'],
      languages: ['Polonais', 'Ukrainien', 'Anglais', 'Russe'], platforms: ['onlyfans', 'fanvue', 'instagram'],
      bio: 'Compte sur-mesure premium, panier moyen élevé sur une audience anglophone. Je veux développer les offres personnalisées et déléguer la relation client.',
      goals: ['Doubler mon chiffre mensuel', 'Ouvrir un nouveau marché', 'Sortir du tout-DM et poser un persona'],
      metrics: { revenue: '14 – 21 k€ / mois', growth: '+19 % sur 90 jours', response: 'Réponse < 10 h', retention: '71 % d’abonnés récurrents' },
      timeline: [
        { period: '2022 — aujourd’hui', title: 'Créatrice indépendante', org: 'OnlyFans, Fanvue', note: '53 k abonnés, positionnement sur-mesure.' }
      ],
      portfolio: [
        { title: 'Offre sur-mesure « studio »', type: 'Monétisation', meta: 'Panier moyen 210 €' },
        { title: 'Boutique Fanvue', type: 'Monétisation', meta: '38 % du chiffre mensuel' }
      ],
      pro: { statut: 'JDG enregistrée', tarif: 'Cible : 20 % de commission', outils: 'OnlyFans, Fanvue, Notion, DaVinci', dispo: '38 h / semaine', paiement: 'Virement SEPA' },
      looking: {
        title: 'Manager anglophone, spécialiste du sur-mesure',
        split: '20 % de commission',
        notes: 'Je cherche quelqu’un qui sait vendre du personnalisé sans forcer, avec un ton respectueux et une vraie écoute client.',
        must: ['Anglais natif ou bilingue', 'Expérience sur-mesure / customs', 'Respect du consentement et des limites', 'Disponible en soirée européenne']
      }
    },
    {
      id: 'c22', role: 'creator', name: 'Tomás Herrera', handle: '@tomasherrera', tone: 't-sand', verified: true,
      city: 'Madrid', country: 'Espagne', region: 'Europe', joined: '2025-12-06', availability: 'active',
      exp: 'e3', network: 'n3', subs: 47000, status: 'active',
      specialties: ['lives', 'growth_x', 'collabs', 'branding'],
      languages: ['Espagnol', 'Anglais', 'Français'], platforms: ['onlyfans', 'x', 'instagram'],
      bio: 'Créateur fitness masculin, audience hispanophone et anglophone. Les lives fonctionnent très bien mais je n’arrive pas à déléguer la partie vente.',
      goals: ['Déléguer le chatting', 'Lancer une seconde plateforme', 'Stabiliser mes revenus'],
      metrics: { revenue: '8 – 13 k€ / mois', growth: '+15 % sur 90 jours', response: 'Réponse < 6 h', retention: '57 % d’abonnés récurrents' },
      timeline: [
        { period: '2022 — aujourd’hui', title: 'Créateur fitness', org: 'OnlyFans, X', note: '47 k abonnés, 4 lives par semaine.' },
        { period: '2018 — 2022', title: 'Préparateur physique', org: 'Salles indépendantes, Madrid', note: 'Suivi de clients, programmes personnalisés.' }
      ],
      portfolio: [
        { title: 'Rendez-vous live du jeudi', type: 'Contenu', meta: '1 200 spectateurs simultanés' },
        { title: 'Collab créateur UK', type: 'Croissance', meta: '3 600 abonnés croisés' }
      ],
      pro: { statut: 'Autónomo', tarif: 'Splits dès 18 %', outils: 'OnlyFans, OBS, Notion', dispo: '36 h / semaine', paiement: 'Virement SEPA' },
      looking: {
        title: 'Manager hispanophone, spécialiste vente en DM',
        split: '18 – 22 % de commission',
        notes: 'Je garde la production et les lives, je délègue la vente et la relance des abonnés inactifs.',
        must: ['Espagnol courant', 'Expérience vente en messages', 'Point quotidien court', 'Respect de ma ligne éditoriale']
      }
    },
    {
      id: 'c23', role: 'creator', name: 'Malik Ferreira', handle: '@malikferreira', tone: 't-clay', verified: false,
      city: 'Lisbonne', country: 'Portugal', region: 'Europe', joined: '2026-10-07', availability: 'active',
      exp: 'e2', network: 'n2', subs: 19200, status: 'active',
      specialties: ['growth_tt', 'ppv', 'analytics', 'moderation'],
      languages: ['Portugais', 'Anglais', 'Espagnol'], platforms: ['onlyfans', 'tiktok', 'fansly'],
      bio: 'Je viens de quitter un management qui ne m’apportait rien : contrat flou, aucune visibilité sur les chiffres. Je cherche mieux, avec des règles écrites.',
      goals: ['Stabiliser mes revenus', 'Doubler mon chiffre mensuel', 'Structurer mon planning de publication'],
      metrics: { revenue: '3,1 – 5,4 k€ / mois', growth: '+12 % sur 90 jours', response: 'Réponse < 2 h', retention: '49 % d’abonnés récurrents' },
      timeline: [
        { period: '2024 — aujourd’hui', title: 'Créateur indépendant', org: 'OnlyFans, Fansly', note: '19,2 k abonnés, précédent accompagnement rompu en septembre.' }
      ],
      portfolio: [{ title: 'Tableau de bord personnel', type: 'Analytics', meta: 'Suivi quotidien des ventes par offre' }],
      pro: { statut: 'Indépendant', tarif: 'Cible : 15 – 20 %', outils: 'OnlyFans, Google Sheets, CapCut', dispo: '30 h / semaine', paiement: 'SEPA / Wise' },
      looking: {
        title: 'Manager transparent, chiffres d’abord',
        split: '15 – 20 % de commission',
        notes: 'Après une mauvaise expérience, je veux un accès permanent à mes statistiques et un contrat lisible avant de commencer.',
        must: ['Accès complet aux statistiques', 'Contrat de 3 mois renouvelable', 'Aucun frais caché', 'Réponse sous 24 h']
      }
    },
    {
      id: 'c24', role: 'creator', name: 'Nina Kovač', handle: '@ninakovac', tone: 't-blush', verified: true,
      city: 'Zagreb', country: 'Croatie', region: 'Europe', joined: '2026-02-25', availability: 'booked',
      exp: 'e4', network: 'n4', subs: 132000, status: 'active',
      specialties: ['branding', 'media_buying', 'chatting', 'legal'],
      languages: ['Anglais', 'Allemand', 'Italien'], platforms: ['onlyfans', 'instagram', 'x'],
      bio: 'Compte établi avec une équipe interne de trois personnes. Je cherche un partenaire uniquement sur l’acquisition et la conformité, pas sur la production.',
      goals: ['Stabiliser mes revenus', 'Structurer mon planning de publication'],
      metrics: { revenue: '26 – 38 k€ / mois', growth: '+6 % sur 90 jours', response: 'Réponse < 4 h', retention: '64 % d’abonnés récurrents' },
      timeline: [
        { period: '2019 — aujourd’hui', title: 'Créatrice indépendante', org: 'OnlyFans, Instagram', note: '132 k abonnés, équipe interne de 3 personnes.' },
        { period: '2015 — 2019', title: 'Photographe freelance', org: 'Zagreb', note: 'Editorial et publicité.' }
      ],
      portfolio: [
        { title: 'Refonte du tunnel d’abonnement', type: 'Conversion', meta: 'Taux de conversion +27 %' }
      ],
      pro: { statut: 'd.o.o. enregistrée', tarif: 'Facturation mensuelle', outils: 'OnlyFans, Metabase, Slack, Figma', dispo: '25 h / semaine', paiement: 'Virement SEPA' },
      looking: {
        title: 'Partenaire acquisition uniquement',
        split: 'Facturation mensuelle (2 – 3 k€)',
        notes: 'Créneaux limités : je cherche un spécialiste média et conformité, en complément de mon équipe existante.',
        must: ['Expertise acquisition payante', 'Connaissance des règles plateformes', 'Aucun accès à la production', 'Rapport de performance mensuel']
      }
    },
    {
      id: 'c25', role: 'creator', name: 'Rachel Klein', handle: '@rachelklein', tone: 't-lilac', verified: true,
      city: 'Amsterdam', country: 'Pays-Bas', region: 'Europe', joined: '2026-05-30', availability: 'active',
      exp: 'e3', network: 'n3', subs: 76000, status: 'active',
      specialties: ['content_photo', 'customs', 'pricing', 'growth_ig'],
      languages: ['Néerlandais', 'Anglais', 'Allemand'], platforms: ['onlyfans', 'fanvue', 'instagram'],
      bio: 'Univers mode et lingerie, production studio deux fois par mois. Je veux améliorer la conversion et professionnaliser la relation client.',
      goals: ['Doubler mon chiffre mensuel', 'Déléguer le chatting', 'Sortir du tout-DM et poser un persona'],
      metrics: { revenue: '11 – 16 k€ / mois', growth: '+17 % sur 90 jours', response: 'Réponse < 12 h', retention: '62 % d’abonnés récurrents' },
      timeline: [
        { period: '2023 — aujourd’hui', title: 'Créatrice indépendante', org: 'OnlyFans, Fanvue', note: '76 k abonnés, deux journées studio par mois.' },
        { period: '2020 — 2023', title: 'Visual merchandiser', org: 'Maison de prêt-à-porter', note: 'Direction visuelle et mise en scène produit.' }
      ],
      portfolio: [
        { title: 'Coffret « studio »', type: 'Monétisation', meta: '1 100 ventes en 5 jours' },
        { title: 'Charte de marque personnelle', type: 'Branding', meta: 'Ton, couleurs, formats déclinés' }
      ],
      pro: { statut: 'ZZP enregistrée', tarif: 'Cible : 20 % de commission', outils: 'OnlyFans, Fanvue, Lightroom, Notion', dispo: '34 h / semaine', paiement: 'Virement SEPA' },
      looking: {
        title: 'Manager bilingue NL-EN, vente et fidélisation',
        split: '20 % de commission',
        notes: 'J’ai la production et l’image, il me manque une équipe de vente sérieuse et un suivi de la satisfaction des abonnés.',
        must: ['Anglais impeccable', 'Expérience fidélisation', 'Pas de spam de masse', 'Disponible en journée (CET)']
      }
    },
    {
      id: 'c26', role: 'creator', name: 'Jade Okonkwo', handle: '@jadeokonkwo', tone: 't-moss', verified: true,
      city: 'Londres', country: 'Royaume-Uni', region: 'Europe', joined: '2025-08-14', availability: 'open',
      exp: 'e4', network: 'n4', subs: 312000, status: 'active',
      specialties: ['ppv', 'media_buying', 'analytics', 'collabs'],
      languages: ['Anglais', 'Français'], platforms: ['onlyfans', 'fansly', 'x', 'reddit'],
      bio: 'Compte anglophone de grande taille, historiquement porté par l’acquisition payante. Je cherche à diversifier les canaux et à réduire ma dépendance aux plateformes de trafic.',
      goals: ['Ouvrir un nouveau marché', 'Stabiliser mes revenus', 'Lancer une seconde plateforme'],
      metrics: { revenue: '38 – 52 k€ / mois', growth: '+7 % sur 90 jours', response: 'Réponse < 5 h', retention: '55 % d’abonnés récurrents' },
      timeline: [
        { period: '2018 — aujourd’hui', title: 'Créatrice indépendante', org: 'OnlyFans, Fansly', note: '312 k abonnés, équipe de 6 personnes.' },
        { period: '2014 — 2018', title: 'Traffic manager', org: 'Groupe média, Londres', note: 'Budgets publicitaires multicanaux.' }
      ],
      portfolio: [
        { title: 'Test Reddit organique', type: 'Croissance', meta: '1 400 abonnés pour 0 € de média' },
        { title: 'Réduction du coût d’acquisition', type: 'Acquisition', meta: '−31 % de CPA en un trimestre' }
      ],
      pro: { statut: 'Ltd enregistrée', tarif: 'Retainer + commission', outils: 'OnlyFans, Fansly, Looker Studio, Slack', dispo: '40 h / semaine', paiement: 'Virement international' },
      looking: {
        title: 'Partenaire croissance organique et diversification',
        split: 'Retainer + 10 %',
        notes: 'Je veux moins dépendre de l’achat de trafic : communautés, collabs, SEO social, contenu long format.',
        must: ['Expertise organique', 'Anglais natif', 'Pas de fermes de bots', 'Test mensuel chiffré']
      }
    },
    {
      id: 'c27', role: 'creator', name: 'Camille Sutter', handle: '@camillesutter', tone: 't-stone', verified: true,
      city: 'Genève', country: 'Suisse', region: 'Europe', joined: '2026-01-19', availability: 'open',
      exp: 'e3', network: 'n3', subs: 29000, status: 'active',
      specialties: ['planning', 'pricing', 'content_video', 'legal'],
      languages: ['Français', 'Allemand', 'Anglais'], platforms: ['onlyfans', 'patreon', 'instagram'],
      bio: 'Compte discret, audience suisse et française, revenus très réguliers. Je cherche à professionnaliser la gestion sans exposer ma vie privée.',
      goals: ['Structurer mon planning de publication', 'Stabiliser mes revenus', 'Lancer une seconde plateforme'],
      metrics: { revenue: '5,2 – 7,8 k€ / mois', growth: '+11 % sur 90 jours', response: 'Réponse < 9 h', retention: '69 % d’abonnés récurrents' },
      timeline: [
        { period: '2023 — aujourd’hui', title: 'Créatrice indépendante', org: 'OnlyFans, Patreon', note: '29 k abonnés, publication hebdomadaire régulière.' },
        { period: '2017 — 2023', title: 'Gestionnaire de paie', org: 'Genève', note: 'Administration, conformité, rigueur documentaire.' }
      ],
      portfolio: [
        { title: 'Calendrier éditorial annuel', type: 'Organisation', meta: '48 semaines planifiées à l’avance' }
      ],
      pro: { statut: 'Indépendante', tarif: 'Cible : 18 % de commission', outils: 'OnlyFans, Patreon, Notion', dispo: '28 h / semaine', paiement: 'Virement SEPA / TWINT' },
      looking: {
        title: 'Manager discret, respect absolu de l’anonymat',
        split: '18 % de commission',
        notes: 'Priorité à la discrétion et à la régularité. Aucune publication hors du calendrier validé ensemble.',
        must: ['Discrétion contractuelle', 'Validation préalable de chaque publication', 'Pas de collaborateur externe non déclaré', 'Français ou allemand']
      }
    },
    {
      id: 'c28', role: 'creator', name: 'Zoé Ferrand', handle: '@zoeferrand', tone: 't-sage', verified: false,
      city: 'Bordeaux', country: 'France', region: 'Europe', joined: '2026-10-12', availability: 'active',
      exp: 'e2', network: 'n2', subs: 11700, status: 'active',
      specialties: ['chatting', 'lives', 'growth_tt', 'customs'],
      languages: ['Français', 'Anglais'], platforms: ['onlyfans', 'tiktok'],
      bio: 'Je démarre sérieusement après un an à mi-temps sur la plateforme. Je veux un premier vrai accompagnement, avec des objectifs réalistes.',
      goals: ['Stabiliser mes revenus', 'Déléguer le chatting', 'Doubler mon chiffre mensuel'],
      metrics: { revenue: '1,6 – 2,9 k€ / mois', growth: '+28 % sur 90 jours', response: 'Réponse < 1 h', retention: '46 % d’abonnés récurrents' },
      timeline: [
        { period: '2025 — aujourd’hui', title: 'Créatrice indépendante', org: 'OnlyFans, TikTok', note: '11,7 k abonnés, activité en parallèle de mes études.' }
      ],
      portfolio: [{ title: 'Première série de lives', type: 'Contenu', meta: 'Panier moyen +22 % sur les semaines de live' }],
      pro: { statut: 'Micro-entreprise', tarif: 'Splits dès 15 %', outils: 'OnlyFans, CapCut, Notion', dispo: '22 h / semaine', paiement: 'Virement SEPA' },
      looking: {
        title: 'Premier manager, cadre clair et souple',
        split: '15 – 20 % de commission',
        notes: 'Je suis étudiante : j’ai besoin d’horaires souples et d’un accompagnement honnête sur ce qui est réaliste.',
        must: ['Horaires souples', 'Francophone', 'Objectifs écrits et réalistes', 'Aucun engagement de volume']
      }
    },
    {
      id: 'c29', role: 'creator', name: 'Anna Bauer', handle: '@annabauer', tone: 't-mist', verified: true,
      city: 'Berlin', country: 'Allemagne', region: 'Europe', joined: '2025-10-27', availability: 'busy',
      exp: 'e4', network: 'n4', subs: 148000, status: 'active',
      specialties: ['growth_ig', 'branding', 'ppv', 'moderation'],
      languages: ['Allemand', 'Anglais'], platforms: ['onlyfans', 'instagram', 'fanvue'],
      bio: 'Compte allemand à forte croissance, deux personnes autour de moi. Je cherche à structurer la modération et à tester des offres plus haut de gamme.',
      goals: ['Stabiliser mes revenus', 'Passer à un rythme soutenable', 'Sortir du tout-DM et poser un persona'],
      metrics: { revenue: '22 – 31 k€ / mois', growth: '+14 % sur 90 jours', response: 'Réponse < 4 h', retention: '60 % d’abonnés récurrents' },
      timeline: [
        { period: '2020 — aujourd’hui', title: 'Créatrice indépendante', org: 'OnlyFans, Fanvue', note: '148 k abonnés, 2 personnes en appui.' },
        { period: '2016 — 2020', title: 'Rédactrice web freelance', org: 'Berlin', note: 'Contenus mode et culture.' }
      ],
      portfolio: [
        { title: 'Offre premium « salon »', type: 'Monétisation', meta: 'Panier moyen 3 × supérieur' },
        { title: 'Charte de modération', type: 'Organisation', meta: 'Réponses types, escalade en 10 minutes' }
      ],
      pro: { statut: 'GmbH enregistrée', tarif: 'Cible : 18 – 22 %', outils: 'OnlyFans, Fanvue, Notion, Slack', dispo: '42 h / semaine', paiement: 'Virement SEPA' },
      looking: {
        title: 'Agence germanophone, modération et offres',
        split: '18 – 22 % de commission',
        notes: 'J’ai besoin d’être soulagée sur la modération et de tester des offres plus travaillées, sans changer mon ton.',
        must: ['Allemand courant', 'Modération 7 j / 7', 'Pas de rupture de ton', 'Rapport hebdomadaire']
      }
    },
    {
      id: 'c30', role: 'creator', name: 'Leila Haddad', handle: '@leilahaddad', tone: 't-lilac', verified: true,
      city: 'Dubaï', country: 'Émirats arabes unis', region: 'Moyen-Orient', joined: '2026-06-21', availability: 'active',
      exp: 'e3', network: 'n3', subs: 68000, status: 'active',
      specialties: ['media_buying', 'ppv', 'pricing', 'growth_x'],
      languages: ['Arabe', 'Français', 'Anglais'], platforms: ['onlyfans', 'x', 'instagram'],
      bio: 'Compte basé aux Émirats, audience francophone et anglophone. J’investis déjà en publicité mais je manque de méthode sur les prix et les relances.',
      goals: ['Doubler mon chiffre mensuel', 'Stabiliser mes revenus', 'Déléguer le chatting'],
      metrics: { revenue: '13 – 19 k€ / mois', growth: '+21 % sur 90 jours', response: 'Réponse < 6 h', retention: '56 % d’abonnés récurrents' },
      timeline: [
        { period: '2023 — aujourd’hui', title: 'Créatrice indépendante', org: 'OnlyFans, X', note: '68 k abonnés, acquisition payante depuis janvier.' },
        { period: '2019 — 2023', title: 'Chargée d’achat média', org: 'Agence, Dubaï', note: 'Campagnes Meta et TikTok, budgets 5 chiffres.' }
      ],
      portfolio: [
        { title: 'Test créatifs TikTok', type: 'Acquisition', meta: 'ROAS 2,7 sur 30 jours' },
        { title: 'Grille tarifaire revue', type: 'Pricing', meta: 'Panier moyen +19 %' }
      ],
      pro: { statut: 'Free zone licence', tarif: 'Retainer + 12 %', outils: 'OnlyFans, Meta Ads, Sheets', dispo: '38 h / semaine', paiement: 'Virement international' },
      looking: {
        title: 'Data et vente en messages, multilingue',
        split: 'Retainer + 12 %',
        notes: 'Je cherche un partenaire qui pilote l’acquisition et la vente, avec des rapports chiffrés et une vraie rigueur sur le consentement.',
        must: ['Arabe / français / anglais', 'Achat média encadré', 'Rapports de performance hebdomadaires', 'Conformité et consentement stricts']
      }
    },
    {
      id: 'c31', role: 'creator', name: 'Manon Vasseur', handle: '@manonvasseur', tone: 't-clay', verified: true,
      city: 'Nantes', country: 'France', region: 'Europe', joined: '2026-03-13', availability: 'open',
      exp: 'e3', network: 'n3', subs: 23400, status: 'active',
      specialties: ['customs', 'chatting', 'planning', 'growth_tt'],
      languages: ['Français', 'Anglais', 'Espagnol'], platforms: ['onlyfans', 'tiktok', 'fanvue'],
      bio: 'Positionnement confiance et proximité, très peu de promotions agressives. Je veux monter en gamme et déléguer la vente sans perdre mon ton.',
      goals: ['Déléguer le chatting', 'Doubler mon chiffre mensuel', 'Passer à un rythme soutenable'],
      metrics: { revenue: '4,3 – 6,7 k€ / mois', growth: '+18 % sur 90 jours', response: 'Réponse < 90 min', retention: '72 % d’abonnés récurrents' },
      timeline: [
        { period: '2023 — aujourd’hui', title: 'Créatrice indépendante', org: 'OnlyFans, Fanvue', note: '23,4 k abonnés, forte fidélité, croissance lente.' },
        { period: '2019 — 2023', title: 'Auxiliaire de vie', org: 'Loire-Atlantique', note: 'Écoute, patience, accompagnement.' }
      ],
      portfolio: [
        { title: 'Programme d’abonnés fidèles', type: 'Fidélisation', meta: '72 % de récurrence' }
      ],
      pro: { statut: 'Micro-entreprise', tarif: 'Cible : 20 % de commission', outils: 'OnlyFans, Fanvue, Notion', dispo: '26 h / semaine', paiement: 'Virement SEPA' },
      looking: {
        title: 'Manager francophone, respect du ton et de la confiance',
        split: '20 % de commission',
        notes: 'Mon audience vient pour la bienveillance : je refuse les techniques de vente agressives, mais je veux gagner correctement ma vie.',
        must: ['Vente respectueuse', 'Francophone', 'Formation à la vente', 'Aucun script intrusif']
      }
    },
    {
      id: 'c32', role: 'creator', name: 'Yasmine Chérif', handle: '@yasminecherif', tone: 't-sand', verified: false,
      city: 'Tunis', country: 'Tunisie', region: 'Afrique', joined: '2026-09-26', availability: 'open',
      exp: 'e2', network: 'n2', subs: 6700, status: 'active',
      specialties: ['moderation', 'growth_ig', 'chatting', 'content_photo'],
      languages: ['Arabe', 'Français', 'Italien'], platforms: ['onlyfans', 'instagram'],
      bio: 'Compte discret sur une niche bien identifiée, communauté très soudée. Je cherche une structure francophone pour lancer la monétisation sérieusement.',
      goals: ['Stabiliser mes revenus', 'Ouvrir un nouveau marché', 'Structurer mon planning de publication'],
      metrics: { revenue: '700 – 1 500 € / mois', growth: '+33 % sur 90 jours', response: 'Réponse < 3 h', retention: '41 % d’abonnés récurrents' },
      timeline: [
        { period: '2025 — aujourd’hui', title: 'Créatrice indépendante', org: 'OnlyFans, Instagram', note: '6,7 k abonnés, lancement progressif.' }
      ],
      portfolio: [{ title: 'Audit de profil', type: 'Organisation', meta: 'Bio et offres retravaillées, +33 % de croissance' }],
      pro: { statut: 'Indépendante', tarif: 'Splits dès 15 %', outils: 'OnlyFans, Canva, Sheets', dispo: '24 h / semaine', paiement: 'Virement international' },
      looking: {
        title: 'Accompagnement francophone, palier 20 k abonnés',
        split: '15 – 20 % de commission',
        notes: 'Je veux un plan clair sur six mois, avec des paliers chiffrés et de la pédagogie sur la vente et la production.',
        must: ['Francophone ou arabophone', 'Plan à 6 mois', 'Disponibilité en soirée', 'Respect du cadre légal']
      }
    },
    {
      id: 'c33', role: 'creator', name: 'Élias Kaminski', handle: '@eliaskaminski', tone: 't-moss', verified: true,
      city: 'Vienne', country: 'Autriche', region: 'Europe', joined: '2026-04-03', availability: 'active',
      exp: 'e3', network: 'n3', subs: 39000, status: 'active',
      specialties: ['lives', 'customs', 'analytics', 'content_video'],
      languages: ['Allemand', 'Polonais', 'Anglais'], platforms: ['onlyfans', 'fansly', 'reddit'],
      bio: 'Créateur masculin, contenu sur-mesure et lives. Les revenus sont corrects mais irréguliers selon les mois ; je veux lisser et structurer.',
      goals: ['Stabiliser mes revenus', 'Passer à un rythme soutenable', 'Lancer une seconde plateforme'],
      metrics: { revenue: '6,4 – 9,8 k€ / mois', growth: '+12 % sur 90 jours', response: 'Réponse < 7 h', retention: '53 % d’abonnés récurrents' },
      timeline: [
        { period: '2022 — aujourd’hui', title: 'Créateur indépendant', org: 'OnlyFans, Fansly', note: '39 k abonnés, irrégularité saisonnière marquée.' },
        { period: '2018 — 2022', title: 'Technicien audiovisuel', org: 'Vienne', note: 'Tournage, montage, étalonnage.' }
      ],
      portfolio: [
        { title: 'Calendrier de lives', type: 'Organisation', meta: 'Revenus mensuels lissés à ±8 %' }
      ],
      pro: { statut: 'Indépendant', tarif: 'Splits dès 18 %', outils: 'OnlyFans, Fansly, DaVinci, Sheets', dispo: '32 h / semaine', paiement: 'Virement SEPA' },
      looking: {
        title: 'Manager germanophone, régularité et relances',
        split: '18 % de commission',
        notes: 'Je cherche de la méthode : relances, offres ponctuelles, suivi des abonnés inactifs.',
        must: ['Allemand ou anglais', 'Discipline de suivi', 'Pas de promesse de revenus', 'Point mensuel chiffré']
      }
    },
    {
      id: 'c34', role: 'creator', name: 'Mélanie Dorval', handle: '@melaniedorval', tone: 't-blush', verified: true,
      city: 'Miami', country: 'États-Unis', region: 'Amérique du Nord', joined: '2025-07-16', availability: 'booked',
      exp: 'e5', network: 'n5', subs: 720000, status: 'active',
      specialties: ['ppv', 'media_buying', 'analytics', 'branding'],
      languages: ['Français', 'Anglais', 'Espagnol'], platforms: ['onlyfans', 'fanvue', 'x', 'instagram'],
      bio: 'Compte de grande envergure, équipe de huit personnes réparties entre Miami et Paris. Je cherche un partenaire sur des projets précis, pas une gestion complète.',
      goals: ['Ouvrir un nouveau marché', 'Stabiliser mes revenus'],
      metrics: { revenue: '95 – 140 k€ / mois', growth: '+5 % sur 90 jours', response: 'Réponse < 2 h', retention: '62 % d’abonnés récurrents' },
      timeline: [
        { period: '2017 — aujourd’hui', title: 'Créatrice indépendante', org: 'OnlyFans, Fanvue', note: '720 k abonnés, équipe de 8 personnes.' },
        { period: '2013 — 2017', title: 'Mannequin commercial', org: 'Agences internationales', note: 'Campagnes print et digital.' }
      ],
      portfolio: [
        { title: 'Lancement marché francophone', type: 'Croissance', meta: '+28 k abonnés en 5 mois' },
        { title: 'Studio interne', type: 'Organisation', meta: '8 personnes, 2 sites' }
      ],
      pro: { statut: 'LLC enregistrée', tarif: 'Facturation mensuelle', outils: 'OnlyFans, Meta Ads, Looker, Slack', dispo: '20 h / semaine', paiement: 'Virement international' },
      looking: {
        title: 'Prestataires experts, mission ponctuelle',
        split: 'Facturation mensuelle (4 – 8 k€)',
        notes: 'Missions ciblées : ouverture du marché latino, refonte des offres, audit de l’équipe. Créneaux de réunion limités.',
        must: ['Expérience 500 k+ abonnés', 'Résultats chiffrés dans le dossier', 'Anglais ou espagnol', 'Aucun accès aux comptes personnels']
      }
    }
  ];

  const managers = [
    {
      id: 'm1', role: 'manager', name: 'Atelier Nova', kind: 'Agence de management', tone: 't-sage', verified: true, demo: false,
      city: 'Paris', country: 'France', region: 'Europe', joined: '2024-09-12', availability: 'open',
      exp: 'e4', team: 't3', teamSize: 9, creatorsCount: 14, commission: '20 – 25 %', status: 'active', featured: true,
      specialties: ['chatting', 'ppv', 'branding', 'analytics'],
      languages: ['Français', 'Anglais'], platforms: ['onlyfans', 'fanvue'],
      bio: 'Agence parisienne de 9 personnes spécialisée dans la monétisation des comptes francophones. Nous accompagnons 14 créatrices et créateurs, avec un pôle chatting dédié et un reporting mensuel.',
      goals: ['Structurer un compte en croissance', 'Scaler un compte établi', 'Tisser une relation long terme'],
      metrics: { clients: '14 créateurs', growth: '+21 % de revenus moyens sur 6 mois', response: 'Réponse < 24 h', retention: 'Durée moyenne : 2,4 ans' },
      timeline: [
        { period: '2024 — aujourd’hui', title: 'Fondation de l’atelier', org: 'Paris', note: '9 personnes, 14 comptes accompagnés, pôle chatting de 5 personnes.' },
        { period: '2019 — 2024', title: 'Directrice de la monétisation', org: 'Plateforme de créateurs', note: 'Accompagnement de 200+ créateurs, construction des playbooks de vente.' }
      ],
      portfolio: [
        { title: 'Compte lifestyle FR — 6 mois', type: 'Scaling', meta: 'Revenus ×2,4 sans hausse de production' },
        { title: 'Pôle chatting francophone', type: 'Organisation', meta: '5 personnes, 40 h / jour de couverture' },
        { title: 'Playbook pricing 2025', type: 'Méthode', meta: 'Testé sur 11 comptes' }
      ],
      pro: { statut: 'SARL enregistrée', tarif: '20 – 25 % de commission', outils: 'Notion, Looker Studio, Slack', dispo: '2 comptes disponibles', paiement: 'Facturation mensuelle' },
      looking: {
        title: 'Créatrices et créateurs francophones, 20 k à 200 k abonnés',
        split: '20 – 25 % de commission',
        notes: 'Nous recherchons des profils sérieux, réguliers dans la production, qui souhaitent déléguer la vente tout en gardant la direction artistique.',
        must: ['Production régulière', 'Persona clair', 'Contrat de 6 mois minimum', 'Rien d’illicite ou de contraire à notre charte']
      }
    },
    {
      id: 'm2', role: 'manager', name: 'Halo Management', kind: 'Agence de management', tone: 't-mist', verified: true, demo: true,
      city: 'Paris', country: 'France', region: 'Europe', joined: '2024-10-02', availability: 'open',
      exp: 'e5', team: 't3', teamSize: 12, creatorsCount: 21, commission: '20 – 30 %', status: 'active', featured: true,
      specialties: ['chatting', 'growth_tt', 'growth_ig', 'planning', 'analytics'],
      languages: ['Français', 'Anglais', 'Espagnol'], platforms: ['onlyfans', 'fanvue', 'fansly'],
      bio: 'Halo accompagne 21 créatrices et créateurs francophones et anglophones. Équipe de 12 personnes à Paris, Madrid et Casablanca. Nous sommes spécialisés dans la structuration des comptes en palier de croissance.',
      goals: ['Structurer un compte en croissance', 'Développer une offre premium', 'Recruter pour notre équipe chatting'],
      metrics: { clients: '21 créateurs', growth: '+27 % de revenus moyens sur 6 mois', response: 'Réponse < 6 h', retention: 'Durée moyenne : 1,8 an' },
      timeline: [
        { period: '2024 — aujourd’hui', title: 'Agence Halo', org: 'Paris · Madrid · Casablanca', note: '12 personnes, 21 comptes, 3 marchés linguistiques.' },
        { period: '2018 — 2024', title: 'Création et direction de ClickNord', org: 'Agence de contenu', note: 'Direction d’une équipe de 30 personnes, acquisition et monétisation.' }
      ],
      portfolio: [
        { title: 'Programme « Palier 20 k »', type: 'Méthode', meta: '9 comptes accompagnés, +180 % en moyenne' },
        { title: 'Équipe chatting 3 marchés', type: 'Organisation', meta: 'FR, EN, ES — 24 h / 24' },
        { title: 'Reporting hebdomadaire client', type: 'Analytics', meta: 'Tableau de bord par créateur' }
      ],
      pro: { statut: 'SAS enregistrée', tarif: '20 – 30 % de commission', outils: 'Notion, Metabase, Slack, Zapier', dispo: '3 comptes disponibles', paiement: 'Facturation mensuelle' },
      looking: {
        title: 'Comptes francophones et anglophones, 10 k à 300 k abonnés',
        split: '20 – 30 % de commission',
        notes: 'Nous cherchons des créatrices et créateurs motivés, prêts à déléguer la totalité des conversations, avec une production régulière et un cadre de travail serein.',
        must: ['Régularité de production', 'Ouverture à un suivi hebdomadaire', 'Charte Sève acceptée sans réserve']
      }
    },
    {
      id: 'm3', role: 'manager', name: 'Marc Vidal', kind: 'Manager indépendant', tone: 't-sand', verified: true,
      city: 'Barcelone', country: 'Espagne', region: 'Europe', joined: '2025-01-08', availability: 'active',
      exp: 'e4', team: 't1', teamSize: 1, creatorsCount: 4, commission: '25 %', status: 'active', featured: true,
      specialties: ['chatting', 'customs', 'pricing', 'reddit'],
      languages: ['Français', 'Espagnol', 'Anglais'], platforms: ['onlyfans', 'x', 'reddit'],
      bio: 'Manager indépendant franco-espagnol, 4 comptes en portefeuille. Je travaille en relation très directe : trois échanges par semaine et un accès permanent aux statistiques.',
      goals: ['Lancer une nouvelle créatrice / un nouveau créateur', 'Tisser une relation long terme', 'Structurer un compte en croissance'],
      metrics: { clients: '4 créateurs', growth: '+34 % de revenus moyens sur 6 mois', response: 'Réponse < 3 h', retention: 'Durée moyenne : 2,1 ans' },
      timeline: [
        { period: '2023 — aujourd’hui', title: 'Manager indépendant', org: 'Barcelone', note: '4 créatrices, spécialisation chatting personnalisé et pricing.' },
        { period: '2017 — 2023', title: 'Responsable support client', org: 'Startup SaaS', note: 'Culture du service et de la réponse rapide.' }
      ],
      portfolio: [
        { title: 'Compte FR — palier 5 k → 12 k€ / mois', type: 'Scaling', meta: 'En 5 mois, sans budget publicitaire' },
        { title: 'Grille tarifaire personnalisée', type: 'Pricing', meta: 'Panier moyen ×1,7' }
      ],
      pro: { statut: 'Auto-entrepreneur', tarif: '25 % de commission', outils: 'Notion, Google Sheets, Telegram', dispo: '1 compte disponible', paiement: 'Facturation mensuelle' },
      looking: {
        title: 'Créateur ou créatrice francophone prêt(e) à déléguer',
        split: '25 % de commission',
        notes: 'Je prends un maximum de deux nouveaux comptes par semestre pour garder la qualité du suivi.',
        must: ['Francophone', 'Réactivité sur les demandes de validation', 'Aucun contenu illicite']
      }
    },
    {
      id: 'm4', role: 'manager', name: 'Studio Bruma', kind: 'Studio de production', tone: 't-lilac', verified: true,
      city: 'Bruxelles', country: 'Belgique', region: 'Europe', joined: '2024-07-21', availability: 'busy',
      exp: 'e4', team: 't2', teamSize: 4, creatorsCount: 6, commission: 'Offre au forfait', status: 'active',
      specialties: ['content_photo', 'content_video', 'branding', 'moderation'],
      languages: ['Français', 'Néerlandais', 'Anglais'], platforms: ['onlyfans', 'fanvue', 'instagram'],
      bio: 'Studio photo et vidéo basé à Bruxelles. Nous produisons deux shootings par mois et gérons la modération, avec une exigence forte sur la qualité d’image.',
      goals: ['Développer une offre premium', 'Tisser une relation long terme'],
      metrics: { clients: '6 créateurs', growth: '+12 % d’engagement sur 6 mois', response: 'Réponse < 12 h', retention: 'Durée moyenne : 1,5 an' },
      timeline: [
        { period: '2023 — aujourd’hui', title: 'Studio Bruma', org: 'Bruxelles', note: '12 shootings par mois, 2 salles, équipe de 4 personnes.' },
        { period: '2016 — 2023', title: 'Directeur artistique freelance', org: 'Bruxelles', note: 'Campagnes de marque et éditoriaux.' }
      ],
      portfolio: [
        { title: 'Forfait « Studio 2×/mois »', type: 'Production', meta: '180 visuels et 12 vidéos par mois' },
        { title: 'Retouche et colorimétrie', type: 'Direction artistique', meta: 'Étalonnage sur mesure' }
      ],
      pro: { statut: 'SPRL enregistrée', tarif: 'Forfait mensuel + 8 % sur les revenus', outils: 'Capture One, Premiere Pro, Frame.io', dispo: 'Capacité 2 comptes', paiement: 'Facturation mensuelle' },
      looking: {
        title: 'Créateurs et créatrices belges ou du Nord de la France',
        split: 'Forfait mensuel, commission réduite',
        notes: 'Nous cherchons des personnes qui aiment le travail d’image soigné et acceptent une production encadrée.',
        must: ['Disponible pour deux jours de tournage par mois', 'Présence à Bruxelles', 'Goût pour un rendu éditorial']
      }
    },
    {
      id: 'm5', role: 'manager', name: 'Kaïna Sow', kind: 'Equipe de chatting', tone: 't-clay', verified: true,
      city: 'Dakar', country: 'Sénégal', region: 'Afrique', joined: '2025-02-19', availability: 'active',
      exp: 'e3', team: 't2', teamSize: 5, creatorsCount: 9, commission: '18 – 22 %', status: 'active',
      specialties: ['chatting', 'moderation', 'lives', 'fanvue'],
      languages: ['Français', 'Anglais', 'Portugais'], platforms: ['onlyfans', 'fanvue'],
      bio: 'Équipe de chatting francophone composée de 5 personnes, spécialisée dans les gros volumes de messages. Nous travaillons sur créneaux élargis avec des scripts validés par la créatrice.',
      goals: ['Recruter pour notre équipe chatting', 'Scaler un compte établi', 'Tisser une relation long terme'],
      metrics: { clients: '9 créateurs', growth: '+22 % de revenus moyens sur 6 mois', response: 'Réponse < 2 h', retention: 'Durée moyenne : 1,6 an' },
      timeline: [
        { period: '2024 — aujourd’hui', title: 'Direction de l’équipe', org: 'Dakar', note: '5 chatters formés, couverture de 8 h à 2 h du matin.' },
        { period: '2020 — 2024', title: 'Community manager', org: 'Agence de contenu', note: 'Gestion de communautés de 100 k+ membres.' }
      ],
      portfolio: [
        { title: 'Chattering 3 langues', type: 'Organisation', meta: 'FR, EN, PT — 9 comptes' },
        { title: 'Scripts de relance abonnés dormants', type: 'Méthode', meta: '+26 % de revenus sur abonnés inactifs' }
      ],
      pro: { statut: 'Structure déclarée', tarif: '18 – 22 % de commission', outils: 'Slack, Notion, OnlyFans', dispo: '2 équipes disponibles', paiement: 'Facturation mensuelle' },
      looking: {
        title: 'Créateurs francophones avec fort volume de DM',
        split: '18 – 22 % de commission',
        notes: 'Nous sommes à l’aise avec les comptes qui reçoivent plus de 800 messages par jour.',
        must: ['Volume de messages élevé', 'Charte de ton écrite', 'Disponibilité pour un brief hebdomadaire']
      }
    },
    {
      id: 'm6', role: 'manager', name: 'Elias Rocha', kind: 'Manager indépendant', tone: 't-stone', verified: true,
      city: 'Porto', country: 'Portugal', region: 'Europe', joined: '2025-04-25', availability: 'open',
      exp: 'e3', team: 't1', teamSize: 1, creatorsCount: 3, commission: '20 – 25 %', status: 'active',
      specialties: ['growth_x', 'reddit', 'media_buying', 'analytics'],
      languages: ['Portugais', 'Anglais', 'Français'], platforms: ['onlyfans', 'x', 'reddit', 'tiktok'],
      bio: 'Manager lusophone spécialisé acquisition : Reddit, X et TikTok. Trois comptes en portefeuille, dont deux en marché anglophone.',
      goals: ['Lancer une nouvelle créatrice / un nouveau créateur', 'Développer une offre premium'],
      metrics: { clients: '3 créateurs', growth: '+41 % de trafic qualifié sur 6 mois', response: 'Réponse < 8 h', retention: 'Durée moyenne : 1,2 an' },
      timeline: [
        { period: '2024 — aujourd’hui', title: 'Manager indépendant', org: 'Porto', note: '3 comptes, spécialisation acquisition Reddit et X.' },
        { period: '2019 — 2024', title: 'Traffic manager', org: 'Agence performance, Lisbonne', note: 'Media buying et croissance organique.' }
      ],
      portfolio: [
        { title: 'Machine Reddit Portugal', type: 'Acquisition', meta: '28 k visiteurs qualifiés / mois' },
        { title: 'Test créas TikTok', type: 'Croissance', meta: 'Coût par abonné payant : 2,10 €' }
      ],
      pro: { statut: 'Auto-entrepreneur', tarif: '20 – 25 % de commission', outils: 'Reddit, X, GA4, Notion', dispo: '2 comptes disponibles', paiement: 'Wise / SEPA' },
      looking: {
        title: 'Comptes anglophones ou lusophones à forte audience organique',
        split: '20 – 25 % de commission',
        notes: 'Je construis la croissance par les communautés et le contenu organique, pas par la pression publicitaire.',
        must: ['Audience organique existante', 'Ouverture aux marchés UK / US / BR', 'Suivi bimensuel']
      }
    },
    {
      id: 'm7', role: 'manager', name: 'Lumen Agency', kind: 'Agence de management', tone: 't-moss', verified: true,
      city: 'Genève', country: 'Suisse', region: 'Europe', joined: '2024-06-30', availability: 'open',
      exp: 'e5', team: 't4', teamSize: 22, creatorsCount: 38, commission: '18 – 24 %', status: 'active',
      specialties: ['chatting', 'ppv', 'pricing', 'legal', 'analytics'],
      languages: ['Français', 'Allemand', 'Anglais', 'Italien'], platforms: ['onlyfans', 'fanvue', 'fansly', 'patreon'],
      bio: 'Agence suisse de 22 personnes, 38 comptes accompagnés. Cadre contractuel strict, conformité vérifiée, et process de monétisation éprouvés sur quatre marchés.',
      goals: ['Scaler un compte établi', 'Développer une offre premium', 'Structurer un compte en croissance'],
      metrics: { clients: '38 créateurs', growth: '+19 % de revenus moyens sur 6 mois', response: 'Réponse < 24 h', retention: 'Durée moyenne : 2,7 ans' },
      timeline: [
        { period: '2022 — aujourd’hui', title: 'Agence Lumen', org: 'Genève', note: '22 personnes, 38 comptes, pôle conformité et juridique interne.' },
        { period: '2015 — 2022', title: 'Direction d’une agence de talents', org: 'Zurich', note: 'Gestion de contrats et de partenariats internationaux.' }
      ],
      portfolio: [
        { title: 'Cadre contractuel type', type: 'Conformité', meta: 'Revu par un cabinet genevois' },
        { title: 'Programme de formation des chatters', type: 'Organisation', meta: '6 modules, 30 heures' },
        { title: 'Pilotage multi-plateformes', type: 'Analytics', meta: '4 plateformes, un seul tableau de bord' }
      ],
      pro: { statut: 'SA enregistrée', tarif: '18 – 24 % de commission', outils: 'Metabase, Notion, DocuSign', dispo: '4 comptes disponibles', paiement: 'Facturation mensuelle' },
      looking: {
        title: 'Comptes établis (50 k+ abonnés), toutes langues européennes',
        split: '18 – 24 % de commission',
        notes: 'Nous recherchons des créatrices et créateurs qui veulent une structure solide, avec un cadre clair et une vraie éthique de travail.',
        must: ['Compte établi', 'Contrat écrit', 'Paiements traçables', 'Respect de la charte de conformité']
      }
    },
    {
      id: 'm8', role: 'manager', name: 'Sasha Ivanova', kind: 'Manager indépendant', tone: 't-blush', verified: false,
      city: 'Vilnius', country: 'Lituanie', region: 'Europe', joined: '2025-08-04', availability: 'active',
      exp: 'e2', team: 't1', teamSize: 1, creatorsCount: 2, commission: '25 %', status: 'active',
      specialties: ['growth_tt', 'customs', 'lives', 'moderation'],
      languages: ['Russe', 'Anglais', 'Ukrainien'], platforms: ['onlyfans', 'tiktok', 'fansly'],
      bio: 'Manager russophone et anglophone, spécialisé TikTok. Deux comptes en portefeuille, méthodes d’acquisition organique testées sur le marché anglophone.',
      goals: ['Lancer une nouvelle créatrice / un nouveau créateur', 'Recruter pour notre équipe chatting'],
      metrics: { clients: '2 créateurs', growth: '+52 % d’abonnés sur 6 mois', response: 'Réponse < 12 h', retention: 'Durée moyenne : 0,9 an' },
      timeline: [
        { period: '2025 — aujourd’hui', title: 'Manager indépendante', org: 'Vilnius', note: '2 comptes, croissance TikTok et formats courts.' },
        { period: '2023 — 2025', title: 'Monteuse vidéo', org: 'Studio local', note: 'Montage et formats viraux pour créateurs.' }
      ],
      portfolio: [
        { title: 'Programme TikTok anglophone', type: 'Croissance', meta: '2,4 M de vues cumulées en 90 jours' }
      ],
      pro: { statut: 'Auto-entrepreneuse', tarif: '25 % de commission', outils: 'CapCut, TikTok, Fansly', dispo: '2 comptes disponibles', paiement: 'Wise / crypto déconseillé' },
      looking: {
        title: 'Créateurs russophones ou anglophones, formats courts',
        split: '25 % de commission',
        notes: 'Je cherche des personnes à l’aise avec la vidéo verticale et le rythme de publication TikTok.',
        must: ['Aisance à l’écran', 'Anglais ou russe', 'Publication 4× / semaine']
      }
    },
    {
      id: 'm9', role: 'manager', name: 'North & Co', kind: 'Agence de management', tone: 't-mist', verified: true,
      city: 'Montréal', country: 'Canada', region: 'Amérique du Nord', joined: '2025-05-22', availability: 'busy',
      exp: 'e3', team: 't2', teamSize: 6, creatorsCount: 11, commission: '20 – 26 %', status: 'active',
      specialties: ['chatting', 'growth_x', 'fanvue', 'pricing'],
      languages: ['Français', 'Anglais'], platforms: ['onlyfans', 'fanvue', 'x'],
      bio: 'Agence québécoise bilingue. Nous travaillons exclusivement avec des créateurs francophones qui veulent développer le marché nord-américain.',
      goals: ['Structurer un compte en croissance', 'Ouvrir une nouvelle catégorie de contenu premium'],
      metrics: { clients: '11 créateurs', growth: '+25 % de revenus moyens sur 6 mois', response: 'Réponse < 10 h', retention: 'Durée moyenne : 1,7 an' },
      timeline: [
        { period: '2023 — aujourd’hui', title: 'North & Co', org: 'Montréal', note: '6 personnes, 11 comptes francophones, spécialité marché US / CA.' },
        { period: '2018 — 2023', title: 'Gestionnaire de comptes premium', org: 'Plateforme de streaming', note: 'Accompagnement de créateurs et politiques de monétisation.' }
      ],
      portfolio: [
        { title: 'Développement marché US', type: 'Croissance', meta: 'Part des revenus US : 12 % → 41 %' },
        { title: 'Onboarding bilingue', type: 'Méthode', meta: 'Documents FR / EN, réponses types validées' }
      ],
      pro: { statut: 'Inc. enregistrée', tarif: '20 – 26 % de commission', outils: 'Notion, Slack, Looker', dispo: 'Liste d’attente', paiement: 'Facturation mensuelle' },
      looking: {
        title: 'Créatrices et créateurs francophones visant l’Amérique du Nord',
        split: '20 – 26 % de commission',
        notes: 'Notre liste d’attente est ouverte : nous privilégions les comptes francophones ambitieux et réguliers.',
        must: ['Francophone', 'Anglais fonctionnel', 'Appétence pour le marché US']
      }
    },
    {
      id: 'm10', role: 'manager', name: 'Studio Verve', kind: 'Studio de production', tone: 't-clay', verified: true,
      city: 'Lyon', country: 'France', region: 'Europe', joined: '2025-05-21', availability: 'active',
      exp: 'e3', team: 't2', teamSize: 4, creatorsCount: 7, commission: '18 – 24 %', status: 'active',
      specialties: ['content_photo', 'content_video', 'branding', 'planning'],
      languages: ['Français', 'Anglais'], platforms: ['onlyfans', 'instagram', 'fanvue'],
      bio: 'Studio lyonnais de 4 personnes : image, production et planning éditorial. Nous travaillons avec 7 créatrices et créateurs francophones, deux journées de tournage par mois et une direction artistique suivie.',
      goals: ['Structurer un compte en croissance', 'Tisser une relation long terme', 'Professionnaliser la production'],
      metrics: { clients: '7 créateurs', growth: '+17 % de revenus moyens sur 6 mois', response: 'Réponse < 4 h', retention: 'Durée moyenne : 1,9 an' },
      timeline: [
        { period: '2025 — aujourd’hui', title: 'Création du studio', org: 'Lyon', note: '4 personnes, 2 plateaux, 7 comptes accompagnés.' },
        { period: '2018 — 2025', title: 'Photographe publicitaire', org: 'Lyon et Genève', note: 'Edition de mode, direction de casting, retouche.' }
      ],
      portfolio: [
        { title: 'Identité visuelle « Atelier »', type: 'Branding', meta: 'Charte, 6 séries, 480 visuels' },
        { title: 'Direct-to-consumer Instagram', type: 'Croissance', meta: '+9 400 abonnés en un trimestre' }
      ],
      pro: { statut: 'SAS enregistrée', tarif: 'Forfait studio + 18 – 24 %', outils: 'Capture One, DaVinci, Notion', dispo: '3 comptes disponibles', paiement: 'Facturation mensuelle' },
      looking: {
        title: 'Créatrices régulières, 20 k à 150 k abonnés',
        split: '18 – 24 % de commission',
        notes: 'Nous privilégions les personnes qui veulent une vraie direction visuelle et acceptent deux tournages par mois à Lyon.',
        must: ['Présence à Lyon deux jours par mois', 'Ouverture aux retours artistiques', 'Régularité de production']
      }
    },
    {
      id: 'm11', role: 'manager', name: 'Maison Lumen', kind: 'Agence de management', tone: 't-mist', verified: true,
      city: 'Montréal', country: 'Canada', region: 'Amérique du Nord', joined: '2024-11-18', availability: 'open',
      exp: 'e4', team: 't3', teamSize: 8, creatorsCount: 12, commission: '20 – 26 %', status: 'active',
      specialties: ['chatting', 'ppv', 'pricing', 'analytics'],
      languages: ['Français', 'Anglais'], platforms: ['onlyfans', 'fansly', 'fanvue'],
      bio: 'Agence québécoise de 8 personnes, pôle chatting bilingue et analyste dédié. Nous accompagnons 12 comptes francophones et anglophones avec un reporting hebdomadaire et une politique de prix testée en continu.',
      goals: ['Doubler le chiffre mensuel', 'Professionnaliser la vente', 'Structurer la relation client'],
      metrics: { clients: '12 créateurs', growth: '+24 % de revenus moyens sur 6 mois', response: 'Réponse < 3 h', retention: 'Durée moyenne : 2,7 ans' },
      timeline: [
        { period: '2024 — aujourd’hui', title: 'Fondation de la maison', org: 'Montréal', note: '8 personnes, 12 comptes, pôle chatting 7 j / 7.' },
        { period: '2017 — 2024', title: 'Directrice des opérations', org: 'Plateforme de contenus', note: 'Équipes de vente et de support, pilotage de la rétention.' }
      ],
      portfolio: [
        { title: 'Programme de relance des inactifs', type: 'Rétention', meta: '+19 % de réactivations' },
        { title: 'Playbook prix et bundles', type: 'Pricing', meta: 'Panier moyen +26 %' },
        { title: 'Rapport hebdomadaire type', type: 'Méthode', meta: 'Utilisé sur 12 comptes' }
      ],
      pro: { statut: 'Inc. enregistrée', tarif: '20 – 26 % de commission', outils: 'OnlyFans, Looker, Slack', dispo: '4 comptes disponibles', paiement: 'Facturation mensuelle' },
      looking: {
        title: 'Comptes francophones et anglophones, 30 k et plus',
        split: '20 – 26 % de commission',
        notes: 'Nous cherchons des personnes qui acceptent de déléguer réellement la vente, avec un accès transparent aux statistiques.',
        must: ['Accès complet aux statistiques', 'Contrat écrit de 6 mois', 'Anglais ou français', 'Aucune promesse de revenus exigée']
      }
    },
    {
      id: 'm12', role: 'manager', name: 'Nova Chatting', kind: 'Équipe de chatting', tone: 't-sage', verified: true,
      city: 'Bruxelles', country: 'Belgique', region: 'Europe', joined: '2026-03-09', availability: 'active',
      exp: 'e3', team: 't3', teamSize: 11, creatorsCount: 9, commission: '15 – 20 %', status: 'active',
      specialties: ['chatting', 'ppv', 'moderation', 'customs'],
      languages: ['Français', 'Néerlandais', 'Anglais'], platforms: ['onlyfans', 'fanvue'],
      bio: 'Équipe de 11 chatters francophones et néerlandophones, spécialisée exclusivement dans la vente en messages. Nous ne touchons ni à la production ni à l’image : vous gardez votre compte, nous tenons la conversation.',
      goals: ['Déléguer le chatting', 'Stabiliser les revenus', 'Améliorer le panier moyen'],
      metrics: { clients: '9 créateurs', growth: '+31 % de revenus en messages', response: 'Réponse < 12 min', retention: 'Couverture 17 h / jour' },
      timeline: [
        { period: '2026 — aujourd’hui', title: 'Création de l’équipe', org: 'Bruxelles', note: '11 personnes, 3 langues, 9 comptes.' },
        { period: '2021 — 2026', title: 'Responsable d’un pôle vente', org: 'Agence de management', note: 'Recrutement et formation de 30 chatters.' }
      ],
      portfolio: [
        { title: 'Formation chatting en 10 jours', type: 'Organisation', meta: 'Taux de conformité 98 %' },
        { title: 'Scripts de relance respectueux', type: 'Méthode', meta: 'Taux de réponse 41 %' }
      ],
      pro: { statut: 'SPRL enregistrée', tarif: '15 – 20 % de commission', outils: 'OnlyFans, Notion, Discord', dispo: '5 créneaux disponibles', paiement: 'Facturation mensuelle' },
      looking: {
        title: 'Comptes qui veulent déléguer uniquement la conversation',
        split: '15 – 20 % de commission',
        notes: 'Notre périmètre est strict : messages, relances, modération. Nous refusons les comptes sans cadre écrit sur les limites à respecter.',
        must: ['Limites écrites fournies par la créatrice', 'Aucune demande de production', 'Contrat de 3 mois renouvelable', 'Charte Sève acceptée']
      }
    },
    {
      id: 'm13', role: 'manager', name: 'Bloom Talent', kind: 'Agence de management', tone: 't-lilac', verified: true,
      city: 'Madrid', country: 'Espagne', region: 'Europe', joined: '2025-02-14', availability: 'open',
      exp: 'e4', team: 't3', teamSize: 7, creatorsCount: 16, commission: '20 – 25 %', status: 'active',
      specialties: ['growth_ig', 'growth_tt', 'collabs', 'media_buying'],
      languages: ['Espagnol', 'Anglais', 'Français'], platforms: ['onlyfans', 'instagram', 'tiktok', 'x'],
      bio: 'Agence madrilène spécialisée dans la croissance organique et les collaborations croisées. Nous accompagnons 16 créateurs hispanophones et francophones, avec un budget média encadré et des tests mensuels documentés.',
      goals: ['Ouvrir un nouveau marché', 'Scaler un compte établi', 'Diversifier les canaux'],
      metrics: { clients: '16 créateurs', growth: '+29 % d’abonnés sur 6 mois', response: 'Réponse < 6 h', retention: 'Durée moyenne : 2,1 ans' },
      timeline: [
        { period: '2025 — aujourd’hui', title: 'Création de Bloom', org: 'Madrid', note: '7 personnes, 16 comptes, réseau de 40 créateurs partenaires.' },
        { period: '2019 — 2025', title: 'Social media manager', org: 'Marques lifestyle', note: 'Community management et collaborations.' }
      ],
      portfolio: [
        { title: 'Réseau de collabs hispanophones', type: 'Croissance', meta: '40 partenaires, 62 k abonnés croisés' },
        { title: 'Test média TikTok', type: 'Acquisition', meta: 'ROAS 2,4 sur 45 jours' }
      ],
      pro: { statut: 'S.L. enregistrée', tarif: '20 – 25 % de commission', outils: 'Meta Ads, Metricool, Notion', dispo: '3 comptes disponibles', paiement: 'Facturation mensuelle' },
      looking: {
        title: 'Comptes francophones ou hispanophones en croissance',
        split: '20 – 25 % de commission',
        notes: 'Nous cherchons des personnes prêtes à publier régulièrement sur les réseaux sociaux d’acquisition : c’est là que se joue la croissance.',
        must: ['Appétence pour le contenu social', 'Régularité (3 publications / semaine)', 'Espagnol ou français', 'Aucune contrainte d’exclusivité la première année']
      }
    },
    {
      id: 'm14', role: 'manager', name: 'Kestrel Media', kind: 'Agence de management', tone: 't-stone', verified: false,
      city: 'Manchester', country: 'Royaume-Uni', region: 'Europe', joined: '2026-10-06', availability: 'active',
      exp: 'e2', team: 't2', teamSize: 3, creatorsCount: 4, commission: '20 – 25 %', status: 'active',
      specialties: ['growth_x', 'reddit', 'analytics', 'planning'],
      languages: ['Anglais', 'Français'], platforms: ['onlyfans', 'x', 'reddit', 'fansly'],
      bio: 'Petite structure britannique de 3 personnes, spécialisée dans les communautés (Reddit, X) et la mesure. Profil en cours de vérification par l’équipe Sève : quatre comptes accompagnés pour l’instant.',
      goals: ['Lancer un compte en construction', 'Diversifier les canaux', 'Structurer la mesure'],
      metrics: { clients: '4 créateurs', growth: '+22 % d’abonnés sur 90 jours', response: 'Réponse < 8 h', retention: 'Durée moyenne : 11 mois' },
      timeline: [
        { period: '2026 — aujourd’hui', title: 'Lancement de Kestrel', org: 'Manchester', note: '3 personnes, 4 comptes, approche 100 % communautés.' },
        { period: '2022 — 2026', title: 'Community manager', org: 'Forums et médias en ligne', note: 'Modération, animation, croissance organique.' }
      ],
      portfolio: [
        { title: 'Croissance Reddit sans publicité', type: 'Croissance', meta: '1 900 abonnés en 4 mois' }
      ],
      pro: { statut: 'Ltd enregistrée', tarif: '20 – 25 % de commission', outils: 'Reddit, X, Sheets, Notion', dispo: '4 comptes disponibles', paiement: 'Facturation mensuelle' },
      looking: {
        title: 'Comptes en lancement, approche communautés',
        split: '20 – 25 % de commission',
        notes: 'Nous démarrons avec vous : pas de gros portefeuille, mais un travail de fond sur Reddit et X, mesuré chaque semaine.',
        must: ['Anglais', 'Patience sur les 3 premiers mois', 'Validation de chaque publication communautaire']
      }
    },
    {
      id: 'm15', role: 'manager', name: 'Studio Aurora', kind: 'Studio de production', tone: 't-sand', verified: true,
      city: 'Berlin', country: 'Allemagne', region: 'Europe', joined: '2024-08-27', availability: 'busy',
      exp: 'e5', team: 't4', teamSize: 18, creatorsCount: 22, commission: '22 – 28 %', status: 'active',
      specialties: ['content_video', 'lives', 'customs', 'legal'],
      languages: ['Allemand', 'Anglais', 'Polonais'], platforms: ['onlyfans', 'fansly', 'fanvue'],
      bio: 'Studio berlinois de 18 personnes : deux plateaux vidéo, un pôle conformité et un pôle sur-mesure. 22 comptes accompagnés, principalement germanophones, avec une exigence forte sur les contrats et les limites.',
      goals: ['Scaler un compte établi', 'Professionnaliser la production', 'Sécuriser juridiquement'],
      metrics: { clients: '22 créateurs', growth: '+15 % de revenus moyens sur 6 mois', response: 'Réponse < 5 h', retention: 'Durée moyenne : 3,1 ans' },
      timeline: [
        { period: '2024 — aujourd’hui', title: 'Studio Aurora', org: 'Berlin', note: '18 personnes, 22 comptes, 2 plateaux.' },
        { period: '2015 — 2024', title: 'Productrice audiovisuelle', org: 'Studios européens', note: 'Tournages, post-production, contrats artistiques.' }
      ],
      portfolio: [
        { title: 'Pôle conformité et contrats', type: 'Juridique', meta: '22 contrats vérifiés, 0 litige en 2 ans' },
        { title: 'Format live multi-caméras', type: 'Production', meta: 'Revenus live ×1,8' },
        { title: 'Atelier sur-mesure encadré', type: 'Monétisation', meta: 'Panier moyen 190 €' }
      ],
      pro: { statut: 'GmbH enregistrée', tarif: '22 – 28 % de commission', outils: 'OnlyFans, DaVinci, Airtable', dispo: 'Liste d’attente (4 – 6 semaines)', paiement: 'Facturation mensuelle' },
      looking: {
        title: 'Comptes germanophones ou polonais, 50 k et plus',
        split: '22 – 28 % de commission',
        notes: 'Notre liste d’attente est ouverte. Nous ne prenons que des comptes où les limites et le périmètre sont strictement écrits.',
        must: ['Allemand ou polonais', 'Limites écrites fournies', 'Contrat de 12 mois', 'Présence possible à Berlin deux fois par trimestre']
      }
    },
    {
      id: 'm16', role: 'manager', name: 'Grupo Alta', kind: 'Agence de management', tone: 't-blush', verified: true,
      city: 'Mexico', country: 'Mexique', region: 'Amérique latine', joined: '2025-07-02', availability: 'open',
      exp: 'e3', team: 't4', teamSize: 21, creatorsCount: 19, commission: '20 – 24 %', status: 'active',
      specialties: ['chatting', 'media_buying', 'pricing', 'analytics'],
      languages: ['Espagnol', 'Portugais', 'Anglais'], platforms: ['onlyfans', 'fansly', 'onlyfans'],
      bio: 'Agence mexicaine de 21 personnes, deux équipes de chatting (espagnol et portugais) et un pôle acquisition. 19 comptes accompagnés sur l’Amérique latine, avec un pilotage par les coûts d’acquisition.',
      goals: ['Ouvrir un nouveau marché', 'Scaler un compte établi', 'Réduire la dépendance au trafic payant'],
      metrics: { clients: '19 créateurs', growth: '+26 % de revenus moyens sur 6 mois', response: 'Réponse < 2 h', retention: 'Durée moyenne : 1,7 an' },
      timeline: [
        { period: '2025 — aujourd’hui', title: 'Grupo Alta', org: 'Mexico', note: '21 personnes, 19 comptes, 2 pôles de chatting.' },
        { period: '2018 — 2025', title: 'Traffic manager', org: 'E-commerce latino-américain', note: 'Budgets média et optimisation de conversion.' }
      ],
      portfolio: [
        { title: 'Réduction du coût d’acquisition', type: 'Acquisition', meta: '−34 % de CPA en 6 mois' },
        { title: 'Équipe chatting portugais', type: 'Organisation', meta: '12 personnes, 20 h / jour' }
      ],
      pro: { statut: 'S.A. de C.V.', tarif: '20 – 24 % de commission', outils: 'Meta Ads, Metabase, Slack', dispo: '6 comptes disponibles', paiement: 'Facturation mensuelle' },
      looking: {
        title: 'Comptes hispanophones et lusophones, 10 k à 300 k',
        split: '20 – 24 % de commission',
        notes: 'Nous cherchons des personnes prêtes à travailler un marché précis avec nous, chiffres partagés chaque semaine.',
        must: ['Espagnol ou portugais', 'Acceptation du reporting hebdomadaire', 'Contrat de 6 mois', 'Aucune promesse de résultat']
      }
    },
    {
      id: 'm17', role: 'manager', name: 'Lumen Gulf', kind: 'Agence de management', tone: 't-clay', verified: true,
      city: 'Dubaï', country: 'Émirats arabes unis', region: 'Moyen-Orient', joined: '2026-01-27', availability: 'active',
      exp: 'e3', team: 't3', teamSize: 9, creatorsCount: 11, commission: '20 – 26 %', status: 'active',
      specialties: ['media_buying', 'ppv', 'growth_x', 'legal'],
      languages: ['Arabe', 'Anglais', 'Français'], platforms: ['onlyfans', 'x', 'instagram'],
      bio: 'Structure basée à Dubaï, 9 personnes, spécialisée sur les marchés du Golfe et la diaspora francophone. Acquisition payante encadrée, conformité vérifiée et réponses en arabe, anglais et français.',
      goals: ['Ouvrir un nouveau marché', 'Diversifier les canaux', 'Structurer la conformité'],
      metrics: { clients: '11 créateurs', growth: '+23 % de revenus moyens sur 6 mois', response: 'Réponse < 3 h', retention: 'Durée moyenne : 1,6 an' },
      timeline: [
        { period: '2026 — aujourd’hui', title: 'Lancement de Lumen Gulf', org: 'Dubaï', note: '9 personnes, 11 comptes, 3 langues.' },
        { period: '2020 — 2026', title: 'Responsable acquisition', org: 'Agence média, Dubaï', note: 'Campagnes multilingues, budgets 6 chiffres.' }
      ],
      portfolio: [
        { title: 'Campagne multilingue', type: 'Acquisition', meta: '3 langues, CPA −21 %' },
        { title: 'Vérification conformité 18+', type: 'Juridique', meta: 'Procédure documentée, 100 % des comptes' }
      ],
      pro: { statut: 'Licence free zone', tarif: 'Retainer + 12 %', outils: 'Meta Ads, Notion, Slack', dispo: '3 comptes disponibles', paiement: 'Facturation mensuelle' },
      looking: {
        title: 'Comptes arabophones ou francophones',
        split: 'Retainer + 12 %',
        notes: 'Nous travaillons les marchés du Golfe et la diaspora : utile si votre audience y est déjà présente.',
        must: ['Arabe ou français', 'Vérification d’âge documentaire', 'Acceptation du cadre légal local', 'Contrat écrit']
      }
    },
    {
      id: 'm18', role: 'manager', name: 'Pacific Sway', kind: 'Agence de management', tone: 't-moss', verified: true,
      city: 'Singapour', country: 'Singapour', region: 'Asie-Pacifique', joined: '2025-10-15', availability: 'open',
      exp: 'e4', team: 't3', teamSize: 10, creatorsCount: 13, commission: '18 – 23 %', status: 'active',
      specialties: ['chatting', 'moderation', 'analytics', 'planning'],
      languages: ['Anglais', 'Français'], platforms: ['onlyfans', 'fansly', 'patreon'],
      bio: 'Agence de Singapour, 10 personnes, couverture des fuseaux Asie-Pacifique et Europe. 13 comptes accompagnés, avec une équipe de modération dédiée et un suivi analytique mensuel.',
      goals: ['Passer à un rythme soutenable', 'Structurer la relation client', 'Sécuriser la modération'],
      metrics: { clients: '13 créateurs', growth: '+18 % de revenus moyens sur 6 mois', response: 'Réponse < 2 h', retention: 'Durée moyenne : 2,3 ans' },
      timeline: [
        { period: '2025 — aujourd’hui', title: 'Pacific Sway', org: 'Singapour', note: '10 personnes, 13 comptes, couverture 20 h / jour.' },
        { period: '2018 — 2025', title: 'Responsable support', org: 'Plateforme numérique', note: 'Modération et qualité de service à grande échelle.' }
      ],
      portfolio: [
        { title: 'Pôle modération 7 j / 7', type: 'Modération', meta: 'Temps de traitement moyen : 9 min' },
        { title: 'Reporting mensuel type', type: 'Méthode', meta: 'Utilisé sur 13 comptes' }
      ],
      pro: { statut: 'Pte. Ltd. enregistrée', tarif: '18 – 23 % de commission', outils: 'OnlyFans, Looker, Notion', dispo: '4 comptes disponibles', paiement: 'Facturation mensuelle' },
      looking: {
        title: 'Comptes anglophones, couverture Asie-Pacifique',
        split: '18 – 23 % de commission',
        notes: 'Nous sommes utiles si votre audience est active en soirée asiatique ou en matinée européenne.',
        must: ['Anglais courant', 'Aucune demande de contenu explicite dans nos échanges', 'Contrat de 6 mois', 'Rapport mensuel chiffré']
      }
    }
  ];

  /* ------------------------------------------------------------------ */
  /* Demandes de collaboration                                           */
  /* ------------------------------------------------------------------ */
  const requests = [
    { id: 'r1', from: 'm2', to: 'c9', status: 'pending', created: to(0, 5), message: 'Bonjour Lya, votre compte m’a été recommandé par une de nos créatrices. Nous avons une équipe chatting francophone disponible dès novembre et je pense que votre palier se situe surtout sur la vente en messages. Seriez-vous disponible pour un appel de 20 minutes cette semaine ?' },
    { id: 'r2', from: 'm3', to: 'c9', status: 'pending', created: to(1, 3), message: 'Bonjour Lya, je gère 4 comptes francophones, dont deux dans le lifestyle. Je travaille en direct, sans intermédiaire, avec un point de suivi deux fois par semaine. Je serais ravi de vous présenter ma méthode et mes résultats.' },
    { id: 'r3', from: 'm1', to: 'c9', status: 'pending', created: to(2, 8), message: 'Bonjour, l’Atelier Nova organise une session d’information le 12 du mois prochain pour les créatrices francophones entre 20 k et 100 k abonnés. Nous pensons que votre profil correspond à notre programme. Souhaitez-vous recevoir le détail ?' },
    { id: 'r4', from: 'c9', to: 'm2', status: 'accepted', created: to(9, 2), updated: to(7, 4), message: 'Bonjour, je cherche à déléguer progressivement la partie conversation tout en gardant la direction artistique. Votre programme « palier 20 k » m’intéresse. Pouvons-nous en parler ?', reply: 'Bonjour Lya, avec plaisir. Je vous propose un appel de 30 minutes jeudi à 18 h. En attendant, je vous envoie notre dossier de méthode et deux études de cas.' },
    { id: 'r5', from: 'c9', to: 'm7', status: 'declined', created: to(21, 6), updated: to(19, 1), message: 'Bonjour, je souhaiterais échanger avec votre pôle conformité sur les aspects contractuels avant de m’engager.', reply: 'Bonjour Lya, merci pour votre message. Lumen accompagne actuellement des comptes établis à partir de 50 k abonnés payants : votre volume reste en dessous de notre seuil d’entrée. Nous gardons votre profil en veille avec plaisir.' },
    { id: 'r6', from: 'm5', to: 'c1', status: 'accepted', created: to(14, 2), updated: to(12, 5), message: 'Bonjour Léa, notre équipe de 5 chatters gère actuellement 9 comptes francophones. Nous sommes à l’aise avec les gros volumes et les audiences internationales. Souhaitez-vous tester un premier mois sur un créneau limité ?', reply: 'Bonjour Kaïna, je suis intéressée par un test de 30 jours sur les créneaux de soirée. Envoyez-moi votre plan de démarrage et votre charte de ton.' },
    { id: 'r7', from: 'm6', to: 'c3', status: 'pending', created: to(3, 1), message: 'Bonjour Nour, je suis spécialisé dans l’acquisition Reddit et X. Je pense pouvoir porter votre compte au-delà des 30 k€ mensuels en travaillant le marché anglophone. Pouvons-nous en discuter ?' },
    { id: 'r8', from: 'm8', to: 'c5', status: 'pending', created: to(4, 6), message: 'Bonjour Jade, je lance deux comptes francophones sur TikTok cette année et je cherche une créatrice sérieuse pour l’un d’eux. Je propose un accompagnement pédagogique avec des objectifs clairs.' },
    { id: 'r9', from: 'm4', to: 'c4', status: 'accepted', created: to(27, 4), updated: to(25, 2), message: 'Bonjour Sofía, votre travail visuel est très soigné. Nous avons deux créneaux studio disponibles par mois à Bruxelles. Nous pouvons aussi assurer la retouche et la colorimétrie.', reply: 'Bonjour, merci beaucoup. Je suis ouverte à un premier shooting test en décembre pour valider le rendu.' },
    { id: 'r10', from: 'm9', to: 'c6', status: 'pending', created: to(6, 7), message: 'Bonjour Elena, nous cherchons des comptes anglophones à forte audience organique pour développer le marché américain. Votre système Reddit nous intéresse beaucoup.' },
    { id: 'r11', from: 'm2', to: 'c7', status: 'pending', created: to(5, 2), message: 'Bonjour Camille, nous avons déjà accompagné deux comptes en duo et nous savons adapter nos scripts à ce format. Je serais ravie d’échanger sur votre organisation actuelle.' },
    { id: 'r12', from: 'm3', to: 'c8', status: 'pending', created: to(4, 9), message: 'Bonjour Amira, la monétisation autour des lives est l’un de mes axes favoris. Je vous propose une séance de travail gratuite d’une heure pour vous montrer ma méthode.' },
    { id: 'r13', from: 'm7', to: 'c10', status: 'pending', created: to(7, 3), message: 'Bonjour Nina, notre pôle conformité et notre équipe chatting anglophone peuvent prendre en charge une partie de votre équipe interne. Souhaitez-vous échanger avec notre directrice de compte ?' },
    { id: 'r14', from: 'm6', to: 'c9', status: 'archived', created: to(34, 2), message: 'Bonjour Lya, je me permets un message : je cherche à élargir mon portefeuille francophone avec des comptes orientés croissance organique.' },
    { id: 'r15', from: 'c2', to: 'm1', status: 'pending', created: to(1, 11), message: 'Bonjour, je suis créatrice francophone avec 76 k abonnés et une audience TikTok très engagée. J’aimerais comprendre votre fonctionnement côté chatting et le détail de votre commission.' },
    { id: 'r16', from: 'c12', to: 'm6', status: 'accepted', created: to(11, 5), updated: to(9, 3), message: 'Bonjour Elias, je suis lusophone et francophone, avec un panier moyen élevé. Je cherche un partenaire pour ouvrir le marché français.', reply: 'Bonjour Inès, votre profil correspond exactement à ce que je cherche. Je vous envoie ma proposition de plan de croissance sur 6 mois.' },
    { id: 'r17', from: 'c11', to: 'm3', status: 'pending', created: to(2, 4), message: 'Bonjour Marc, je lance mon compte dans quelques semaines. J’ai besoin d’un cadre et de conseils sur le positionnement dès le départ.' },
    { id: 'r18', from: 'c9', to: 'm9', status: 'pending', created: to(3, 12), message: 'Bonjour, je souhaite développer la part anglophone de mon audience. Quelle est la durée moyenne de votre liste d’attente ?' },
    { id: 'r19', from: 'c9', to: 'm4', status: 'sent', created: to(0, 2), message: 'Bonjour, je cherche à améliorer la qualité visuelle de mes séries photo. Votre forfait studio m’intéresse, en particulier la colorimétrie. Quel serait le coût pour deux shootings par mois ?' },
    { id: 'r20', from: 'm2', to: 'c5', status: 'pending', created: to(1, 6), message: 'Bonjour Jade, nous ouvrons deux places dans notre programme de lancement pour des comptes en construction. Pédagogie garantie, engagement de trois mois seulement.' }
  ];

  /* ------------------------------------------------------------------ */
  /* Messagerie                                                          */
  /* ------------------------------------------------------------------ */
  const conversations = [
    {
      id: 'cv1', demo: 'creator', with: 'm2', name: 'Halo Management', role: 'Agence de management', verified: true, unread: 2,
      messages: [
        { from: 'them', text: 'Bonjour Lya, merci pour votre message. Je vous propose un appel de 30 minutes jeudi à 18 h.', at: to(7, 3) },
        { from: 'me', text: 'Bonjour, jeudi 18 h me convient. Je vous enverrai avant l’appel mon planning de publication actuel.', at: to(7, 2) },
        { from: 'them', text: 'Parfait. De mon côté je vous prépare une simulation sur la base de vos 90 derniers jours.', at: to(6, 20) },
        { from: 'them', text: 'Voici le dossier promis : méthode de suivi, trois études de cas et le détail des commissions.', at: to(1, 4) },
        { from: 'them', text: 'Un dernier point : êtes-vous ouverte à un mois d’essai avant de signer quoi que ce soit ?', at: to(0, 6) }
      ]
    },
    {
      id: 'cv2', demo: 'creator', with: 'm4', name: 'Studio Bruma', role: 'Studio de production', verified: true, unread: 0,
      messages: [
        { from: 'me', text: 'Bonjour, je cherche à améliorer la qualité de mes séries photo. Votre forfait studio m’intéresse.', at: to(4, 5) },
        { from: 'them', text: 'Bonjour Lya, merci. Nous avons deux créneaux libres par mois à Bruxelles, avec retouche et colorimétrie incluses.', at: to(3, 22) },
        { from: 'them', text: 'Nous pouvons vous envoyer une proposition avec deux formules : demi-journée et journée complète.', at: to(3, 21) },
        { from: 'me', text: 'Avec plaisir, envoyez la formule demi-journée en priorité.', at: to(2, 9) }
      ]
    },
    {
      id: 'cv3', demo: 'creator', with: 'm3', name: 'Marc Vidal', role: 'Manager indépendant', verified: true, unread: 0,
      messages: [
        { from: 'them', text: 'Bonjour Lya, je travaille avec quatre comptes francophones. Mon approche : peu de clients, beaucoup de présence.', at: to(12, 6) },
        { from: 'me', text: 'Bonjour Marc, c’est exactement ce que je cherche : quelqu’un qui connaît mon compte en détail.', at: to(12, 2) },
        { from: 'them', text: 'Je vous envoie mon plan d’action sur 90 jours. Si les objectifs vous paraissent réalistes, on se lance.', at: to(11, 7) }
      ]
    },
    {
      id: 'cv4', demo: 'creator', with: 'team', name: 'Équipe Sève', role: 'Accompagnement & confiance', verified: true, unread: 1,
      messages: [
        { from: 'them', text: 'Bonjour Lya, bienvenue sur Sève. Votre profil est vérifié : identité confirmée et informations contrôlées.', at: to(120, 3) },
        { from: 'them', text: 'Votre recherchée « Aide au matching » a été prise en charge. Nous avons présélectionné quatre managers qui correspondent à vos critères.', at: to(2, 6) },
        { from: 'them', text: 'Petit rappel de sécurité : nous ne demandons jamais d’avance de frais aux créatrices. Si un contact vous en réclame, signalez-le immédiatement.', at: to(0, 9) }
      ]
    },
    {
      id: 'cv5', demo: 'manager', with: 'c9', name: 'Lya Moreau', role: 'Créatrice', verified: true, unread: 1,
      messages: [
        { from: 'them', text: 'Bonjour, je cherche à déléguer progressivement la partie conversation tout en gardant la direction artistique.', at: to(9, 3) },
        { from: 'me', text: 'Bonjour Lya, avec plaisir. Je vous propose un appel de 30 minutes jeudi à 18 h.', at: to(8, 22) },
        { from: 'them', text: 'Jeudi 18 h me convient parfaitement.', at: to(8, 20) },
        { from: 'me', text: 'Je vous envoie notre dossier de méthode, deux études de cas et le détail de nos commissions.', at: to(1, 4) },
        { from: 'them', text: 'Merci, je l’ai reçu. Une question : le mois d’essai est-il possible avant signature ?', at: to(0, 4) }
      ]
    },
    {
      id: 'cv6', demo: 'manager', with: 'c7', name: 'Camille Roy', role: 'Créatrice (duo)', verified: true, unread: 0,
      messages: [
        { from: 'me', text: 'Bonjour Camille, nous avons déjà accompagné deux comptes en duo. Je serais ravie d’échanger sur votre organisation actuelle.', at: to(5, 3) },
        { from: 'them', text: 'Bonjour, merci pour votre message. Nous étions justement en train d’hésiter entre plusieurs agences.', at: to(4, 23) },
        { from: 'me', text: 'Je vous propose un échange court, 20 minutes, pour comprendre vos contraintes de production.', at: to(4, 21) },
        { from: 'them', text: 'Nous sommes disponibles mardi ou mercredi soir après 19 h.', at: to(1, 8) }
      ]
    },
    {
      id: 'cv7', demo: 'manager', with: 'c12', name: 'Inès Da Silva', role: 'Créatrice', verified: true, unread: 0,
      messages: [
        { from: 'them', text: 'Bonjour Elias, je suis lusophone et francophone, avec un panier moyen élevé. Je cherche un partenaire pour ouvrir le marché français.', at: to(11, 6) },
        { from: 'me', text: 'Bonjour Inès, votre profil correspond exactement à ce que je cherche. Je vous envoie ma proposition de plan de croissance sur 6 mois.', at: to(10, 4) },
        { from: 'them', text: 'Reçu, merci. La partie « contenu francophone » me paraît la plus délicate : comment procéder sans trahir mon style ?', at: to(2, 7) }
      ]
    },
    {
      id: 'cv8', demo: 'manager', with: 'team', name: 'Équipe Sève', role: 'Accompagnement & confiance', verified: true, unread: 0,
      messages: [
        { from: 'them', text: 'Bonjour Halo, votre profil agence est vérifié. Merci d’avoir téléversé votre extrait Kbis et votre charte de conformité.', at: to(90, 1) },
        { from: 'them', text: 'Deux créatrices franches de votre zone de recherche ont demandé un accompagnement : nous vous les avons recommandées.', at: to(6, 2) }
      ]
    }
  ];

  /* ------------------------------------------------------------------ */
  /* Demandes d’accompagnement (aide au matching)                        */
  /* ------------------------------------------------------------------ */
  const applications = [
    { id: 'a1', user: 'c11', type: 'créateur', status: 'new', created: to(1, 2), goals: ['Stabiliser mes revenus', 'Structurer mon planning de publication'], specialties: ['chatting', 'pricing'], location: 'France · Nantes · à distance', criteria: 'Manager francophone acceptant les comptes en lancement, pédagogie indispensable', need: 'Je lance mon compte dans trois semaines et je ne sais pas comment fixer mes prix ni organiser ma production. J’aimerais être mise en relation avec une personne expérimentée qui accepte un compte en construction.' },
    { id: 'a2', user: 'c2', type: 'créateur', status: 'progress', created: to(3, 5), goals: ['Doubler mon chiffre mensuel', 'Déléguer le chatting'], specialties: ['chatting', 'ppv'], location: 'France · Bordeaux · à distance', criteria: 'Manager disponible en soirée, francophone natif, contrat court au départ', need: 'Je perds beaucoup de chiffre sur les messages car je ne réponds pas assez vite. Je cherche quelqu’un pour reprendre la vente sur les créneaux 18 h – 1 h.' },
    { id: 'a3', user: 'c5', type: 'créateur', status: 'matched', created: to(9, 4), assigned: 'm8', goals: ['Passer à un rythme soutenable'], specialties: ['growth_tt', 'customs'], location: 'France · Lille · à distance', criteria: 'Accompagnement TikTok en français', need: 'Je voudrais quelqu’un pour m’aider à structurer mes publications TikTok et convertir mieux vers l’abonnement payant.' },
    { id: 'a4', user: 'm4', type: 'manager', status: 'new', created: to(0, 8), goals: ['Développer une offre premium'], specialties: ['content_photo'], location: 'Belgique · Bruxelles · présentiel possible', criteria: 'Créatrices belges acceptant un travail d’image encadré', need: 'Nous avons deux créneaux studio à compléter. Nous cherchons des créatrices belges ou du Nord de la France, prêtes à venir tourner deux jours par mois.' },
    { id: 'a5', user: 'm8', type: 'manager', status: 'progress', created: to(2, 9), goals: ['Lancer une nouvelle créatrice / un nouveau créateur'], specialties: ['growth_tt'], location: 'Lituanie · Vilnius · à distance', criteria: 'Créatrices francophones à l’aise à l’écran', need: 'Je cherche deux créatrices francophones pour lancer des comptes TikTok et les amener vers un abonnement payant.' },
    { id: 'a6', user: 'c9', type: 'créateur', status: 'matched', created: to(16, 6), assigned: 'm3', goals: ['Déléguer le chatting', 'Doubler mon chiffre mensuel'], specialties: ['chatting', 'pricing'], location: 'France · Paris · à distance', criteria: 'Manager francophone, suivi hebdomadaire, contrat écrit', need: 'Je souhaite déléguer 60 % de mes conversations à partir de janvier, avec un cadre clair et un suivi régulier. Je cherche un manager qui accepte de travailler dans la durée.' },
    { id: 'a7', user: 'c6', type: 'créateur', status: 'closed', created: to(41, 3), assigned: 'm9', goals: ['Ouvrir un nouveau marché'], specialties: ['growth_x', 'reddit'], location: 'Espagne · Barcelone · à distance', criteria: 'Partenaire anglophone orienté performance', need: 'Je cherche un partenaire capable de gérer l’acquisition sur trois marchés anglophones en parallèle.' }
  ];

  /* ------------------------------------------------------------------ */
  /* Signalements                                                        */
  /* ------------------------------------------------------------------ */
  const reports = [
    { id: 's1', target: 'm8', targetName: 'Sasha Ivanova', by: 'c5', reason: 'Demande de paiement hors plateforme', detail: 'Le contact me demande 150 € de frais de dossier avant l’appel de présentation.', severity: 'high', status: 'open', created: to(0, 10) },
    { id: 's2', target: 'c5', targetName: 'Jade Lefèvre', by: 'm8', reason: 'Ambiguïté sur l’âge déclaré', detail: 'Aucun élément formel, mais les réponses laissent penser que la personne pourrait être mineure. Vérification demandée avant toute collaboration.', severity: 'high', status: 'open', created: to(1, 4) },
    { id: 's3', target: 'm3', targetName: 'Marc Vidal', by: 'c8', reason: 'Messages trop insistant hors des propositions', detail: 'Le contact relance plusieurs fois par jour malgré une réponse négative claire.', severity: 'mid', status: 'progress', created: to(2, 7) },
    { id: 's4', target: 'c12', targetName: 'Inès Da Silva', by: 'm3', reason: 'Contenu suspecté comme partagé sans accord', detail: 'Un visuel du portfolio apparaît sur un compte tiers. Vérification de la titularité demandée.', severity: 'mid', status: 'open', created: to(3, 2) },
    { id: 's5', target: 'm6', targetName: 'Elias Rocha', by: 'c4', reason: 'Promesse de résultats chiffrés', detail: 'Le manager annonce des revenus garantis, ce qui est contraire aux règles de la plateforme.', severity: 'low', status: 'closed', created: to(8, 5), resolution: 'Rappel à la charte envoyé, mention retirée de la présentation. Dossier clos.' },
    { id: 's6', target: 'c3', targetName: 'Nour El Amrani', by: 'm5', reason: 'Photo de profil non conforme', detail: 'La photo de profil affiche des éléments de contact externe.', severity: 'low', status: 'closed', created: to(13, 8), resolution: 'Photo mise à jour par la créatrice après notification.' },
    { id: 's7', target: 'm9', targetName: 'North & Co', by: 'c10', reason: 'Pression sur les délais de signature', detail: 'Relances quotidiennes pour signer un contrat d’exclusivité avant la fin de la semaine.', severity: 'mid', status: 'progress', created: to(4, 3) }
  ];

  /* ------------------------------------------------------------------ */
  /* Litiges & remboursements (données de démonstration)                 */
  /* ------------------------------------------------------------------ */
  /* Un litige = une contestation bancaire (chargeback) subie par une     */
  /* créatrice. Aucune donnée bancaire : identifiant du contact tel       */
  /* qu’il apparaît sur la plateforme, montant, type, canal, signaux.     */
  const disputes = [
    /* vague de juillet : 6 litiges en 9 jours sur les mêmes canaux */
    { id: 'l1', owner: 'c9', fan: 'm_bru_0712', amount: 48, type: 'custom', channel: 'reddit', status: 'perdu', created: to(104, 6), signals: ['custom_seul', 'silence_apres_reception', 'arrivee_campagne'], note: 'Commande passée le 12, vidéo livrée le 14, contestée le 28 sans aucun message.' },
    { id: 'l2', owner: 'c9', fan: 'm_bru_0719', amount: 32, type: 'ppv', channel: 'reddit', status: 'perdu', created: to(101, 3), signals: ['lieu_achat_seul', 'arrivee_campagne'], note: 'Compte créé le jour du déblocage, aucun message, disparu.' },
    { id: 'l3', owner: 'c9', fan: 'm_bru_0721', amount: 24, type: 'abo', channel: 'reddit', status: 'conteste', created: to(99, 8), signals: ['lieu_achat_seul'], note: 'Dossier transmis au support avec les captures et l’identifiant de transaction.' },
    { id: 'l4', owner: 'c9', fan: 'm_bru_0724', amount: 96, type: 'custom', channel: 'dm', status: 'recupere', created: to(96, 4), signals: ['premier_gros_achat', 'silence_apres_reception'], note: 'Contesté puis récupéré : le dossier prouvait la livraison et l’accord écrit.' },
    { id: 'l5', owner: 'c9', fan: 'm_bru_0802', amount: 18, type: 'abo', channel: 'reddit', status: 'perdu', created: to(94, 9), signals: ['lieu_achat_seul', 'litige_anterieur'], note: 'Même identifiant que le litige de juillet, sous une autre écriture.' },
    { id: 'l6', owner: 'c9', fan: 'm_bru_0803', amount: 55, type: 'session', channel: 'reddit', status: 'perdu', created: to(93, 2), signals: ['session_longue', 'lieu_achat_seul'], note: 'Session de 40 minutes, aucune limite acceptée, contestée le lendemain.' },
    /* litiges plus récents */
    { id: 'l7', owner: 'c9', fan: 'm_sw_1010', amount: 22, type: 'ppv', channel: 'tiktok', status: 'nouveau', created: to(4, 5), signals: ['lieu_achat_seul'] },
    { id: 'l8', owner: 'c9', fan: 'm_sw_1008', amount: 130, type: 'custom', channel: 'dm', status: 'conteste', created: to(7, 7), signals: ['premier_gros_achat', 'custom_seul'], note: 'Accord écrit, livraison horodatée, contestation pour « non reçu ».' },
    { id: 'l9', owner: 'c9', fan: 'm_sw_1005', amount: 16, type: 'abo', channel: 'direct', status: 'recupere', created: to(9, 3), signals: [] },
    /* autres créatrices : la vague est visible sur toute la plateforme */
    { id: 'l10', owner: 'c1', fan: 'm_bru_0711', amount: 40, type: 'ppv', channel: 'reddit', status: 'perdu', created: to(102, 5), signals: ['lieu_achat_seul', 'arrivee_campagne'], note: 'Même schéma que sur d’autres comptes francophones.' },
    { id: 'l11', owner: 'c1', fan: 'm_bru_0722', amount: 28, type: 'abo', channel: 'reddit', status: 'perdu', created: to(98, 6), signals: ['lieu_achat_seul'] },
    { id: 'l12', owner: 'c13', fan: 'm_bru_0716', amount: 75, type: 'custom', channel: 'reddit', status: 'perdu', created: to(103, 2), signals: ['custom_seul', 'silence_apres_reception'] },
    { id: 'l13', owner: 'c13', fan: 'm_bru_0726', amount: 19, type: 'abo', channel: 'reddit', status: 'conteste', created: to(95, 8), signals: ['lieu_achat_seul'] },
    { id: 'l14', owner: 'c20', fan: 'm_bru_0708', amount: 61, type: 'ppv', channel: 'reddit', status: 'perdu', created: to(105, 4), signals: ['premier_gros_achat'] },
    { id: 'l15', owner: 'c20', fan: 'm_bru_1101', amount: 44, type: 'session', channel: 'reddit', status: 'nouveau', created: to(6, 2), signals: ['session_longue'] },
    { id: 'l16', owner: 'c26', fan: 'm_sw_0928', amount: 88, type: 'ppv', channel: 'twitter', status: 'conteste', created: to(12, 9), signals: ['premier_gros_achat', 'arrivee_campagne'] },
    { id: 'l17', owner: 'c31', fan: 'm_sw_1012', amount: 35, type: 'custom', channel: 'dm', status: 'nouveau', created: to(2, 4), signals: ['custom_seul', 'lieu_achat_seul'] },
    { id: 'l18', owner: 'c28', fan: 'm_sw_1013', amount: 14, type: 'abo', channel: 'direct', status: 'nouveau', created: to(1, 6), signals: [] }
  ];

  /* ------------------------------------------------------------------ */
  /* Messages directs à l'équipe & accompagnement (démonstration)        */
  /* ------------------------------------------------------------------ */
  /* Un fil = une conversation entre un membre et l'équipe Sève, avec un  */
  /* sujet, un référent nommé, un statut et une échéance de réponse.      */
  const teamThreads = [
    {
      id: 't1', user: 'c9', topic: 'litige', status: 'repondu', referent: 'Élise',
      created: to(96, 3), updated: to(95, 2),
      messages: [
        { id: 'tm1', from: 'member', at: to(95, 6), text: 'Bonjour, depuis juillet je reçois des contestations bancaires en série. Environ 2 000 € au départ, puis quelques centaines chaque mois. Le support me renvoie toujours la même phrase, je ne sais plus quoi faire.' },
        { id: 'tm2', from: 'team', author: 'Élise', at: to(95, 4), text: 'Bonjour Lya. Vous avez bien fait de nous écrire — et vous n’êtes pas responsable de ce qui vous arrive. Ce sont des chargebacks : la banque de l’acheteur décide, la plateforme ne peut ni les accepter ni les refuser. Ce que nous pouvons faire ensemble, et que nous ferons : documenter chaque contestation, construire un constat daté, et demander la suspension des comptes concernés.' },
        { id: 'tm3', from: 'member', at: to(95, 3), text: 'D’accord. Est-ce que ça vaut le coup, ou est-ce que je ferais mieux de tout arrêter ?' },
        { id: 'tm4', from: 'team', author: 'Élise', at: to(95, 2), text: 'Cela vaut le coup, oui : une contestation se défend avec des faits, et votre encaissement est solide sur le reste. Avant de décider quoi que ce soit, prenez une heure pour tout enregistrer dans votre registre — je vous ai ouvert la page. Ensuite, nous regardons les chiffres ensemble. Si la seule chose qui vous tient debout, c’est de fermer, nous le ferons : mais fermer n’arrête pas les contestations déjà lancées, et vous perdriez votre revenu.' },
        { id: 'tm5', from: 'team', author: 'Élise', at: to(95, 1), text: 'Petite précision utile : sur vos 9 contestations, la majorité arrive par Reddit avec des comptes créés le jour de l’achat. Nous avons un dossier commun sur ce schéma. Dites-moi quand vous êtes prête, je m’en occupe avec vous.' }
      ]
    },
    {
      id: 't2', user: 'c1', topic: 'collab', status: 'pris_en_charge', referent: 'Nadia',
      created: to(2, 6), updated: to(0, 5),
      messages: [
        { id: 'tm6', from: 'member', at: to(2, 6), text: 'Mon manager ne répond plus depuis dix jours et ne m’a pas envoyé le contrat signé. Je ne sais pas si je peux travailler avec quelqu’un d’autre en attendant.' },
        { id: 'tm7', from: 'team', author: 'Nadia', at: to(2, 2), text: 'Bonjour Camille. Merci de nous l’avoir dit, c’est exactement le genre de situation que nous suivons. Rien ne vous oblige à attendre : sans contrat signé, vous restez libre. Je regarde son historique de la semaine et je vous reviens avant ce soir.' },
        { id: 'tm8', from: 'member', at: to(0, 7), text: 'Merci. Je préfère que ça reste entre nous pour l’instant, je ne veux pas de conflit.' },
        { id: 'tm9', from: 'team', author: 'Nadia', at: to(0, 5), text: 'C’est noté : aucun signalement public, aucune mention sur son profil. Nous vous répondons ici, et vous restez décisionnaire. Je vous propose un point de 20 minutes jeudi si vous le souhaitez.' }
      ]
    },
    {
      id: 't3', user: 'm2', topic: 'question', status: 'nouveau', referent: null,
      created: to(0, 2), updated: to(0, 2),
      messages: [
        { id: 'tm10', from: 'member', at: to(0, 2), text: 'Question simple : une créatrice m’a demandé d’attendre avant de signer. Est-ce qu’un accord verbal engage quelque chose chez vous ?' }
      ]
    }
  ];

  /* Préférences de confort : pause, discrétion, rythme des notifications,
     accompagnement renforcé, canal préféré. Aucune n'est verrouillée. */
  const care = {
    c9: { pause: false, discret: false, rythme: 'tout', accompagnement: 'renforce', canal: 'message' },
    c1: { pause: false, discret: true, rythme: 'essentiel', accompagnement: 'renforce', canal: 'appel' },
    m2: { pause: false, discret: false, rythme: 'quotidien', accompagnement: 'normal', canal: 'message' }
  };

  /* ------------------------------------------------------------------ */
  /* Notifications                                                       */
  /* ------------------------------------------------------------------ */
  const notifications = {
    creator: [
      { id: 'n1', type: 'request', icon: 'send', title: 'Nouvelle demande de Halo Management', text: 'Agence vérifiée · Paris · 21 créateurs accompagnés', at: to(0, 5), unread: true, href: '#/app/requests' },
      { id: 'n2', type: 'message', icon: 'message', title: '2 nouveaux messages de Halo Management', text: '« Un dernier point : êtes-vous ouverte à un mois d’essai… »', at: to(0, 6), unread: true, href: '#/app/messages/cv1' },
      { id: 'n3', type: 'match', icon: 'sparkles', title: '3 profils très compatibles avec votre recherche', text: 'Compatibilité estimée entre 78 % et 92 %', at: to(0, 9), unread: true, href: '#/app/matching' },
      { id: 'n4', type: 'team', icon: 'headset', title: 'Prise en charge de votre demande', text: 'L’équipe Sève a présélectionné 4 managers pour vous', at: to(2, 6), unread: false, href: '#/app/messages/cv4' },
      { id: 'n5', type: 'request', icon: 'checkCircle', title: 'Demande acceptée par Halo Management', text: 'Vous pouvez poursuivre la conversation dans la messagerie', at: to(7, 4), unread: false, href: '#/app/requests' }
    ],
    manager: [
      { id: 'n1', type: 'request', icon: 'send', title: 'Nouvelle demande de Lya Moreau', text: 'Créatrice · Paris · 88 k abonnés', at: to(0, 4), unread: true, href: '#/app/requests' },
      { id: 'n2', type: 'message', icon: 'message', title: 'Lya Moreau a répondu', text: '« Merci, je l’ai reçu. Une question : le mois d’essai est-il possible… »', at: to(0, 4), unread: true, href: '#/app/messages/cv5' },
      { id: 'n3', type: 'profile', icon: 'userPlus', title: '2 nouveaux profils dans votre zone', text: 'Camille Roy (Lyon) et Inès Da Silva (Porto)', at: to(0, 8), unread: true, href: '#/app/discover' },
      { id: 'n4', type: 'match', icon: 'sparkles', title: 'Recommandation : 4 créatrices compatibles', text: 'Compatibilité estimée entre 74 % et 89 %', at: to(1, 2), unread: false, href: '#/app/matching' },
      { id: 'n5', type: 'team', icon: 'headset', title: 'Demande d’accompagnement traitée', text: 'Studio Bruma · 2 créatrices recommandées', at: to(6, 2), unread: false, href: '#/app/requests' }
    ],
    admin: [
      { id: 'n1', type: 'report', icon: 'flag', title: 'Signalement prioritaire à traiter', text: 'Demande de paiement hors plateforme · Sasha Ivanova', at: to(0, 10), unread: true, href: '#/admin/reports' },
      { id: 'n2', type: 'report', icon: 'flag', title: 'Vérification d’âge demandée', text: 'Jade Lefèvre · contrôle avant toute mise en relation', at: to(1, 4), unread: true, href: '#/admin/reports' },
      { id: 'n3', type: 'moderation', icon: 'shield', title: '3 profils en attente de vérification', text: 'Jade Lefèvre, Sasha Ivanova, Chloé Bertrand', at: to(1, 6), unread: true, href: '#/admin/profiles' },
      { id: 'n4', type: 'application', icon: 'headset', title: '2 nouvelles demandes d’accompagnement', text: 'Chloé Bertrand · Studio Bruma', at: to(1, 2), unread: false, href: '#/admin/applications' }
    ]
  };

  /* ------------------------------------------------------------------ */
  /* Comptes de démonstration                                            */
  /* ------------------------------------------------------------------ */
  const users = [
    { id: 'c9', role: 'creator', profileId: 'c9', name: 'Lya Moreau', email: 'lya@exemple.fr', password: 'seve2026', verified: true, status: 'active', joined: '2025-01-14' },
    { id: 'm2', role: 'manager', profileId: 'm2', name: 'Halo Management', email: 'halo@exemple.fr', password: 'seve2026', verified: true, status: 'active', joined: '2024-10-02' },
    { id: 'admin', role: 'admin', profileId: null, name: 'Équipe Sève', email: 'admin@seve.fr', password: 'seve2026', verified: true, status: 'active', joined: '2024-06-01' }
  ];

  /* ------------------------------------------------------------------ */
  /* Versions publiques                                                  */
  /* ------------------------------------------------------------------ */
  const publicProfile = (p) => ({
    id: p.id, role: p.role, name: p.name, handle: p.handle, kind: p.kind, tone: p.tone,
    city: p.city, country: p.country, region: p.region, verified: !!p.verified,
    availability: p.availability, specialties: (p.specialties || []).slice(),
    languages: (p.languages || []).slice()
  });

  return {
    creators, managers, requests, conversations, applications, reports, notifications, users, disputes,
    teamThreads, care,
    profiles: creators.concat(managers),
    publicProfile,
    daysAgo: to
  };
})();
