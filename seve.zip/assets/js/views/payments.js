/* ==========================================================================
   Sève — Coordonnées de paiement (RIB) : espace membre + administration
   --------------------------------------------------------------------------
   Chaque compte dispose d’un jeu de coordonnées : déclaré par le membre
   (validé : clé IBAN, clé RIB française, format BIC) ou généré en jeu de
   démonstration. Le document RIB est imprimable et joinable à une facture.
   Sève ne transporte aucun fonds.
   ========================================================================== */
(function () {
  const U = SEVE.util;
  const OF = SEVE.of;
  const ui = SEVE.ui;
  const store = SEVE.store;
  const IB = SEVE.iban;
  const C = SEVE.components;
  const icon = SEVE.icons.svg;

  SEVE.views = SEVE.views || {};

  /* ================================================================== */
  /* ESPACE MEMBRE                                                       */
  /* ================================================================== */
  SEVE.views.payouts = {
    title: 'Coordonnées de paiement',
    render() {
      const me = store.me();
      const acc = store.ensurePayout(me.id);
      const isManager = me.role === 'manager';
      const ib = IB.inspectIban(acc.iban);
      const parts = IB.frenchParts(acc.iban);
      const status = store.PAYOUT_STATUS[acc.status] || store.PAYOUT_STATUS.declared;

      return '<div class="page-head"><div>' +
        '<h1>Coordonnées de paiement (RIB)</h1>' +
        '<p>Le RIB rattaché à votre compte : ' + (isManager ? 'il sert à facturer vos prestations ' : 'il sert à être payé(e) de vos commissions ') +
        'et à régler ce que vous devez. Sève n’encaisse rien et ne transporte aucun fonds.</p></div>' +
        '<div class="row gap-10" style="flex-wrap:wrap">' +
        ui.btn({ label: 'Générer mon RIB', variant: 'primary', act: 'payouts-generate', icon: 'doc' }) +
        '</div></div>' +

        ui.banner({
          variant: 'soft', icon: 'shield',
          html: '<b>Ce que ce document est — et n’est pas.</b> C’est un relevé d’identité bancaire généré depuis les informations de votre compte Sève, à imprimer pour vos factures ou à transmettre à un partenaire. Ce n’est pas un ordre de virement : aucune somme ne passe par Sève, et vos coordonnées ne sont jamais partagées avec les autres membres.'
        }) +

        '<div class="grid grid--side mt-20" style="align-items:start">' +

        /* ------------------------------- Formulaire ------------------------------ */
        '<section class="card card--pad reveal">' +
        '<h3>Vos coordonnées</h3>' +
        '<p class="small muted mt-8">Chaque modification est enregistrée et repasse en « à vérifier » : l’équipe contrôle la cohérence (clé IBAN, format BIC, concordance du titulaire).</p>' +
        '<form id="payout-form" novalidate>' +
        '<div class="formgrid mt-20">' +
        '<div class="field"><label class="label" for="po-holder">Titulaire du compte <span class="req">*</span></label>' +
        '<input class="input" id="po-holder" required value="' + U.esc(acc.holder) + '" placeholder="Le nom exact figurant sur le compte">' +
        '<p class="help">Identique à celui de votre banque, sans abréviation.</p></div>' +
        '<div class="field"><label class="label" for="po-bank">Domiciliation / banque</label>' +
        '<input class="input" id="po-bank" value="' + U.esc(acc.bank || '') + '" placeholder="Ex. Crédit Agricole — Paris 11e"></div>' +
        '<div class="field span2"><label class="label" for="po-iban">IBAN <span class="req">*</span></label>' +
        '<input class="input" id="po-iban" required value="' + U.esc(acc.iban ? IB.format(acc.iban) : '') + '" placeholder="FR76 3000 6000 0112 3456 7890 189" autocomplete="off" spellcheck="false" style="font-family:var(--mono);letter-spacing:.02em">' +
        '<div id="po-iban-status" class="row gap-8 mt-8" style="flex-wrap:wrap"></div></div>' +
        '<div class="field"><label class="label" for="po-bic">BIC / SWIFT</label>' +
        '<input class="input" id="po-bic" value="' + U.esc(acc.bic || '') + '" placeholder="AGRIFRPP" spellcheck="false" style="font-family:var(--mono)">' +
        '<p class="help" id="po-bic-help">8 ou 11 caractères. Souvent demandé pour les virements hors France.</p></div>' +
        '<div class="field"><label class="label" for="po-code">Code banque / guichet</label>' +
        '<input class="input" id="po-code" value="' + U.esc(parts ? parts.banque + ' · ' + parts.guichet : (acc.bankCode || '')) + '" placeholder="30006 · 00001" spellcheck="false">' +
        '<p class="help">Renseigné automatiquement depuis l’IBAN.</p></div>' +
        '<div class="field span2"><label class="label" for="po-city">Ville de signature</label>' +
        '<input class="input" id="po-city" value="' + U.esc(acc.city || '') + '" placeholder="Paris"></div>' +
        '</div>' +
        '<div id="payout-feedback"></div>' +
        '<div class="row gap-12 mt-24" style="flex-wrap:wrap">' +
        ui.btn({ label: 'Enregistrer mes coordonnées', variant: 'primary', act: 'payouts-save' }) +
        ui.btn({ label: 'Utiliser un jeu de test', variant: 'outline', act: 'payouts-demo-fill' }) +
        ui.btn({ label: 'Copier l’IBAN', variant: 'ghost', act: 'payouts-copy', icon: 'link', iconSize: 15 }) +
        '</div>' +
        '<p class="tiny muted mt-16">' + icon('info', 13) + ' Le jeu de test remplit le formulaire avec des coordonnées fictives (codes bancaires d’exemple) : utile pour voir le rendu du document, jamais pour un vrai virement.</p>' +
        '</form></section>' +

        /* -------------------------------- Colonne ------------------------------- */
        '<aside class="sticky-side">' +

        '<div class="card card--pad reveal">' +
        '<div class="between"><h4>État de la déclaration</h4>' + ui.pill(status.label, status.variant) + '</div>' +
        '<p class="small muted mt-8">' + U.esc(status.hint) + '</p>' +
        '<dl class="defs mt-12">' +
        '<div class="def"><dt>Dernière mise à jour</dt><dd>' + U.esc(acc.updated ? U.fmtDate(acc.updated) + ' à ' + U.fmtTime(acc.updated) : 'Jamais modifiée') + '</dd></div>' +
        '<div class="def"><dt>Origine des données</dt><dd>' + (acc.updated ? 'Déclarées par vous' : 'Jeu de démonstration') + '</dd></div>' +
        '<div class="def"><dt>Partage</dt><dd>Aucun — visible par vous et l’équipe de vérification</dd></div>' +
        '</dl></div>' +

        '<div class="card card--pad reveal">' +
        '<h4>Aperçu du RIB</h4>' +
        '<div class="copyable mt-12" style="width:100%;justify-content:space-between">' + U.esc(IB.mask(acc.iban)) +
        '<span class="tiny muted">' + (ib.ok ? 'clé valide' : 'à corriger') + '</span></div>' +
        '<dl class="defs mt-12">' +
        '<div class="def"><dt>Titulaire</dt><dd>' + U.esc(acc.holder) + '</dd></div>' +
        '<div class="def"><dt>Clé RIB</dt><dd>' + U.esc((parts && parts.cle) || acc.cle || '—') + '</dd></div>' +
        '<div class="def"><dt>BIC</dt><dd>' + U.esc(acc.bic || '—') + '</dd></div>' +
        '</dl>' +
        '<div class="stack gap-8 mt-16">' +
        ui.btn({ label: 'Voir et imprimer le document', variant: 'primary', block: true, act: 'payouts-generate', icon: 'doc' }) +
        '</div></div>' +

        '<div class="card card--pad reveal" style="border-color:var(--warn-bg)">' +
        '<h4>Rappels importants</h4>' +
        '<ul class="stack gap-10 mt-12">' + [
          'Ne communiquez jamais un RIB qui n’est pas le vôtre : l’usurpation de coordonnées bancaires est un délit.',
          'Le RIB d’un tiers ne peut pas servir à recevoir vos gains OnlyFans : le titulaire doit être le vôtre, sinon la plateforme refuse le versement et peut geler le compte.',
          'Un changement de coordonnées se confirme toujours par un second canal : méfiez-vous des messages urgents.',
          'Sève ne vous demandera jamais d’avance, de « frais de dossier » ni de paiement entre membres.',
          'Signalez toute demande de coordonnées inhabituelle : elle est traitée en priorité.'
        ].map((t) => '<li class="row gap-8" style="align-items:flex-start"><span style="color:var(--warn)">' + icon('shield', 15) + '</span>' +
          '<span class="small muted">' + U.esc(t) + '</span></li>').join('') + '</ul></div>' +

        '</aside></div>' +

        /* ------------------ Répartition avec un partenaire ------------------- */
        sectionRepartition(me);
    },

    mount(ctx) {
      const me = store.me();
      brancherRepartition(ctx);
      const form = ctx.root.querySelector('#payout-form');
      if (!form) return;

      const statusSlot = ctx.root.querySelector('#po-iban-status');
      const ibanInput = ctx.root.querySelector('#po-iban');
      const bicInput = ctx.root.querySelector('#po-bic');
      const codeInput = ctx.root.querySelector('#po-code');

      /* Validation en direct de l’IBAN ---------------------------------- */
      const checkIban = () => {
        const res = IB.inspectIban(ibanInput.value);
        const parts = IB.frenchParts(ibanInput.value);
        if (parts) codeInput.value = parts.banque + ' · ' + parts.guichet;
        if (!ibanInput.value.trim()) {
          statusSlot.innerHTML = '<span class="help">Saisissez votre IBAN : nous contrôlons la longueur, la clé de contrôle et, en France, la clé RIB.</span>';
          return res;
        }
        if (res.ok) {
          statusSlot.innerHTML = '<span class="chip chip--ok chip--sm">' + icon('check', 13) + 'IBAN valide</span>' +
            (res.rib ? '<span class="chip chip--sm">clé RIB ' + U.esc(res.rib.cle) + '</span>' : '') +
            '<span class="small muted">' + U.esc(IB.format(ibanInput.value)) + '</span>';
        } else {
          statusSlot.innerHTML = '<span class="chip chip--danger chip--sm">' + icon('alert', 13) + 'À corriger</span>' +
            '<span class="small" style="color:var(--danger)">' + U.esc(res.errors[0]) + '</span>';
        }
        return res;
      };

      const checkBic = () => {
        const help = ctx.root.querySelector('#po-bic-help');
        const v = bicInput.value.trim();
        if (!v) { help.textContent = '8 ou 11 caractères. Souvent demandé pour les virements hors France.'; help.style.color = ''; return; }
        if (IB.isValidBic(v)) { help.textContent = 'Format BIC valide.'; help.style.color = 'var(--ok)'; }
        else { help.textContent = 'Format inattendu : 8 ou 11 caractères, par exemple AGRIFRPP ou AGRIFRPP123.'; help.style.color = 'var(--danger)'; }
      };

      ibanInput.addEventListener('input', checkIban);
      ibanInput.addEventListener('blur', () => { if (ibanInput.value.trim()) ibanInput.value = IB.format(ibanInput.value); });
      bicInput.addEventListener('input', checkBic);
      checkIban();
      checkBic();

      /* Enregistrement --------------------------------------------------- */
      const feedback = ctx.root.querySelector('#payout-feedback');
      const save = ctx.root.querySelector('[data-act="payouts-save"]');
      save.addEventListener('click', () => {
        feedback.innerHTML = '';
        /* 1. validation générique du formulaire (elle purge les erreurs précédentes) */
        let ok = ui.validate(form);
        /* 2. validation métier des coordonnées bancaires, appliquée après */
        const ib = IB.inspectIban(ibanInput.value);
        if (!ibanInput.value.trim()) {
          ui.fieldError(ibanInput, 'L’IBAN est nécessaire pour générer un RIB.');
          ok = false;
        } else if (!ib.ok) {
          ib.errors.forEach((m, i) => { if (i === 0) ui.fieldError(ibanInput, m); });
          ok = false;
        }
        if (bicInput.value.trim() && !IB.isValidBic(bicInput.value)) {
          ui.fieldError(bicInput, 'BIC au format invalide.');
          ok = false;
        }
        if (!ok) {
          feedback.innerHTML = ui.banner({ variant: 'danger', title: 'Enregistrement impossible.', text: 'Corrigez les champs signalés : des coordonnées invalides empêcheraient un virement d’aboutir.' });
          return;
        }
        ui.loading(save, true, 'Enregistrement…');
        setTimeout(() => {
          store.savePayout(me.id, {
            holder: ctx.root.querySelector('#po-holder').value.trim(),
            bank: ctx.root.querySelector('#po-bank').value.trim(),
            bic: IB.formatBic(bicInput.value),
            iban: IB.clean(ibanInput.value),
            city: ctx.root.querySelector('#po-city').value.trim(),
            country: me.country,
            demo: false
          });
          ui.loading(save, false);
          ui.toast('Coordonnées enregistrées. Elles repassent en « à vérifier » jusqu’au contrôle de l’équipe.', 'ok');
          SEVE.router.refresh();
        }, 640);
      });

      /* Jeu de test ------------------------------------------------------ */
      ctx.root.querySelector('[data-act="payouts-demo-fill"]').addEventListener('click', () => {
        const demo = IB.demoAccount(me);
        ctx.root.querySelector('#po-holder').value = demo.holder;
        ctx.root.querySelector('#po-bank').value = demo.bank;
        ibanInput.value = IB.format(demo.iban);
        bicInput.value = demo.bic;
        ctx.root.querySelector('#po-city').value = demo.city;
        checkIban();
        checkBic();
        ui.toast('Coordonnées de test insérées : elles sont fictives et servent uniquement à visualiser le document.', 'info');
      });

      /* Copie de l’IBAN -------------------------------------------------- */
      ctx.root.querySelector('[data-act="payouts-copy"]').addEventListener('click', () => {
        ui.copy(IB.format(ibanInput.value), 'IBAN copié. Vérifiez-le avant tout envoi.');
      });

      /* Document RIB ----------------------------------------------------- */
      ctx.root.querySelectorAll('[data-act="payouts-generate"]').forEach((b) => b.addEventListener('click', () => {
        const acc = store.ensurePayout(me.id);
        openRibDocument(acc, me);
      }));
    }
  };

  /* ================================================================== */
  /* RÉPARTITION — ce que je dois à mon partenaire, et comment le régler  */
  /* ================================================================== */
  /* Le calcul et la pièce justificative sont ici ; le virement se fait
     entre les deux membres, de compte à compte. Sève ne reçoit rien : c'est
     la loi (activité de services de paiement réservée aux établissements
     agréés), et c'est aussi ce qui protège les deux parties.              */
  function sectionRepartition(me) {
    const partenaires = store.partenaires(me.id);
    const stats = store.commissionStats({ profileId: me.id });
    const registre = store.commissions({ profileId: me.id });
    const estManager = me.role === 'manager';
    const st = store.ofStats();
    const revenusReels = st.reel ? st.revenus30 : null;

    const resume = registre.length
      ? '<span class="tiny muted">' + registre.length + ' relevé' + (registre.length > 1 ? 's' : '') + ' · ' +
        (stats.aRegler ? stats.aRegler + ' à régler (' + OF.euros0(stats.montantARegler) + ')' : 'tout est réglé') + '</span>'
      : '<span class="tiny muted">aucun relevé pour l’instant</span>';

    const choix = partenaires.length
      ? '<div class="grid mt-12" style="grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px">' +
        '<div class="field span2"><label class="label" for="cm-partenaire">' + (estManager ? 'Avec' : 'À') + ' qui ?</label>' +
        '<select class="input" id="cm-partenaire">' + partenaires.map((p) =>
          '<option value="' + U.esc(p.id) + '">' + U.esc(p.name) + (p.role === 'manager' ? ' — manager' : ' — créateur') + '</option>').join('') +
        '</select></div>' +
        '<div class="field"><label class="label" for="cm-base">Revenus de la période (€)</label>' +
        '<input class="input" id="cm-base" inputmode="decimal" value="' + (revenusReels ? String(Math.round(revenusReels)) : '') + '" placeholder="' + (revenusReels ? '' : 'ex. 1200') + '"></div>' +
        '<div class="field"><label class="label" for="cm-taux">Taux convenu (%)</label>' +
        '<input class="input" id="cm-taux" inputmode="decimal" value="' + U.esc(String(store.tauxAnnonce(partenaires[0]) || '')) + '" placeholder="ex. 20"></div>' +
        '<div class="field"><label class="label" for="cm-periode">Période</label>' +
        '<input class="input" id="cm-periode" value="30 derniers jours" spellcheck="false"></div>' +
        '</div>' +
        '<div class="row gap-10 mt-12" style="flex-wrap:wrap;align-items:center">' +
        ui.btn({ label: 'Créer le relevé', variant: 'primary', act: 'commission-creer', icon: 'percent' }) +
        '<span class="small muted">Montant dû : <b id="cm-montant">—</b></span>' +
        (revenusReels ? '<span class="tiny muted">· repris de tes revenus relevés (' + OF.euros0(revenusReels) + ' sur 30 jours), modifiable</span>' : '') +
        '</div>'
      : '<p class="small muted mt-12">Dès qu’une demande de collaboration est acceptée avec un manager (ou une créatrice), ' +
        'il apparaît ici : vous saisissez la base et le taux convenus, Sève calcule et produit le relevé. ' +
        '<a href="#/app/discover">Trouver un partenaire</a>.</p>';

    const tableau = registre.length
      ? '<div class="table-wrap mt-16"><table class="table"><thead><tr><th>Établi le</th><th>' +
        (estManager ? 'De la part de' : 'Vers') + '</th><th>Période</th><th>Base</th><th>Taux</th><th>Montant</th><th>État</th><th></th></tr></thead><tbody>' +
        registre.map((c) => {
          const autre = estManager ? c.from : c.to;
          const du = estManager ? (c.toId === me.id) : (c.fromId === me.id);
          return '<tr><td>' + U.fmtDate(c.at.slice(0, 10)) + '</td>' +
            '<td>' + U.esc(autre.name) + '</td>' +
            '<td>' + U.esc(c.periode || '—') + '</td>' +
            '<td class="tnum">' + OF.euros0(c.base) + '</td>' +
            '<td class="tnum">' + U.fmtNum(c.taux) + ' %</td>' +
            '<td class="tnum"><b>' + OF.euros(c.montant) + '</b></td>' +
            '<td><span class="chip chip--sm ' + (store.COMMISSION_STATUT[c.statut] || {}).tone + '">' + U.esc(c.statutLabel) + '</span></td>' +
            '<td class="cell-actions">' +
            ui.btn({ label: 'Relevé', variant: 'ghost', size: 'xs', act: 'commission-releve', data: { id: c.id }, icon: 'doc' }) +
            (du && c.statut !== 'regle'
              ? ui.btn({ label: 'Régler', variant: 'ghost', size: 'xs', act: 'commission-regler', data: { id: c.id }, icon: 'checkCircle' })
              : '') +
            ui.btn({ label: 'Retirer', variant: 'ghost', size: 'xs', act: 'commission-supprimer', data: { id: c.id }, icon: 'trash' }) +
            '</td></tr>';
        }).join('') + '</tbody></table></div>'
      : '';

    return '<section class="panel reveal mt-20" id="repartition">' +
      '<div class="panel__head"><h3>' + icon('percent', 16) + (estManager ? 'Commissions à recevoir' : 'Régler mon manager') + '</h3>' + resume + '</div>' +
      '<div class="panel__body">' +
      '<p class="small muted">Sève calcule ce qui est dû et produit le relevé à joindre au virement. ' +
      'Le virement part de votre compte vers le compte de votre partenaire : <b>Sève ne reçoit jamais cet argent</b>, ' +
      'ne le conserve pas et ne le répartit pas — encaisser des fonds pour le compte de tiers est une activité réservée aux établissements de paiement agréés.</p>' +
      ui.banner({ variant: 'soft', icon: 'shield',
        html: '<b>Votre IBAN doit être à votre nom.</b> Chez OnlyFans comme ailleurs, les gains arrivent sur un compte au nom vérifié de la créatrice : ' +
          'un compte au nom d’un tiers est refusé, et le compte peut être gelé pour cette raison. Aucun montant ne doit transiter par Sève ou par un autre membre.' }) +
      '<div class="paiement-gate mt-16" id="paiement-ligne" role="status">' +
      '<div class="paiement-gate__top"><span class="paiement-gate__icon">' + icon('shieldCheck', 19) + '</span>' +
      '<div><b>Paiement en ligne des commissions</b>' +
      '<p>Piste retenue : Segpay, prestataire spécialisé dans le secteur adulte et présent en Europe. Son accord écrit sur les commissions OFM reste nécessaire avant tout paiement.</p></div>' +
      '<span class="chip chip--warn">En attente de validation</span></div>' +
      '<div class="paiement-gate__actions">' +
      ui.btn({ label: 'Contacter Segpay', variant: 'outline', size: 'sm', act: 'paiement-segpay-demande', icon: 'doc' }) +
      '<span>Pas de bouton de paiement actif, pas de saisie de carte ici. Une commission ne passe à « Réglé » qu’après un vrai virement confirmé par la personne qui paie ; jamais en simulant un paiement par carte.</span>' +
      '</div></div>' +
      choix + tableau +
      '</div></section>';
  }

  /** Aperçu du montant dû, calculé en direct pendant la saisie. */
  function brancherRepartition(ctx) {
    const base = ctx.root.querySelector('#cm-base');
    const taux = ctx.root.querySelector('#cm-taux');
    const cible = ctx.root.querySelector('#cm-montant');
    if (!base || !taux || !cible) { return; }
    const maj = () => {
      const montant = SEVE.of.montant(base.value) * (Number(taux.value) || 0) / 100;
      cible.textContent = montant > 0 ? OF.euros(montant) : '—';
    };
    base.addEventListener('input', maj);
    taux.addEventListener('input', maj);
    /* Le taux annoncé du partenaire choisi sert de valeur de départ. */
    const choix = ctx.root.querySelector('#cm-partenaire');
    if (choix) {
      choix.addEventListener('change', () => {
        const p = store.get(choix.value);
        const t = store.tauxAnnonce(p);
        if (t) { taux.value = String(t); }
        maj();
      });
    }
    maj();
  }

  /** Le relevé imprimable d'une commission. */
  function openRelevéCommission(c) {
    const profils = [store.get(c.fromId), store.get(c.toId)].filter(Boolean);
    ui.modal({
      title: 'Relevé de commission',
      subtitle: 'Pièce justificative à joindre au virement, entre vous deux. À imprimer ou enregistrer en PDF.',
      size: 'lg',
      body: IB.repartitionDocument(c, profils),
      footer: ui.btn({ label: 'Fermer', variant: 'ghost', act: 'cancel' }) +
        (c.toIban ? ui.btn({ label: 'Copier l’IBAN du bénéficiaire', variant: 'outline', act: 'rib-copy' }) : '') +
        ui.btn({ label: 'Imprimer / PDF', variant: 'primary', act: 'rib-print', icon: 'doc' }),
      onMount(panel) {
        panel.querySelector('[data-act="cancel"]').addEventListener('click', () => ui.close());
        const copie = panel.querySelector('[data-act="rib-copy"]');
        if (copie) { copie.addEventListener('click', () => ui.copy(IB.format(c.toIban), 'IBAN copié — vérifiez le titulaire avant d’envoyer.')); }
        panel.querySelector('[data-act="rib-print"]').addEventListener('click', () => {
          document.documentElement.classList.add('is-printing');
          setTimeout(() => { window.print(); document.documentElement.classList.remove('is-printing'); }, 60);
        });
      }
    });
  }

  /* ------------------------------------------------------------------ */
  /* Document RIB : modale imprimable                                    */
  /* ------------------------------------------------------------------ */
  function openRibDocument(acc, profile, opts) {
    opts = opts || {};
    ui.modal({
      title: 'Relevé d’identité bancaire',
      subtitle: opts.subtitle || 'Document généré depuis les informations de votre compte. À imprimer ou à enregistrer en PDF (Imprimer → Enregistrer au format PDF).',
      size: 'lg',
      body: IB.document(acc, profile),
      footer: ui.btn({ label: 'Fermer', variant: 'ghost', act: 'cancel' }) +
        ui.btn({ label: 'Copier l’IBAN', variant: 'outline', act: 'rib-copy' }) +
        ui.btn({ label: 'Imprimer / PDF', variant: 'primary', act: 'rib-print', icon: 'doc' }),
      onMount(panel) {
        panel.querySelector('[data-act="cancel"]').addEventListener('click', () => ui.close());
        panel.querySelector('[data-act="rib-copy"]').addEventListener('click', () => ui.copy(IB.format(acc.iban), 'IBAN copié.'));
        panel.querySelector('[data-act="rib-print"]').addEventListener('click', () => {
          document.documentElement.classList.add('is-printing');
          setTimeout(() => {
            window.print();
            document.documentElement.classList.remove('is-printing');
          }, 60);
        });
      }
    });
  }

  /* --------------------------------- Actions du registre --------------------------- */
  SEVE.act('paiement-segpay-demande', function () {
    ui.modal({
      title: 'Demander l’accord de Segpay',
      subtitle: 'Écrivez à sales@segpay.com, ou utilisez leur formulaire commerçant. Aucun paiement n’est activé.',
      size: 'lg',
      body: '<div class="stack gap-12">' +
        '<p class="small">Segpay travaille avec des entreprises du secteur adulte dans l’Union européenne et indique pouvoir gérer des versements à des tiers. <b>Cela ne prouve pas qu’il acceptera ce cas particulier</b> : une confirmation écrite et des conditions commerciales sont indispensables avant toute intégration.</p>' +
        '<label class="label" for="segpay-demande">Texte à envoyer à sales@segpay.com</label>' +
        '<textarea class="textarea" id="segpay-demande" rows="12" readonly>Subject: Approval request — France OFM management-service commissions (Sève)\n\nHello,\n\nSève is a France-based matchmaking platform for adult OnlyFans creators and OFM managers. OnlyFans pays creators directly to their own verified bank accounts. We do not process fan payments or host/sell adult content. We want an adult-industry payment provider to process the creator’s separate payment of an agreed management-service invoice/commission to a verified manager, in EUR, without Sève ever holding or redistributing funds.\n\nDo you explicitly accept this exact business model in France? Can the manager be the merchant/payee, or can Segpay legally handle the third-party payout? Which account(s) must pass KYC, and who is merchant of record? Are one-off card payments and SEPA available, with a hosted checkout, API and signed payment notifications? Please detail fees, rolling reserves, chargebacks, required contracts, tax/invoicing obligations and onboarding steps. Please confirm in writing that this model is approved before any live payment.\n\nThank you.</textarea>' +
        '<p class="small muted">N’envoyez aucune clé API ni pièce d’identité dans Sève. Pour les justificatifs KYC, utilisez uniquement le canal sécurisé indiqué par Segpay.</p></div>',
      footer: ui.btn({ label: 'Fermer', variant: 'ghost', act: 'cancel' }) +
        ui.btn({ label: 'Copier la demande', variant: 'primary', act: 'segpay-demande-copier', icon: 'doc' }),
      onMount(panel) {
        panel.querySelector('[data-act="cancel"]').addEventListener('click', () => ui.close());
        panel.querySelector('[data-act="segpay-demande-copier"]').addEventListener('click', () => {
          ui.copy(panel.querySelector('#segpay-demande').value, 'Demande copiée. Envoyez-la à sales@segpay.com.');
        });
      }
    });
  });

  SEVE.act('commission-creer', function () {
    const me = store.me();
    const choix = document.querySelector('#cm-partenaire');
    const base = document.querySelector('#cm-base');
    const taux = document.querySelector('#cm-taux');
    const periode = document.querySelector('#cm-periode');
    if (!choix || !choix.value) { ui.toast('Choisissez d’abord votre partenaire.', 'err'); return; }
    const b = SEVE.of.montant(base ? base.value : '');
    const t = Number(String(taux ? taux.value : '').replace(',', '.'));
    if (!(b > 0)) { ui.toast('Indiquez les revenus de la période (en euros).', 'err'); return; }
    if (!(t > 0)) { ui.toast('Indiquez le taux convenu, en pourcentage (ex. 20).', 'err'); return; }
    if (t > 90) { ui.toast('Un taux au-delà de 90 % n’est pas réaliste : vérifiez la valeur.', 'err'); return; }

    const partenaire = store.get(choix.value) || {};
    const rib = store.ensurePayout(partenaire.id) || {};
    const c = store.commissionAjouter({
      fromId: me.id, toId: partenaire.id,
      periode: (periode && periode.value) || '30 derniers jours',
      base: b, taux: t, montant: Math.round(b * t) / 100,
      note: 'Taux convenu : ' + t + ' %',
      toIban: rib.iban || '', toBic: rib.bic || '', toHolder: rib.holder || partenaire.name || '',
      toDemo: !!rib.demo      /* coordonnées du jeu de démonstration : à signaler */
    });
    ui.toast('Relevé établi : ' + OF.euros(c.montant) + ' dus à ' + partenaire.name + '. Le virement se fait de vous à votre partenaire.',
      'ok', { title: 'Relevé créé' });
    SEVE.router.refresh();
    openRelevéCommission(c);
  });

  SEVE.act('commission-releve', function (el) {
    const c = store.commissionDepuisId(el.getAttribute('data-id'));
    if (!c) { ui.toast('Ce relevé n’est plus là.', 'info'); return; }
    openRelevéCommission(c);
  });

  SEVE.act('commission-regler', function (el) {
    const id = el.getAttribute('data-id');
    const c = store.commissionDepuisId(id);
    if (!c) { return; }
    ui.confirm({
      title: 'Marquer comme réglé ?',
      text: 'À confirmer seulement quand le virement est parti de votre compte vers ' + (c.to && c.to.name ? c.to.name : 'votre partenaire') +
        '. Sève n’a pas accès à votre banque : c’est vous qui attestez. Rien ne doit transiter par Sève.',
      ok: 'Oui, c’est réglé'
    }).then((vrai) => {
      if (!vrai) { return; }
      store.commissionMarquer(id, 'regle');
      ui.toast('Relevé marqué comme réglé.', 'ok');
      SEVE.router.refresh();
    });
  });

  SEVE.act('commission-supprimer', function (el) {
    const id = el.getAttribute('data-id');
    const c = store.commissionDepuisId(id);
    if (!c) { return; }
    ui.confirm({
      title: 'Retirer ce relevé ?',
      text: 'Le relevé sera supprimé du registre. Cela ne change rien au virement lui-même : si l’argent est parti, gardez une preuve de votre côté.',
      ok: 'Retirer'
    }).then((vrai) => {
      if (!vrai) { return; }
      store.commissionSupprimer(id);
      ui.toast('Relevé retiré.', 'info');
      SEVE.router.refresh();
    });
  });

  /* ================================================================== */
  /* ADMINISTRATION — coordonnées de paiement de tous les comptes         */
  /* ================================================================== */
  SEVE.views.adminPayouts = {
    title: 'Coordonnées de paiement',
    render(ctx) {
      const q = ctx.query.q || '';
      const status = ctx.query.status || 'all';
      const list = store.payouts({ q, status });
      const s = store.payoutsStats();

      const rows = list.map((a) => {
        const st = store.PAYOUT_STATUS[a.status] || store.PAYOUT_STATUS.declared;
        return '<tr>' +
          '<td><div class="tcell">' + ui.avatar(Object.assign({ square: a.profile.role === 'manager' }, a.profile), 'sm') +
          '<div class="tcell__txt"><b>' + U.esc(a.profile.name) + '</b><span>' + U.esc(a.profile.role === 'manager' ? (a.profile.kind || 'Manager') : 'Créateur') +
          ' · ' + U.esc(a.profile.city || '—') + '</span></div></div></td>' +
          '<td><div class="tcell__txt"><b>' + U.esc(a.holder) + '</b><span>' + U.esc(a.bank || '—') + '</span></div></td>' +
          '<td class="num-inline" style="font-family:var(--mono);font-size:12.5px">' + U.esc(IB.mask(a.iban)) + '</td>' +
          '<td class="small muted" style="font-family:var(--mono)">' + U.esc(a.bic || '—') + '</td>' +
          '<td>' + ui.pill(st.label, st.variant) + (a.updated ? '' : '<div class="tiny muted mt-4">jeu de démonstration</div>') + '</td>' +
          '<td class="small muted">' + U.esc(a.updated ? U.fmtRelative(a.updated) : '—') + '</td>' +
          '<td><div class="cell-actions">' +
          ui.btn({ label: 'Document', variant: 'ghost', size: 'xs', act: 'admin-payout-doc', data: { id: a.profile.id } }) +
          (a.status === 'verified'
            ? ui.btn({ label: 'Révoquer', variant: 'ghost', size: 'xs', act: 'admin-payout-status', data: { id: a.profile.id, status: 'declared' } })
            : ui.btn({ label: 'Vérifier', variant: 'soft', size: 'xs', act: 'admin-payout-status', data: { id: a.profile.id, status: 'verified' } })) +
          (a.status === 'rejected' ? '' : ui.btn({ label: 'Demander une correction', variant: 'outline', size: 'xs', act: 'admin-payout-reject', data: { id: a.profile.id } })) +
          '</div></td></tr>';
      }).join('');

      return '<div class="page-head"><div>' +
        '<h1>Coordonnées de paiement</h1>' +
        '<p>Un RIB par compte, vérifié à la main. Le contrôle porte sur la <b>cohérence formelle</b> (clé IBAN, clé RIB, format BIC, concordance du titulaire) : nous n’interrogeons pas la banque et ne validons pas l’existence du compte.</p></div>' +
        '<div class="row gap-10" style="flex-wrap:wrap">' +
        ui.btn({ label: 'Exporter (IBAN masqués)', variant: 'outline', act: 'admin-export-payouts', icon: 'doc' }) +
        ui.btn({ label: 'Règles de paiement', variant: 'ghost', href: '#/legal/rules', icon: 'scale' }) + '</div></div>' +

        '<div class="kpis">' +
        ui.kpi({ label: 'Comptes avec coordonnées', value: s.total, icon: 'wallet', foot: s.demo + ' en jeu de démonstration' }) +
        ui.kpi({ label: 'Vérifiées', value: s.verified, icon: 'shieldCheck', foot: 'Contrôle formel effectué' }) +
        ui.kpi({ label: 'À vérifier', value: s.declared, icon: 'clock', foot: 'File de contrôle' }) +
        ui.kpi({ label: 'Demandes de correction', value: s.rejected, icon: 'alert', foot: 'Le membre doit mettre à jour' }) +
        '</div>' +

        /* ------------------------ Registre de répartition ------------------------ */
        (function () {
          const cs = store.commissionStats({});
          const liste = store.commissions({}).slice(0, 12);
          const lignes = liste.length
            ? '<div class="table-wrap mt-12"><table class="table"><thead><tr><th>Établi le</th><th>De</th><th>Vers</th><th>Période</th><th>Base</th><th>Taux</th><th>Montant</th><th>État</th></tr></thead><tbody>' +
              liste.map((c) => '<tr><td>' + U.fmtDate(c.at.slice(0, 10)) + '</td>' +
                '<td>' + U.esc(c.from.name) + '</td><td>' + U.esc(c.to.name) + '</td>' +
                '<td>' + U.esc(c.periode || '—') + '</td>' +
                '<td class="tnum">' + OF.euros0(c.base) + '</td>' +
                '<td class="tnum">' + U.fmtNum(c.taux) + ' %</td>' +
                '<td class="tnum">' + OF.euros(c.montant) + '</td>' +
                '<td><span class="chip chip--sm ' + (store.COMMISSION_STATUT[c.statut] || {}).tone + '">' + U.esc(c.statutLabel) + '</span></td></tr>').join('') +
              '</tbody></table></div>'
            : '<p class="small muted mt-12">Aucune commission établie pour l’instant. Les membres en créent une depuis « Paiements & RIB » quand une collaboration acceptée donne lieu à rémunération.</p>';
          return '<section class="panel reveal mt-20" id="admin-repartition">' +
            '<div class="panel__head"><h3>' + icon('percent', 16) + 'Répartition entre membres</h3>' +
            '<span class="tiny muted">' + cs.total + ' relevé(s) · ' + OF.euros0(cs.volume) + ' au total</span></div>' +
            '<div class="panel__body">' +
            '<div class="row gap-16" style="flex-wrap:wrap">' +
            '<span class="small"><b>' + cs.aRegler + '</b> à régler <span class="muted">(' + OF.euros0(cs.montantARegler) + ')</span></span>' +
            '<span class="small"><b>' + cs.regle + '</b> réglé(s) <span class="muted">(' + OF.euros0(cs.montantRegle) + ')</span></span>' +
            '</div>' +
            '<p class="small muted mt-8">Ce registre est un suivi documentaire. Les virements se font entre les membres, de compte à compte : ' +
            'Sève n’encaisse, ne conserve et ne répartit aucun fonds, et n’est pas un établissement de paiement.</p>' +
            lignes + '</div></section>';
        })() +

        '<div class="banner banner--soft mt-20">' + icon('shield', 18) +
        '<div><b>Procédure.</b> Vérifier = contrôler la forme et la concordance du titulaire avec le profil public, puis marquer le compte comme vérifié. En cas de doute (nom différent, IBAN d’un pays incohérent avec la localisation déclarée), demander une correction et consigner le motif. Sève ne stocke aucun document bancaire et n’exécute aucun virement.</div></div>' +

        '<div class="filterbar mt-20" data-filters><div class="filters">' +
        '<div class="filter" style="grid-column:span 2">' + C.searchBar({ value: q, id: 'pay-q', placeholder: 'Rechercher un titulaire, un profil, un IBAN' }) + '</div>' +
        C.chipsHTML({ key: 'status', label: 'État', value: status,
          options: [['all', 'Tous les états'], ['declared', 'À vérifier'], ['verified', 'Vérifiées'], ['rejected', 'À corriger']] }) +
        '</div></div>' +

        '<div class="mt-20">' + (list.length
          ? '<div class="table-wrap"><table class="table"><thead><tr><th>Compte</th><th>Titulaire / domiciliation</th><th>IBAN</th><th>BIC</th><th>État</th><th>Mise à jour</th><th></th></tr></thead><tbody>' + rows + '</tbody></table></div>'
          : ui.empty({ icon: 'wallet', title: 'Aucune coordonnée dans ce filtre', text: 'Chaque nouveau compte reçoit un jeu de coordonnées de démonstration tant que le membre n’a pas déclaré les siennes.' })) +
        '</div>';
    },
    mount(ctx) { SEVE.components.bindFilters(ctx.root, '/admin/payouts'); }
  };

  /* ================================================================== */
  /* ACTIONS                                                             */
  /* ================================================================== */
  SEVE.act('payouts-generate', function () {
    const me = store.me();
    if (!me || me.role === 'admin') return;
    const acc = store.ensurePayout(me.id);
    openRibDocument(acc, me);
  });

  SEVE.act('admin-payout-doc', function (el) {
    const p = store.get(el.getAttribute('data-id'));
    if (!p) return;
    const acc = store.ensurePayout(p.id);
    openRibDocument(acc, p, { subtitle: 'Coordonnées déclarées par ' + p.name + ' — document de contrôle interne.' });
  });

  SEVE.act('admin-payout-status', function (el) {
    const id = el.getAttribute('data-id');
    const status = el.getAttribute('data-status');
    const p = store.get(id);
    const acc = store.ensurePayout(id);
    const ib = IB.inspectIban(acc.iban);
    ui.confirm({
      title: status === 'verified' ? 'Marquer ces coordonnées comme vérifiées ?' : 'Revenir à « à vérifier » ?',
      text: status === 'verified'
        ? 'Contrôlez d’abord la forme (clé IBAN, clé RIB, format BIC) et la concordance du titulaire avec le profil. Ce marquage est un avis interne : il n’atteste pas de l’existence du compte.'
        : 'Le compte repasse dans la file de contrôle ; le membre n’est pas notifié.',
      detail: U.esc((p ? p.name : '') + ' — ' + (ib.ok ? 'clé IBAN cohérente' : 'coordonnées incohérentes : vérification déconseillée')),
      okLabel: status === 'verified' ? 'Marquer comme vérifié' : 'Revenir à à vérifier'
    }).then((ok) => {
      if (!ok) return;
      if (status === 'verified' && !ib.ok) {
        ui.toast('Impossible de vérifier : la clé IBAN est incohérente. Demandez une correction au membre.', 'err');
        return;
      }
      store.verifyPayout(id, status);
      ui.toast(status === 'verified' ? 'Coordonnées marquées comme vérifiées.' : 'Le compte repasse en file de contrôle.', 'ok');
      SEVE.router.refresh();
    });
  });

  SEVE.act('admin-payout-reject', function (el) {
    const id = el.getAttribute('data-id');
    const p = store.get(id);
    if (!p) return;
    ui.modal({
      title: 'Demander une correction',
      size: 'sm',
      subtitle: 'Le membre reçoit une notification et voit le motif dans ses paramètres de paiement.',
      body: '<div class="field"><label class="label" for="pay-note">Motif transmis</label>' +
        '<textarea class="textarea" id="pay-note">Le titulaire déclaré ne correspond pas au nom public du profil. Merci d’indiquer le nom exact figurant sur votre compte bancaire, puis d’enregistrer à nouveau vos coordonnées.</textarea></div>',
      footer: ui.btn({ label: 'Annuler', variant: 'ghost', act: 'cancel' }) + ui.btn({ label: 'Envoyer la demande', variant: 'primary', act: 'do-reject' }),
      onMount(panel) {
        panel.querySelector('[data-act="cancel"]').addEventListener('click', () => ui.close());
        panel.querySelector('[data-act="do-reject"]').addEventListener('click', (e) => {
          const note = panel.querySelector('#pay-note').value.trim();
          ui.loading(e.currentTarget, true, 'Envoi…');
          setTimeout(() => {
            store.verifyPayout(id, 'rejected', note);
            store.pushNotification(p.role, {
              type: 'payout', icon: 'wallet', title: 'Coordonnées bancaires à corriger',
              text: note.slice(0, 90), href: '#/app/payouts'
            });
            ui.close();
            ui.toast('Demande de correction envoyée au membre.', 'ok');
            SEVE.router.refresh();
          }, 600);
        });
      }
    });
  });
})();
