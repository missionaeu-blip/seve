/* ==========================================================================
   Sève — inscription (créateur / manager) et connexion
   ========================================================================== */
(function () {
  const U = SEVE.util;
  const ui = SEVE.ui;
  const store = SEVE.store;
  const T = SEVE.taxo;
  const icon = SEVE.icons.svg;

  SEVE.views = SEVE.views || {};

  /* ================================================================== */
  /* CONNEXION                                                           */
  /* ================================================================== */
  SEVE.views.login = {
    title: 'Connexion',
    render(ctx) {
      const next = ctx.query.next ? ' data-next="' + U.esc(ctx.query.next) + '"' : '';
      return '<div class="auth">' +
        '<aside class="auth__aside">' +
        '<span class="kicker" style="color:#9FD9BB">Espace membre</span>' +
        '<h2>Reprenez là où vous vous êtes arrêté.</h2>' +
        '<p>Vos demandes, vos messages et vos recommandations vous attendent. Nous ne vous enverrons jamais de relance commerciale sans votre accord.</p>' +
        '<div class="auth__points">' + [
          ['shieldCheck', 'Accès de démonstration', 'La connexion de cette maquette reste locale à ce navigateur.'],
          ['message', 'Historique local', 'Les demandes et messages de cette maquette ne sont pas transmis à une équipe.'],
          ['headset', 'Service non ouvert', 'Aucun délai de réponse humaine n’est promis dans cette version.']
        ].map((x) => '<div class="auth__point">' + icon(x[0], 18) + '<div><b>' + x[1] + '</b><br>' + U.esc(x[2]) + '</div></div>').join('') + '</div>' +
        '</aside>' +
        '<div class="auth__form"><div class="auth__box" id="loginbox"' + next + '>' +
        '<h1 style="font-size:clamp(23px,2.6vw,29px)">Se connecter</h1>' +
        '<p class="muted mt-8">Accédez à votre tableau de bord, votre messagerie et vos demandes.</p>' +
        '<form id="loginform" class="mt-24" novalidate>' +
        '<div class="stack gap-16">' +
        '<div class="field"><label class="label" for="li-email">Adresse email <span class="req">*</span></label>' +
        '<input class="input field--lg" id="li-email" type="email" name="email" required autocomplete="email" placeholder="prenom@domaine.fr"></div>' +
        '<div class="field"><label class="label" for="li-pass">Mot de passe <span class="req">*</span></label>' +
        '<div style="position:relative"><input class="input" id="li-pass" type="password" name="password" required autocomplete="current-password" placeholder="••••••••" style="padding-right:44px">' +
        '<button type="button" class="btn btn--ghost btn--icon btn--sm" data-act="toggle-pass" data-target="li-pass" style="position:absolute;right:5px;top:50%;transform:translateY(-50%)" aria-label="Afficher le mot de passe">' + icon('eye', 16) + '</button></div></div>' +
        '<div class="between" style="gap:12px;flex-wrap:wrap">' +
        '<label class="check"><input type="checkbox" name="remember" checked><span class="small">Rester connecté sur cet appareil</span></label>' +
        '<button type="button" class="small" data-act="forgot" style="color:var(--green-700);font-weight:600">Mot de passe oublié ?</button>' +
        '</div>' +
        '<div id="login-error"></div>' +
        ui.btn({ label: 'Se connecter', variant: 'primary', size: 'lg', block: true, act: 'do-login', submit: true }) +
        '</div></form>' +
        '<p class="center small muted mt-20">Pas encore de compte ? <a href="#/signup" style="color:var(--green-700);font-weight:600">Créer un profil</a></p>' +
        '<div class="card card--pad card--soft mt-24">' +
        '<div class="row gap-8"><span class="tag">Démonstration</span><span class="small muted">Entrer sans email ni mot de passe</span></div>' +
        '<div class="stack gap-8 mt-12">' +
        ui.btn({ label: 'Entrer comme créatrice (Lya Moreau)', variant: 'outline', size: 'sm', block: true, act: 'demo-login', data: { role: 'creator' } }) +
        ui.btn({ label: 'Entrer comme manager (Halo Management)', variant: 'outline', size: 'sm', block: true, act: 'demo-login', data: { role: 'manager' } }) +
        '<a class="btn btn--outline btn--block" href="#/admin/connexion">Administration Sève sécurisée</a>' +
        '</div>' +
        '<p class="tiny muted mt-12">Ces boutons ouvrent seulement une maquette locale. Aucune connexion réelle, vérification de majorité ou réception par une équipe.</p>' +
        '</div>' +
        '</div></div></div>';
    },
    mount(ctx) {
      const form = ctx.root.querySelector('#loginform');
      const box = ctx.root.querySelector('#loginbox');
      const submit = ctx.root.querySelector('[data-act="do-login"]');
      const errSlot = ctx.root.querySelector('#login-error');
      ctx.root.querySelectorAll('[data-act="toggle-pass"]').forEach((b) => b.addEventListener('click', () => {
        const input = ctx.root.querySelector('#' + b.getAttribute('data-target'));
        input.type = input.type === 'password' ? 'text' : 'password';
        b.innerHTML = icon(input.type === 'password' ? 'eye' : 'eyeOff', 16);
      }));
      ctx.root.querySelector('[data-act="forgot"]').addEventListener('click', () => {
        ui.modal({
          title: 'Réinitialiser le mot de passe',
          size: 'sm',
          body: '<p class="small">Indiquez l’adresse associée à votre compte : nous envoyons un lien de réinitialisation valable 30 minutes.</p>' +
            '<div class="field mt-16"><label class="label" for="fp-email">Adresse email</label><input class="input" id="fp-email" type="email" placeholder="prenom@domaine.fr"></div>',
          footer: ui.btn({ label: 'Annuler', variant: 'ghost', act: 'cancel' }) + ui.btn({ label: 'Envoyer le lien', variant: 'primary', act: 'send-reset' }),
          onMount(panel) {
            panel.querySelector('[data-act="cancel"]').addEventListener('click', () => ui.close());
            panel.querySelector('[data-act="send-reset"]').addEventListener('click', (e) => {
              const email = panel.querySelector('#fp-email');
              ui.clearErrors(panel);
              if (!ui.EMAIL_RE.test(email.value)) { ui.fieldError(email, 'Indiquez une adresse valide.'); return; }
              ui.loading(e.currentTarget, true, 'Envoi…');
              setTimeout(() => {
                ui.close();
                ui.toast('Si un compte existe pour cette adresse, un lien de réinitialisation vient d’être envoyé.', 'ok', { title: 'Demande enregistrée' });
              }, 800);
            });
          }
        });
      });

      const doLogin = () => {
        ui.clearErrors(form);
        if (!ui.validate(form)) return;
        ui.loading(submit, true, 'Connexion…');
        errSlot.innerHTML = '';
        setTimeout(() => {
          const values = ui.readForm(form);
          const res = store.login(values.email, values.password);
          ui.loading(submit, false);
          if (!res.ok) {
            errSlot.innerHTML = ui.banner({ variant: 'danger', title: 'Connexion impossible.', text: res.error });
            const field = form.querySelector('#li-pass');
            ui.fieldError(field, 'Vérifiez votre mot de passe.');
            return;
          }
          const role = res.user.role;
          const next = box.getAttribute('data-next');
          const dest = next || (role === 'admin' ? '/admin' : '/app');
          SEVE.router.navigate(dest);
          ui.toast('Bienvenue ' + res.user.name + '.', 'ok', { title: 'Connecté' });
        }, 760);
      };
      submit.addEventListener('click', (e) => { e.preventDefault(); doLogin(); });
      form.addEventListener('submit', (e) => { e.preventDefault(); doLogin(); });
      form.querySelectorAll('input').forEach((i) => i.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') { e.preventDefault(); doLogin(); }
      }));
    }
  };

  /* ================================================================== */
  /* INSCRIPTION                                                         */
  /* ================================================================== */
  const ROLES = [
    {
      id: 'creator', icon: 'camera', title: 'Je suis créateur / créatrice',
      text: 'Je cherche un manager ou une agence pour m’accompagner sur la vente, la croissance ou la production.'
    },
    {
      id: 'manager', icon: 'building', title: 'Je suis manager / agence',
      text: 'Je cherche des créatrices et des créateurs à accompagner, avec un cadre clair et des profils vérifiés.'
    }
  ];

  function specialtyPicker(id, label, help) {
    const groups = {};
    T.SPECIALTIES.forEach((s) => { (groups[s.group] = groups[s.group] || []).push(s); });
    return '<div class="field span2"><span class="label">' + U.esc(label) + ' <span class="req">*</span></span>' +
      '<div class="specialty-grid" id="' + id + '">' +
      Object.keys(groups).map((g) => '<div>' +
        '<span class="specialty-grid__group">' + U.esc(g) + '</span>' +
        groups[g].map((s) => '<label class="check check--tight"><input type="checkbox" name="specialties" value="' + s.id + '"><span class="small">' + U.esc(s.label) + '</span></label>').join('') +
        '</div>').join('') +
      '</div>' + (help ? '<p class="help">' + U.esc(help) + '</p>' : '') + '</div>';
  }

  function step1() {
    return '<div id="signup-step1">' +
      '<h1 style="font-size:clamp(23px,2.8vw,31px)">Créer mon profil Sève</h1>' +
      '<p class="lede mt-12">Deux choix seulement au départ : dites-nous qui vous êtes. Les champs affichés ensuite seront adaptés à votre situation — rien de superflu.</p>' +
      '<div class="rolepick mt-24">' + ROLES.map((r) =>
        '<button class="role" data-role="' + r.id + '" aria-pressed="false">' +
        '<span class="role__ico">' + icon(r.icon, 19) + '</span>' +
        '<b>' + U.esc(r.title) + '</b><span>' + U.esc(r.text) + '</span>' +
        '<span class="small strong mt-12" style="color:var(--green-700)">Choisir →</span></button>').join('') + '</div>' +
      '<div class="banner banner--soft mt-24">' + icon('shield', 18) +
      '<div>La plateforme est réservée aux personnes majeures. La vérification d’identité intervient après création du compte, avant toute mise en relation — jamais avant votre entrée sur la plateforme.</div></div>' +
      '<p class="center small muted mt-20">Vous avez déjà un compte ? <a href="#/login" style="color:var(--green-700);font-weight:600">Se connecter</a></p>' +
      '</div>';
  }

  function creatorForm() {
    return '<form id="signup-form" novalidate data-role="creator">' +
      '<div class="formgrid">' +
      '<div class="field span2"><label class="label" for="su-name">Nom public <span class="req">*</span></label>' +
      '<input class="input" id="su-name" name="name" required placeholder="Le nom que verront les managers"><p class="help">Votre nom d’artiste ou votre pseudo. Jamais votre nom légal.</p></div>' +
      '<div class="field"><label class="label" for="su-email">Adresse email <span class="req">*</span></label>' +
      '<input class="input" id="su-email" name="email" type="email" required placeholder="prenom@domaine.fr"></div>' +
      '<div class="field"><label class="label" for="su-pass">Mot de passe <span class="req">*</span></label>' +
      '<input class="input" id="su-pass" name="password" type="password" required data-minlen="8" autocomplete="new-password">' +
      '<p class="help" id="pass-help">8 caractères minimum.</p></div>' +
      '<div class="field"><label class="label" for="su-city">Ville <span class="req">*</span></label>' +
      '<input class="input" id="su-city" name="city" required placeholder="Paris"></div>' +
      '<div class="field"><label class="label" for="su-country">Pays <span class="req">*</span></label>' +
      '<input class="input" id="su-country" name="country" required value="France"></div>' +
      specialtyPicker('su-spec', 'Vos spécialités', 'Choisissez ce que vous faites réellement : cela détermine les managers que nous vous proposons.') +
      '<div class="field span2"><label class="label" for="su-bio">Présentation <span class="req">*</span></label>' +
      '<textarea class="textarea" id="su-bio" name="bio" data-minlen="80" required placeholder="Votre univers, votre rythme de publication, votre audience, ce que vous attendez d’un manager."></textarea></div>' +
      '<div class="field"><label class="label" for="su-exp">Expérience <span class="req">*</span></label>' +
      '<select class="select" id="su-exp" name="exp" required>' + T.EXPERIENCE.map((e) => '<option value="' + e.id + '">' + U.esc(e.label) + '</option>').join('') + '</select></div>' +
      '<div class="field"><label class="label" for="su-network">Taille du réseau</label>' +
      '<select class="select" id="su-network" name="network">' + T.NETWORK.map((n) => '<option value="' + n.id + '">' + U.esc(n.label) + '</option>').join('') + '</select></div>' +
      '<div class="field"><label class="label" for="su-plat">Plateformes utilisées</label>' +
      '<select class="select" id="su-plat" name="platforms" multiple size="4">' + T.PLATFORMS.map((p) => '<option value="' + p.id + '">' + U.esc(p.label) + '</option>').join('') + '</select></div>' +
      '<div class="field"><label class="label" for="su-lang">Langues de travail</label>' +
      '<select class="select" id="su-lang" name="languages" multiple size="4">' + T.LANGUAGES.map((l) => '<option value="' + l + '"' + (l === 'Français' ? ' selected' : '') + '>' + U.esc(l) + '</option>').join('') + '</select></div>' +
      '<div class="field span2"><label class="label">Photo de profil</label>' +
      '<div class="row gap-12" style="flex-wrap:wrap"><span class="avatar avatar--lg t-sage" id="photo-preview">?</span>' +
      '<div><input type="file" id="su-photo" accept="image/*" hidden>' +
      ui.btn({ label: 'Choisir une photo', variant: 'outline', size: 'sm', act: 'pick-photo' }) +
      '<p class="help mt-4">Contrôlée par notre équipe avant publication. Aucune photo explicite : le portfolio se décrit, il ne s’affiche pas.</p></div></div></div>' +
      '<div class="field span2"><label class="label" for="su-portfolio">Portfolio</label>' +
      '<textarea class="textarea" id="su-portfolio" name="portfolio" placeholder="Décrivez vos références : type de contenus, formats, nombre de visuels, résultats obtenus. Un lien public (non explicite) est accepté."></textarea></div>' +
      '<div class="field span2"><label class="label" for="su-need">Critères de recherche <span class="req">*</span></label>' +
      '<textarea class="textarea" id="su-need" name="need" data-minlen="60" required placeholder="Ce que vous cherchez : type de partenaire, commission envisagée, niveau d’autonomie, limites à respecter."></textarea></div>' +
      '<div class="field"><label class="label" for="su-goals">Objectif principal</label>' +
      '<select class="select" id="su-goals" name="goals">' + T.GOALS_CREATOR.map((g) => '<option>' + U.esc(g) + '</option>').join('') + '</select></div>' +
      '<div class="field"><label class="label" for="su-av">Disponibilité pour échanger</label>' +
      '<select class="select" id="su-av" name="availability">' + T.AVAILABILITY.map((a) => '<option value="' + a.id + '"' + (a.id === 'open' ? ' selected' : '') + '>' + U.esc(a.label) + '</option>').join('') + '</select></div>' +
      '<div class="field span2"><label class="check"><input type="checkbox" id="su-18" required><span>Je certifie être majeur(e), titulaire des droits sur mes contenus, et j’accepte les <a href="#/legal/terms" style="color:var(--green-700)">conditions générales</a> et les <a href="#/legal/rules" style="color:var(--green-700)">règles de la plateforme</a>.</span></label>' +
      '<label class="check mt-12"><input type="checkbox" id="su-consent"><span>J’accepte de recevoir les informations produit de Sève (facultatif).</span></label></div>' +
      '</div>' +
      submitRow('Créer mon profil créateur') + '</form>';
  }

  function managerForm() {
    return '<form id="signup-form" novalidate data-role="manager">' +
      '<div class="formgrid">' +
      '<div class="field span2"><label class="label" for="su-name">Nom de l’agence ou nom public <span class="req">*</span></label>' +
      '<input class="input" id="su-name" name="name" required placeholder="Ex. Halo Management, ou votre nom si vous travaillez seul"></div>' +
      '<div class="field"><label class="label" for="su-email">Adresse email professionnelle <span class="req">*</span></label>' +
      '<input class="input" id="su-email" name="email" type="email" required placeholder="contact@structure.fr"></div>' +
      '<div class="field"><label class="label" for="su-pass">Mot de passe <span class="req">*</span></label>' +
      '<input class="input" id="su-pass" name="password" type="password" required data-minlen="8" autocomplete="new-password"><p class="help" id="pass-help">8 caractères minimum.</p></div>' +
      '<div class="field"><label class="label" for="su-kind">Type de structure <span class="req">*</span></label>' +
      '<select class="select" id="su-kind" name="kind" required>' + T.MANAGER_KINDS.map((k) => '<option>' + U.esc(k) + '</option>').join('') + '</select></div>' +
      '<div class="field"><label class="label" for="su-team">Taille de l’équipe</label>' +
      '<select class="select" id="su-team" name="team">' + T.TEAMSIZE.map((t) => '<option value="' + t.id + '">' + U.esc(t.label) + '</option>').join('') + '</select></div>' +
      '<div class="field"><label class="label" for="su-city">Ville <span class="req">*</span></label>' +
      '<input class="input" id="su-city" name="city" required placeholder="Paris"></div>' +
      '<div class="field"><label class="label" for="su-country">Pays <span class="req">*</span></label>' +
      '<input class="input" id="su-country" name="country" required value="France"></div>' +
      specialtyPicker('su-spec', 'Vos spécialités', 'Ce que vous prenez réellement en charge : chatting, croissance, production, planning, modération…') +
      '<div class="field span2"><label class="label" for="su-bio">Présentation <span class="req">*</span></label>' +
      '<textarea class="textarea" id="su-bio" name="bio" data-minlen="80" required placeholder="Votre structure, votre méthode, le nombre de créateurs accompagnés, ce qui vous distingue."></textarea></div>' +
      '<div class="field"><label class="label" for="su-exp">Expérience <span class="req">*</span></label>' +
      '<select class="select" id="su-exp" name="exp" required>' + T.EXPERIENCE.map((e) => '<option value="' + e.id + '">' + U.esc(e.label) + '</option>').join('') + '</select></div>' +
      '<div class="field"><label class="label" for="su-commission">Commission annoncée</label>' +
      '<input class="input" id="su-commission" name="commission" placeholder="Ex. 20 – 25 % de commission"></div>' +
      '<div class="field"><label class="label" for="su-lang">Langues de travail</label>' +
      '<select class="select" id="su-lang" name="languages" multiple size="4">' + T.LANGUAGES.map((l) => '<option value="' + l + '"' + (l === 'Français' ? ' selected' : '') + '>' + U.esc(l) + '</option>').join('') + '</select></div>' +
      '<div class="field"><label class="label" for="su-plat">Plateformes maîtrisées</label>' +
      '<select class="select" id="su-plat" name="platforms" multiple size="4">' + T.PLATFORMS.map((p) => '<option value="' + p.id + '">' + U.esc(p.label) + '</option>').join('') + '</select></div>' +
      '<div class="field span2"><label class="label">Logo ou photo</label>' +
      '<div class="row gap-12" style="flex-wrap:wrap"><span class="avatar avatar--lg avatar--sq t-mist" id="photo-preview">?</span>' +
      '<div><input type="file" id="su-photo" accept="image/*" hidden>' +
      ui.btn({ label: 'Choisir un visuel', variant: 'outline', size: 'sm', act: 'pick-photo' }) +
      '<p class="help mt-4">Un logo sobre suffit. Les visuels comportant des coordonnées de contact sont refusés.</p></div></div></div>' +
      '<div class="field span2"><label class="label" for="su-portfolio">Portfolio & références</label>' +
      '<textarea class="textarea" id="su-portfolio" name="portfolio" placeholder="Études de cas, résultats chiffrés, comptes accompagnés (anonymisés), process interne, formation des équipes."></textarea></div>' +
      '<div class="field span2"><label class="label" for="su-need">Critères concernant les créateurs recherchés <span class="req">*</span></label>' +
      '<textarea class="textarea" id="su-need" name="need" data-minlen="60" required placeholder="Taille de réseau visée, rythme de production attendu, langues, zone géographique, niveau d’autonomie, exclusions."></textarea></div>' +
      '<div class="field"><label class="label" for="su-goals">Objectif principal</label>' +
      '<select class="select" id="su-goals" name="goals">' + T.GOALS_MANAGER.map((g) => '<option>' + U.esc(g) + '</option>').join('') + '</select></div>' +
      '<div class="field"><label class="label" for="su-av">Capacité d’accueil</label>' +
      '<select class="select" id="su-av" name="availability">' + T.AVAILABILITY.map((a) => '<option value="' + a.id + '"' + (a.id === 'open' ? ' selected' : '') + '>' + U.esc(a.label) + '</option>').join('') + '</select></div>' +
      '<div class="field span2"><label class="check"><input type="checkbox" id="su-18" required><span>Je certifie que la structure est légalement déclarée, que je suis habilité(e) à la représenter, et j’accepte les <a href="#/legal/terms" style="color:var(--green-700)">conditions générales</a> et les <a href="#/legal/rules" style="color:var(--green-700)">règles de la plateforme</a> (aucun frais d’entrée ne peut être demandé à un créateur).</span></label>' +
      '<label class="check mt-12"><input type="checkbox" id="su-consent"><span>J’accepte de recevoir les informations produit de Sève (facultatif).</span></label></div>' +
      '</div>' +
      submitRow('Créer mon profil manager') + '</form>';
  }

  function submitRow(label) {
    return '<div class="banner banner--soft mt-24">' + icon('info', 18) +
      '<div>Votre profil est publié immédiatement en <b>vérification en cours</b>. La vérification complète (identité ou structure) prend en général moins de 24 heures. Vous pouvez déjà explorer et préparer votre recherche.</div></div>' +
      '<div class="row gap-12 mt-24" style="flex-wrap:wrap">' +
      ui.btn({ label: label, variant: 'primary', size: 'lg', act: 'do-signup', submit: true }) +
      ui.btn({ label: 'Retour', variant: 'ghost', act: 'signup-back' }) +
      '</div><p class="tiny muted mt-16">Aucune carte bancaire, aucun frais d’inscription. Sève ne prélève aucune commission sur vos revenus.</p>';
  }

  SEVE.views.signup = {
    title: 'Inscription',
    render(ctx) {
      const role = ctx.query.role;
      return '<div class="auth">' +
        '<aside class="auth__aside">' +
        '<span class="kicker" style="color:#9FD9BB">Inscription</span>' +
        '<h2>Deux minutes, uniquement l’essentiel.</h2>' +
        '<p>Nous ne demandons que ce qui sert à la mise en relation. Ni adresse postale, ni téléphone, ni pièce d’identité à cette étape.</p>' +
        '<div class="auth__points">' + [
          ['userCheck', 'Profil public maîtrisé', 'Vous décidez de ce qui apparaît : présentation, spécialités, critères. Jamais votre email.'],
          ['sparkles', 'Recommandations expliquées', 'Dès votre profil complété, vous recevez des profils comparés à vos critères.'],
          ['shieldCheck', 'Vérification humaine', 'Un membre de l’équipe contrôle votre profil avant mise en relation.']
        ].map((x) => '<div class="auth__point">' + icon(x[0] === 'userCheck' ? 'user' : x[0], 18) + '<div><b>' + x[1] + '</b><br>' + U.esc(x[2]) + '</div></div>').join('') + '</div>' +
        '</aside>' +
        '<div class="auth__form"><div class="auth__box" style="max-width:640px" id="signupbox">' +
        (role ? renderStep2(role) : step1()) +
        '</div></div></div>';
    },
    mount(ctx) {
      const box = ctx.root.querySelector('#signupbox');

      const wireStep1 = () => {
        const pick = box.querySelector('.rolepick');
        if (!pick) return;
        pick.addEventListener('click', (e) => {
          const btn = e.target.closest('.role');
          if (!btn) return;
          const role = btn.getAttribute('data-role');
          pick.querySelectorAll('.role').forEach((b) => b.setAttribute('aria-pressed', b === btn ? 'true' : 'false'));
          setTimeout(() => { SEVE.router.navigate('/signup?role=' + role); }, 140);
        });
      };

      const wireStep2 = () => {
        const form = box.querySelector('#signup-form');
        if (!form) return;
        /* Photo : aperçu local uniquement (aucun envoi dans cette démonstration) */
        const file = box.querySelector('#su-photo');
        const pickPhoto = box.querySelector('[data-act="pick-photo"]');
        if (pickPhoto && file) {
          pickPhoto.addEventListener('click', () => file.click());
          file.addEventListener('change', () => {
            const f = file.files && file.files[0];
            if (!f) return;
            const url = URL.createObjectURL(f);
            const prev = box.querySelector('#photo-preview');
            prev.textContent = '';
            prev.style.backgroundImage = 'url(' + url + ')';
            prev.style.backgroundSize = 'cover';
            prev.style.backgroundPosition = 'center';
            ui.toast('Photo ajoutée. Elle sera contrôlée avant publication.', 'ok');
          });
        }
        /* Indicateur de robustesse du mot de passe */
        const pass = box.querySelector('#su-pass');
        const help = box.querySelector('#pass-help');
        const pw = ui.passwords();
        pass.addEventListener('input', () => {
          const s = pw.score(pass.value);
          if (!pass.value) { help.textContent = '8 caractères minimum.'; return; }
          help.innerHTML = 'Robustesse : <b style="color:' + (s >= 3 ? 'var(--ok)' : s === 2 ? 'var(--warn)' : 'var(--danger)') + '">' + pw.label(s) + '</b>';
        });

        const submit = box.querySelector('[data-act="do-signup"]');
        box.querySelector('[data-act="signup-back"]').addEventListener('click', () => SEVE.router.navigate('/signup'));

        submit.addEventListener('click', (e) => {
          e.preventDefault();
          ui.clearErrors(form);
          const boxes = form.querySelectorAll('input[name="specialties"]:checked');
          if (!boxes.length) {
            const grid = form.querySelector('#su-spec');
            ui.fieldError(grid || form, 'Choisissez au moins une spécialité : c’est la base du matching.');
            return;
          }
          if (!ui.validate(form)) return;

          ui.loading(submit, true, 'Création du profil…');
          setTimeout(() => {
            const v = ui.readForm(form);
            const specialties = Array.from(form.querySelectorAll('input[name="specialties"]:checked')).map((i) => i.value);
            const platforms = Array.from((form.querySelector('#su-plat').selectedOptions) || []).map((o) => o.value);
            const languages = Array.from((form.querySelector('#su-lang').selectedOptions) || []).map((o) => o.value);
            const portfolioText = (v.portfolio || '').trim();
            const role = form.getAttribute('data-role') === 'manager' ? 'manager' : 'creator';
            const isManager = role === 'manager';
            v.role = role;

            const res = SEVE.store.register({
              role: role, name: v.name, email: v.email, password: v.password,
              city: v.city, country: v.country, exp: v.exp, specialties, languages, platforms,
              bio: v.bio,
              network: v.network, handle: '@' + String(v.name || '').toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 12),
              kind: v.kind, team: v.team, commission: v.commission,
              availability: v.availability,
              goals: v.goals ? [v.goals] : [],
              pro: isManager
                ? { statut: v.kind, tarif: v.commission || 'À définir', outils: '', dispo: '', paiement: '' }
                : { statut: 'Indépendant', tarif: 'Souhaite discuter des splits', outils: '', dispo: '', paiement: '' },
              looking: { title: (v.need || '').split('.')[0] || '', split: v.commission || '', notes: v.need || '', must: [] },
              portfolio: portfolioText ? [{ title: 'Portfolio déclaré', type: isManager ? 'Références' : 'Production', meta: portfolioText.slice(0, 90) }] : [],
              timeline: []
            });

            if (!res.ok) {
              ui.loading(submit, false);
              ui.fieldError(form.querySelector('#su-email'), res.error);
              return;
            }
            SEVE.store.saveConsent({ decided: true, essential: true, analytics: false, newsletter: !!form.querySelector('#su-consent').checked });
            SEVE.router.navigate('/app');
            ui.toast('Profil créé. Complétez votre présentation pour être mieux recommandé.', 'ok', { title: 'Bienvenue sur Sève' });
            const me = SEVE.store.me();
            const comp = SEVE.store.completion(me);
            setTimeout(() => {
              ui.modal({
                title: 'Votre profil est en ligne',
                size: 'sm',
                body: '<p>Votre profil est visible avec la mention « vérification en cours ». La vérification complète prend en général moins de 24 heures.</p>' +
                  '<div class="row gap-16 mt-20">' + ui.ring(comp.percent, { size: 62, caption: 'complété' }) +
                  '<div><b class="small">Complétion du profil</b><p class="tiny muted mt-4">Un profil complet reçoit en moyenne 3 fois plus de demandes pertinentes.</p></div></div>' +
                  (comp.missing.length ? '<div class="banner banner--soft mt-16">' + icon('info', 18) + '<div class="small"><b>À compléter :</b> ' + U.esc(comp.missing.slice(0, 3).join(', ')) + '</div></div>' : ''),
                footer: ui.btn({ label: 'Compléter mon profil', variant: 'primary', href: '#/app/profile' }) + ' ' +
                  ui.btn({ label: 'Découvrir les profils', variant: 'outline', href: '#/app/discover' }),
                onMount(panel) {
                  panel.querySelectorAll('[data-href]').forEach((b) => b.addEventListener('click', () => {
                    const href = b.getAttribute('data-href');
                    ui.close();
                    SEVE.router.navigate(href.replace(/^#/, ''));
                  }));
                }
              });
            }, 700);
          }, 1100);
        });
      };

      wireStep1();
      wireStep2();
    }
  };

  function renderStep2(role) {
    const r = ROLES.filter((x) => x.id === role)[0] || ROLES[0];
    return '<div class="row gap-12 mb-20" style="flex-wrap:wrap">' +
      '<button class="btn btn--ghost btn--sm" data-act="signup-back">' + icon('arrowLeft', 15) + '<span>Changer</span></button>' +
      '<span class="chip chip--green chip--sm">' + icon(r.icon, 14) + U.esc(r.title) + '</span></div>' +
      (role === 'manager' ? managerForm() : creatorForm());
  }
})();
