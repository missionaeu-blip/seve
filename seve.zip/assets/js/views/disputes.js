/* ==========================================================================
   Sève — Litiges & remboursements (chargebacks)
   --------------------------------------------------------------------------
   Un litige n'est pas un « remboursement » de la plateforme : c'est une
   contestation bancaire (chargeback) déposée par l'acheteur. La plateforme
   joue l'intermédiaire ; la décision appartient à la banque. Le seul levier
   réel d'une créatrice, c'est la qualité de son dossier et sa rapidité.

   Ce module fournit : le registre des litiges, la détection de vagues, les
   signaux de risque observables, et un dossier de défense imprimable.
   Aucune donnée bancaire n'est stockée : jamais de numéro de carte, jamais de
   coordonnées — uniquement l'identifiant public du contact.
   ========================================================================== */
(function () {
  const U = SEVE.util;
  const ui = SEVE.ui;
  const C = SEVE.components;
  const store = SEVE.store;
  const icon = SEVE.icons.svg;
  const T = SEVE.taxo;

  /* ------------------------------------------------------------ outils ---- */

  function money(n) { return U.fmtNum(Math.round(Number(n) || 0)) + ' €'; }

  function waveFor(owner) {
    const waves = store.disputeWaves({ owner: owner || 'all' });
    const now = Date.now();
    return waves.filter((w) => now - new Date(w.to).getTime() < 21 * 864e5)[0] || null;
  }

  function waveBanner(w) {
    if (!w) return '';
    return ui.banner({
      variant: 'warn',
      title: 'Vague détectée : ' + w.count + ' litiges en 7 jours',
      html: 'Du <b>' + U.fmtDate(w.from) + '</b> au <b>' + U.fmtDate(w.to) + '</b> · ' +
        money(w.amount) + ' contestés · canal principal : <b>' + U.esc(w.channelLabel) + '</b>' +
        (w.owners > 1 ? ' · <b>' + w.owners + ' comptes</b> concernés sur la plateforme' : '') +
        '.<br><span class="small muted">Ce n\'est pas vous : c\'est un schéma. Documentez chaque cas et contestez par lot.</span>'
    });
  }

  function signalChips(ids) {
    return (ids || []).map((id) => '<span class="chip chip--sm chip--warn" title="' + U.esc(store.signalHint(id)) + '">' +
      icon('alert', 12) + U.esc(store.signalLabel(id)) + '</span>').join('');
  }

  function statusPill(status) {
    const st = store.DISPUTE_STATUS[status] || store.DISPUTE_STATUS.nouveau;
    return ui.pill(st.label, st.variant);
  }

  /* ------------------------------------------------- dossier imprimable -- */

  function dossierHTML(scope, profile, opts) {
    opts = opts || {};
    const list = scope.list.slice().sort((a, b) => String(a.created).localeCompare(String(b.created)));
    const st = scope.stats;
    const periode = list.length
      ? U.fmtDate(list[0].created) + ' → ' + U.fmtDate(list[list.length - 1].created)
      : '—';

    const lignes = list.map((d) => '<tr>' +
      '<td>' + U.esc(U.fmtDate(d.created)) + '</td>' +
      '<td><b>' + U.esc(d.fan) + '</b></td>' +
      '<td>' + U.esc(store.typeLabel(d.type)) + '</td>' +
      '<td>' + U.esc(store.channelLabel(d.channel)) + '</td>' +
      '<td class="num">' + money(d.amount) + '</td>' +
      '<td>' + U.esc((store.DISPUTE_STATUS[d.status] || {}).label || d.status) + '</td>' +
      '<td>' + U.esc((d.signals || []).map((s) => store.signalLabel(s)).join(' · ') || '—') + '</td>' +
      '</tr>').join('');

    const signaux = {};
    list.forEach((d) => (d.signals || []).forEach((s) => { signaux[s] = (signaux[s] || 0) + 1; }));
    const topSignaux = Object.keys(signaux)
      .sort((a, b) => signaux[b] - signaux[a])
      .map((s) => '<li><b>' + U.esc(store.signalLabel(s)) + '</b> — ' + signaux[s] + ' cas. ' + U.esc(store.signalHint(s)) + '</li>')
      .join('');

    return '' +
      '<article class="dossierdoc" id="dossierdoc">' +
      '<header class="dossierdoc__head">' +
      '<div><b>Constat de contestations bancaires</b>' +
      '<span>Établi pour transmission au support de la plateforme et, si nécessaire, à la banque acquéreuse.</span></div>' +
      '<span class="dossierdoc__mark">Sève</span>' +
      '</header>' +

      '<dl class="dossierdoc__meta">' +
      '<div><dt>Compte concerné</dt><dd>' + U.esc((profile && profile.name) || '—') +
      (profile && profile.handle ? ' · ' + U.esc(profile.handle) : '') + '</dd></div>' +
      '<div><dt>Identifiant de profil</dt><dd>' + U.esc((profile && profile.id) || '—') + '</dd></div>' +
      '<div><dt>Période couverte</dt><dd>' + U.esc(periode) + '</dd></div>' +
      '<div><dt>Litiges recensés</dt><dd>' + st.total + ' contestation(s) · ' + money(st.amount) + '</dd></div>' +
      '<div><dt>Dont perdus / récupérés</dt><dd>' + st.lost + ' perdu(s) · ' + st.recovered + ' récupéré(s)' +
      (st.winRate != null ? ' (' + st.winRate + ' % de dossiers gagnés)' : '') + '</dd></div>' +
      '<div><dt>Date d\'établissement</dt><dd>' + U.fmtDate(new Date().toISOString()) + '</dd></div>' +
      '</dl>' +

      '<section class="dossierdoc__block">' +
      '<h4>1. Faits constatés</h4>' +
      '<p>Les opérations ci-dessous ont été réalisées par les personnes identifiées par leur identifiant public, ' +
      'le contenu ou la prestation a été livré comme convenu, puis chaque paiement a fait l\'objet d\'une ' +
      'contestation bancaire. Les demandes sont groupées dans le temps, proviennent des mêmes canaux et ' +
      'présentent des schémas de comportement identiques : cela caractérise un usage coordonné, et non des ' +
      'réclamations indépendantes.</p>' +
      '<table class="dossierdoc__table">' +
      '<thead><tr><th>Date</th><th>Identifiant</th><th>Achat</th><th>Canal</th><th class="num">Montant</th><th>État</th><th>Signaux observés</th></tr></thead>' +
      '<tbody>' + lignes + '</tbody>' +
      '<tfoot><tr><th colspan="4">Total contesté</th><th class="num">' + money(st.amount) + '</th><th colspan="2">' +
      (waveFor(profile && profile.id) ? 'Vague active : ' + waveFor(profile && profile.id).count + ' litiges en 7 jours' : 'Pas de vague active') + '</th></tr></tfoot>' +
      '</table>' +
      '</section>' +

      '<section class="dossierdoc__block">' +
      '<h4>2. Signaux communs aux différents cas</h4>' +
      (topSignaux ? '<ul class="dossierdoc__list">' + topSignaux + '</ul>'
        : '<p class="small muted">Aucun signal particulier enregistré sur ces dossiers.</p>') +
      '</section>' +

      '<section class="dossierdoc__block">' +
      '<h4>3. Éléments de preuve joints</h4>' +
      '<ul class="dossierdoc__list">' +
      ['Historique complet des conversations (captures horodatées) pour chaque identifiant',
        'Preuve de livraison du contenu ou de la prestation, avec date et heure',
        'Identifiants de transaction tels qu\'ils figurent dans le relevé des ventes',
        'Conditions générales et mention d\'absence de remboursement, affichées sur le profil',
        'Enregistrement des signaux de comportement listés au point 2'
      ].map((x) => '<li>' + U.esc(x) + '</li>').join('') +
      '</ul>' +
      '</section>' +

      '<section class="dossierdoc__block dossierdoc__ask">' +
      '<h4>4. Demande</h4>' +
      '<p>Je demande l\'examen de ces transactions par l\'équipe en charge des paiements et des risques, ' +
      'la transmission des éléments ci-dessus au motif de contestation, le blocage définitif des comptes ' +
      'identifiés, et la confirmation que ce schéma est enregistré au dossier afin qu\'il ne soit pas ' +
      'interprété, sur mon compte, comme un taux de contestation anormal de ma part.</p>' +
      '</section>' +

      '<footer class="dossierdoc__legal">' +
      '<p>Document établi à partir du registre de litiges tenu par ' + U.esc((profile && profile.name) || 'la créatrice') +
      ' sur Sève. Aucune donnée bancaire n\'y figure : seuls des identifiants publics, des montants et des dates ' +
      'y sont consignés, conformément au principe de minimisation (RGPD, art. 5).</p>' +
      '<p class="dossierdoc__sign">Signature : ..................................................</p>' +
      '</footer>' +
      '</article>';
  }

  function openDossier(scope, profile, opts) {
    ui.modal({
      title: 'Dossier de défense',
      subtitle: 'Document prêt à transmettre au support de la plateforme, avec les captures d’écran et les identifiants de transaction.',
      size: 'lg',
      body: dossierHTML(scope, profile, opts),
      footer: ui.btn({ label: 'Fermer', variant: 'ghost', act: 'cancel' }) +
        ui.btn({ label: 'Copier le résumé', variant: 'outline', act: 'dossier-copy' }) +
        ui.btn({ label: 'Imprimer / PDF', variant: 'primary', act: 'dossier-print', icon: 'doc' }),
      onMount(panel) {
        const resume = function () {
          const list = scope.list;
          const st = scope.stats;
          return 'Constat de contestations bancaires — ' + ((profile && profile.name) || '') + '\n' +
            'Période : ' + (list.length ? U.fmtDate(list[0].created) + ' → ' + U.fmtDate(list[list.length - 1].created) : '—') + '\n' +
            'Total : ' + st.total + ' litige(s), ' + money(st.amount) + ' contestés\n' +
            list.map((d) => '· ' + U.fmtDate(d.created) + ' — ' + d.fan + ' — ' + store.typeLabel(d.type) +
              ' — ' + money(d.amount) + ' — ' + store.channelLabel(d.channel)).join('\n') + '\n' +
            'Demande : examen des transactions, transmission au motif de contestation, blocage des comptes concernés.';
        };
        panel.querySelector('[data-act="cancel"]').addEventListener('click', () => ui.close());
        panel.querySelector('[data-act="dossier-copy"]').addEventListener('click', () => ui.copy(resume(), 'Résumé copié.'));
        panel.querySelector('[data-act="dossier-print"]').addEventListener('click', () => {
          document.documentElement.classList.add('is-printing');
          setTimeout(() => {
            window.print();
            document.documentElement.classList.remove('is-printing');
          }, 60);
        });
      }
    });
  }

  /* ------------------------------------------------ éditeur d'un litige -- */

  function disputeForm(d) {
    d = d || {};
    const selected = d.signals || [];
    return '<form id="dispform" novalidate>' +
      '<div class="formgrid">' +
      '<div class="field"><label class="label" for="dp-fan">Identifiant du contact <span class="req">*</span></label>' +
      '<input class="input" id="dp-fan" name="fan" required maxlength="40" placeholder="Tel qu’il apparaît sur la plateforme" value="' + U.esc(d.fan || '') + '">' +
      '<p class="help">L’identifiant public uniquement. Jamais de nom réel, d’adresse ni de coordonnées bancaires.</p></div>' +
      '<div class="field"><label class="label" for="dp-amount">Montant contesté (€) <span class="req">*</span></label>' +
      '<input class="input" id="dp-amount" name="amount" type="number" min="1" max="5000" step="1" required value="' + U.esc(d.amount || '') + '">' +
      '<div class="field"><label class="label" for="dp-type">Type d’achat</label>' +
      '<select class="select" id="dp-type" name="type">' +
      store.DISPUTE_TYPES().map((t) => '<option value="' + t.id + '"' + (d.type === t.id ? ' selected' : '') + '>' + U.esc(t.label) + '</option>').join('') +
      '</select></div>' +
      '<div class="field"><label class="label" for="dp-channel">Canal d’arrivée</label>' +
      '<select class="select" id="dp-channel" name="channel">' +
      store.DISPUTE_CHANNELS().map((c) => '<option value="' + c.id + '"' + (d.channel === c.id ? ' selected' : '') + '>' + U.esc(c.label) + '</option>').join('') +
      '</select></div>' +
      '<div class="field"><label class="label" for="dp-date">Date de la contestation</label>' +
      '<input class="input" id="dp-date" name="date" type="date" value="' + U.esc((d.created || new Date().toISOString()).slice(0, 10)) + '"></div>' +
      '<div class="field"><label class="label" for="dp-status">État</label>' +
      '<select class="select" id="dp-status" name="status">' +
      Object.keys(store.DISPUTE_STATUS).map((k) => '<option value="' + k + '"' + (d.status === k ? ' selected' : '') + '>' +
        U.esc(store.DISPUTE_STATUS[k].label) + '</option>').join('') +
      '</select></div>' +
      '</div>' +
      '<div class="field mt-16"><span class="label">Signaux observés</span>' +
      '<div class="signals">' +
      store.DISPUTE_SIGNALS().map((s) => '<label class="signalbox"><input type="checkbox" name="signals" value="' + s.id + '"' +
        (selected.indexOf(s.id) > -1 ? ' checked' : '') + '>' +
        '<span><b>' + U.esc(s.label) + '</b><em>' + U.esc(s.hint) + '</em></span></label>').join('') +
      '</div></div>' +
      '<div class="field mt-16"><label class="label" for="dp-note">Notes de preuve (ce que vous conserverez)</label>' +
      '<textarea class="textarea" id="dp-note" name="note" placeholder="Ex. commande passée le 12, contenu livré le 14, capture de la conversation enregistrée, identifiant de transaction noté.">' + U.esc(d.note || '') + '</textarea></div>' +
      '<div class="banner banner--soft mt-16">' + icon('shield', 18) +
      '<div>Enregistrer un litige ne se substitue pas à la procédure de la plateforme : c’est votre mémoire. ' +
      'Elle sert à contester vite, par lot, et à repérer les contacts récidivistes.</div></div>' +
      '</form>';
  }

  function openDisputeEditor(d) {
    const editing = !!d;
    ui.modal({
      title: editing ? 'Modifier le litige' : 'Enregistrer un litige',
      subtitle: 'Cinq informations suffisent. Aucune donnée bancaire.',
      size: 'lg',
      body: disputeForm(d),
      footer: ui.btn({ label: 'Annuler', variant: 'ghost', act: 'cancel' }) +
        ui.btn({ label: editing ? 'Enregistrer' : 'Ajouter au registre', variant: 'primary', act: 'dispute-save', icon: 'check' }),
      onMount(panel) {
        const form = panel.querySelector('#dispform');
        panel.querySelector('[data-act="cancel"]').addEventListener('click', () => ui.close());
        panel.querySelector('[data-act="dispute-save"]').addEventListener('click', () => {
          if (!ui.validate(form)) return;
          const btn = panel.querySelector('[data-act="dispute-save"]');
          ui.loading(btn, true, 'Enregistrement…');
          setTimeout(() => {
            const payload = {
              fan: form.querySelector('#dp-fan').value.trim(),
              amount: Number(form.querySelector('#dp-amount').value) || 0,
              type: form.querySelector('#dp-type').value,
              channel: form.querySelector('#dp-channel').value,
              status: form.querySelector('#dp-status').value,
              note: form.querySelector('#dp-note').value.trim(),
              created: new Date(form.querySelector('#dp-date').value || Date.now()).toISOString(),
              signals: Array.from(form.querySelectorAll('input[name="signals"]:checked')).map((x) => x.value)
            };
            if (editing) store.updateDispute(d.id, payload);
            else store.createDispute(payload);
            ui.loading(btn, false);
            ui.close();
            ui.toast(editing ? 'Litige mis à jour.' : 'Litige ajouté au registre.', 'ok');
            SEVE.router.refresh();
          }, 500);
        });
      }
    });
  }

  /* ==================================================================== */
  /* ESPACE MEMBRE — /app/disputes                                        */
  /* ==================================================================== */
  SEVE.views.disputes = {
    title: 'Litiges & remboursements',
    render(ctx) {
      const me = store.me();
      const owner = (me && me.profileId) || 'c9';
      const profile = store.get(owner) || (me && me.profileId ? { name: me.name, id: owner } : null);
      const status = ctx.query.status || 'all';
      const channel = ctx.query.channel || 'all';
      const q = ctx.query.q || '';
      const list = store.disputes({ owner, status, channel, q });
      const s = store.disputesStats(owner);
      const wave = waveFor(owner);

      const rows = list.map((d) => {
        const st = store.DISPUTE_STATUS[d.status] || store.DISPUTE_STATUS.nouveau;
        return '<article class="disprow">' +
          '<div class="disprow__main">' +
          '<div class="between" style="align-items:flex-start;gap:12px">' +
          '<div><b style="font-size:15px">' + U.esc(d.fan) + '</b>' +
          '<p class="small muted">' + U.esc(U.fmtDate(d.created)) + ' · ' + U.esc(store.typeLabel(d.type)) +
          ' · ' + U.esc(store.channelLabel(d.channel)) + '</p></div>' +
          '<div class="row gap-8" style="align-items:center">' +
          '<span class="disprow__amount">' + money(d.amount) + '</span>' + statusPill(d.status) + '</div></div>' +
          (d.signals && d.signals.length ? '<div class="chips mt-12">' + signalChips(d.signals) + '</div>' : '') +
          (d.note ? '<p class="small muted mt-12">' + U.esc(d.note) + '</p>' : '') +
          '<p class="tiny muted mt-12">' + U.esc(st.hint) + '</p>' +
          '</div>' +
          '<div class="disprow__side">' +
          ui.btn({ label: 'Modifier', variant: 'ghost', size: 'sm', act: 'dispute-edit', data: { id: d.id } }) +
          (d.status !== 'conteste' ? ui.btn({ label: 'Contester', variant: 'outline', size: 'sm', act: 'dispute-status', data: { id: d.id, status: 'conteste' } }) : '') +
          (d.status !== 'recupere' ? ui.btn({ label: 'Récupéré', variant: 'ghost', size: 'sm', act: 'dispute-status', data: { id: d.id, status: 'recupere' } }) : '') +
          (d.status !== 'perdu' ? ui.btn({ label: 'Perdu', variant: 'ghost', size: 'sm', act: 'dispute-status', data: { id: d.id, status: 'perdu' } }) : '') +
          '</div></article>';
      }).join('');

      const topSignals = s.topSignals.length
        ? s.topSignals.map((x) => '<li><b>' + U.esc(x.label) + '</b> · ' + x.count + ' cas<em>' + U.esc(x.hint) + '</em></li>').join('')
        : '<li class="muted">Aucun signal enregistré pour l’instant.</li>';

      return '' +
        '<div class="page-head"><div>' +
        '<span class="kicker">Protection du compte</span>' +
        '<h1>Litiges & remboursements</h1>' +
        '<p class="lede small">Une contestation bancaire n’est pas un remboursement accepté : la plateforme n’en décide pas, ' +
        'la banque oui. Ce que vous contrôlez, c’est la vitesse et la qualité du dossier. Ce registre est votre mémoire.</p>' +
        '</div><div class="row gap-10" style="flex-wrap:wrap">' +
        ui.btn({ label: 'Enregistrer un litige', variant: 'primary', act: 'dispute-new', icon: 'alert' }) +
        ui.btn({ label: 'Dossier de défense', variant: 'outline', act: 'dispute-dossier', icon: 'doc' }) +
        '</div></div>' +

        (wave ? '<div class="mt-20">' + waveBanner(wave) + '</div>' : '') +

        '<div class="kpis mt-20">' +
        ui.kpi({ label: 'Litiges enregistrés', value: s.total, icon: 'alert', foot: s.open + ' à documenter · ' + s.contested + ' contestés' }) +
        ui.kpi({ label: 'Montant contesté', value: money(s.amount), icon: 'wallet', foot: 'moyenne ' + money(s.average) + ' par litige' }) +
        ui.kpi({ label: 'Taux de dossiers gagnés', value: s.winRate == null ? '—' : s.winRate + ' %', icon: 'shieldCheck', foot: s.recovered + ' récupérés · ' + s.lost + ' perdus' }) +
        ui.kpi({ label: 'Canal principal', value: s.topChannel ? U.esc(store.channelLabel(s.topChannel)) : '—', icon: 'compass', foot: s.repeat + ' contact(s) déjà connu(s)' }) +
        '</div>' +

        '<div class="grid grid--2 mt-20">' +

        '<section class="panel"><div class="panel__head"><h3>' + icon('alert', 16) + 'Signaux à surveiller</h3>' +
        '<a class="small strong" href="#/chargebacks" style="color:var(--green-700)">Guide complet</a></div>' +
        '<div class="panel__body"><ul class="signallist">' + topSignals + '</ul>' +
        '<p class="small muted mt-16">Ces signaux ne sont pas des accusations : ce sont des faits observables dans la conversation ou la commande. ' +
        'Ils servent à modérer les premières commandes, jamais à juger quelqu’un sur une impression.</p>' +
        '<div class="row gap-12 mt-16" style="flex-wrap:wrap">' +
        ui.btn({ label: 'Demander de l’aide sur un litige', variant: 'outline', size: 'sm', act: 'ask-dispute-help' }) +
        '</div></div></section>' +

        '<section class="panel"><div class="panel__head"><h3>' + icon('scale', 16) + 'Règles de prudence</h3></div>' +
        '<div class="panel__body"><ol class="prudence">' +
        ['Aucun contenu sur-mesure ni session longue pour un contact sans historique : le seuil se gagne, il ne se vend pas.',
          'Le message de bienvenue indique qu’un prélèvement récurrent aura lieu et à quel nom il apparaît sur le relevé.',
          'Chaque livraison est suivie d’un message de confirmation : c’est cette trace qui fait gagner un dossier.',
          'Aucun échange, aucun paiement hors plateforme : un dossier hors plateforme est indéfendable.',
          'Watermark sur chaque contenu livré, horodaté : il prouve la livraison et dissuade la revente.',
          'Un contact qui conteste une fois est bloqué immédiatement, sans discussion.',
          'Un dossier par contestation, en moins de 72 h : au-delà, l’intermédiaire n’a plus le temps d’agir.'
        ].map((t, i) => '<li><span>' + (i + 1) + '</span>' + U.esc(t) + '</li>').join('') +
        '</ol></div></section>' +

        '</div>' +

        '<section class="section section--tight"><div class="between mb-16">' +
        '<h2 style="font-size:clamp(18px,2.2vw,23px)">Registre des litiges</h2>' +
        '<span class="small muted">' + list.length + ' entrée(s) affichée(s)</span></div>' +
        '<div class="filterbar" data-filters><div class="filters">' +
        C.chipsHTML({ key: 'status', label: 'État', value: status, options: [['all', 'Tous']].concat(Object.keys(store.DISPUTE_STATUS).map((k) => [k, store.DISPUTE_STATUS[k].label])) }) +
        C.chipsHTML({ key: 'channel', label: 'Canal', value: channel, options: [['all', 'Tous les canaux']].concat(store.DISPUTE_CHANNELS().map((c) => [c.id, c.label])) }) +
        '<div class="filter filter--wide"><label class="label" for="d-q">Recherche</label>' +
        '<input class="input" id="d-q" data-filter="q" placeholder="Identifiant ou note" value="' + U.esc(q) + '"></div>' +
        '</div></div>' +
        '<div class="stack gap-12 mt-20">' + (rows || ui.empty({
          icon: 'shieldCheck', title: 'Aucun litige dans ce filtre',
          text: 'C’est une bonne nouvelle. Enregistrez les cas au fur et à mesure : c’est ce registre qui fait la différence le jour où une vague arrive.'
        })) + '</div></section>';
    },
    mount(ctx) {
      C.bindFilters(ctx.root, '/app/disputes');
    }
  };

  /* ==================================================================== */
  /* ADMINISTRATION — /admin/disputes                                     */
  /* ==================================================================== */
  SEVE.views.adminDisputes = {
    title: 'Litiges & vagues',
    render(ctx) {
      const status = ctx.query.status || 'all';
      const channel = ctx.query.channel || 'all';
      const q = ctx.query.q || '';
      const list = store.disputes({ owner: 'all', status, channel, q });
      const s = store.disputesStats('all');
      const waves = store.disputeWaves();
      const patterns = store.disputePatterns(8);

      const rows = list.map((d) => {
        const owner = store.get(d.owner) || { name: d.owner };
        return '<tr>' +
          '<td>' + U.esc(U.fmtDate(d.created)) + '</td>' +
          '<td><div class="tcell">' + ui.avatar(owner, 'sm') + '<div class="tcell__txt"><b>' + U.esc(owner.name) + '</b>' +
          '<span>' + U.esc(d.owner) + '</span></div></div></td>' +
          '<td><b>' + U.esc(d.fan) + '</b></td>' +
          '<td>' + U.esc(store.typeLabel(d.type)) + '<span class="small muted"> · ' + U.esc(store.channelLabel(d.channel)) + '</span></td>' +
          '<td class="num">' + money(d.amount) + '</td>' +
          '<td>' + statusPill(d.status) + '</td>' +
          '<td>' + ((d.signals || []).length ? '<span class="small">' + U.esc((d.signals || []).map((x) => store.signalLabel(x)).join(' · ')) + '</span>' : '<span class="muted">—</span>') + '</td>' +
          '<td class="cell-actions">' +
          ui.btn({ label: 'Dossier', variant: 'ghost', size: 'sm', act: 'admin-dispute-dossier', data: { id: d.id } }) +
          (d.status !== 'conteste' ? ui.btn({ label: 'Contesté', variant: 'ghost', size: 'sm', act: 'admin-dispute-status', data: { id: d.id, status: 'conteste' } }) : '') +
          (d.status !== 'recupere' ? ui.btn({ label: 'Récupéré', variant: 'ghost', size: 'sm', act: 'admin-dispute-status', data: { id: d.id, status: 'recupere' } }) : '') +
          ui.btn({ label: 'Bloquer', variant: 'ghost', size: 'sm', act: 'admin-dispute-block', data: { id: d.id } }) +
          '</td></tr>';
      }).join('');

      return '' +
        '<div class="page-head"><div>' +
        '<span class="kicker">Protection des membres</span>' +
        '<h1>Litiges & vagues</h1>' +
        '<p class="lede small">Veille des contestations bancaires déclarées par les membres. Les données sont agrégées ' +
        'et anonymisées : aucun identifiant de contact n’est publié, aucune donnée bancaire n’est stockée.</p>' +
        '</div><div class="row gap-10" style="flex-wrap:wrap">' +
        ui.btn({ label: 'Exporter (anonymisé)', variant: 'outline', act: 'admin-export-disputes', icon: 'doc' }) +
        ui.btn({ label: 'Voir le guide public', variant: 'ghost', href: '#/chargebacks', icon: 'scale' }) +
        '</div></div>' +

        '<div class="kpis mt-20">' +
        ui.kpi({ label: 'Litiges déclarés', value: s.total, icon: 'alert', foot: s.open + ' à documenter' }) +
        ui.kpi({ label: 'Montant concerné', value: money(s.amount), icon: 'wallet', foot: 'récupéré : ' + money(s.amountRecovered) }) +
        ui.kpi({ label: 'Taux de dossiers gagnés', value: s.winRate == null ? '—' : s.winRate + ' %', icon: 'shieldCheck', foot: 'objectif > 40 %' }) +
        ui.kpi({ label: 'Vagues détectées', value: waves.length, icon: 'trending', foot: 'seuil : 3 litiges en 7 jours' }) +
        '</div>' +

        '<section class="panel mt-20"><div class="panel__head"><h3>' + icon('trending', 16) + 'Veille — litiges par semaine</h3>' +
        '<span class="small muted">' + patterns.length + ' semaine(s) observée(s)</span></div>' +
        '<div class="panel__body">' +
        (patterns.length ? ui.bars(patterns.slice().reverse().map((w) => ({
          label: 'Semaine du ' + U.fmtDate(w.week),
          value: w.count,
          display: w.count + ' · ' + money(w.amount) + ' · ' + w.channelLabel + ' · ' + w.profilesCount + ' compte(s)'
        }))) : ui.empty({ icon: 'chart', title: 'Aucune donnée', text: 'La veille se remplit dès que des membres enregistrent des litiges.' })) +
        '<p class="small muted mt-16">Un canal qui concentre les contestations doit être traité à la source : ' +
        'contenu publicitaire, message d’approche, communauté. C’est là que Sève aide ses membres à se protéger.</p>' +
        '</div></section>' +

        (waves.length ? '<section class="panel mt-20"><div class="panel__head"><h3>' + icon('alert', 16) + 'Vagues détectées</h3></div>' +
          '<div class="panel__body"><div class="stack gap-12">' + waves.slice(0, 5).map((w) => '<div class="waverow">' +
            '<div><b>' + w.count + ' litiges en 7 jours</b> · ' + money(w.amount) +
            '<p class="small muted">Du ' + U.fmtDate(w.from) + ' au ' + U.fmtDate(w.to) + ' · canal ' + U.esc(w.channelLabel) +
            ' · ' + w.owners + ' compte(s) touché(s)</p></div>' +
            ui.btn({ label: 'Dossier global', variant: 'outline', size: 'sm', act: 'admin-dispute-wave', data: { ids: w.ids.join(',') } }) +
            '</div>').join('') + '</div></div></section>' : '') +

        '<section class="section section--tight">' +
        '<div class="filterbar" data-filters><div class="filters">' +
        C.chipsHTML({ key: 'status', label: 'État', value: status, options: [['all', 'Tous']].concat(Object.keys(store.DISPUTE_STATUS).map((k) => [k, store.DISPUTE_STATUS[k].label])) }) +
        C.chipsHTML({ key: 'channel', label: 'Canal', value: channel, options: [['all', 'Tous les canaux']].concat(store.DISPUTE_CHANNELS().map((c) => [c.id, c.label])) }) +
        '<div class="filter filter--wide"><label class="label" for="ad-q">Recherche</label>' +
        '<input class="input" id="ad-q" data-filter="q" placeholder="Identifiant, note" value="' + U.esc(q) + '"></div>' +
        '</div></div>' +
        '<div class="table-wrap mt-20"><table class="table">' +
        '<thead><tr><th>Date</th><th>Compte</th><th>Contact</th><th>Achat</th><th class="num">Montant</th><th>État</th><th>Signaux</th><th></th></tr></thead>' +
        '<tbody>' + (rows || '<tr><td colspan="8"><div class="muted small">Aucun litige dans ce filtre.</div></td></tr>') + '</tbody>' +
        '</table></div></section>';
    },
    mount(ctx) { C.bindFilters(ctx.root, '/admin/disputes'); }
  };

  /* ==================================================================== */
  /* ACTIONS                                                              */
  /* ==================================================================== */

  SEVE.act('dispute-new', SEVE.flows.sure(function () { openDisputeEditor(null); }));

  SEVE.act('dispute-edit', SEVE.flows.sure(function (el) {
    const d = store.disputeById(el.getAttribute('data-id'));
    if (d) openDisputeEditor(d);
  }));

  SEVE.act('dispute-status', SEVE.flows.sure(function (el) {
    const id = el.getAttribute('data-id');
    const status = el.getAttribute('data-status');
    const st = store.DISPUTE_STATUS[status];
    ui.confirm({
      title: 'Marquer ce litige « ' + (st ? st.label : status) + ' » ?',
      text: (st ? st.hint : ''),
      okLabel: 'Confirmer'
    }).then((ok) => {
      if (!ok) return;
      store.updateDispute(id, { status });
      ui.toast('Litige mis à jour.', 'ok');
      SEVE.router.refresh();
    });
  }));

  SEVE.act('dispute-dossier', SEVE.flows.sure(function () {
    const me = store.me();
    const owner = (me && me.profileId) || 'c9';
    const list = store.disputes({ owner });
    if (!list.length) return ui.toast('Aucun litige à documenter pour l’instant.', 'warn');
    openDossier({ list, stats: store.disputesStats(owner) }, store.get(owner) || { name: me && me.name, id: owner });
  }));

  SEVE.act('dossier-print', function () { /* géré dans la modale */ });
  SEVE.act('dossier-copy', function () { /* géré dans la modale */ });

  SEVE.act('ask-dispute-help', SEVE.flows.sure(function () { disputeHelpModal(); }));

  function disputeHelpModal() {
    const me = store.me();
    ui.modal({
      title: 'Se faire accompagner sur un litige',
      subtitle: 'L’équipe Sève peut reprendre votre registre, prioriser les contestations et vous aider à construire le dossier.',
      size: 'lg',
      body: '<form id="helpform" novalidate><div class="formgrid">' +
        '<div class="field span2"><label class="label" for="hf-need">Ce qui se passe <span class="req">*</span></label>' +
        '<textarea class="textarea" id="hf-need" data-minlen="80" required placeholder="Depuis quand, combien de litiges, par quels canaux, ce que le support vous a répondu…"></textarea></div>' +
        '<div class="field"><label class="label" for="hf-amount">Montant total contesté (€)</label>' +
        '<input class="input" id="hf-amount" type="number" min="0" step="1" placeholder="Ex. 620"></div>' +
        '<div class="field"><label class="label" for="hf-status">État actuel</label>' +
        '<select class="select" id="hf-status"><option>Litige en cours, non contesté</option>' +
        '<option>Contestations transmises, sans réponse</option><option>Le support refuse de traiter</option>' +
        '<option>Risque de suspension du compte</option></select></div>' +
        '</div>' +
        '<div class="banner banner--soft mt-20">' + icon('info', 18) + '<div>Service d’accompagnement : relecture de votre registre, ' +
        'priorisation, rédaction du dossier et suivi. Réservé aux membres vérifiés, sans frais.</div></div></form>',
      footer: ui.btn({ label: 'Annuler', variant: 'ghost', act: 'cancel' }) +
        ui.btn({ label: 'Envoyer la demande', variant: 'primary', act: 'send-dispute-help', icon: 'send' }),
      onMount(panel) {
        panel.querySelector('[data-act="cancel"]').addEventListener('click', () => ui.close());
        panel.querySelector('[data-act="send-dispute-help"]').addEventListener('click', () => {
          const form = panel.querySelector('#helpform');
          if (!ui.validate(form)) return;
          const btn = panel.querySelector('[data-act="send-dispute-help"]');
          ui.loading(btn, true, 'Envoi…');
          setTimeout(() => {
            store.createApplication({
              user: (me && me.id) || 'c9',
              type: 'créateur (litige)',
              goals: ['Faire cesser les contestations bancaires'],
              specialties: [],
              location: 'À distance',
              criteria: 'Reprise du registre de litiges et aide à la constitution du dossier',
              need: form.querySelector('#hf-need').value +
                ' — Montant déclaré : ' + (form.querySelector('#hf-amount').value || 'non précisé') +
                ' € — État : ' + form.querySelector('#hf-status').value
            });
            ui.close();
            ui.toast('Demande envoyée. L’équipe revient vers vous sous 24 h ouvrées.', 'ok');
          }, 700);
        });
      }
    });
  }

  /* ------------------------------------------------------ côté admin ----- */

  SEVE.act('admin-dispute-status', function (el) {
    store.updateDispute(el.getAttribute('data-id'), { status: el.getAttribute('data-status') });
    ui.toast('Litige mis à jour.', 'ok');
    SEVE.router.refresh();
  });

  SEVE.act('admin-dispute-block', function (el) {
    const d = store.disputeById(el.getAttribute('data-id'));
    if (!d) return;
    ui.confirm({
      title: 'Bloquer ce contact ?',
      text: 'L’identifiant « ' + d.fan + ' » sera ajouté à la liste de surveillance partagée avec les membres qui déclarent des litiges. ' +
        'Aucune donnée personnelle n’est publiée : un identifiant public, un motif, une date.',
      okLabel: 'Ajouter à la surveillance'
    }).then((ok) => {
      if (!ok) return;
      store.updateDispute(d.id, { status: 'perdu', blocked: true });
      ui.toast('Contact ajouté à la liste de surveillance.', 'ok');
      SEVE.router.refresh();
    });
  });

  SEVE.act('admin-dispute-dossier', function (el) {
    const d = store.disputeById(el.getAttribute('data-id'));
    if (!d) return;
    openDossier({ list: [d], stats: store.disputesStats('all') && statsOf([d]) }, store.get(d.owner) || { name: d.owner, id: d.owner });
  });

  function statsOf(list) {
    const total = list.reduce((n, d) => n + (Number(d.amount) || 0), 0);
    const recovered = list.filter((d) => d.status === 'recupere');
    const lost = list.filter((d) => d.status === 'perdu');
    return {
      total: list.length, amount: total, recovered: recovered.length, lost: lost.length,
      open: list.filter((d) => d.status === 'nouveau').length,
      contested: list.filter((d) => d.status === 'conteste').length,
      amountLost: lost.reduce((n, d) => n + (Number(d.amount) || 0), 0),
      amountRecovered: recovered.reduce((n, d) => n + (Number(d.amount) || 0), 0),
      average: list.length ? Math.round(total / list.length) : 0,
      winRate: (recovered.length + lost.length) ? Math.round((recovered.length / (recovered.length + lost.length)) * 100) : null
    };
  }

  SEVE.act('admin-dispute-wave', function (el) {
    const ids = String(el.getAttribute('data-ids') || '').split(',').filter(Boolean);
    const list = ids.map((id) => store.disputeById(id)).filter(Boolean);
    if (!list.length) return;
    openDossier({ list, stats: statsOf(list) }, { name: 'Vague inter-comptes', id: list.length + ' dossiers' });
  });

  SEVE.act('admin-export-disputes', function () {
    const rows = [['semaine', 'litiges', 'montant', 'canal_principal', 'type_principal', 'comptes_concernes']]
      .concat(store.disputePatterns(52).map((w) => [w.week, w.count, w.amount, w.channelLabel, w.typeLabel, w.profilesCount]));
    const csv = rows.map((r) => r.map((c) => '"' + String(c).replace(/"/g, '""') + '"').join(';')).join('\n');
    const a = document.createElement('a');
    a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent('\uFEFF' + csv);
    a.download = 'seve-litiges-veille-anonymisee.csv';
    a.click();
    ui.toast('Export généré : agrégats par semaine, sans identifiant de contact.', 'ok');
  });
  /* ==================================================================== */
  /* PAGE PUBLIQUE — /chargebacks : comprendre et agir                    */
  /* ==================================================================== */
  const MODELES = {
    fan: 'Bonjour, je vois qu’une contestation a été déposée sur un paiement lié à mon compte.\n' +
      'Je ne vous en veux pas : si quelque chose ne vous a pas convenu, dites-le moi et je corrige (contenu remplacé, geste, explication).\n' +
      'En revanche, une contestation bancaire implique la banque et peut entraîner la fermeture de votre compte : si c’est une erreur de votre part, il est plus simple pour vous de l’annuler directement auprès de votre banque.\n' +
      'Dans tous les cas, je préfère qu’on en parle avant.',
    support: 'Objet : contestations bancaires groupées — demande d’examen par l’équipe paiements et risques\n\n' +
      'Bonjour,\n\n' +
      'Je constate [NOMBRE] contestations bancaires entre le [DATE 1] et le [DATE 2], pour un total de [MONTANT] €, ' +
      'sur des achats livrés (abonnements, contenus payants et commandes personnalisées).\n\n' +
      'Ces contestations présentent des points communs : mêmes canaux d’arrivée ([CANAL]), comptes créés le jour de l’achat, ' +
      'absence de tout échange avant ou après la livraison, demandes groupées dans le temps. Il ne s’agit pas de réclamations indépendantes.\n\n' +
      'Je joins un constat détaillé pour chaque transaction : identifiant public du contact, date, montant, preuve de livraison et historique de conversation horodaté.\n\n' +
      'Je demande :\n' +
      '1. l’examen de ces transactions par l’équipe en charge des paiements et des risques ;\n' +
      '2. la transmission de ces éléments au motif de contestation ;\n' +
      '3. le blocage définitif des comptes identifiés ;\n' +
      '4. la confirmation que ce schéma est enregistré à mon dossier, afin qu’un taux de contestation anormal ne me soit pas imputé.\n\n' +
      'Merci pour votre aide,\n[VOTRE NOM / PROFIL]'
  };

  function modeleHTML(cle, titre, sous) {
    return '<div class="model"><div class="between"><b>' + U.esc(titre) + '</b>' +
      ui.btn({ label: 'Copier', variant: 'outline', size: 'sm', act: 'copy-modele', data: { modele: cle } }) + '</div>' +
      '<p class="small muted mt-8">' + U.esc(sous) + '</p>' +
      '<pre class="model__text">' + U.esc(MODELES[cle]) + '</pre></div>';
  }

  SEVE.views.chargebacks = {
    title: 'Remboursements & litiges',
    render() {
      const me = store.me();
      return '' +
        '<section class="section"><div class="wrap wrap--narrow">' +

        '<span class="kicker">Comprendre</span>' +
        '<h1 class="mt-12">Vos « remboursements » ne viennent pas de la plateforme.<br>Ils viennent de leur banque.</h1>' +
        '<p class="lede mt-16">Une contestation bancaire — un <em>chargeback</em> — n’est pas un remboursement accepté par la plateforme. ' +
        'La plateforme joue l’intermédiaire ; c’est la banque de l’acheteur qui décide. C’est pour cela que le support vous répond ' +
        'toujours la même chose : il ne peut pas refuser ce qu’on ne lui demande pas.</p>' +

        '<div class="banner banner--soft mt-24">' + icon('info', 18) + '<div>' +
        '<strong>Trois motifs passent.</strong> Contenu non reçu, transaction non autorisée (carte volée, partagée, ou utilisée à votre insu), ' +
        'erreur technique. Tout le reste — « j’ai changé d’avis », « l’abonnement s’est renouvelé » — est normalement rejeté. ' +
        'Un pic soudain et durable signale donc autre chose : un schéma, pas une déception.</div></div>' +

        '<h2 class="mt-32">Le calendrier réel : 90 à 120 jours</h2>' +
        '<p class="lede mt-12">C’est ce qui surprend le plus : une contestation peut être déposée plusieurs semaines après l’achat. ' +
        'Une vague d’achats suspects peut donc devenir une vague de contestations deux mois plus tard.</p>' +
        '<div class="timeline mt-24">' +
        [
          { p: 'Jour 0', t: 'L’achat', d: 'Abonnement, déblocage d’un contenu, commande personnalisée, session. Rien d’anormal ne se voit à ce moment-là.' },
          { p: 'Semaine 1 à 2', t: 'Le débit apparaît sur le relevé', d: 'Le vrai titulaire de la carte — ou le propriétaire du compte détourné — découvre un prélèvement qu’il ne reconnaît pas. C’est là que le motif « transaction non autorisée » naît.' },
          { p: 'Jour 30 à 120', t: 'La banque accepte la contestation', d: 'La fenêtre est large : jusqu’à quatre mois. C’est le délai pendant lequel une même personne peut revenir, ou un même groupe appliquer la même méthode.' },
          { p: 'Jusqu’à Jour 120', t: 'Le montant quitte votre solde', d: 'Le retrait intervient avant que quiconque ait pu répondre. C’est pour cela qu’on documente dès les premiers jours, pas après le retrait.' },
          { p: '72 heures', t: 'Votre fenêtre utile', d: 'Une fois la contestation signalée, un dossier complet envoyé en trois jours a beaucoup plus de poids qu’un message isolé envoyé trois semaines après.' }
        ].map((x) => '<div class="tl"><span class="tl__dot"></span><div><span class="tl__period">' + U.esc(x.p) + '</span>' +
          '<h4>' + U.esc(x.t) + '</h4><p class="small muted">' + U.esc(x.d) + '</p></div></div>').join('') +
        '</div>' +

        '<h2 class="mt-40">Pourquoi ça arrive, par vagues</h2>' +
        '<div class="grid grid--2 mt-20">' +
        [
          { t: 'Cartes volées ou partagées', d: 'Le vrai titulaire de la carte découvre le prélèvement et conteste « transaction non autorisée ». Le remboursement est presque automatique. C’est le vecteur n°1 des vagues.' },
          { t: 'Méthodes partagées en communauté', d: 'Des groupes diffusent des procédures de contestation. Une même méthode appliquée par des dizaines de comptes produit exactement le schéma que vous vivez : un mois qui explose, puis un rythme régulier.' },
          { t: 'Un seul acteur, plusieurs comptes', d: 'Commence souvent par une interaction désagréable, un refus, un différend. La personne revient avec d’autres comptes, cible les mêmes canaux, et demande systématiquement du sur-mesure ou des sessions longues.' },
          { t: 'Un changement côté paiement', d: 'Un processeur, un contrôle renforcé, une nouvelle règle bancaire : le taux de contestation peut bouger sans que vous ayez rien changé. Le schéma est alors visible chez plusieurs créatrices au même moment.' }
        ].map((x) => '<article class="split reveal"><h3>' + U.esc(x.t) + '</h3><p class="small muted mt-8">' + U.esc(x.d) + '</p></article>').join('') +
        '</div>' +

        '<h2 class="mt-40">Un chargeback, concrètement : les sept gestes utiles</h2>' +
        '<div class="steps mt-20">' +
        [
          { n: '1', t: 'Arrêter le robinet', d: 'Aucun sur-mesure, aucune session longue pour un contact sans historique. Le contenu personnalisé et les longues conversations sont les achats les plus faciles à contester.' },
          { n: '2', t: 'Annoncer le prélèvement', d: 'Le message de bienvenue précise qu’un abonnement se renouvelle et sous quel nom le débit apparaîtra sur le relevé. Cela retire l’argument « je ne savais pas ».' },
          { n: '3', t: 'Garder la trace de chaque livraison', d: 'Un message de confirmation après l’envoi, horodaté, avec filigrane sur le contenu. Une capture vaut mieux qu’un souvenir.' },
          { n: '4', t: 'Regrouper les dossiers', d: 'Contester à l’unité est perdu d’avance. Un constat groupé, avec les points communs, change la lecture des faits.' },
          { n: '5', t: 'Répondre en moins de 72 h', d: 'La fenêtre de contestation est courte. Après, l’intermédiaire n’a plus de prise.' },
          { n: '6', t: 'Bloquer, systématiquement', d: 'Un contact qui conteste une fois recommence. Le bloquer protège vos mois suivants.' },
          { n: '7', t: 'Documenter le canal d’origine', d: 'Si toutes les contestations arrivent par le même endroit, ce n’est pas votre contenu qu’il faut changer : c’est l’endroit.' }
        ].map((x) => '<article class="step reveal"><span class="step__n">' + x.n + '</span>' +
          '<h4 class="mt-16" style="font-size:15.5px">' + U.esc(x.t) + '</h4><p class="small muted mt-8">' + U.esc(x.d) + '</p></article>').join('') +
        '</div>' +

        '<h2 class="mt-40">Deux modèles à copier</h2>' +
        '<div class="grid grid--2 mt-20">' +
        modeleHTML('fan', 'Au contact qui a contesté', 'Court, sans accusation. Souvent, la contestation est annulée à la lecture.') +
        modeleHTML('support', 'Au support de la plateforme', 'Un dossier, pas une plainte : dates, montants, points communs, demande claire.') +
        '</div>' +

        '<h2 class="mt-40">Ce que Sève met à votre disposition</h2>' +
        '<div class="grid grid--2 mt-20">' +
        [
          { t: 'Un registre de litiges', d: 'Chaque contestation enregistrée en trente secondes : identifiant, montant, type, canal, signaux. Aucune donnée bancaire, jamais.' },
          { t: 'Un dossier de défense imprimable', d: 'Un constat structuré, prêt à transmettre, avec la chronologie, les totaux et les preuves à joindre.' },
          { t: 'La détection de vagues', d: 'Quand trois contestations arrivent en sept jours, Sève le signale. Vous n’êtes plus seule à essayer de comprendre.' },
          { t: 'La veille anonymisée', d: 'Canal et période qui concentrent les contestations, partagés sans aucun identifiant. Ce qui se voit chez tout le monde cesse d’être votre faute.' }
        ].map((x) => '<article class="split reveal"><h3 style="font-size:16px">' + icon('check', 16) + ' ' + U.esc(x.t) + '</h3><p class="small muted mt-8">' + U.esc(x.d) + '</p></article>').join('') +
        '</div>' +

        '<div class="ctaband reveal mt-40"><span class="ctaband__grid"></span>' +
        '<h2>Un litige en cours, ou une vague à endiguer ?</h2>' +
        '<p>Ouvrez votre registre, générez le constat, et demandez à l’équipe de reprendre le dossier avec vous. Ce service est inclus.</p>' +
        '<div class="row">' +
        (me ? ui.btn({ label: 'Ouvrir mon registre', variant: 'primary', size: 'lg', href: '#/app/disputes', icon: 'alert' })
            : ui.btn({ label: 'Créer mon compte', variant: 'primary', size: 'lg', href: '#/signup' })) +
        ui.btn({ label: 'Demander de l’aide', variant: 'outline', size: 'lg', act: 'ask-dispute-help', icon: 'headset' }) +
        '</div></div>' +

        '<p class="center small muted mt-32">Ce guide décrit des mécanismes généraux et ne constitue pas un conseil juridique. ' +
        'Pour un préjudice important, conservez les preuves et rapprochez-vous d’un professionnel du droit.</p>' +

        '</div></section>';
    }
  };

  SEVE.act('copy-modele', function (el) {
    const cle = el.getAttribute('data-modele');
    if (MODELES[cle]) ui.copy(MODELES[cle], 'Modèle copié.');
  });
})();
