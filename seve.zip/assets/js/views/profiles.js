/* ==========================================================================
   Sève — page profil (créateur et manager)
   ========================================================================== */
(function () {
  const U = SEVE.util;
  const ui = SEVE.ui;
  const C = SEVE.components;
  const store = SEVE.store;
  const T = SEVE.taxo;
  const icon = SEVE.icons.svg;

  SEVE.views = SEVE.views || {};

  SEVE.views.profile = {
    render(ctx) {
      const p = store.get(ctx.params.id);
      if (!p) {
        return '<section class="section"><div class="wrap">' + ui.empty({
          icon: 'user', title: 'Profil introuvable',
          text: 'Ce profil a peut-être été retiré par son titulaire, suspendu par l’équipe, ou supprimé à sa demande.',
          action: ui.btn({ label: 'Revenir à la découverte', variant: 'primary', href: '#/discover' })
        }) + '</div></section>';
      }
      const me = store.me();
      const isMe = me && me.id === p.id;
      const isManager = p.role === 'manager';
      const match = me && !isMe && me.role !== 'admin' && me.role !== p.role ? store.scoreFor(me, p) : null;
      const similar = store.recommendations(me && !isMe ? me : null, { role: p.role, limit: 4 })
        .filter((e) => e.profile.id !== p.id).slice(0, 3);
      const stats = C.profileStats(p);
      const blocked = store.isBlocked(p.id);

      return '<section class="section section--tight">' +
        '<div class="wrap">' +
        '<div class="row gap-12 mb-16" style="flex-wrap:wrap">' +
        '<a class="btn btn--ghost btn--sm" href="#/' + (isManager ? 'managers' : 'creators') + '">' + icon('arrowLeft', 15) + '<span>Retour aux ' + (isManager ? 'managers' : 'créateurs') + '</span></a>' +
        (p.status === 'suspended' ? ui.pill('Compte suspendu par l’équipe Sève', 'declined') : '') +
        (p.status === 'pending' ? ui.pill('Profil en cours de vérification', 'pending') : '') +
        (p.status === 'archived' ? ui.pill('Profil archivé', 'archived') : '') +
        (blocked ? '<span class="chip chip--danger chip--sm">' + icon('ban', 13) + 'Vous avez bloqué ce profil</span>' : '') +
        '</div>' +

        /* --------------------------------------------------- EN-TÊTE */
        '<header class="phead reveal">' +
        '<div class="phead__top">' +
        ui.avatar(Object.assign({ square: isManager }, p), '2xl') +
        '<div class="phead__id">' +
        '<div class="row gap-10" style="flex-wrap:wrap">' +
        '<h1>' + U.esc(p.name) + '</h1>' +
        (p.verified ? '<span class="chip chip--green chip--sm">' + icon('shieldCheck', 14) + 'Profil vérifié</span>' : '<span class="chip chip--sm">Vérification en cours</span>') +
        '</div>' +
        '<p class="mt-8" style="color:var(--ink-2);font-size:15px">' + U.esc(isManager ? (p.kind || 'Manager') : 'Créatrice / Créateur') +
        (p.handle ? ' · <span class="muted">' + U.esc(p.handle) + '</span>' : '') + '</p>' +
        '<div class="phead__meta">' +
        '<span>' + icon('mapPin', 15) + U.esc(p.city) + ', ' + U.esc(p.country) + '</span>' +
        '<span>' + icon('globe', 15) + U.esc(p.region) + '</span>' +
        '<span>' + icon('calendar', 15) + 'Membre depuis ' + U.fmtDate(p.joined, { short: true }) + '</span>' +
        '<span>' + icon('clock', 15) + U.esc((p.metrics && p.metrics.response) || 'Réactivité non renseignée') + '</span>' +
        '</div>' +
        '<div class="chips mt-16">' +
        ui.status(p.availability) +
        (p.languages || []).map((l) => '<span class="chip chip--sm">' + U.esc(l) + '</span>').join('') +
        '</div>' +
        '</div>' +
        '<div class="phead__actions">' +
        (isMe
          ? ui.btn({ label: 'Modifier mon profil', variant: 'primary', href: '#/app/profile', icon: 'edit' }) +
            ui.btn({ label: 'Mes paramètres', variant: 'outline', href: '#/app/settings' })
          : ui.btn({ label: 'Contacter', variant: 'primary', size: 'lg', act: 'contact-profile', data: { id: p.id }, icon: 'send', iconSize: 18 }) +
            ui.btn({ label: 'Partager', variant: 'outline', size: 'lg', act: 'share-profile', data: { id: p.id }, icon: 'link' }) +
            '<div class="pmenu" id="pm-more"><button class="btn btn--outline btn--lg btn--icon" data-act="toggle-more" aria-label="Plus d’options">' + icon('more', 18) + '</button>' +
            '<div class="pmenu__slot"></div></div>') +
        '</div>' +
        '</div>' +
        '<div class="phead__stats">' + stats.map((s) =>
          '<div class="phead__stat"><b>' + U.esc(s.value) + '</b><span>' + U.esc(s.label) + '</span></div>').join('') + '</div>' +
        '</header>' +

        /* --------------------------------------------------- CORPS */
        '<div class="grid grid--side mt-24">' +
        '<div class="stack gap-20">' +

        '<section class="psection reveal"><h3>' + icon('user', 17) + 'Présentation</h3>' +
        '<p style="color:var(--ink-2)">' + U.esc(p.bio) + '</p>' +
        ((p.goals || []).length ? '<div class="mt-20"><span class="small strong">Objectifs affichés</span><div class="chips mt-8">' +
          p.goals.map((g) => '<span class="chip chip--sm chip--green">' + U.esc(g) + '</span>').join('') + '</div></div>' : '') +
        '</section>' +

        '<section class="psection reveal"><h3>' + icon('history', 17) + 'Expérience</h3>' +
        ((p.timeline || []).length ? C.timeline(p.timeline) : '<p class="muted small">Aucune expérience détaillée pour le moment.</p>') +
        '</section>' +

        '<section class="psection reveal"><h3>' + icon('layers', 17) + 'Spécialités</h3>' +
        '<div class="chips">' + T.labels(p.specialties || []).map((l) => '<span class="chip">' + U.esc(l) + '</span>').join('') + '</div>' +
        ((p.platforms || []).length ? '<div class="mt-20"><span class="small strong">Plateformes et canaux déclarés</span><div class="chips mt-8">' +
          p.platforms.map((k) => '<span class="chip chip--sm">' + SEVE.icons.platform(k, 14) + U.esc((T.PLATFORMS.filter((x) => x.id === k)[0] || {}).label || k) + '</span>').join('') +
          '</div></div>' : '') +
        (p.metrics ? '<dl class="defs mt-20">' + [
          ['Croissance déclarée', p.metrics.growth],
          ['Rétention', p.metrics.retention],
          [isManager ? 'Revenus moyens des comptes' : 'Revenus déclarés', p.metrics.revenue]
        ].filter((x) => x[1] && x[1] !== '—').map((d) =>
          '<div class="def"><dt>' + U.esc(d[0]) + '</dt><dd>' + U.esc(d[1]) + '</dd></div>').join('') + '</dl>' : '') +
        '</section>' +

        '<section class="psection reveal"><h3>' + icon('image', 17) + 'Portfolio</h3>' +
        ((p.portfolio || []).length ? C.portfolioTiles(p.portfolio)
          : '<p class="muted small">Le portfolio n’est pas encore renseigné. Demandez des exemples directement via une demande de collaboration.</p>') +
        '<p class="tiny muted mt-16">Les contenus sont décrits mais jamais exposés publiquement : Sève n’héberge pas de médias explicites.</p>' +
        '</section>' +

        '<section class="psection reveal"><h3>' + icon('briefcase', 17) + 'Informations professionnelles</h3>' +
        '<dl class="defs">' + proRows(p).map((d) =>
          '<div class="def"><dt>' + U.esc(d[0]) + '</dt><dd>' + U.esc(d[1] || '—') + '</dd></div>').join('') + '</dl>' +
        '</section>' +

        '<section class="psection reveal"><h3>' + icon('target', 17) + 'Collaborations recherchées</h3>' +
        (p.looking && p.looking.title
          ? '<div class="banner banner--ok">' + icon('target', 18) + '<div><b>' + U.esc(p.looking.title) + '</b>' +
            (p.looking.split ? '<br>Forme envisagée : ' + U.esc(p.looking.split) : '') + '</div></div>' +
            (p.looking.notes ? '<p class="mt-16" style="color:var(--ink-2)">' + U.esc(p.looking.notes) + '</p>' : '') +
            ((p.looking.must || []).length ? '<div class="mt-20"><span class="small strong">Non négociable pour ' + (isManager ? 'cette structure' : 'ce profil') + '</span>' +
              '<ul class="stack gap-10 mt-12">' + p.looking.must.map((m) =>
                '<li class="row gap-10" style="align-items:flex-start"><span style="color:var(--green-600)">' + icon('check', 16) + '</span>' +
                '<span style="font-size:14.2px;color:var(--ink-2)">' + U.esc(m) + '</span></li>').join('') + '</ul></div>' : '')
          : '<p class="muted small">Les critères de collaboration ne sont pas encore précisés.</p>') +
        '</section>' +

        /* --------------------------------------- DEMANDE DE COLLABORATION */
        (isMe ? '' : '<section class="psection reveal" id="demande"><h3>' + icon('send', 17) + 'Envoyer une demande de collaboration</h3>' +
          '<p class="small muted">Présentez-vous et expliquez ce que vous recherchez. Un message précis reçoit beaucoup plus de réponses.</p>' +
          (match ? '<div class="matchline mt-16">' + ui.ring(match.score, { size: 48, stroke: 4 }) +
            '<div><b class="small">Compatibilité estimée : ' + match.score + '%</b>' +
            '<p class="tiny muted">' + U.esc((match.reasons || []).slice(0, 2).join(' · ') || 'Peu de critères communs déclarés') + '</p></div></div>' : '') +
          '<div class="field mt-20"><label class="label" for="inline-msg">Votre message</label>' +
          '<textarea class="textarea" id="inline-msg" data-minlen="120" placeholder="Bonjour, je suis…"></textarea>' +
          '<p class="help">120 caractères minimum. Indiquez votre situation actuelle, ce que vous cherchez et vos conditions.</p></div>' +
          '<div class="row gap-8 mt-12" style="flex-wrap:wrap"><span class="tiny muted">Suggestions :</span>' +
          '<button class="chip chip--sm" data-inline-tpl="0">Présentation courte</button>' +
          '<button class="chip chip--sm" data-inline-tpl="1">Préciser mes attentes</button>' +
          '<button class="chip chip--sm" data-inline-tpl="2">Proposer un essai</button></div>' +
          '<label class="check mt-16"><input type="checkbox" id="inline-consent"><span>Je confirme être majeur(e) et respecter les <a href="#/legal/rules" style="color:var(--green-700)">règles de la plateforme</a>.</span></label>' +
          '<div class="row gap-12 mt-20" style="flex-wrap:wrap">' +
          ui.btn({ label: 'Envoyer la demande', variant: 'primary', act: 'inline-send', data: { id: p.id } }) +
          ui.btn({ label: 'Signaler ce profil', variant: 'ghost', size: 'sm', act: 'report-profile', data: { id: p.id }, icon: 'flag', iconSize: 15 }) +
          '</div></section>') +

        '</div>' +

        /* --------------------------------------------------- COLONNE */
        '<aside class="sticky-side">' +
        (match ? '<div class="card card--pad reveal"><div class="row gap-16">' +
          ui.ring(match.score, { size: 74, caption: 'compat.' }) +
          '<div style="min-width:0"><b style="font-size:15px">Compatibilité estimée</b>' +
          '<p class="tiny muted mt-4">Repère indicatif, pas une garantie.</p></div></div>' +
          '<ul class="stack gap-10 mt-16">' + (match.reasons || []).map((r) =>
            '<li class="row gap-8" style="align-items:flex-start"><span style="color:var(--green-600)">' + icon('check', 15) + '</span>' +
            '<span class="small" style="color:var(--ink-2)">' + U.esc(r) + '</span></li>').join('') + '</ul>' +
          ((match.cautions || []).length ? '<div class="banner banner--warn mt-16" style="padding:11px 13px">' + icon('info', 16) +
            '<div class="small">' + U.esc(match.cautions.join(' ')) + '</div></div>' : '') +
          '<div class="mt-16">' + ui.btn({ label: 'Envoyer une demande', variant: 'primary', block: true, act: 'scroll-to-request' }) + '</div>' +
          '</div>' : '') +

        '<div class="card card--pad reveal">' +
        '<h4>Repères rapides</h4>' +
        '<dl class="defs mt-12">' + [
          ['Disponibilité', (T.AVAILABILITY.filter((a) => a.id === p.availability)[0] || {}).label],
          ['Expérience', C.expShort(p.exp)],
          [isManager ? 'Structure' : 'Réseau', isManager ? ((T.TEAMSIZE.filter((t) => t.id === p.team)[0] || {}).label) : ((T.NETWORK.filter((n) => n.id === p.network)[0] || {}).label)],
          ['Langues', (p.languages || []).join(', ')],
          ['Vérification', p.verified ? 'Identité et informations contrôlées' : 'En attente']
        ].map((d) => '<div class="def"><dt>' + U.esc(d[0]) + '</dt><dd>' + U.esc(d[1] || '—') + '</dd></div>').join('') + '</dl>' +
        (isMe ? '' : '<div class="stack gap-8 mt-16">' +
          ui.btn({ label: 'Contacter', variant: 'primary', block: true, act: 'contact-profile', data: { id: p.id } }) +
          ui.btn({ label: blocked ? 'Débloquer' : 'Bloquer ce profil', variant: 'ghost', size: 'sm', block: true, act: 'block-profile', data: { id: p.id } }) +
          '</div>') +
        '</div>' +

        '<div class="card card--pad reveal" style="background:var(--surface)">' +
        '<h4>Rappels de sécurité</h4>' +
        '<ul class="stack gap-10 mt-12">' + [
          'Aucun paiement ne doit être demandé entre membres.',
          'Exigez un contrat écrit avant la moindre production.',
          'Signalez toute pression ou demande hors cadre.'
        ].map((t) => '<li class="row gap-8" style="align-items:flex-start"><span style="color:var(--ink-4)">' + icon('shield', 15) + '</span>' +
          '<span class="small muted">' + U.esc(t) + '</span></li>').join('') + '</ul>' +
        '<a class="btn btn--ghost btn--sm mt-12" href="#/legal/rules">Lire les règles ' + icon('arrowRight', 15) + '</a>' +
        '</div>' +

        ((similar || []).length && !isMe ? '<div class="card card--pad reveal">' +
          '<h4>Profils comparables</h4><div class="stack gap-12 mt-12">' + similar.map((e) =>
            '<a class="row gap-12" href="#/profiles/' + e.profile.id + '">' + ui.avatar(Object.assign({ square: e.profile.role === 'manager' }, e.profile), 'sm') +
            '<span class="grow" style="min-width:0"><b style="display:block;font-size:13.5px">' + U.esc(e.profile.name) + '</b>' +
            '<span class="tiny muted">' + U.esc(e.profile.city) + ' · ' + e.score + '% de compatibilité</span></span>' +
            icon('chevronRight', 15) + '</a>').join('') + '</div></div>' : '') +
        '</aside>' +
        '</div>' +
        '</div></section>';
    },

    mount(ctx) {
      const p = store.get(ctx.params.id);
      if (!p) return;
      const me = store.me();

      /* Menu « plus d’options » */
      const more = ctx.root.querySelector('#pm-more');
      if (more) {
        more.querySelector('[data-act="toggle-more"]').addEventListener('click', () => {
          const slot = more.querySelector('.pmenu__slot');
          if (slot.firstElementChild) { slot.innerHTML = ''; return; }
          document.querySelectorAll('.pmenu__panel').forEach((n) => n.remove());
          slot.innerHTML = '<div class="pmenu__panel">' +
            '<button class="pmenu__item" data-act="share-profile" data-id="' + p.id + '">' + icon('link', 17) + '<span>Copier le lien du profil</span></button>' +
            '<button class="pmenu__item" data-act="report-profile" data-id="' + p.id + '">' + icon('flag', 17) + '<span>Signaler ce profil</span></button>' +
            '<div class="pmenu__sep"></div>' +
            '<button class="pmenu__item pmenu__item--danger" data-act="block-profile" data-id="' + p.id + '">' + icon('ban', 17) + '<span>' + (store.isBlocked(p.id) ? 'Débloquer' : 'Bloquer') + ' ce profil</span></button>' +
            '</div>';
        });
      }

      /* Zone de demande intégrée à la page */
      const ta = ctx.root.querySelector('#inline-msg');
      const send = ctx.root.querySelector('[data-act="inline-send"]');
      if (!ta || !send) return;
      const templates = [
        'Bonjour, je suis {moi}. Votre profil correspond à ce que je recherche, notamment sur {points}. Je vous propose un échange de 20 minutes pour voir si nos façons de travailler se rejoignent.',
        'Bonjour, {points} m’intéressent particulièrement. De mon côté, je peux apporter de la régularité et une communication directe. Souhaitez-vous que je vous présente mes chiffres actuels et mon planning ?',
        'Bonjour, je préfère avancer par étapes : que diriez-vous d’une période d’essai d’un mois avec un point hebdomadaire, puis un contrat si le rythme vous convient ?'
      ];
      ctx.root.querySelectorAll('[data-inline-tpl]').forEach((b) => b.addEventListener('click', () => {
        const i = Number(b.getAttribute('data-inline-tpl'));
        const points = T.labels((p.specialties || []).slice(0, 2)).join(' et ');
        ta.value = templates[i].replace('{moi}', me ? me.name : 'votre futur partenaire').replace('{points}', points || 'votre approche');
        ta.focus();
      }));

      send.addEventListener('click', () => {
        if (!store.isAuthed()) return SEVE.flows.needAuth();
        const consent = ctx.root.querySelector('#inline-consent');
        const wrap = ta.closest('.psection');
        ui.clearErrors(wrap);
        let ok = true;
        if (ta.value.trim().length < 120) { ui.fieldError(ta, 'Encore ' + (120 - ta.value.trim().length) + ' caractères pour que votre demande soit prise au sérieux.'); ok = false; }
        if (!consent.checked) { ui.fieldError(consent, 'Cette confirmation est obligatoire.'); ok = false; }
        if (!ok) return;

        ui.loading(send, true, 'Envoi…');
        setTimeout(() => {
          const cree = store.createRequest({ from: me.id, to: p.id, message: ta.value.trim() });
          if (!cree) {
            ui.loading(send, false);
            ui.toast('Ce profil est en pause : aucune nouvelle demande n’est envoyée pour le moment.', 'warn');
            return;
          }
          store.pushNotification(p.role, {
            type: 'request', icon: 'send', title: 'Nouvelle demande de ' + me.name,
            text: SEVE.flows.roleLabel(me) + ' · ' + me.city, href: '#/app/requests'
          });
          const zone = ctx.root.querySelector('#demande');
          zone.innerHTML = '<div class="empty" style="border:0;background:transparent;padding:8px 0 0">' +
            '<div class="empty__icon" style="background:var(--ok-bg);color:var(--ok)">' + icon('checkCircle', 23) + '</div>' +
            '<h3>Demande envoyée</h3><p>' + U.esc(p.name) + ' reçoit votre message dès maintenant. Vous serez notifié(e) de sa réponse dans vos messages.</p>' +
            '<div class="row gap-12 mt-16" style="justify-content:center;flex-wrap:wrap">' +
            ui.btn({ label: 'Voir mes demandes', variant: 'primary', href: '#/app/requests' }) +
            ui.btn({ label: 'Découvrir d’autres profils', variant: 'outline', href: '#/' + (p.role === 'manager' ? 'managers' : 'creators') }) +
            '</div></div>';
          ui.toast('Demande envoyée à ' + p.name + '.', 'ok');
        }, 820);
      });
    }
  };

  function proRows(p) {
    const pro = p.pro || {};
    const base = [
      ['Statut professionnel', pro.statut],
      ['Commission / tarif annoncé', p.role === 'manager' ? (p.commission || pro.tarif) : pro.tarif],
      ['Outils utilisés', pro.outils],
      ['Disponibilité hebdomadaire', pro.dispo],
      ['Modalités de paiement déclarées', pro.paiement],
      ['Langues de travail', (p.languages || []).join(', ')]
    ];
    if (p.role === 'manager') {
      base.splice(1, 0, ['Créateurs accompagnés', U.fmtNum(p.creatorsCount || 0)]);
      base.splice(2, 0, ['Taille de l’équipe', (T.TEAMSIZE.filter((t) => t.id === p.team)[0] || {}).label]);
    } else {
      base.splice(1, 0, ['Abonnés déclarés', U.fmtK(p.subs || 0)]);
      base.splice(2, 0, ['Expérience', C.expShort(p.exp)]);
    }
    return base;
  }
})();
