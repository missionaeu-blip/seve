/* ==========================================================================
   Sève — espace connecté : tableaux de bord, recherche, recommandations,
   demandes, messagerie, profil, paramètres, mes créateurs, aide
   ========================================================================== */
(function () {
  const U = SEVE.util;
  const ui = SEVE.ui;
  const C = SEVE.components;
  const store = SEVE.store;
  const T = SEVE.taxo;
  const icon = SEVE.icons.svg;

  SEVE.views = SEVE.views || {};

  const IS_MANAGER = () => store.me() && store.me().role === 'manager';

  function page(head, body) {
    return '<div class="page-head"><div><h1>' + U.esc(head.title) + '</h1>' +
      (head.subtitle ? '<p>' + U.esc(head.subtitle) + '</p>' : '') + '</div>' +
      (head.actions ? '<div class="row gap-10" style="flex-wrap:wrap">' + head.actions + '</div>' : '') + '</div>' + body;
  }

  function panelRow(o) {
    return '<button class="panelrow" data-href="' + o.href + '">' +
      (o.avatar ? ui.avatar(o.profile || {}, 'sm') : '<span class="notif__icon">' + icon(o.icon || 'info', 16) + '</span>') +
      '<span class="panelrow__body"><b>' + U.esc(o.title) + '</b><span>' + U.esc(o.text || '') + '</span></span>' +
      (o.meta ? '<span class="panelrow__meta">' + U.esc(o.meta) + '</span>' : '') +
      (o.badge ? ui.pill(o.badge, o.badgeVariant || 'pending') : '') +
      '</button>';
  }

  /* ================================================================== */
  /* TABLEAU DE BORD                                                     */
  /* ================================================================== */
  /**
   * Ce qu'il y a à faire aujourd'hui — ou rien, et c'est dit calmement.
   * Trois lignes au maximum, chacune avec un geste unique. Le reste du tableau
   * de bord sert à consulter ; ici, on agit. Aucun chiffre alarmant, aucune
   * pastille rouge : on annonce l'état, on propose le geste, on s'arrête là.
   */
  function aujourdhui(me, isManager) {
    const box = store.requestBox(me.id);
    const enAttente = box.received.filter((r) => r.status === 'pending');
    const nonLus = store.unreadTotal(isManager ? 'manager' : 'creator');
    const of = store.ofAccount();
    const st = store.ofStats();
    const jours = st.releveLe ? Math.floor((Date.now() - new Date(st.releveLe + 'T12:00:00').getTime()) / 86400000) : null;
    const lignes = [];

    if (!isManager && of.connected && !of.demo && (st.vide || jours === null || jours >= 3)) {
      lignes.push({ icone: 'percent', titre: 'Ton suivi OnlyFans attend des chiffres',
        texte: st.vide ? 'Dépose ton export ou colle tes chiffres : ton tableau se remplit tout seul.'
                       : 'Dernier relevé il y a ' + jours + ' jours. Un dépôt de fichier suffit à remettre ta courbe à jour.',
        action: ui.btn({ label: 'Mettre à jour', variant: 'primary', size: 'sm', href: '#/app/of', icon: 'folder' }) });
    }
    if (nonLus > 0) {
      lignes.push({ icone: 'message', titre: nonLus + ' message' + (nonLus > 1 ? 's' : '') + ' à lire',
        texte: 'Répondre aujourd’hui entretient la relation : c’est le geste qui compte le plus.',
        action: ui.btn({ label: 'Ouvrir', variant: 'primary', size: 'sm', href: '#/app/messages', icon: 'message' }) });
    }
    if (enAttente.length > 0) {
      lignes.push({ icone: 'send', titre: enAttente.length + ' demande' + (enAttente.length > 1 ? 's' : '') + ' en attente',
        texte: 'Une réponse claire, même négative, laisse toujours une bonne impression.',
        action: ui.btn({ label: 'Voir les demandes', variant: 'outline', size: 'sm', href: '#/app/requests', icon: 'send' }) });
    }

    if (!lignes.length) {
      return '<div class="aujourdhui aujourdhui--calme reveal">' +
        '<div class="aujourdhui__head">' + icon('checkCircle', 18) +
        '<b>Rien d’urgent aujourd’hui.</b><span>Tout est à jour : vos messages sont lus, vos demandes traitées. Prenez le temps qu’il vous faut.</span></div>' +
        '</div>';
    }

    return '<div class="aujourdhui reveal">' +
      '<div class="aujourdhui__head">' + icon('sparkles', 17) +
      '<b>' + lignes.length + ' chose' + (lignes.length > 1 ? 's' : '') + ' aujourd’hui</b>' +
      '<span>Choisissez ce que vous souhaitez traiter maintenant, à votre rythme.</span></div>' +
      '<div class="aujourdhui__liste">' + lignes.slice(0, 3).map((l) =>
        '<div class="aujourdhui__ligne"><i>' + icon(l.icone, 15) + '</i><b>' + U.esc(l.titre) + '</b>' +
        '<span>' + U.esc(l.texte) + '</span>' + l.action + '</div>').join('') + '</div></div>';
  }

  SEVE.views.dashboard = {
    title: 'Tableau de bord',
    render() {
      const me = store.me();
      const isManager = me.role === 'manager';
      const box = store.requestBox(me.id);
      const convs = store.conversations({ demo: isManager ? 'manager' : 'creator' }).slice(0, 3);
      const unread = store.unreadTotal(isManager ? 'manager' : 'creator');
      const recs = store.recommendations(me, { limit: 4 });
      const comp = store.completion(me);
      const newProfiles = store.search({ type: isManager ? 'creator' : 'manager', sort: 'recent' }).slice(0, 3);

      const kpis = isManager
        ? [
          { label: 'Demandes reçues', value: box.received.length, icon: 'send', foot: box.received.filter((r) => r.status === 'pending').length + ' en attente' },
          { label: 'Nouveaux profils', value: newProfiles.length + 6, icon: 'userPlus', foot: 'sur les 7 derniers jours' },
          { label: 'Messages non lus', value: unread, icon: 'message', foot: convs.length ? 'Dernier échange ' + U.fmtRelative(convs[0].last.at) : 'Aucun échange' }
        ]
        : [
          { label: 'Demandes reçues', value: box.received.length, icon: 'send', foot: box.received.filter((r) => r.status === 'pending').length + ' en attente' },
          { label: 'Messages non lus', value: unread, icon: 'message', foot: convs.length ? 'Dernier échange ' + U.fmtRelative(convs[0].last.at) : 'Aucun échange' },
          { label: 'Profils recommandés', value: recs.length + (recs.length ? 2 : 0), icon: 'sparkles', foot: recs.length ? 'Meilleure compatibilité : ' + recs[0].score + '%' : 'Complétez vos critères' }
        ];

      const ancienTableau = page({
        title: isManager ? 'Bonjour ' + me.name : 'Bonjour ' + me.name,
        subtitle: isManager
          ? 'Vos demandes, vos créateurs et vos recommandations.'
          : 'Vos demandes, vos conversations et vos recommandations.',
        actions: (isManager
          ? ui.btn({ label: 'Rechercher des créateurs', variant: 'primary', href: '#/app/discover', icon: 'search' })
          : ui.btn({ label: 'Rechercher un manager', variant: 'primary', href: '#/app/discover', icon: 'search' })) +
          '<a class="btn btn--ghost" href="#/app/matching">Mes recommandations</a>'
      },
        /* Ce qu'il y a à faire maintenant — ou rien, dit calmement */
        aujourdhui(me, isManager) +

        /* Un coin bien-être au premier écran : pause et message direct. */
        (function () {
          const confort = store.care(me.id);
          const fil = store.myTeamThread(false);
          const envoyes = fil && fil.messages ? fil.messages.filter((m) => m.from === 'member') : [];
          const dernier = envoyes.length ? envoyes[envoyes.length - 1] : null;
          return '<section class="bienetre reveal mt-16" id="coin-bien-etre" aria-labelledby="bienetre-titre">' +
            '<div class="bienetre__intro">' +
            '<span class="bienetre__mark">' + icon('heart', 20) + '</span>' +
            '<div><span class="kicker">À votre rythme</span><h2 id="bienetre-titre">Mon coin bien-être</h2>' +
            '<p>Une pause, une question, ou quelque chose qui ne va pas : vous pouvez nous l’écrire ici. Sans jugement.</p></div>' +
            '<a class="bienetre__link" href="#/app/care">Ouvrir mon coin détente →</a>' +
            '</div>' +
            '<div class="bienetre__body">' +
            '<div class="bienetre__pause"><b>' + icon('pause', 15) + ' Prendre une pause</b>' +
            '<p>' + (confort.pause ? 'Votre profil est en pause. Vos conversations restent ouvertes.' :
              'Votre profil quitte la recherche, sans couper vos conversations.') + '</p>' +
            ui.btn({ label: confort.pause ? 'Reprendre mon activité' : 'Mettre mon profil en pause',
              variant: 'outline', size: 'sm', act: 'care-toggle', data: { key: 'pause' }, icon: confort.pause ? 'play' : 'pause' }) +
            '</div>' +
            '<div class="bienetre__chat"><b>' + icon('message', 15) + ' Parler à l’équipe Sève</b>' +
            '<p>Un problème, une inquiétude ou juste besoin de discuter ? Ce message va dans votre fil privé avec l’équipe.</p>' +
            (dernier ? '<span class="bienetre__last">Dernier échange : ' + U.esc(String(dernier.text || '').slice(0, 110)) + '</span>' : '') +
            '<label class="sr-only" for="bienetre-message">Votre message à l’équipe</label>' +
            '<textarea class="textarea" id="bienetre-message" rows="2" maxlength="2000" placeholder="Dites-nous ce qui se passe, avec vos mots…"></textarea>' +
            '<div class="bienetre__send">' +
            '<span>Privé entre vous et l’équipe · Démonstration : enregistré sur cet appareil, pas transmis à une équipe réelle.</span>' +
            ui.btn({ label: 'Envoyer mon message', variant: 'primary', size: 'sm', act: 'bienetre-envoyer', icon: 'send' }) +
            '</div><a class="bienetre__link" href="#/app/team">Voir toute la conversation →</a></div>' +
            '</div></section>';
        })() +

        /* Le coin bien-être remplace l’ancien bandeau de réassurance redondant. */
        '<div class="kpis mt-20">' + kpis.map((k) => ui.kpi(k)).join('') + '</div>' +


        /* Progression du profil : une ligne, pas une carte */
        '<div class="progressline reveal">' +
        '<span class="progressline__label">' + icon('user', 15) + 'Complétion de votre profil</span>' +
        '<span class="progressline__track"><i style="width:' + comp.percent + '%"></i></span>' +
        '<b class="tnum">' + comp.percent + ' %</b>' +
        (comp.missing.length ? ui.fold({ label: 'Ce qu’il reste à compléter', hint: comp.missing.length + ' élément(s)', bare: true,
          html: '<ul class="stack gap-8">' + comp.missing.slice(0, 4).map((m) => '<li class="row gap-8 small muted" style="align-items:flex-start"><span>' + icon('alert', 14) + '</span>' + U.esc(m) + '</li>').join('') + '</ul>' }) : '') +
        ui.btn({ label: 'Compléter', variant: 'soft', size: 'xs', href: '#/app/profile' }) +
        '</div>' +
        '<div class="dash-grid mt-20">' +

        /* Demandes reçues */
        '<section class="panel reveal">' +
        '<div class="panel__head"><h3>' + icon('send', 16) + 'Demandes reçues</h3>' +
        '<a class="small strong" href="#/app/requests" style="color:var(--green-700)">Tout voir</a></div>' +
        (box.received.length
          ? '<div class="panel__list">' + box.received.slice(0, 3).map((r) => panelRow({
            href: '#/app/requests', avatar: true, profile: r.fromProfile,
            title: r.fromProfile.name, text: SEVE.flows.roleLabel(r.fromProfile) + ' · ' + r.fromProfile.city,
            meta: U.fmtRelative(r.created),
            badge: r.status === 'pending' ? 'en attente' : r.status === 'accepted' ? 'acceptée' : r.status === 'declined' ? 'refusée' : 'archivée',
            badgeVariant: r.status === 'pending' ? 'pending' : r.status === 'accepted' ? 'accepted' : r.status === 'declined' ? 'declined' : 'archived'
          })).join('') + '</div>'
          : ui.empty({ icon: 'send', title: 'Aucune demande reçue pour l’instant', text: 'Complétez votre profil et publiez vos critères : les demandes arrivent plus vite quand les attentes sont claires.' })) +
        '</section>' +

        /* Conversations récentes */
        '<section class="panel reveal">' +
        '<div class="panel__head"><h3>' + icon('message', 16) + 'Conversations récentes</h3>' +
        '<a class="small strong" href="#/app/messages" style="color:var(--green-700)">Messagerie</a></div>' +
        (convs.length
          ? '<div class="panel__list">' + convs.map((c) => panelRow({
            href: '#/app/messages/' + c.id, avatar: false, icon: 'message',
            title: c.name, text: (c.last.from === 'me' ? 'Vous : ' : '') + c.last.text,
            meta: U.fmtRelative(c.last.at), badge: c.unread ? c.unread + ' non lu(s)' : null, badgeVariant: 'accepted'
          })).join('') + '</div>'
          : ui.empty({ icon: 'message', title: 'Pas encore de conversation', text: 'Une demande acceptée ouvre automatiquement une conversation ici.' })) +
        '</section>' +

        /* Recommandations */
        '<section class="panel reveal">' +
        '<div class="panel__head"><h3>' + icon('sparkles', 16) + 'Recommandations pour vous</h3>' +
        '<a class="small strong" href="#/app/matching" style="color:var(--green-700)">Voir tout</a></div>' +
        '<div class="panel__body stack gap-12">' +
        recs.slice(0, 2).map((e) => '<div class="row gap-12">' + ui.avatar(Object.assign({ square: e.profile.role === 'manager' }, e.profile), 'sm') +
          '<div class="grow" style="min-width:0"><b style="font-size:13.8px;display:block">' + U.esc(e.profile.name) + '</b>' +
          '<span class="small muted">' + U.esc((e.reasons || [])[0] || '') + '</span></div>' +
          ui.ring(e.score, { size: 42, stroke: 4 }) +
          ui.btn({ label: 'Voir', variant: 'outline', size: 'xs', href: '#/profiles/' + e.profile.id }) + '</div>').join('') +
        '<a class="tiny muted strong" href="#/app/matching" style="color:var(--green-700)">Comment est calculé le score ?</a>' +
        '</div></section>' +

        /* Nouveaux profils / aide */
        '<section class="panel reveal">' +
        '<div class="panel__head"><h3>' + icon('userPlus', 16) + (isManager ? 'Nouveaux profils' : 'Managers récemment vérifiés') + '</h3></div>' +
        '<div class="panel__list">' + newProfiles.map((p) => panelRow({
          href: '#/profiles/' + p.id, avatar: true, profile: p, title: p.name,
          text: (p.role === 'manager' ? p.kind : T.labels([(p.specialties || [])[0]])[0] || '') + ' · ' + p.city,
          meta: p.verified ? 'vérifié' : 'en vérification'
        })).join('') + '</div></section>' +

        '</div>' +
        '<div class="dash-grid dash-grid--2 mt-20">' +
        (isManager ? rosterPanel() : helpPanel()) +
        '</div>'
      );
      if (isManager) return ancienTableau;
      const p = store.care(me.id);
      return '<div class="creator-new"><section class="creator-new__hero"><div><span class="refuge-kicker">Votre espace, à votre rythme</span>' +
        '<h1>Bonjour ' + U.esc(me.name) + '<span>.</span></h1><p>Tout ce qui compte pour vous, au même endroit. Commencez par une conversation, une pause, ou un coup d’œil à vos outils.</p>' +
        '<a class="refuge-cta" href="#/app/team">💬 Ouvrir ma conversation</a></div><div class="creator-new__symbol" aria-hidden="true">✿</div></section>' +
        '<div class="creator-new__quick"><a href="#/app/team"><span>💌</span><b>Mon espace d’échange</b><small>Un chemin simple pour écrire</small></a>' +
        '<a href="#/app/care"><span>🌿</span><b>Mon coin détente</b><small>' + (p.pause ? 'Pause activée sur cet appareil' : 'Faire une pause quand je veux') + '</small></a>' +
        '<a href="#/app/requests"><span>✨</span><b>Mes demandes</b><small>' + box.received.length + ' demande(s) dans cette maquette</small></a>' +
        '<a href="#/app/of"><span>🧭</span><b>Mes outils</b><small>Suivi des relevés et paramètres</small></a></div>' +
        '<div class="creator-new__note"><b>Un tableau de bord plus calme.</b> Les chiffres, recommandations et profils historiques de la maquette sont rangés ci-dessous. Le service de mise en relation réelle reste fermé pendant la préparation.</div>' +
        '<details class="creator-new__archive"><summary>Afficher le tableau détaillé de démonstration</summary>' + ancienTableau + '</details></div>';
    }
  };

  function rosterPanel() {
    const me = store.me();
    const accepted = store.requests({ to: me.id, status: 'accepted' });
    return '<section class="panel reveal"><div class="panel__head"><h3>' + icon('users', 16) + 'Mes créateurs</h3>' +
      '<a class="small strong" href="#/app/roster" style="color:var(--green-700)">Gérer</a></div>' +
      (accepted.length
        ? '<div class="panel__list">' + accepted.slice(0, 4).map((r) => panelRow({
          href: '#/app/roster', avatar: true, profile: r.fromProfile, title: r.fromProfile.name,
          text: T.labels((r.fromProfile.specialties || []).slice(0, 2)).join(' · '),
          meta: U.fmtK(r.fromProfile.subs || 0) + ' abonnés'
        })).join('') + '</div>'
        : ui.empty({ icon: 'users', title: 'Aucun créateur dans votre portefeuille', text: 'Les collaborations acceptées apparaissent ici, avec leur statut et le suivi des échanges.' })) +
      '</section>';
  }

  function helpPanel() {
    const me = store.me();
    const apps = store.applications({ user: me.id });
    return '<section class="panel reveal"><div class="panel__head"><h3>' + icon('headset', 16) + 'Accompagnement de l’équipe</h3>' +
      '<a class="small strong" href="#/app/help" style="color:var(--green-700)">Détail</a></div>' +
      (apps.length
        ? '<div class="panel__body stack gap-12">' + apps.slice(0, 2).map((a) =>
          '<div><div class="between"><b class="small">' + U.esc(store.APPLI_LABELS[a.status] || a.status) + '</b>' +
          '<span class="tiny muted">' + U.fmtRelative(a.created) + '</span></div>' +
          '<p class="small muted mt-4 clamp-2">' + U.esc(a.need) + '</p></div>').join('') + '</div>'
        : '<div class="panel__body"><p class="small muted">Vous n’avez pas encore demandé l’aide de l’équipe. C’est gratuit et sans engagement : nous présélectionnons des profils selon vos critères.</p>' +
          '<div class="mt-12">' + ui.btn({ label: 'Demander une présélection', variant: 'outline', size: 'sm', act: 'ask-team' }) + '</div></div>') +
      '</section>';
  }

  /* ================================================================== */
  /* RECHERCHE (espace connecté)                                         */
  /* ================================================================== */
  SEVE.views.appDiscover = {
    title: 'Rechercher',
    render(ctx) {
      const me = store.me();
      const isManager = me.role === 'manager';
      const target = isManager ? 'creator' : 'manager';
      const v = ctx.query;
      const list = store.search({
        q: v.q, type: target, region: v.region, city: v.city, specialty: v.specialty,
        exp: v.exp, size: v.size, availability: v.availability, language: v.language, sort: v.sort
      });
      const limit = Number(v.limit || 9);
      const shown = list.slice(0, limit);

      return page({
        title: isManager ? 'Rechercher des créateurs' : 'Rechercher un manager',
        subtitle: isManager
          ? 'Filtrez par réseau, expérience, langues et disponibilité. Les scores affichés comparent vos critères à ceux des profils.'
          : 'Filtrez par structure, spécialités, portefeuille et disponibilité. Comparez avant de contacter.',
        actions: ui.btn({ label: 'Recommandations', variant: 'outline', href: '#/app/matching', icon: 'sparkles' })
      },
        '<div class="filterbar reveal" data-filters>' +
        '<div class="toolbar">' + C.searchBar({ value: v.q || '', placeholder: isManager ? 'Rechercher une créatrice, une ville, une spécialité…' : 'Rechercher un manager, une agence, une ville…' }) +
        ui.btn({ label: 'Aide au matching', variant: 'soft', act: 'ask-team', icon: 'headset' }) + '</div>' +
        '<div class="mt-16">' + C.filterBar({ values: v, fields: ['region', 'city', 'specialty', 'exp', 'size', 'availability', 'language', 'sort'] }) + '</div>' +
        '</div>' +
        '<div class="grid grid--cards mt-24">' +
        (shown.length ? shown.map((p) => {
          const s = store.scoreFor(me, p);
          return C.profileCard(p, { score: s.score, why: s.reasons });
        }).join('')
          : ui.empty({
            icon: 'search', title: 'Aucun profil ne correspond', text: 'Essayez de retirer un filtre ou d’élargir la zone géographique.',
            action: ui.btn({ label: 'Demander une présélection à l’équipe', variant: 'primary', act: 'ask-team' })
          })) +
        '</div>' +
        (list.length > shown.length ? '<div class="center mt-32">' + ui.btn({
          label: 'Afficher plus de profils', variant: 'outline', act: 'load-more-app', data: { limit: limit + 9 }
        }) + '</div>' : '') +
        '<div class="mt-32">' + C.scoreLegend() + '</div>'
      );
    },
    mount(ctx) {
      const base = SEVE.router.current() ? SEVE.router.current().path : '/app/discover';
      C.bindFilters(ctx.root, '/app/discover');
      SEVE.actions['load-more-app'] = (el) => {
        const values = Object.assign({}, ctx.query, { limit: el.getAttribute('data-limit') });
        SEVE.router.navigate('/app/discover' + U.query(values));
      };
    }
  };

  /* ================================================================== */
  /* RECOMMANDATIONS                                                     */
  /* ================================================================== */
  SEVE.views.matching = {
    title: 'Recommandations',
    render(ctx) {
      const me = store.me();
      const isManager = me.role === 'manager';
      const target = isManager ? 'creator' : 'manager';
      const prefs = {
        specialties: ctx.query.spec ? [ctx.query.spec] : null,
        region: ctx.query.region && ctx.query.region !== 'all' ? ctx.query.region : null,
        availability: ctx.query.availability && ctx.query.availability !== 'all' ? ctx.query.availability : null,
        collab: ctx.query.collab || null
      };
      let ranked = store.recommendations(me, { role: target, prefs, limit: 12 });
      if (prefs.availability) ranked = ranked.filter((e) => e.profile.availability === prefs.availability);
      const strong = ranked.filter((e) => e.score >= 75);

      return page({
        title: 'Recommandations',
        subtitle: 'Nous comparons vos critères déclarés à ceux des profils. Les arguments sont expliqués, les points de vigilance aussi.',
        actions: ui.btn({ label: 'Ajuster mes critères', variant: 'outline', href: '#/app/profile', icon: 'sliders' })
      },
        '<div class="matchbanner reveal">' + icon('sparkles', 20) +
        '<div class="grow"><b style="font-size:15.5px">Nous pensons que ces profils pourraient vous correspondre.</b>' +
        '<p class="small muted mt-4">' + strong.length + ' profil(s) proches de vos critères. Un repère pour prioriser, jamais une garantie de résultat.</p></div>' +
        '<div class="row gap-10">' + ui.btn({ label: 'Revoir la méthodologie', variant: 'outline', size: 'sm', href: '#/how-it-works' }) + '</div></div>' +

        '<div class="filterbar mt-20 reveal" data-filters>' +
        '<div class="filters">' +
        C.filterBar({ values: ctx.query, fields: ['specialty', 'region', 'availability'] }) +
        '<div class="filter"><label class="label" for="f-collab">Forme de collaboration</label>' +
        C.chipsHTML({ key: 'collab', label: 'Type de collaboration', value: ctx.query.collab || 'all',
          options: [['all', 'Peu importe'], ['split', 'Split sur commissions'], ['retainer', 'Retainer + commission'], ['flat', 'Facturation mensuelle'], ['mission', 'Mission ponctuelle']] }) +
        '</div>' +
        '<div class="mt-16">' + C.activeFilters(ctx.query) + '</div>' +
        '</div>' +

        '<div class="recgrid mt-24">' +
        (ranked.length ? ranked.map((e) => C.recCard(e)).join('')
          : ui.empty({ icon: 'sparkles', title: 'Pas encore de recommandation exploitable', text: 'Précisez vos spécialités, votre zone et vos critères de collaboration dans votre profil : le moteur a besoin de ces éléments pour comparer.', action: ui.btn({ label: 'Compléter mes critères', variant: 'primary', href: '#/app/profile' }) })) +
        '</div>' +
        '<div class="mt-32">' + C.scoreLegend() + '</div>'
      );
    },
    mount(ctx) { C.bindFilters(ctx.root, '/app/matching'); }
  };

  /* ================================================================== */
  /* DEMANDES                                                            */
  /* ================================================================== */
  SEVE.views.requests = {
    title: 'Mes demandes',
    render(ctx) {
      const me = store.me();
      const tab = ctx.query.tab || 'received';
      const box = store.requestBox(me.id);
      const tabs = [
        { id: 'received', label: 'Reçues', list: box.received },
        { id: 'sent', label: 'Envoyées', list: box.sent },
        { id: 'accepted', label: 'Acceptées', list: box.all.filter((r) => r.status === 'accepted') },
        { id: 'archived', label: 'Archivées', list: box.all.filter((r) => r.status === 'archived' || r.status === 'declined') }
      ];
      const current = tabs.filter((t) => t.id === tab)[0] || tabs[0];

      return page({
        title: 'Mes demandes',
        subtitle: 'Chaque demande conserve son historique : message envoyé, réponse, statut. Rien ne disparaît sans votre accord.',
        actions: ui.btn({ label: 'Trouver de nouveaux profils', variant: 'primary', href: '#/app/discover', icon: 'search' })
      },
        '<div class="tabs">' + tabs.map((t) =>
          '<button class="tab' + (t.id === current.id ? ' is-active' : '') + '" data-act="req-tab" data-tab="' + t.id + '">' +
          t.label + '<span class="tab__count">' + t.list.length + '</span></button>').join('') + '</div>' +
        '<div class="stack gap-12 mt-20">' +
        (current.list.length ? current.list.map((r) => C.requestRow(r, {
          side: current.id === 'received' ? 'received' : 'sent'
        })).join('')
          : ui.empty({
            icon: 'send', title: 'Aucune demande dans cet onglet',
            text: current.id === 'received'
              ? 'Les demandes que vous recevez apparaissent ici, avec le profil, le message et le statut.'
              : 'Envoyez une demande depuis une fiche profil ou une recommandation : elle apparaîtra ici.'
          })) +
        '</div>' +
        '<div class="card card--pad mt-24 card--soft">' +
        '<div class="between" style="flex-wrap:wrap;gap:16px"><div style="max-width:58ch">' +
        '<h3>Vous ne recevez pas assez de demandes ?</h3>' +
        '<p class="small muted mt-8">Trois leviers : complétez votre portfolio, précisez vos critères de collaboration, et publiez vos résultats réels plutôt que des promesses. Les profils complets sont mis en avant dans les recommandations.</p></div>' +
        ui.btn({ label: 'Améliorer mon profil', variant: 'outline', href: '#/app/profile' }) + '</div></div>'
      );
    },
    mount(ctx) {
      ctx.root.querySelectorAll('[data-act="req-tab"]').forEach((b) => b.addEventListener('click', () => {
        SEVE.router.navigate('/app/requests?tab=' + b.getAttribute('data-tab'));
      }));
    }
  };

  /* ================================================================== */
  /* MESSAGERIE                                                          */
  /* ================================================================== */
  SEVE.views.messages = {
    title: 'Messages',
    render(ctx) {
      const me = store.me();
      const isManager = me.role === 'manager';
      const toutes = store.conversations({ demo: isManager ? 'manager' : 'creator' });
      /* Triage en un geste : « Non lus » et « À répondre » avant tout le reste. */
      const tri = ctx.query.f || 'tous';
      const convs = tri === 'nonlus' ? toutes.filter((c) => c.unread > 0)
        : tri === 'arepondre' ? toutes.filter((c) => c.last && c.last.from !== 'me')
        : toutes;
      const nonLus = toutes.filter((c) => c.unread > 0).length;
      const aRepondre = toutes.filter((c) => c.last && c.last.from !== 'me').length;
      const activeId = ctx.params.id || (convs[0] ? convs[0].id : null);
      const active = activeId ? store.conversation(activeId) : null;
      if (active) store.markRead(active.id);
      const other = active ? store.get(active.with) : null;

      const listHTML = convs.map((c) => {
        const cOther = store.get(c.with);
        return '<button class="conv' + (active && c.id === active.id ? ' is-active' : '') + (c.unread ? ' is-unread' : '') + '" data-act="open-conv" data-id="' + c.id + '">' +
          ui.avatar(cOther || { name: c.name, id: c.with }, 'sm') +
          '<span class="conv__body"><span class="conv__top"><span class="conv__name">' + U.esc(c.name) + '</span>' +
          '<span class="conv__time">' + U.fmtRelative(c.last.at) + '</span></span>' +
          '<span class="conv__last">' + (c.last.from === 'me' ? 'Vous : ' : '') + U.esc(c.last.text) + '</span></span>' +
          (c.unread ? '<span class="conv__badge">' + c.unread + '</span>' : '') + '</button>';
      }).join('');

      return '<div class="page-head" style="margin-bottom:16px"><div><h1>Messages</h1>' +
        '<p>Les échanges restent attachés à votre historique. Aucun numéro de téléphone, aucune adresse : tout passe par ici.</p></div>' +
        '<div class="row gap-10">' +
        ui.btn({ label: isManager ? 'Contacter une créatrice' : 'Contacter un manager', variant: 'outline', href: '#/app/discover', icon: 'search' }) +
        '</div></div>' +

        /* Tri en pastilles : ce qu'on veut voir en un clic, sans menu */
        '<div class="chips mb-12">' +
        '<span class="chips__label">Voir</span><div class="chips__row">' + [
          { id: 'tous', label: 'Toutes', n: toutes.length },
          { id: 'nonlus', label: 'Non lues', n: nonLus },
          { id: 'arepondre', label: 'À répondre', n: aRepondre }
        ].map((t) => '<a class="chip chip--choice' + (tri === t.id ? ' is-on' : '') + '" href="#/app/messages?f=' + t.id + '">' +
          U.esc(t.label) + (t.n ? ' <span class="tnum">' + t.n + '</span>' : '') + '</a>').join('') +
        '</div></div>' +

        '<div class="chat' + (ctx.params.id ? ' is-thread' : '') + '">' +
        '<div class="chat__side">' +
        '<div class="chat__sidehead"><div class="search search--sm">' + icon('search', 16) +
        '<input class="input" id="conv-search" type="search" placeholder="Rechercher dans les conversations" aria-label="Rechercher dans les conversations"></div></div>' +
        '<div class="chat__list" id="conv-list">' + (listHTML || ui.empty({
          icon: 'message',
          title: tri === 'tous' ? 'Aucune conversation' : (tri === 'nonlus' ? 'Tout est lu' : 'Rien à répondre'),
          text: tri === 'tous' ? 'Vos échanges apparaîtront ici.'
            : (tri === 'nonlus' ? 'Aucun message non lu : vous êtes à jour, rien ne vous attend.'
                                : 'Vous avez répondu à tout le monde. C’est le bon moment pour souffler.')
        })) + '</div>' +
        '</div>' +

        (active && other ? '<div class="chat__thread">' + threadHTML(active, other, me) + '</div>' :
          '<div class="chat__thread">' + (ui.empty({
            icon: 'message', title: 'Sélectionnez une conversation',
            text: 'Choisissez un échange à gauche, ou contactez un nouveau profil pour démarrer une discussion.'
          })) + '</div>') +
        '</div>';
    },
    mount(ctx) {
      const me = store.me();
      /* Recherche locale dans les conversations */
      const search = ctx.root.querySelector('#conv-search');
      if (search) {
        search.addEventListener('input', U.debounce(() => {
          const q = search.value.trim().toLowerCase();
          ctx.root.querySelectorAll('.conv').forEach((b) => {
            const name = b.querySelector('.conv__name').textContent.toLowerCase();
            const last = b.querySelector('.conv__last').textContent.toLowerCase();
            b.style.display = !q || name.indexOf(q) >= 0 || last.indexOf(q) >= 0 ? '' : 'none';
          });
        }, 140));
      }

      bindComposer(ctx);
      const body = ctx.root.querySelector('.chat__body');
      if (body) body.scrollTop = body.scrollHeight;
    }
  };

  /** Branche le composeur de la conversation active (appelé après chaque rendu du fil). */
  function bindComposer(ctx) {
    const ta = ctx.root.querySelector('#msg-input');
    const sendBtn = ctx.root.querySelector('#msg-send');
    const convId = ctx.params.id;
    if (!ta || !sendBtn || !convId) return;
    const submit = () => {
      const text = ta.value.trim();
      if (!text) return;
      store.sendMessage(convId, text, 'me');
      ta.value = '';
      ta.style.height = 'auto';
      redrawThread(ctx, convId);
    };
    sendBtn.addEventListener('click', submit);
    ta.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); submit(); }
    });
    ta.addEventListener('input', () => {
      ta.style.height = 'auto';
      ta.style.height = Math.min(140, ta.scrollHeight) + 'px';
    });
  }

  function redrawThread(ctx, convId) {
    const conv = store.conversation(convId);
    if (!conv) return;
    const other = store.get(conv.with);
    const me = store.me();
    const container = ctx.root.querySelector('.chat__thread');
    if (!container) return;
    container.outerHTML = '<div class="chat__thread">' + threadHTML(conv, other, me, true) + '</div>';
    bindComposer(ctx);
    const body = ctx.root.querySelector('.chat__body');
    if (body) body.scrollTop = body.scrollHeight;
    const ta = ctx.root.querySelector('#msg-input');
    if (ta) ta.focus();
  }

  function threadHTML(conv, other, me, skipHeader) {
    let lastDay = null;
    const msgs = conv.messages.map((m) => {
      const day = U.fmtDayLabel(m.at);
      const sep = day !== lastDay ? '<span class="chat__day">' + U.esc(day) + '</span>' : '';
      lastDay = day;
      const mine = m.from === 'me';
      return sep + '<div class="msg ' + (mine ? 'msg--me' : 'msg--them') + '">' +
        '<div class="msg__bubble">' + U.esc(m.text) + '</div>' +
        '<span class="msg__time">' + U.fmtTime(m.at) + (mine ? ' · ' + (conv.unread ? 'envoyé' : 'lu') : '') + '</span></div>';
    }).join('');

    return '<div class="chat__head">' +
      (skipHeader ? '' : '') +
      '<button class="btn btn--ghost btn--icon btn--sm" data-act="back-to-list" aria-label="Retour aux conversations">' + icon('arrowLeft', 17) + '</button>' +
      ui.avatar(Object.assign({ square: other.role === 'manager' }, other), 'sm') +
      '<div style="min-width:0;flex:1"><div class="row gap-8"><b style="font-size:14.5px">' + U.esc(other.name) + '</b>' +
      (other.verified ? ui.verified({ compact: true }) : '') + '</div>' +
      '<span class="small muted">' + U.esc(SEVE.flows.roleLabel(other)) + ' · ' + U.esc(other.city) + ' · ' + U.esc((other.metrics && other.metrics.response) || '') + '</span></div>' +
      '<div class="row gap-8">' + ui.btn({ label: 'Voir le profil', variant: 'outline', size: 'sm', href: '#/profiles/' + other.id }) +
      '<div class="pmenu" id="chat-more"><button class="btn btn--ghost btn--icon btn--sm" data-act="toggle-chat-more" aria-label="Options">' + icon('more', 17) + '</button><div class="pmenu__slot"></div></div>' +
      '</div></div>' +
      '<div class="chat__body">' + (msgs || '<p class="small muted center">Aucun message pour le moment. Présentez-vous en une phrase claire.</p>') + '</div>' +
      '<div class="chat__composer">' +
      '<textarea class="textarea" id="msg-input" rows="1" placeholder="Écrivez votre message… (Entrée pour envoyer, Maj+Entrée pour un retour à la ligne)"></textarea>' +
      '<button class="btn btn--primary" id="msg-send" aria-label="Envoyer">' + icon('send', 17) + '</button>' +
      '</div>' +
      '<p class="chat__hint">' + icon('shield', 13) +
      'Rappel : aucun paiement entre membres, aucun échange de contenu explicite. Signalez tout comportement déviant.</p>';
  }

  /* Actions messagerie ------------------------------------------------ */
  SEVE.act('open-conv', function (el) { SEVE.router.navigate('/app/messages/' + el.getAttribute('data-id')); });
  SEVE.act('back-to-list', function () { SEVE.router.navigate('/app/messages'); });
  SEVE.act('toggle-chat-more', function (el) {
    const slot = el.parentElement.querySelector('.pmenu__slot');
    if (slot.firstElementChild) { slot.innerHTML = ''; return; }
    const conv = store.conversation(findActiveConvId() || '');
    const otherId = conv ? conv.with : null;
    if (!otherId) return;
    document.querySelectorAll('.pmenu__panel').forEach((n) => n.remove());
    slot.innerHTML = '<div class="pmenu__panel">' +
      '<button class="pmenu__item" data-act="gotohref" data-href="#/profiles/' + otherId + '">' + icon('user', 17) + '<span>Voir le profil complet</span></button>' +
      '<button class="pmenu__item" data-act="report-profile" data-id="' + otherId + '">' + icon('flag', 17) + '<span>Signaler un message</span></button>' +
      '<div class="pmenu__sep"></div>' +
      '<button class="pmenu__item pmenu__item--danger" data-act="block-profile" data-id="' + otherId + '">' + icon('ban', 17) + '<span>' + (store.isBlocked(otherId) ? 'Débloquer' : 'Bloquer') + ' ce profil</span></button>' +
      '</div>';
  });

  function findActiveConvId() {
    const el = document.querySelector('.conv.is-active');
    return el ? el.getAttribute('data-id') : null;
  }

  /* ================================================================== */
  /* MON PROFIL (édition)                                                */
  /* ================================================================== */
  SEVE.views.appProfile = {
    title: 'Mon profil',
    render(ctx) {
      const me = store.me();
      const isManager = me.role === 'manager';
      const comp = store.completion(me);
      const tab = ctx.query.tab || 'public';

      const tabs = [
        ['public', 'Profil public'],
        ['portfolio', 'Portfolio'],
        ['experience', 'Expérience'],
        ['looking', 'Critères de collaboration'],
        ['pro', 'Informations professionnelles']
      ];

      return page({
        title: 'Mon profil',
        subtitle: 'Ce que voient les autres membres, et les informations que vous gardez privées.',
        actions: ui.btn({ label: 'Voir mon profil public', variant: 'outline', href: '#/profiles/' + me.id, icon: 'eye' }) +
          ui.btn({ label: 'Paramètres', variant: 'ghost', href: '#/app/settings', icon: 'settings' })
      },
        '<div class="card card--pad reveal">' +
        '<div class="row gap-20" style="flex-wrap:wrap">' + ui.ring(comp.percent, { size: 72, caption: 'complété' }) +
        '<div class="grow" style="min-width:220px"><b style="font-size:15px">' + (comp.percent >= 80 ? 'Votre profil est complet' : 'Complétez ces éléments pour être mieux recommandé') + '</b>' +
        (comp.missing.length ? '<div class="chips mt-12">' + comp.missing.map((m) => '<span class="chip chip--sm chip--warn">' + icon('alert', 12) + U.esc(m) + '</span>').join('') + '</div>'
          : '<p class="small muted mt-8">Tout est renseigné. Les modifications restent possibles à tout moment.</p>') + '</div>' +
        '<div class="row gap-10">' + ui.btn({ label: 'Aperçu public', variant: 'outline', size: 'sm', href: '#/profiles/' + me.id }) + '</div>' +
        '</div></div>' +

        '<div class="tabs mt-24">' + tabs.map((t) =>
          '<button class="tab' + (tab === t[0] ? ' is-active' : '') + '" data-act="prof-tab" data-tab="' + t[0] + '">' + t[1] + '</button>').join('') +
        '</div>' +

        '<div class="tabpanel" id="prof-panel">' + panelFor(tab, me) + '</div>'
      );
    },
    mount(ctx) {
      ctx.root.querySelectorAll('[data-act="prof-tab"]').forEach((b) => b.addEventListener('click', () => {
        SEVE.router.navigate('/app/profile?tab=' + b.getAttribute('data-tab'));
      }));
      wireProfileForm(ctx, ctx.root);
    }
  };

  function panelFor(tab, me) {
    const isManager = me.role === 'manager';
    if (tab === 'portfolio') {
      return '<section class="card card--pad"><h3>Portfolio</h3>' +
        '<p class="small muted mt-8">Décrivez vos références : jamais de contenu explicite ni de lien vers un contenu explicite. Les managers lisent surtout les résultats et les formats.</p>' +
        '<div id="portfolio-list" class="stack gap-12 mt-20">' + (me.portfolio || []).map((it, i) => portfolioRow(it, i)).join('') + '</div>' +
        ui.btn({ label: 'Ajouter un élément', variant: 'outline', size: 'sm', act: 'add-portfolio' }) +
        '<div class="row gap-12 mt-20">' + ui.btn({ label: 'Enregistrer le portfolio', variant: 'primary', act: 'save-portfolio' }) + '</div>' +
        '</section>';
    }
    if (tab === 'experience') {
      return '<section class="card card--pad"><h3>Expérience</h3>' +
        '<p class="small muted mt-8">Chronologie claire : période, rôle, structure, résultat concret.</p>' +
        '<div id="timeline-list" class="stack gap-12 mt-20">' + (me.timeline || []).map((t, i) => timelineRow(t, i)).join('') + '</div>' +
        ui.btn({ label: 'Ajouter une expérience', variant: 'outline', size: 'sm', act: 'add-timeline' }) +
        '<div class="row gap-12 mt-20">' + ui.btn({ label: 'Enregistrer l’expérience', variant: 'primary', act: 'save-timeline' }) + '</div>' +
        '</section>';
    }
    if (tab === 'looking') {
      return '<section class="card card--pad"><form id="looking-form" novalidate><h3>Collaborations recherchées</h3>' +
        '<p class="small muted mt-8">Ces critères alimentent directement le score de compatibilité et évitent les demandes hors sujet.</p>' +
        '<div class="formgrid mt-20">' +
        '<div class="field span2"><label class="label" for="lk-title">Ce que vous cherchez <span class="req">*</span></label>' +
        '<input class="input" id="lk-title" required value="' + U.esc((me.looking && me.looking.title) || '') + '" placeholder="Ex. Manager individuel ou petite agence (FR / EN)"></div>' +
        '<div class="field"><label class="label" for="lk-split">Forme de collaboration</label>' +
        '<input class="input" id="lk-split" value="' + U.esc((me.looking && me.looking.split) || '') + '" placeholder="Ex. 20 – 25 % de commission"></div>' +
        '<div class="field"><label class="label" for="lk-collab">Préférence de contrat</label>' +
        '<select class="select" id="lk-collab">' + T.COLLAB.map((c) => '<option value="' + c.id + '">' + U.esc(c.label) + '</option>').join('') + '</select></div>' +
        '<div class="field span2"><label class="label" for="lk-notes">Précisions</label>' +
        '<textarea class="textarea" id="lk-notes" placeholder="Rythme de travail, autonomie attendue, sujets sur lesquels vous ne transigez pas.">' + U.esc((me.looking && me.looking.notes) || '') + '</textarea></div>' +
        '<div class="field span2"><label class="label" for="lk-must">Non négociable (une ligne par point)</label>' +
        '<textarea class="textarea" id="lk-must" placeholder="Francophone&#10;Reporting mensuel&#10;Aucun frais d’entrée">' + U.esc(((me.looking && me.looking.must) || []).join('\n')) + '</textarea></div>' +
        '</div>' +
        '<div class="row gap-12 mt-20">' + ui.btn({ label: 'Enregistrer mes critères', variant: 'primary', act: 'save-looking' }) + '</div>' +
        '</form></section>';
    }
    if (tab === 'pro') {
      const pro = me.pro || {};
      return '<section class="card card--pad"><form id="pro-form" novalidate><h3>Informations professionnelles</h3>' +
        '<p class="small muted mt-8">Visibles sur votre profil public. Restez factuel : ce sont ces éléments qui rassurent en premier.</p>' +
        '<div class="formgrid mt-20">' +
        '<div class="field"><label class="label" for="pr-statut">Statut professionnel</label>' +
        '<input class="input" id="pr-statut" value="' + U.esc(pro.statut || '') + '" placeholder="Ex. Photographe attitré, SARL enregistrée…"></div>' +
        '<div class="field"><label class="label" for="pr-tarif">' + (isManager ? 'Commission annoncée' : 'Tarif / commission visée') + '</label>' +
        '<input class="input" id="pr-tarif" value="' + U.esc(pro.tarif || '') + '" placeholder="Ex. 20 – 25 % de commission"></div>' +
        '<div class="field"><label class="label" for="pr-outils">Outils utilisés</label>' +
        '<input class="input" id="pr-outils" value="' + U.esc(pro.outils || '') + '" placeholder="Notion, Lightroom, Slack…"></div>' +
        '<div class="field"><label class="label" for="pr-dispo">Disponibilité hebdomadaire</label>' +
        '<input class="input" id="pr-dispo" value="' + U.esc(pro.dispo || '') + '" placeholder="Ex. 40 h / semaine"></div>' +
        '<div class="field"><label class="label" for="pr-paiement">Modalités de paiement déclarées</label>' +
        '<input class="input" id="pr-paiement" value="' + U.esc(pro.paiement || '') + '" placeholder="Virement SEPA, facturation mensuelle…"></div>' +
        (isManager
          ? '<div class="field"><label class="label" for="pr-creators">Créateurs accompagnés</label>' +
            '<input class="input" id="pr-creators" type="number" min="0" value="' + U.esc(me.creatorsCount || 0) + '"></div>'
          : '<div class="field"><label class="label" for="pr-subs">Abonnés déclarés (cumulés)</label>' +
            '<input class="input" id="pr-subs" type="number" min="0" value="' + U.esc(me.subs || 0) + '"></div>') +
        '</div>' +
        '<div class="banner banner--soft mt-20">' + icon('info', 18) + '<div>Ces montants sont déclaratifs. Nous ne demandons aucun justificatif de revenus : la plateforme n’intervient jamais dans vos paiements.</div></div>' +
        '<div class="row gap-12 mt-20">' + ui.btn({ label: 'Enregistrer', variant: 'primary', act: 'save-pro' }) + '</div>' +
        '</form></section>';
    }

    /* Onglet par défaut : profil public */
    return '<section class="card card--pad"><form id="public-form" novalidate>' +
      '<h3>Profil public</h3>' +
      '<p class="small muted mt-8">Ces informations sont visibles par les membres connectés. Votre email et vos justificatifs ne le sont jamais.</p>' +
      '<div class="formgrid mt-20">' +
      '<div class="field"><label class="label" for="pf-name">' + (isManager ? 'Nom public / agence' : 'Nom public') + ' <span class="req">*</span></label>' +
      '<input class="input" id="pf-name" required value="' + U.esc(me.name) + '"></div>' +
      '<div class="field"><label class="label" for="pf-av">Disponibilité</label>' +
      '<select class="select" id="pf-av">' + T.AVAILABILITY.map((a) => '<option value="' + a.id + '"' + (a.id === me.availability ? ' selected' : '') + '>' + U.esc(a.label) + '</option>').join('') + '</select></div>' +
      '<div class="field"><label class="label" for="pf-city">Ville <span class="req">*</span></label>' +
      '<input class="input" id="pf-city" required value="' + U.esc(me.city) + '"></div>' +
      '<div class="field"><label class="label" for="pf-country">Pays <span class="req">*</span></label>' +
      '<input class="input" id="pf-country" required value="' + U.esc(me.country) + '"></div>' +
      '<div class="field"><label class="label" for="pf-exp">Expérience</label>' +
      '<select class="select" id="pf-exp">' + T.EXPERIENCE.map((e) => '<option value="' + e.id + '"' + (e.id === me.exp ? ' selected' : '') + '>' + U.esc(e.label) + '</option>').join('') + '</select></div>' +
      '<div class="field"><label class="label" for="pf-' + (isManager ? 'team' : 'network') + '">' + (isManager ? 'Taille de l’équipe' : 'Taille du réseau') + '</label>' +
      '<select class="select" id="pf-' + (isManager ? 'team' : 'network') + '">' +
      (isManager ? T.TEAMSIZE.map((t) => '<option value="' + t.id + '"' + (t.id === me.team ? ' selected' : '') + '>' + U.esc(t.label) + '</option>').join('')
        : T.NETWORK.map((n) => '<option value="' + n.id + '"' + (n.id === me.network ? ' selected' : '') + '>' + U.esc(n.label) + '</option>').join('')) +
      '</select></div>' +
      '<div class="field span2"><label class="label">Spécialités <span class="req">*</span></label>' +
      '<div class="specialty-grid">' + Object.keys(groupBy(T.SPECIALTIES)).map((g) => '<div><span class="specialty-grid__group">' + U.esc(g) + '</span>' +
        groupBy(T.SPECIALTIES)[g].map((s) => '<label class="check check--tight"><input type="checkbox" name="specialties" value="' + s.id + '"' + ((me.specialties || []).indexOf(s.id) >= 0 ? ' checked' : '') + '><span class="small">' + U.esc(s.label) + '</span></label>').join('') + '</div>').join('') + '</div></div>' +
      '<div class="field span2"><label class="label" for="pf-bio">Présentation <span class="req">*</span></label>' +
      '<textarea class="textarea" id="pf-bio" data-minlen="80" required>' + U.esc(me.bio) + '</textarea>' +
      '<p class="help">Décrivez votre univers, votre rythme, votre audience et ce que vous attendez d’un partenaire.</p></div>' +
      '<div class="field span2"><label class="label" for="pf-lang">Langues de travail</label>' +
      '<select class="select" id="pf-lang" multiple size="4">' + T.LANGUAGES.map((l) => '<option value="' + l + '"' + ((me.languages || []).indexOf(l) >= 0 ? ' selected' : '') + '>' + U.esc(l) + '</option>').join('') + '</select></div>' +
      '<div class="field span2"><label class="label" for="pf-plat">Plateformes et canaux</label>' +
      '<select class="select" id="pf-plat" multiple size="5">' + T.PLATFORMS.map((p) => '<option value="' + p.id + '"' + ((me.platforms || []).indexOf(p.id) >= 0 ? ' selected' : '') + '>' + U.esc(p.label) + '</option>').join('') + '</select></div>' +
      '<div class="field span2"><label class="label" for="pf-goals">Objectifs actuels</label>' +
      '<select class="select" id="pf-goals" multiple size="4">' + (isManager ? T.GOALS_MANAGER : T.GOALS_CREATOR).map((g) => '<option value="' + U.esc(g) + '"' + ((me.goals || []).indexOf(g) >= 0 ? ' selected' : '') + '>' + U.esc(g) + '</option>').join('') + '</select></div>' +
      '</div>' +
      '<div class="row gap-12 mt-24" style="flex-wrap:wrap">' + ui.btn({ label: 'Enregistrer les modifications', variant: 'primary', act: 'save-public' }) +
      ui.btn({ label: 'Annuler', variant: 'ghost', href: '#/app/profile' }) + '</div>' +
      '</form></section>';
  }

  function groupBy(list) {
    const out = {};
    list.forEach((s) => { (out[s.group] = out[s.group] || []).push(s); });
    return out;
  }

  function portfolioRow(it, i) {
    return '<div class="grid" style="grid-template-columns:1.4fr 1fr 1.2fr auto;gap:10px;align-items:center" data-pf="' + i + '">' +
      '<input class="input" data-pf-title value="' + U.esc(it.title || '') + '" placeholder="Titre">' +
      '<input class="input" data-pf-type value="' + U.esc(it.type || '') + '" placeholder="Type">' +
      '<input class="input" data-pf-meta value="' + U.esc(it.meta || '') + '" placeholder="Résultat / volume">' +
      '<button class="btn btn--ghost btn--icon btn--sm" data-act="remove-portfolio" data-i="' + i + '" aria-label="Retirer">' + icon('trash', 16) + '</button>' +
      '</div>';
  }

  function timelineRow(t, i) {
    return '<div class="grid" style="grid-template-columns:1fr 1.4fr 1fr auto;gap:10px;align-items:center" data-tl="' + i + '">' +
      '<input class="input" data-tl-period value="' + U.esc(t.period || '') + '" placeholder="2024 — aujourd’hui">' +
      '<input class="input" data-tl-title value="' + U.esc(t.title || '') + '" placeholder="Rôle">' +
      '<input class="input" data-tl-org value="' + U.esc(t.org || '') + '" placeholder="Structure">' +
      '<button class="btn btn--ghost btn--icon btn--sm" data-act="remove-timeline" data-i="' + i + '" aria-label="Retirer">' + icon('trash', 16) + '</button>' +
      '<input class="input" data-tl-note value="' + U.esc(t.note || '') + '" placeholder="Résultat concret" style="grid-column:1 / -1">' +
      '</div>';
  }

  function wireProfileForm(ctx, root) {
    const me = store.me();

    const addPf = root.querySelector('[data-act="add-portfolio"]');
    if (addPf) addPf.addEventListener('click', () => {
      const list = root.querySelector('#portfolio-list');
      list.appendChild(U.el(portfolioRow({ title: '', type: '', meta: '' }, list.children.length)));
      wireRemove(root);
    });
    const addTl = root.querySelector('[data-act="add-timeline"]');
    if (addTl) addTl.addEventListener('click', () => {
      const list = root.querySelector('#timeline-list');
      list.appendChild(U.el(timelineRow({ period: '', title: '', org: '', note: '' }, list.children.length)));
      wireRemove(root);
    });
    wireRemove(root);

    const savePublic = root.querySelector('[data-act="save-public"]');
    if (savePublic) savePublic.addEventListener('click', () => {
      const form = root.querySelector('#public-form');
      if (!form) return;
      ui.clearErrors(form);
      const specs = Array.from(form.querySelectorAll('input[name="specialties"]:checked')).map((i) => i.value);
      if (!specs.length) { ui.fieldError(form.querySelector('.specialty-grid'), 'Conservez au moins une spécialité.'); return; }
      if (!ui.validate(form)) return;
      ui.loading(savePublic, true, 'Enregistrement…');
      setTimeout(() => {
        store.updateProfile(me.id, {
          name: form.querySelector('#pf-name').value,
          availability: form.querySelector('#pf-av').value,
          city: form.querySelector('#pf-city').value,
          country: form.querySelector('#pf-country').value,
          exp: form.querySelector('#pf-exp').value,
          specialties: specs,
          bio: form.querySelector('#pf-bio').value,
          languages: Array.from(form.querySelector('#pf-lang').selectedOptions).map((o) => o.value),
          platforms: Array.from(form.querySelector('#pf-plat').selectedOptions).map((o) => o.value),
          goals: Array.from(form.querySelector('#pf-goals').selectedOptions).map((o) => o.value),
          network: me.role === 'creator' ? (form.querySelector('#pf-network') || {}).value || me.network : me.network,
          team: me.role === 'manager' ? (form.querySelector('#pf-team') || {}).value || me.team : me.team
        });
        ui.loading(savePublic, false);
        ui.toast('Profil public mis à jour. Les recommandations ont été recalculées.', 'ok');
        SEVE.router.refresh();
      }, 700);
    });

    const saveLooking = root.querySelector('[data-act="save-looking"]');
    if (saveLooking) saveLooking.addEventListener('click', () => {
      const form = root.querySelector('#looking-form');
      if (!ui.validate(form)) return;
      ui.loading(saveLooking, true, 'Enregistrement…');
      setTimeout(() => {
        store.updateProfile(me.id, {
          looking: {
            title: form.querySelector('#lk-title').value,
            split: form.querySelector('#lk-split').value,
            collab: form.querySelector('#lk-collab').value,
            notes: form.querySelector('#lk-notes').value,
            must: form.querySelector('#lk-must').value.split('\n').map((s) => s.trim()).filter(Boolean)
          }
        });
        ui.loading(saveLooking, false);
        ui.toast('Critères de collaboration enregistrés.', 'ok');
        SEVE.router.refresh();
      }, 600);
    });

    const savePro = root.querySelector('[data-act="save-pro"]');
    if (savePro) savePro.addEventListener('click', () => {
      const form = root.querySelector('#pro-form');
      ui.loading(savePro, true, 'Enregistrement…');
      setTimeout(() => {
        const patch = {
          pro: {
            statut: form.querySelector('#pr-statut').value,
            tarif: form.querySelector('#pr-tarif').value,
            outils: form.querySelector('#pr-outils').value,
            dispo: form.querySelector('#pr-dispo').value,
            paiement: form.querySelector('#pr-paiement').value
          }
        };
        if (store.me().role === 'manager') {
          const c = form.querySelector('#pr-creators');
          if (c) patch.creatorsCount = Number(c.value || 0);
        } else {
          const s2 = form.querySelector('#pr-subs');
          if (s2) patch.subs = Number(s2.value || 0);
        }
        store.updateProfile(me.id, patch);
        ui.loading(savePro, false);
        ui.toast('Informations professionnelles enregistrées.', 'ok');
        SEVE.router.refresh();
      }, 600);
    });

    const savePortfolio = root.querySelector('[data-act="save-portfolio"]');
    if (savePortfolio) savePortfolio.addEventListener('click', () => {
      const items = Array.from(root.querySelectorAll('[data-pf]')).map((r) => ({
        title: r.querySelector('[data-pf-title]').value || 'Élément de portfolio',
        type: r.querySelector('[data-pf-type]').value || 'Référence',
        meta: r.querySelector('[data-pf-meta]').value || ''
      })).filter((i) => i.title || i.meta);
      store.updateProfile(me.id, { portfolio: items });
      ui.toast('Portfolio enregistré.', 'ok');
      SEVE.router.refresh();
    });

    const saveTimeline = root.querySelector('[data-act="save-timeline"]');
    if (saveTimeline) saveTimeline.addEventListener('click', () => {
      const items = Array.from(root.querySelectorAll('[data-tl]')).map((r) => ({
        period: r.querySelector('[data-tl-period]').value || '—',
        title: r.querySelector('[data-tl-title]').value || 'Expérience',
        org: r.querySelector('[data-tl-org]').value,
        note: r.querySelector('[data-tl-note]').value
      })).filter((i) => i.title !== 'Expérience' || i.org || i.note);
      store.updateProfile(me.id, { timeline: items });
      ui.toast('Expérience enregistrée.', 'ok');
      SEVE.router.refresh();
    });
  }

  function wireRemove(root) {
    root.querySelectorAll('[data-act="remove-portfolio"]').forEach((b) => {
      if (b.dataset.bound) return;
      b.dataset.bound = '1';
      b.addEventListener('click', () => {
        const list = root.querySelector('#portfolio-list');
        list.removeChild(b.closest('[data-pf]'));
        if (!list.children.length) list.appendChild(U.el(portfolioRow({ title: '', type: '', meta: '' }, 0)));
      });
    });
    root.querySelectorAll('[data-act="remove-timeline"]').forEach((b) => {
      if (b.dataset.bound) return;
      b.dataset.bound = '1';
      b.addEventListener('click', () => {
        const list = root.querySelector('#timeline-list');
        list.removeChild(b.closest('[data-tl]'));
        if (!list.children.length) list.appendChild(U.el(timelineRow({ period: '', title: '', org: '', note: '' }, 0)));
      });
    });
  }

  /* ================================================================== */
  /* MES CRÉATEURS (manager)                                             */
  /* ================================================================== */
  SEVE.views.roster = {
    title: 'Mes créateurs',
    render(ctx) {
      const me = store.me();
      if (me.role !== 'manager') {
        return page({ title: 'Mes créateurs' }, ui.empty({
          title: 'Espace réservé aux managers', text: 'Cette page liste les créateurs avec qui vous avez une collaboration acceptée.',
          action: ui.btn({ label: 'Retour au tableau de bord', variant: 'primary', href: '#/app' })
        }));
      }
      const accepted = store.requests({ to: me.id, status: 'accepted' });
      const pending = store.requests({ to: me.id, status: 'pending' });
      const convs = store.conversations({ demo: 'manager' });

      const rows = accepted.map((r) => {
        const p = r.fromProfile;
        const conv = convs.filter((c) => c.with === p.id)[0];
        return '<tr>' +
          '<td><div class="tcell">' + ui.avatar(p, 'sm') + '<div class="tcell__txt"><b>' + U.esc(p.name) + (p.verified ? ' ' + ui.verified({ compact: true }) : '') + '</b>' +
          '<span>' + U.esc(p.city) + ' · ' + U.fmtK(p.subs || 0) + ' abonnés</span></div></div></td>' +
          '<td>' + C.specChips(p.specialties, 2) + '</td>' +
          '<td>' + ui.status(p.availability, { small: true }) + '</td>' +
          '<td class="muted small">' + (conv ? U.fmtRelative(conv.last.at) : 'Aucun échange') + '</td>' +
          '<td><div class="cell-actions">' +
          (conv ? ui.btn({ label: 'Messages', variant: 'outline', size: 'xs', href: '#/app/messages/' + conv.id }) : '') +
          ui.btn({ label: 'Profil', variant: 'ghost', size: 'xs', href: '#/profiles/' + p.id }) +
          '</div></td></tr>';
      }).join('');

      return page({
        title: 'Mes créateurs',
        subtitle: 'Les collaborations acceptées, leur statut et le dernier échange. Le suivi reste volontairement simple : une ligne, une décision.',
        actions: ui.btn({ label: 'Rechercher des créateurs', variant: 'primary', href: '#/app/discover', icon: 'search' })
      },
        '<div class="kpis">' +
        ui.kpi({ label: 'Créateurs suivis', value: accepted.length, icon: 'users', foot: 'Collaborations acceptées' }) +
        ui.kpi({ label: 'Demandes en attente', value: pending.length, icon: 'send', foot: pending.length ? 'À traiter cette semaine' : 'Aucune urgence' }) +
        ui.kpi({ label: 'Comptes disponibles', value: (me.pro && /(\d+)\s*compte/.exec(me.pro.dispo) || [0, 3])[1] || 3, icon: 'target', foot: 'Capacité déclarée dans votre profil' }) +
        '</div>' +
        (accepted.length
          ? '<div class="table-wrap mt-20"><table class="table"><thead><tr><th>Créateur</th><th>Spécialités</th><th>Disponibilité</th><th>Dernier échange</th><th></th></tr></thead><tbody>' + rows + '</tbody></table></div>'
          : ui.empty({
            icon: 'users', title: 'Aucun créateur dans votre portefeuille',
            text: 'Acceptez une demande ou contactez directement un profil : la collaboration apparaîtra ici automatiquement.',
            action: ui.btn({ label: 'Rechercher des créateurs', variant: 'primary', href: '#/app/discover' })
          })) +
        '<div class="card card--pad mt-24 card--soft"><div class="between" style="flex-wrap:wrap;gap:16px">' +
        '<div style="max-width:58ch"><h3>Besoin de créateurs supplémentaires ?</h3>' +
        '<p class="small muted mt-8">Notre équipe peut rechercher des profils correspondant à vos critères et vous aider à identifier des partenaires potentiels, avec les vérifications déjà effectuées.</p></div>' +
        ui.btn({ label: 'Demander l’aide de l’équipe', variant: 'primary', act: 'ask-team' }) + '</div></div>'
      );
    }
  };

  /* ================================================================== */
  /* PARAMÈTRES                                                          */
  /* ================================================================== */
  SEVE.views.settings = {
    title: 'Paramètres',
    render(ctx) {
      const me = store.me();
      const s = store.getSettings(me.id);
      const blocked = store.blocked().map((id) => store.get(id)).filter(Boolean);
      const user = store.currentUser();
      const tab = ctx.query.tab || 'compte';

      const tabs = [['compte', 'Compte'], ['visibilite', 'Visibilité'], ['notifications', 'Notifications'], ['securite', 'Sécurité & données']];

      return page({
        title: 'Paramètres',
        subtitle: 'Vos préférences, votre visibilité et la gestion de vos données. Tout est modifiable sans passer par notre équipe.',
        actions: ui.btn({ label: 'Voir mon profil public', variant: 'outline', href: '#/profiles/' + me.id, icon: 'eye' })
      },
        '<div class="tabs">' + tabs.map((t) =>
          '<button class="tab' + (tab === t[0] ? ' is-active' : '') + '" data-act="set-tab" data-tab="' + t[0] + '">' + t[1] + '</button>').join('') + '</div>' +
        '<div class="tabpanel">' + settingsPanel(tab, me, s, user, blocked) + '</div>'
      );
    },
    mount(ctx) {
      ctx.root.querySelectorAll('[data-act="set-tab"]').forEach((b) => b.addEventListener('click', () => {
        SEVE.router.navigate('/app/settings?tab=' + b.getAttribute('data-tab'));
      }));
      wireSettings(ctx.root);
    }
  };

  function settingsPanel(tab, me, s, user, blocked) {
    const row = (title, text, control) => '<div class="setrow"><div class="setrow__txt"><b>' + title + '</b><p>' + U.esc(text) + '</p></div><div class="setrow__ctrl">' + control + '</div></div>';
    const sw = (key, checked) => '<label class="switch"><input type="checkbox" data-set="' + key + '"' + (checked ? ' checked' : '') + '><span class="switch__track"></span></label>';

    if (tab === 'visibilite') {
      return '<section class="card card--pad"><h3>Visibilité du profil</h3>' +
        '<p class="small muted mt-8">Ces réglages s’appliquent immédiatement. Les profils non vérifiés restent visibles mais identifiés comme tels.</p>' +
        '<div class="mt-16">' +
        row('Profil visible dans les recherches', 'Désactivez pour disparaître temporairement des listes et des recommandations, sans perdre vos demandes en cours.',
          '<label class="switch"><input type="checkbox" data-set="visibility" ' + (s.visibility === 'public' ? 'checked' : '') + '><span class="switch__track"></span></label>') +
        row('Afficher ma ville', 'Vous pouvez n’indiquer que le pays ou la zone si vous préférez la discrétion.', sw('showLocation', s.showLocation)) +
        row('Afficher mes statistiques déclarées', 'Revenus, croissance, rétention. Désactivé, seuls votre présentation et vos spécialités sont visibles.', sw('showStats', s.showStats)) +
        row('Accepter les nouvelles demandes', 'Si désactivé, seuls les profils avec lesquels vous échangez déjà peuvent vous écrire.', sw('acceptRequests', s.acceptRequests)) +
        '</div></section>';
    }

    if (tab === 'notifications') {
      return '<section class="card card--pad"><h3>Notifications</h3>' +
        '<p class="small muted mt-8">Les notifications de service (demandes, messages, sécurité) sont toujours envoyées : elles concernent votre activité.</p>' +
        '<div class="mt-16">' +
        row('Nouvelles demandes de collaboration', 'Un email et une notification dans l’application à chaque demande reçue.', sw('notifyRequests', s.notifyRequests)) +
        row('Nouveaux messages', 'Notification à chaque message, hors fenêtre de conversation active.', sw('notifyMessages', s.notifyMessages)) +
        row('Recommandations', 'Résumé hebdomadaire des profils les plus compatibles avec vos critères.', sw('notifyMatches', s.notifyMatches)) +
        row('Informations produit', 'Nouveautés de la plateforme et services d’accompagnement. Jamais de publicité tierce.', sw('newsletter', s.notifyNewsletter)) +
        '</div>' +
        '<div class="row gap-12 mt-20">' + ui.btn({ label: 'Enregistrer', variant: 'primary', act: 'save-settings' }) + '</div></section>';
    }

    if (tab === 'securite') {
      return '<section class="card card--pad"><h3>Sécurité du compte</h3>' +
        '<div class="mt-16">' +
        row('Adresse email', U.esc(user.email) + ' — utilisée pour la connexion et les alertes de sécurité.', ui.btn({ label: 'Modifier', variant: 'outline', size: 'sm', act: 'change-email' })) +
        row('Mot de passe', 'Dernière modification il y a 4 mois. Un mot de passe long et unique protège votre compte.', ui.btn({ label: 'Changer', variant: 'outline', size: 'sm', act: 'change-password' })) +
        row('Double authentification', 'Code à usage unique envoyé par email à chaque connexion depuis un nouvel appareil.', ui.btn({ label: 'Activer', variant: 'soft', size: 'sm', act: 'enable-2fa' })) +
        row('Sessions actives', 'Cet appareil · Paris · ' + U.fmtRelative(new Date(Date.now() - 3600e3).toISOString()), ui.btn({ label: 'Déconnecter les autres sessions', variant: 'ghost', size: 'sm', act: 'revoke-sessions' })) +
        '</div></section>' +

        '<section class="card card--pad mt-20"><h3>Confidentialité et données</h3>' +
        '<div class="mt-16">' +
        row('Exporter mes données', 'Vous recevez un fichier contenant votre profil, vos demandes et vos messages.', ui.btn({ label: 'Exporter', variant: 'outline', size: 'sm', act: 'export-data' })) +
        row('Consentement et traceurs', 'Vos choix de cookies et de mesure d’usage, modifiables à tout moment.', ui.btn({ label: 'Gérer', variant: 'outline', size: 'sm', href: '#/legal/cookies' })) +
        row('Profils bloqués', blocked.length ? blocked.map((b) => U.esc(b.name)).join(', ') : 'Vous n’avez bloqué aucun profil. Un profil bloqué ne peut plus vous contacter et n’apparaît plus dans vos recherches.',
          ui.btn({ label: blocked.length ? 'Gérer les blocages' : 'Voir la liste', variant: 'outline', size: 'sm', act: 'manage-blocks' })) +
        '</div></section>' +

        '<section class="card card--pad mt-20" style="border-color:var(--danger-bg)"><h3 style="color:var(--danger)">Zone sensible</h3>' +
        '<p class="small muted mt-8">La suppression est définitive sous 30 jours : profil, demandes et messages sont effacés. Les dossiers de signalement ouverts peuvent être conservés le temps légal nécessaire.</p>' +
        '<div class="row gap-12 mt-16" style="flex-wrap:wrap">' +
        ui.btn({ label: 'Mettre mon profil en pause', variant: 'outline', act: 'pause-profile' }) +
        ui.btn({ label: 'Supprimer mon compte', variant: 'danger', act: 'delete-account' }) +
        '</div></section>';
    }

    /* Compte */
    return '<section class="card card--pad"><h3>Compte</h3>' +
      '<div class="mt-16">' +
      row('Type de compte', me.role === 'manager' ? 'Manager / agence — vous recherchez des créateurs à accompagner.' : 'Créateur / créatrice — vous recherchez un manager ou une agence.',
        ui.btn({ label: 'Voir les avantages', variant: 'ghost', size: 'sm', href: '#/how-it-works' })) +
      row('Langue de travail préférée', 'Utilisée pour vos recommandations et les échanges suggérés.', '<select class="select" data-set="langue" style="min-width:170px">' + T.LANGUAGES.map((l) => '<option' + ((s.languages || []).indexOf(l) >= 0 ? ' selected' : '') + '>' + U.esc(l) + '</option>').join('') + '</select>') +
      row('Rythme de collaboration souhaité', 'Le moteur ajuste le poids de la disponibilité selon votre préférence.',
        '<select class="select" data-set="mode" style="min-width:170px">' + ['Équilibré', 'Je veux aller vite', 'Je privilégie la qualité du suivi'].map((m) => '<option' + (s.mode === m ? ' selected' : '') + '>' + m + '</option>').join('') + '</select>') +
      row('Vérification du profil', me.verified ? 'Votre profil est vérifié : identité et informations contrôlées.' : 'La vérification est en cours. Vous pouvez accélérer en complétant vos informations professionnelles.',
        me.verified ? '<span class="chip chip--ok chip--sm">' + icon('shieldCheck', 13) + 'Vérifié</span>' : ui.btn({ label: 'Accélérer', variant: 'outline', size: 'sm', act: 'accelerate-verif' })) +
      '</div>' +
      '<div class="row gap-12 mt-20">' + ui.btn({ label: 'Enregistrer', variant: 'primary', act: 'save-settings' }) + '</div></section>';
  }

  function wireSettings(root) {
    const save = root.querySelector('[data-act="save-settings"]');
    if (save) save.addEventListener('click', () => {
      const me = store.me();
      const patch = {};
      root.querySelectorAll('[data-set]').forEach((el) => {
        const key = el.getAttribute('data-set');
        if (el.type === 'checkbox') {
          if (key === 'visibility') patch.visibility = el.checked ? 'public' : 'hidden';
          else if (key === 'newsletter') patch.notifyNewsletter = el.checked;
          else patch[key] = el.checked;
        } else {
          patch[key === 'langue' ? 'languages' : key] = key === 'langue' ? [el.value] : el.value;
        }
      });
      store.saveSettings(me.id, patch);
      ui.toast('Préférences enregistrées.', 'ok');
      SEVE.router.refresh();
    });
  }

  SEVE.act('manage-blocks', function () {
    const blocked = store.blocked().map((id) => store.get(id)).filter(Boolean);
    ui.modal({
      title: 'Profils bloqués',
      subtitle: 'Un profil bloqué ne peut plus vous écrire et n’apparaît plus dans vos recherches.',
      size: 'sm',
      body: blocked.length ? '<div class="stack gap-10">' + blocked.map((b) =>
        '<div class="row gap-12">' + ui.avatar(b, 'sm') + '<div class="grow" style="min-width:0"><b style="font-size:14px">' + U.esc(b.name) + '</b>' +
        '<span class="small muted" style="display:block">' + U.esc(SEVE.flows.roleLabel(b)) + ' · ' + U.esc(b.city) + '</span></div>' +
        ui.btn({ label: 'Débloquer', variant: 'outline', size: 'xs', act: 'unblock', data: { id: b.id } }) + '</div>').join('') + '</div>'
        : '<p class="small muted">Aucun profil bloqué pour le moment.</p>',
      footer: ui.btn({ label: 'Fermer', variant: 'primary', act: 'close-modal' }),
      onMount(panel) { panel.querySelector('[data-act="close-modal"]').addEventListener('click', () => ui.close()); }
    });
  });

  SEVE.act('unblock', function (el) {
    store.toggleBlock(el.getAttribute('data-id'));
    ui.close();
    ui.toast('Profil débloqué.', 'info');
    SEVE.router.refresh();
  });

  /* ================================================================== */
  /* AIDE AU MATCHING (espace connecté)                                  */
  /* ================================================================== */
  SEVE.views.appHelp = {
    title: 'Besoin d’aide ?',
    render() {
      const me = store.me();
      const isManager = me.role === 'manager';
      const apps = store.applications({ user: me.id });
      return page({
        title: 'Besoin d’aide pour trouver ' + (isManager ? 'des créateurs' : 'un manager') + ' ?',
        subtitle: 'Notre équipe peut rechercher des profils correspondant à vos critères et vous aider à identifier des partenaires potentiels.'
      },
        '<div class="card card--pad reveal mt-20" style="border-color:var(--green-100);background:var(--green-50)">' +
        '<div class="between" style="align-items:flex-start;gap:16px;flex-wrap:wrap">' +
        '<div style="max-width:64ch"><h3 style="display:flex;align-items:center;gap:9px">' + icon('headset', 18) + ' Écrire directement à l’équipe</h3>' +
        '<p class="small muted mt-8">Pas besoin de remplir un formulaire pour poser une question, signaler un malaise ou demander de l’aide sur un litige. ' +
        'Écrivez en quelques mots : une référente vous est attribuée immédiatement, et vous saurez son nom.</p></div>' +
        '<div class="row gap-10" style="flex-wrap:wrap">' +
        ui.btn({ label: 'Parler à l’équipe', variant: 'primary', act: 'team-help', icon: 'message' }) +
        ui.btn({ label: 'Mon espace tranquille', variant: 'outline', href: '#/app/care', icon: 'pause' }) +
        '</div></div></div>' +

        '<div class="grid grid--split mt-20" style="align-items:start;gap:24px">' +
        '<div class="card card--pad reveal"><h3>Demande d’accompagnement</h3>' +
        '<p class="small muted mt-8">Cinq informations suffisent. Nous ne demandons rien d’autre, et il n’y a aucun frais pour les créateurs.</p>' +
        '<div class="mt-20">' + SEVE.flows.applicationFormHTML(me) + '</div></div>' +
        '<div class="stack gap-16">' +
        '<div class="card card--pad"><h4>Comment ça se passe</h4>' +
        '<div class="timeline mt-16">' + [
          { p: 'Étape 1 — immédiat', t: 'Nous étudions vos critères', n: 'Un membre de l’équipe relit votre demande et vérifie sa faisabilité.' },
          { p: 'Étape 2 — sous 72 h ouvrées', t: 'Recherche et vérifications', n: 'Nous filtrons la base, contactons les profils pertinents et vérifions les points sensibles (statut, historique de signalement).' },
          { p: 'Étape 3 — transmission', t: 'Présélection argumentée', n: 'Vous recevez jusqu’à quatre profils, avec les raisons du rapprochement et les points de vigilance.' },
          { p: 'Étape 4 — vous décidez', t: 'Mise en relation', n: 'Vous choisissez qui contacter. Nous restons disponibles si vous souhaitez un avis sur un contrat.' }
        ].map((x) => '<div class="tl"><span class="tl__dot"></span><div><span class="tl__period">' + U.esc(x.p) + '</span>' +
          '<h4>' + U.esc(x.t) + '</h4><p class="small muted mt-4">' + U.esc(x.n) + '</p></div></div>').join('') + '</div></div>' +
        '<div class="card card--pad card--soft"><h4>Vos demandes</h4>' +
        (apps.length ? '<div class="stack gap-12 mt-12">' + apps.map((a) =>
          '<div><div class="between"><b class="small">' + U.esc(store.APPLI_LABELS[a.status] || a.status) + '</b>' +
          '<span class="tiny muted">' + U.fmtRelative(a.created) + '</span></div>' +
          '<p class="small muted mt-4 clamp-2">' + U.esc(a.need) + '</p></div>').join('') + '</div>'
          : '<p class="small muted mt-8">Aucune demande envoyée pour le moment.</p>') +
        '</div>' +
        '<div class="card card--pad"><h4>Rappels de sécurité</h4><ul class="stack gap-10 mt-12">' + [
          'Aucun paiement, aucune avance, aucun « frais de dossier ».',
          'Un contrat écrit avant toute production ou délégation de compte.',
          'Signalez toute pression : les cas de contrainte sont traités sous 12 heures.'
        ].map((t) => '<li class="row gap-8" style="align-items:flex-start"><span style="color:var(--ink-4)">' + icon('shield', 15) + '</span><span class="small muted">' + U.esc(t) + '</span></li>').join('') + '</ul>' +
        '<div class="row gap-10 mt-12" style="flex-wrap:wrap">' +
        '<a class="btn btn--ghost btn--sm" href="#/legal/rules">Lire les règles ' + icon('arrowRight', 15) + '</a>' +
        '<a class="btn btn--ghost btn--sm" href="#/chargebacks">Contestations bancaires ' + icon('arrowRight', 15) + '</a>' +
        '</div></div>' +
        '</div></div>'
      );
    },
    mount(ctx) {
      const form = ctx.root.querySelector('#appform');
      if (!form) return;
      const submit = ctx.root.querySelector('[data-act="submit-application"]');
      submit.addEventListener('click', (e) => {
        e.preventDefault();
        if (!ui.validate(form)) return;
        ui.loading(submit, true, 'Envoi…');
        const me = store.me();
        setTimeout(() => {
          store.createApplication({
            user: me.id, type: me.role === 'manager' ? 'manager' : 'créateur',
            goals: Array.from(form.querySelector('#af-goals').selectedOptions).map((o) => o.value),
            specialties: Array.from(form.querySelector('#af-spec').selectedOptions).map((o) => o.value),
            location: form.querySelector('#af-loc').value,
            criteria: form.querySelector('#af-criteria').value,
            need: form.querySelector('#af-need').value
          });
          ui.loading(submit, false);
          ui.toast('Demande reçue. Réponse sous 72 h ouvrées.', 'ok');
          SEVE.router.refresh();
        }, 900);
      });
    }
  };

  /* ================================================================== */
  /* ACTIONS DEMANDES                                                    */
  /* ================================================================== */
  SEVE.act('req-tab', function (el) { SEVE.router.navigate('/app/requests?tab=' + el.getAttribute('data-tab')); });

  SEVE.act('req-accept', function (el) {
    const r = store.requestById(el.getAttribute('data-id'));
    if (!r) return;
    ui.modal({
      title: 'Accepter la demande',
      size: 'sm',
      subtitle: 'Vous pouvez ajouter un mot : c’est souvent ce qui déclenche la conversation.',
      body: '<div class="row gap-12 mb-16">' + ui.avatar(Object.assign({ square: r.fromProfile.role === 'manager' }, r.fromProfile), 'md') +
        '<div><b>' + U.esc(r.fromProfile.name) + '</b><p class="small muted">' + U.esc(SEVE.flows.roleLabel(r.fromProfile)) + '</p></div></div>' +
        '<div class="field"><label class="label" for="acc-reply">Message de réponse (facultatif)</label>' +
        '<textarea class="textarea" id="acc-reply" placeholder="Bonjour, avec plaisir. Je vous propose un appel de 20 minutes cette semaine…"></textarea></div>',
      footer: ui.btn({ label: 'Annuler', variant: 'ghost', act: 'cancel' }) + ui.btn({ label: 'Accepter et ouvrir la conversation', variant: 'primary', act: 'confirm-accept' }),
      onMount(panel) {
        panel.querySelector('[data-act="cancel"]').addEventListener('click', () => ui.close());
        const btn = panel.querySelector('[data-act="confirm-accept"]');
        btn.addEventListener('click', () => {
          ui.loading(btn, true, 'Acceptation…');
          setTimeout(() => {
            const reply = panel.querySelector('#acc-reply').value.trim();
            store.respondRequest(r.id, 'accepted', reply);
            const conv = store.ensureConversation(store.me().id, r.fromProfile.id);
            if (reply) store.sendMessage(conv.id, reply, 'me');
            store.pushNotification(r.fromProfile.role, {
              type: 'request', icon: 'checkCircle', title: 'Demande acceptée par ' + store.me().name,
              text: 'Vous pouvez poursuivre la conversation', href: '#/app/messages/' + conv.id
            });
            ui.close();
            ui.toast('Demande acceptée. La conversation est ouverte.', 'ok');
            SEVE.router.navigate('/app/messages/' + conv.id);
          }, 700);
        });
      }
    });
  });

  SEVE.act('req-decline', function (el) {
    const r = store.requestById(el.getAttribute('data-id'));
    if (!r) return;
    ui.modal({
      title: 'Refuser cette demande ?',
      size: 'sm',
      body: '<p class="small">' + U.esc(r.fromProfile.name) + ' sera informé(e) du refus, sans connaître votre motif. Refuser n’affecte ni votre visibilité ni votre classement.</p>' +
        '<div class="field mt-16"><label class="label" for="dec-reply">Motif (facultatif, transmis au profil)</label>' +
        '<textarea class="textarea" id="dec-reply" placeholder="Ex. Merci pour votre message : je ne cherche pas ce type de collaboration pour le moment."></textarea></div>',
      footer: ui.btn({ label: 'Annuler', variant: 'ghost', act: 'cancel' }) + ui.btn({ label: 'Refuser la demande', variant: 'danger', act: 'confirm-decline' }),
      onMount(panel) {
        panel.querySelector('[data-act="cancel"]').addEventListener('click', () => ui.close());
        const btn = panel.querySelector('[data-act="confirm-decline"]');
        btn.addEventListener('click', () => {
          store.respondRequest(r.id, 'declined', panel.querySelector('#dec-reply').value.trim());
          ui.close();
          ui.toast('Demande refusée. Vous pouvez la retrouver dans l’onglet Archivées.', 'info');
          SEVE.router.refresh();
        });
      }
    });
  });

  SEVE.act('req-archive', function (el) {
    store.archiveRequest(el.getAttribute('data-id'));
    ui.toast('Demande archivée.', 'info');
    SEVE.router.refresh();
  });

  SEVE.act('open-thread', function (el) {
    const me = store.me();
    const conv = store.ensureConversation(me.id, el.getAttribute('data-id'));
    if (conv) SEVE.router.navigate('/app/messages/' + conv.id);
  });

  SEVE.act('scroll-to-request', function () {
    const zone = document.getElementById('demande');
    if (zone) window.scrollTo({ top: zone.getBoundingClientRect().top + window.scrollY - 90, behavior: 'smooth' });
  });

  /* Paramètres : actions secondaires ---------------------------------- */
  function simpleModal(title, text, okLabel, done) {
    ui.modal({
      title, size: 'sm', body: '<p class="small">' + U.esc(text) + '</p>',
      footer: ui.btn({ label: 'Annuler', variant: 'ghost', act: 'cancel' }) + ui.btn({ label: okLabel, variant: 'primary', act: 'ok' }),
      onMount(panel) {
        panel.querySelector('[data-act="cancel"]').addEventListener('click', () => ui.close());
        panel.querySelector('[data-act="ok"]').addEventListener('click', () => { ui.close(); if (done) done(); });
      }
    });
  }

  SEVE.act('change-email', function () {
    simpleModal('Modifier l’adresse email', 'Pour des raisons de sécurité, le changement est confirmé par un lien envoyé à l’ancienne adresse puis à la nouvelle. Aucun changement n’est pris en compte avant confirmation.', 'Envoyer les confirmations', () => {
      ui.toast('Emails de confirmation envoyés (démonstration).', 'ok');
    });
  });
  SEVE.act('change-password', function () {
    simpleModal('Changer le mot de passe', 'Choisissez un mot de passe long et unique. La double authentification reste recommandée pour les comptes agences.', 'Continuer', () => {
      ui.toast('Procédure de changement de mot de passe lancée.', 'ok');
    });
  });
  SEVE.act('enable-2fa', function () {
    simpleModal('Activer la double authentification', 'À chaque connexion depuis un appareil inconnu, un code à usage unique vous sera envoyé par email. Aucune application tierce n’est nécessaire.', 'Activer', () => {
      ui.toast('Double authentification activée (démonstration).', 'ok');
    });
  });
  SEVE.act('revoke-sessions', function () {
    simpleModal('Déconnecter les autres sessions', 'Toutes les sessions ouvertes sur d’autres appareils seront fermées. La session actuelle est conservée.', 'Déconnecter', () => {
      ui.toast('Les autres sessions ont été fermées.', 'ok');
    });
  });
  SEVE.act('export-data', function () {
    const me = store.me();
    const payload = {
      export: 'seve-demo-export', date: new Date().toISOString(),
      profil: me, demandes: store.requests({ profileId: me.id }), conversations: store.conversations({ demo: me.role }),
      demandesAccompagnement: store.applications({ user: me.id })
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'seve-export-' + me.id + '.json';
    document.body.appendChild(a); a.click(); a.remove();
    ui.toast('Export généré. Vérifiez vos téléchargements.', 'ok');
  });
  SEVE.act('pause-profile', function () {
    ui.confirm({
      title: 'Mettre mon profil en pause ?',
      text: 'Votre profil devient invisible dans les recherches et les recommandations. Vos demandes et messages restent accessibles.',
      okLabel: 'Mettre en pause'
    }).then((ok) => {
      if (!ok) return;
      const me = store.me();
      store.updateProfile(me.id, { availability: 'booked' });
      store.saveSettings(me.id, { visibility: 'hidden' });
      ui.toast('Profil en pause. Vous pouvez le réactiver à tout moment.', 'info');
      SEVE.router.refresh();
    });
  });
  SEVE.act('delete-account', function () {
    ui.confirm({
      title: 'Supprimer définitivement mon compte ?',
      text: 'Cette action est irréversible : profil, demandes et messages sont effacés sous 30 jours. Les dossiers de signalement en cours peuvent être conservés le temps légal nécessaire.',
      detail: 'Vous pourrez recréer un compte plus tard, mais l’historique sera perdu.',
      okLabel: 'Supprimer mon compte', danger: true
    }).then((ok) => {
      if (!ok) return;
      const me = store.me();
      const u = store.currentUser();
      store.removeProfile(me.id);
      store.logout();
      if (u) ui.toast('Compte supprimé (démonstration : réinitialisez la démo pour restaurer les données).', 'info');
      SEVE.router.navigate('/');
    });
  });
  SEVE.act('accelerate-verif', function () {
    SEVE.router.navigate('/app/profile?tab=pro');
  });
})();
