/* ==========================================================================
   Sève — « Chez vous » : espace tranquille, fil direct avec l’équipe,
   guichet d’écoute côté administration.
   --------------------------------------------------------------------------
   Principe de ton : on rassure en donnant du pouvoir, jamais en diminuant.
   Chaque promesse affichée ici est tenue par le store : délai annoncé par
   sujet, pause réellement appliquée, rythme de notifications réellement
   filtré, réponse nommée (une référente, pas « le support »).
   ========================================================================== */
(function () {
  const U = SEVE.util;
  const store = SEVE.store;
  const ui = SEVE.ui;
  const icon = ui.icon;

  function esc(v) { return U.esc(v == null ? '' : v); }

  /* Réponse « humaine » qui suit l’accusé de réception, selon le sujet.
     Volontairement courte : dire ce qu’on fait, pas rassurer en paroles. */
  const SUITE = {
    soutien: 'Merci de l’avoir écrit, et bravo de l’avoir fait : ce n’est jamais un détail. Je suis là, et vous n’avez rien à justifier. On peut en parler par écrit, ou je vous appelle si vous préférez entendre une voix — dites-moi simplement ce qui vous aiderait le plus maintenant.',
    malaise: 'Ce que vous décrivez n’est pas normal, et ce n’est pas de votre faute. Je vous réponds en détail dans l’heure. En attendant : ne payez rien, ne partagez rien, et si possible n’effacez pas la conversation — elle nous sert de preuve. Si vous vous sentez en danger, appelez le 17.',
    collab: 'J’ai commencé à regarder. Pendant ce temps, retenez une chose : sans contrat signé, vous ne devez rien à personne, et vous pouvez refuser sans vous justifier.',
    litige: 'J’ouvre votre registre de litiges : montants, canaux, dates. Je vous dis ce que je vois avant ce soir, et je vous prépare le constat à transmettre.',
    appel: 'Je vous propose deux créneaux en fin de semaine, par téléphone ou en visio — vous n’avez rien à préparer, et rien à montrer si vous ne le souhaitez pas.',
    visibilite: 'Je vérifie vos réglages actuels et je vous confirme exactement ce qui est visible, par qui, et comment tout masquer en un clic.',
    question: 'Je vous réponds point par point, sans jargon. Si une partie reste floue, dites-le : c’est mon travail de reformuler.',
    autre: 'Je lis votre message en entier, et je relis avant de répondre. Aucune question n’est trop petite.'
  };

  const RESSOURCES = [
    { n: '3919', t: 'Violences faites aux femmes', d: 'Gratuit, anonyme, 24 h/24. Compétent aussi pour les violences numériques, le chantage et les pressions.' },
    { n: '17 · 112', t: 'Urgence immédiate', d: 'Menaces physiques, chantage en cours, quelqu’un se présente chez vous.' },
    { n: 'internet-signalement.gouv.fr', t: 'Contenus illégaux en ligne', d: 'Signalement officiel de contenus ou de comportements illégaux, y compris la diffusion non consentie d’images.' }
  ];

  /* ==================================================================== */
  /* Composants partagés                                                   */
  /* ==================================================================== */

  function bulles(messages, moiDehors) {
    let lastDay = null;
    return (messages || []).map((m) => {
      const jour = U.fmtDayLabel(m.at);
      const sep = jour !== lastDay ? '<span class="chat__day">' + esc(jour) + '</span>' : '';
      lastDay = jour;
      const team = m.from === 'team';
      return sep + '<div class="msg ' + (team ? 'msg--them' : 'msg--me') + '">' +
        (team ? '<span class="msg__author">' + icon('headset', 13) + ' ' + esc(m.author || 'Équipe Sève') + (m.auto ? ' · message automatique de bonne réception' : '') + '</span>' : '') +
        '<div class="msg__bubble">' + esc(m.text) + '</div>' +
        '<span class="msg__time">' + U.fmtTime(m.at) + (team ? '' : ' · reçu') + '</span></div>';
    }).join('') + (moiDehors || '');
  }

  function sujetsChips(selectionne) {
    return '<div class="chips chips--wrap" id="team-topics">' +
      store.TEAM_TOPICS().map((t) =>
        '<button class="chip chip--sm' + (selectionne === t.id ? ' chip--green is-on' : '') + '" data-act="team-topic" data-topic="' + t.id + '">' +
        icon(t.icon, 13) + '<span>' + esc(t.label) + '</span></button>').join('') + '</div>';
  }

  function sujetSelectionne() {
    const el = document.querySelector('[data-topic].is-on');
    return (el && el.getAttribute('data-topic')) || 'question';
  }

  /** Envoi commun à la page et au bouton flottant. */
  function envoyer(texte, topicId, opts) {
    opts = opts || {};
    const t = store.sendTeamMessage({ text: texte, topic: topicId, context: opts.context || null });
    if (!t) { return null; }
    setTimeout(() => {
      /* Une vraie personne a peut-être déjà répondu entre-temps : on ne double pas. */
      const fil = store.teamThreadById(t.id);
      if (!fil) { return; }
      const dernier = fil.messages[fil.messages.length - 1] || {};
      if (dernier.from === 'team') { return; }
      store.replyTeamThread(t.id, { text: SUITE[topicId] || SUITE.autre, status: 'pris_en_charge' });
      if (SEVE.router && SEVE.router.refresh) { SEVE.router.refresh(); }
    }, 3000);
    return t;
  }

  function apresEnvoi(t) {
    ui.toast('Message reçu. ' + t.referent + ' le lit maintenant — ' + store.teamDelay(t.topic).toLowerCase() + '.', 'ok');
  }

  /* ==================================================================== */
  /* ESPACE MEMBRE — /app/team : parler à l’équipe                        */
  /* ==================================================================== */
  SEVE.views.teamHelp = {
    title: 'Parler à l’équipe',
    render(ctx) {
      const me = store.me();
      if (!me) { return ''; }
      const topic = (ctx.query && ctx.query.topic) || null;
      const t = store.myTeamThread(false);
      store.markTeamSeen(me.id);
      const statut = t ? store.TEAM_STATUS[t.status] : store.TEAM_STATUS.nouveau;
      const enAttente = t ? (t.messages[t.messages.length - 1] || {}).from === 'member' : false;

      return '' +
        '<div class="page-head"><div>' +
        '<span class="kicker">Vous n’êtes pas seule</span>' +
        '<h1>Parler à l’équipe</h1>' +
        '<p class="lede small">Une personne vous répond — pas un robot, pas un jugement. Écrivez avec vos mots, même maladroits, ' +
        'même si vous pensez que ce n’est pas grave. Nous lisons chaque message en entier, et nous ne décidons jamais à votre place.</p>' +
        '</div><div class="row gap-10" style="flex-wrap:wrap">' +
        ui.btn({ label: 'Écrire maintenant', variant: 'primary', act: 'team-focus', icon: 'message' }) +
        ui.btn({ label: 'Mon espace tranquille', variant: 'outline', href: '#/app/care', icon: 'heart' }) +
        '</div></div>' +

        '<div class="kpis mt-20">' +
        ui.kpi({ icon: 'headset', label: 'Votre référente', value: (t && t.referent) || 'Dès votre premier message', foot: '<span class="muted">Nommée, joignable, la même du début à la fin</span>' }) +
        ui.kpi({ icon: 'clock', label: 'Délai annoncé', value: t ? (store.teamTopic(t.topic) || {}).urgent ? '1 h ouvrée' : '4 h ouvrées' : '1 h à 24 h', foot: '<span class="muted">Selon le sujet — urgent d’abord, toujours</span>' }) +
        ui.kpi({ icon: 'shield', label: 'Confidentialité', value: 'Personne d’autre', foot: '<span class="muted">Ni manager, ni membre, ni public : jamais</span>' }) +
        ui.kpi({ icon: 'heart', label: 'Réponse', value: 'Humannement', foot: '<span class="muted">Aucune réponse automatique ne conclut un dossier</span>' }) +
        '</div>' +

        '<div class="grid grid--split mt-24" style="align-items:start;gap:24px">' +

        /* ---------------- Le fil ---------------- */
        '<div class="card card--pad reveal">' +
        '<div class="between" style="align-items:flex-start">' +
        '<div class="row gap-10">' +
        '<span class="teamavatar">' + icon('headset', 18) + '</span>' +
        '<div><b style="font-size:15px">Équipe Sève</b>' +
        '<span class="small muted" style="display:block">' + (t && t.referent ? esc(t.referent) + ' suit votre dossier' : 'Une référente vous est attribuée dès votre premier message') + '</span></div></div>' +
        ui.pill(statut.label, statut.variant) +
        '</div>' +

        '<div class="care-thread" id="team-thread">' +
        (t && t.messages.length
          ? bulles(t.messages)
          : '<div class="empty" style="border:0;background:transparent"><div class="empty__icon" style="background:var(--green-50);color:var(--green-800)">' + icon('heart', 22) + '</div>' +
            '<h3>Vous commencerez ici</h3><p>Personne ne verra ce message en dehors de l’équipe. Vous pouvez écrire une phrase, ou dix ; poser une question simple, ou raconter quelque chose de difficile. Les deux sont normaux.</p></div>') +
        (enAttente ? '<p class="small muted center mt-8" id="team-wait">Votre message est lu. ' + esc((t.referent || 'L’équipe')) + ' vous répond ici même.</p>' : '') +
        '</div>' +

        '<div class="care-composer">' +
        '<div class="field"><label class="label" for="team-input">Votre message</label>' +
        '<textarea class="textarea" id="team-input" rows="4" placeholder="Écrivez comme vous le diriez à une personne en face de vous. Si vous ne savez pas par où commencer, une phrase suffit : « j’ai besoin d’aide pour… »"></textarea></div>' +
        sujetsChips(topic) +
        '<div class="between mt-12" style="flex-wrap:wrap;gap:10px">' +
        '<span class="tiny muted">' + icon('lock', 12) + ' Visible uniquement par l’équipe Sève. Conservé pour le suivi de votre dossier, supprimable sur demande.</span>' +
        ui.btn({ label: 'Envoyer à l’équipe', variant: 'primary', act: 'team-send', icon: 'send' }) +
        '</div></div>' +
        '</div>' +

        /* ---------------- Colonne de réassurance ---------------- */
        '<div class="stack gap-16">' +

        ui.panel({ title: 'Ce que vous pouvez nous écrire', icon: 'message', body:
          '<ul class="signallist">' + store.TEAM_TOPICS().map((tp) =>
            '<li><b>' + esc(tp.label) + '</b><em>' + esc(tp.hint) + '</em>' +
            '<button class="linkish mt-4" data-act="team-quick" data-topic="' + tp.id + '">Écrire sur ce sujet</button></li>').join('') + '</ul>' }) +

        ui.panel({ title: 'Ce que nous ne ferons jamais', icon: 'shield', body:
          '<ul class="prudence">' + [
            { i: '1', t: 'Aucun jugement sur votre travail, vos choix ou votre rythme. Ni ici, ni dans un dossier.' },
            { i: '2', t: 'Aucun partage avec un manager, une agence ou un autre membre — même si l’on nous le demande.' },
            { i: '3', t: 'Aucune décision à votre place : nous proposons, vous tranchez, et nous notons votre décision.' },
            { i: '4', t: 'Aucune question sur le contenu de votre page, ni sur vos revenus, au-delà de ce qui aide à vous protéger.' },
            { i: '5', t: 'Aucune promesse de résultat : nous ne dirons jamais « ce sera réglé ». Nous dirons ce que nous faisons.' }
          ].map((x) => '<li><span>' + x.i + '</span><div>' + esc(x.t) + '</div></li>').join('') + '</ul>' }) +

        ui.panel({ title: 'Ce qui se passe après l’envoi', icon: 'clock', body:
          '<div class="timeline mt-8">' + [
            { p: 'Immédiatement', t: 'Un accusé de réception, avec un nom', n: 'Vous savez tout de suite qui prend votre message — pas « le support ».' },
            { p: 'Sous 1 à 4 h ouvrées', t: 'Une réponse humaine et concrète', n: 'Ce que nous avons vérifié, ce que nous proposons, et ce que vous pouvez décider.' },
            { p: 'Ensuite', t: 'Le suivi, même sans réponse de votre part', n: 'Nous revenons vers vous : vous n’avez pas à relancer pour exister.' }
          ].map((x) => '<div class="tl"><span class="tl__dot"></span><div><span class="tl__period">' + esc(x.p) + '</span>' +
            '<h4>' + esc(x.t) + '</h4><p class="small muted">' + esc(x.n) + '</p></div></div>').join('') + '</div>' }) +

        ui.panel({ title: 'Si vous êtes en danger maintenant', icon: 'phone', body:
          '<p class="small muted">L’équipe Sève n’est pas un service d’urgence. Ces numéros sont indépendants de nous et ne nous préviennent pas :</p>' +
          '<ul class="signallist mt-12">' + RESSOURCES.map((r) =>
            '<li><b>' + esc(r.t) + ' — <span class="num">' + esc(r.n) + '</span></b><em>' + esc(r.d) + '</em></li>').join('') + '</ul>' }) +

        '</div></div>';
    },
    mount(ctx) {
      const ta = ctx.root.querySelector('#team-input');
      const fil = ctx.root.querySelector('#team-thread');
      if (fil) { fil.scrollTop = fil.scrollHeight; }
      if (ta) { ta.focus(); }
    }
  };

  /* ==================================================================== */
  /* ESPACE MEMBRE — /app/care : vous êtes chez vous                       */
  /* ==================================================================== */
  SEVE.views.care = {
    title: 'Mon coin bien-être',
    render() {
      const me = store.me();
      if (!me) { return ''; }
      const c = store.care(me.id);
      const t = store.myTeamThread(false);
      const litiges = store.disputes({ owner: me.id }).length;

      /* Interrupteur : on réutilise le composant natif de la charte. */
      const interrupteur = (cle, titre, texte, valeur) =>
        '<div class="carecard">' +
        '<div class="between" style="align-items:flex-start">' +
        '<div style="max-width:52ch"><b>' + esc(titre) + '</b><p class="small muted mt-8">' + esc(texte) + '</p></div>' +
        '<label class="switch" title="' + esc(titre) + '">' +
        '<input type="checkbox" data-act="care-toggle" data-key="' + cle + '" aria-label="' + esc(titre) + '"' + (valeur ? ' checked' : '') + '>' +
        '<span class="switch__track"></span></label>' +
        '</div></div>';

      return '' +
        '<div class="page-head"><div>' +
        '<span class="kicker">Chez vous</span>' +
        '<h1>Mon coin bien-être</h1>' +
        '<p class="lede small">Vous décidez du rythme, de la visibilité, et de ce qui vous parvient. Rien de tout cela n’est une faveur ' +
        'qu’il faudrait justifier : ce sont vos réglages, et vous pouvez les reprendre à tout moment.</p>' +
        '</div><div class="row gap-10" style="flex-wrap:wrap">' +
        (c.pause
          ? ui.btn({ label: 'Reprendre mon activité', variant: 'primary', act: 'care-toggle', data: { key: 'pause' }, icon: 'play' })
          : ui.btn({ label: 'Faire une pause', variant: 'primary', act: 'care-toggle', data: { key: 'pause' }, icon: 'pause' })) +
        ui.btn({ label: 'Parler à l’équipe', variant: 'outline', href: '#/app/team', icon: 'headset' }) +
        '</div></div>' +

        (c.pause
          ? '<div class="banner banner--ok mt-8">' + icon('pause', 18) + '<div><strong>Votre profil est en pause.</strong> ' +
            'Il ne remonte plus dans la recherche et aucune nouvelle demande ne vous parvient. Votre messagerie, elle, reste ouverte : ' +
            'vous n’êtes pas coupée du monde, et vous revenez quand vous voulez.</div></div>'
          : '<div class="banner banner--soft mt-8">' + icon('heart', 18) + '<div><strong>Vous êtes chez vous.</strong> ' +
            'Trois choses, ici, se règlent en un clic : faire une pause, sortir des résultats, choisir ce qui vous notifie. ' +
            'Aucune ne ferme quoi que ce soit, aucune ne se voit sur votre profil.</div></div>') +

        '<div class="kpis mt-20">' +
        ui.kpi({ icon: 'eyeOff', label: 'Visibilité', value: c.discret || c.pause ? 'Retirée' : 'Visible', foot: '<span class="muted">' + (c.discret ? 'Mode discret actif' : c.pause ? 'Pause en cours' : 'Vous apparaissez dans la recherche') + '</span>' }) +
        ui.kpi({ icon: 'bell', label: 'Notifications', value: store.CARE_RYTHME[c.rythme].label, foot: '<span class="muted">Modifiable ci-dessous, sans conséquence</span>' }) +
        ui.kpi({ icon: 'headset', label: 'Accompagnement', value: store.CARE_ACCOMPAGNEMENT[c.accompagnement].label, foot: '<span class="muted">' + (t && t.referent ? 'Référente : ' + esc(t.referent) : 'Référente attribuée au premier message') + '</span>' }) +
        ui.kpi({ icon: 'alert', label: 'Litiges suivis', value: litiges ? String(litiges) : 'Aucun', foot: '<span class="muted">' + (litiges ? 'Dossier repris par l’équipe' : 'Rien à votre charge') + '</span>' }) +
        '</div>' +

        '<div class="grid grid--2 mt-24" style="align-items:start">' +

        ui.panel({ title: 'Votre rythme', icon: 'pause', body:
          interrupteur('pause', 'Faire une pause',
            'Votre profil quitte la recherche et vous ne recevez plus de nouvelles demandes. Vos conversations restent ouvertes, votre page reste en ligne : personne n’est informé, et vous revenez quand vous le souhaitez.', c.pause) +
          interrupteur('discret', 'Mode discret',
            'Vous restez joignable par les personnes qui ont déjà votre lien, mais vous sortez des résultats publics et des recommandations. Utile quand un profil vous suit de trop près.', c.discret) +
          '<div class="carecard"><b>Ce qui vous notifie</b>' +
          '<div class="optlist mt-12">' + Object.keys(store.CARE_RYTHME).map((k) =>
            '<button class="optrow' + (c.rythme === k ? ' is-on' : '') + '" data-act="care-rythme" data-key="' + k + '">' +
            '<span class="optrow__mark"></span><span><b>' + esc(store.CARE_RYTHME[k].label) + '</b>' +
            '<em>' + esc(store.CARE_RYTHME[k].hint) + '</em></span></button>').join('') + '</div></div>' }) +

        ui.panel({ title: 'Votre accompagnement', icon: 'headset', body:
          '<div class="optlist">' + Object.keys(store.CARE_ACCOMPAGNEMENT).map((k) =>
            '<button class="optrow' + (c.accompagnement === k ? ' is-on' : '') + '" data-act="care-accompagnement" data-key="' + k + '">' +
            '<span class="optrow__mark"></span><span><b>' + esc(store.CARE_ACCOMPAGNEMENT[k].label) + '</b>' +
            '<em>' + esc(store.CARE_ACCOMPAGNEMENT[k].hint) + '</em></span></button>').join('') + '</div>' +
          '<div class="carecard mt-16"><b>Être appelée plutôt qu’écrire</b>' +
          '<p class="small muted mt-8">Certaines choses se disent mieux de vive voix. C’est vous qui choisissez : nous ne prenons jamais l’initiative d’un appel sans votre accord.</p>' +
          '<div class="row gap-10 mt-12" style="flex-wrap:wrap">' +
          '<select class="select" id="care-slot" style="max-width:220px"><option value="matin">Plutôt le matin</option><option value="apresmidi">Plutôt l’après-midi</option><option value="soir">Plutôt en fin de journée</option></select>' +
          ui.btn({ label: 'Demander un appel de 20 minutes', variant: 'primary', size: 'sm', act: 'care-callback', icon: 'phone' }) +
          '</div></div>',
          footer: '' }) +

        ui.panel({ title: 'Vos droits, en un clic', icon: 'scale', body:
          '<div class="quickgrid">' + [
            { l: 'Refuser une demande', d: 'Sans justification, sans conséquence sur votre visibilité.', href: '#/app/requests' },
            { l: 'Couper une conversation', d: 'Vous pouvez arrêter un échange à tout moment, en un geste.', href: '#/app/messages' },
            { l: 'Signaler un comportement', d: 'Insistance, pression, demande d’argent : priorité au traitement.', href: '#/app/team?topic=malaise' },
            { l: 'Vérifier mes données', d: 'Ce qui est visible, ce qui est conservé, ce qui peut être effacé.', href: '#/app/settings' }
          ].map((x) => '<a class="quicklink" href="' + x.href + '"><b>' + esc(x.l) + '</b><span>' + esc(x.d) + '</span>' + icon('arrowRight', 15) + '</a>').join('') + '</div>' }) +

        ui.panel({ title: 'Ce qui ne vous sera jamais demandé', icon: 'shieldCheck', body:
          '<ul class="prudence">' + [
            { i: '1', t: 'Aucun paiement, aucune avance, aucun « frais de dossier ». Jamais, sous aucun prétexte.' },
            { i: '2', t: 'Aucun accès à votre compte : ni identifiants, ni code de sécurité, ni double authentification.' },
            { i: '3', t: 'Aucun contenu hors plateforme, aucune photo envoyée par un autre canal, aucun service contre une faveur.' },
            { i: '4', t: 'Aucune exclusivité forcée : vous restez libre de travailler avec qui vous voulez, quand vous voulez.' }
          ].map((x) => '<li><span>' + x.i + '</span><div>' + esc(x.t) + '</div></li>').join('') + '</ul>' +
          '<p class="small muted mt-12">Si quelqu’un vous demande l’un de ces quatre points, ce n’est pas une négociation : c’est un signalement. ' +
          '<a href="#/app/team?topic=malaise">Écrivez-nous</a> et nous nous en occupons.</p>' }) +

        ui.panel({ title: 'Si vous êtes en danger maintenant', icon: 'phone', body:
          '<p class="small muted">L’équipe Sève n’est pas un service d’urgence. Ces numéros sont indépendants de nous et ne nous préviennent pas :</p>' +
          '<ul class="signallist mt-12">' + RESSOURCES.map((r) =>
            '<li><b>' + esc(r.t) + ' — <span class="num">' + esc(r.n) + '</span></b><em>' + esc(r.d) + '</em></li>').join('') + '</ul>' }) +

        '</div>';
    }
  };

  /* ==================================================================== */
  /* ADMINISTRATION — /admin/help : le guichet d’écoute                    */
  /* ==================================================================== */
  SEVE.views.adminHelp = {
    title: 'Messages à l’équipe',
    render(ctx) {
      const status = (ctx.query && ctx.query.status) || 'all';
      const topic = (ctx.query && ctx.query.topic) || 'all';
      const q = (ctx.query && ctx.query.q) || '';
      const list = store.teamThreads({ status: status, topic: topic, q: q, user: 'all' });
      const s = store.teamInboxStats();

      const dernier = (t) => (t.messages[t.messages.length - 1] || {});
      const trs = list.map((t) => {
        const p = store.get(t.user);
        const tp = store.teamTopic(t.topic) || {};
        const st = store.TEAM_STATUS[t.status];
        const d = dernier(t);
        return '<tr>' +
          '<td><div class="row gap-10">' + ui.avatar(p || { name: t.user, tone: 'green' }, 'sm') +
          '<span style="min-width:0"><b class="small">' + esc(p ? p.name : t.user) + '</b>' +
          '<span class="tiny muted" style="display:block">' + esc(p ? SEVE.flows.roleLabel(p) : '') + (p && p.city ? ' · ' + esc(p.city) : '') + '</span></span></div></td>' +
          '<td><span class="chip chip--sm' + (tp.urgent ? ' chip--danger' : '') + '">' + icon(tp.icon || 'message', 12) + '<span>' + esc(tp.label || t.topic) + '</span></span>' +
          (tp.urgent ? '<span class="tiny" style="display:block;color:var(--danger);margin-top:4px">prioritaire</span>' : '') + '</td>' +
          '<td><span class="small clamp-2" style="display:block;max-width:420px">' + esc(String(d.text || '').slice(0, 160)) + '</span>' +
          '<span class="tiny muted">' + (d.from === 'team' ? 'dernier mot : équipe' : 'dernier mot : membre') + '</span></td>' +
          '<td class="small muted">' + U.fmtRelative(t.updated || t.created) + '</td>' +
          '<td>' + esc(t.referent || '—') + '</td>' +
          '<td>' + ui.pill(st.label, st.variant) + '</td>' +
          '<td><div class="cell-actions">' + ui.btn({ label: 'Ouvrir', variant: 'outline', size: 'xs', act: 'admin-help-open', data: { id: t.id } }) + '</div></td>' +
          '</tr>';
      }).join('');

      return '' +
        '<div class="page-head"><div>' +
        '<span class="kicker">Écoute des membres</span>' +
        '<h1>Messages à l’équipe</h1>' +
        '<p class="lede small">Un message non répondu est un membre qui doute. Cette page se lit de haut en bas : les sujets sensibles d’abord, ' +
        'puis les plus anciens. Chaque fil a un référent nommé, et le membre voit ce nom.</p>' +
        '</div><div class="row gap-10" style="flex-wrap:wrap">' +
        ui.btn({ label: 'Guide public', variant: 'ghost', href: '#/chargebacks', icon: 'scale' }) +
        ui.btn({ label: 'Vigilance des profils', variant: 'outline', href: '#/admin/profiles', icon: 'eye' }) +
        '</div></div>' +

        '<div class="kpis mt-20">' +
        ui.kpi({ icon: 'message', label: 'Fils ouverts', value: String(s.total), foot: '<span class="muted">Tous les échanges membre ↔ équipe</span>' }) +
        ui.kpi({ icon: 'alert', label: 'Sans réponse', value: String(s.enAttente), foot: '<span class="muted">Le dernier message vient du membre</span>' }) +
        ui.kpi({ icon: 'shield', label: 'Sujets prioritaires', value: String(s.sensibles), foot: '<span class="muted">Malaise ou collaboration qui se passe mal</span>' }) +
        ui.kpi({ icon: 'clock', label: 'Délai de première réponse', value: s.delaiMoyen === null ? '—' : s.delaiMoyen + ' h', foot: '<span class="muted">Objectif : moins de 4 h ouvrées</span>' }) +
        ui.kpi({ icon: 'heart', label: 'Accompagnement renforcé', value: String(s.accompagnes), foot: '<span class="muted">Point hebdomadaire tenu par un référent</span>' }) +
        '</div>' +

        '<div class="filterbar mt-24" data-filters><div class="filters">' +
        '<label class="filter filter--wide"><span class="label">Rechercher</span>' +
        '<input class="input" id="adm-hq" type="search" data-filter="q" value="' + esc(q) + '" placeholder="Nom du membre, mot dans la conversation, référent…"></label>' +
        SEVE.components.chipsHTML({ key: 'topic', label: 'Sujet', value: topic,
          options: [['all', 'Tous les sujets']].concat(store.TEAM_TOPICS().map((t) => [t.id, t.label])) }) +
        SEVE.components.chipsHTML({ key: 'status', label: 'Statut', value: status,
          options: [['all', 'Tous les statuts']].concat(Object.keys(store.TEAM_STATUS).map((k) => [k, store.TEAM_STATUS[k].label])) }) +
        '</div></div>' +

        '<div class="panel mt-20"><div class="table-wrap"><table class="table">' +
        '<thead><tr><th>Membre</th><th>Sujet</th><th>Dernier message</th><th>Depuis</th><th>Référent</th><th>Statut</th><th></th></tr></thead>' +
        '<tbody>' + (trs || '<tr><td colspan="7"><p class="small muted" style="padding:12px 0">Aucun message ne correspond à ce filtre. C’est une bonne nouvelle.</p></td></tr>') + '</tbody>' +
        '</table></div></div>' +

        '<div class="grid grid--2 mt-24" style="align-items:start">' +
        ui.panel({ title: 'Liste de vigilance', icon: 'eye', body:
          '<p class="small muted">Membres qui ont demandé une pause, un mode discret ou un accompagnement renforcé — plus ceux dont le dernier message est sans réponse.</p>' +
          '<div class="table-wrap mt-12"><table class="table"><thead><tr><th>Membre</th><th>Réglages</th><th>Litiges</th><th>Dernier échange</th></tr></thead><tbody>' +
          (store.profiles().filter((p) => {
            const cc = store.care(p.id);
            const th = store.teamThreads({ user: p.id })[0];
            return cc.pause || cc.discret || cc.accompagnement === 'renforce' || (th && th.status === 'nouveau');
          }).slice(0, 12).map((p) => {
            const cc = store.care(p.id);
            const th = store.teamThreads({ user: p.id })[0];
            const tags = [];
            if (cc.pause) { tags.push('<span class="chip chip--sm chip--warn">En pause</span>'); }
            if (cc.discret) { tags.push('<span class="chip chip--sm chip--outline">Discret</span>'); }
            if (cc.accompagnement === 'renforce') { tags.push('<span class="chip chip--sm chip--green">Renforcé</span>'); }
            if (th && th.status === 'nouveau') { tags.push('<span class="chip chip--sm chip--danger">Sans réponse</span>'); }
            return '<tr><td><b class="small">' + esc(p.name) + '</b><span class="tiny muted" style="display:block">' + esc(p.role === 'creator' ? 'Créateur' : 'Manager') + '</span></td>' +
              '<td><div class="chips">' + tags.join('') + '</div></td>' +
              '<td class="small">' + store.disputes({ owner: p.id }).length + '</td>' +
              '<td class="small muted">' + (th ? U.fmtRelative(th.updated || th.created) : '—') + '</td></tr>';
          }).join('') || '<tr><td colspan="4" class="small muted">Personne à surveiller.</td></tr>') +
          '</tbody></table></div>' }) +

        ui.panel({ title: 'Posture attendue dans une réponse', icon: 'scale', body:
          '<ul class="prudence">' + [
            { i: '1', t: 'Répondre à la personne, pas au dossier : la nommer, reconnaître ce qu’elle a écrit, puis expliquer.' },
            { i: '2', t: 'Aucune promesse de résultat — « nous faisons » plutôt que « ce sera réglé ».' },
            { i: '3', t: 'Aucune question sur le contenu de sa page, ses revenus ou sa vie privée au-delà du nécessaire.' },
            { i: '4', t: 'Toujours laisser une décision à sa main : deux options, ou la possibilité de ne rien décider tout de suite.' },
            { i: '5', t: 'Écrire la réponse avant de classer : un fil n’est jamais clos sans un mot humain.' }
          ].map((x) => '<li><span>' + x.i + '</span><div>' + esc(x.t) + '</div></li>').join('') + '</ul>' }) +
        '</div>';
    },
    mount(ctx) {
      if (SEVE.components && SEVE.components.bindFilters) { SEVE.components.bindFilters(ctx.root, '/admin/help'); }
    }
  };

  /* ==================================================================== */
  /* Fenêtre « Parler à l’équipe » — accessible depuis n’importe où        */
  /* ==================================================================== */
  SEVE.flows.teamHelpModal = function (sujetDeDepart) {
    let topic = sujetDeDepart || 'question';
    const me = store.me();
    const t = store.myTeamThread(false);
    const dejaOuvert = !!t;

    const body = '' +
      (dejaOuvert
        ? '<div class="banner banner--soft">' + icon('info', 18) + '<div>Vous avez déjà un fil avec l’équipe' +
          (t.referent ? ' — ' + esc(t.referent) + ' le suit' : '') + '. Votre message s’ajoutera à la suite : ' +
          '<a href="#/app/team" data-act="cancel-then-goto" data-href="#/app/team">voir la conversation</a>.</div></div>'
        : '<div class="banner banner--soft">' + icon('heart', 18) + '<div><strong>Vous écrivez à des personnes.</strong> ' +
          'Une référente vous est attribuée dès ce message, et vous saurez son nom. Rien de ce que vous écrivez ici n’est partagé avec un manager ou un membre.</div></div>') +
      '<div class="fabrecap mt-16"><span class="teamavatar">' + icon('headset', 17) + '</span>' +
      '<span><b>À : Équipe Sève — bureau de l’administration</b>' +
      '<em>Message privé. Visible uniquement par les personnes de l’équipe qui traitent les demandes d’aide — jamais par un manager, une agence ou un autre membre.</em></span></div>' +
      '<div class="mt-16"><label class="label">Pourquoi écrivez-vous ?</label>' + sujetsChips(topic) + '</div>' +
      '<div class="field mt-16"><label class="label" for="quick-team">Votre message</label>' +
      '<textarea class="textarea" id="quick-team" rows="5" placeholder="Même trois lignes suffisent. Dites-nous ce qui se passe, et ce que vous attendez de nous."></textarea></div>' +
      '<p class="tiny muted mt-12">' + icon('lock', 12) + ' Aucune donnée bancaire n’est demandée. Le message part dès l’envoi et apparaît dans Administration → Messages à l’équipe ; vous recevez un accusé de réception avec le nom de votre référente.</p>';

    ui.modal({
      title: 'Parler à l’équipe',
      subtitle: me ? 'Réponse d’une personne, jamais d’un robot.' : '',
      size: 'lg',
      body: body,
      footer: ui.btn({ label: 'Plus tard', variant: 'ghost', act: 'cancel' }) +
        ui.btn({ label: 'Envoyer maintenant', variant: 'primary', act: 'team-quick-send', icon: 'send' }),
      onMount(panel) {
        panel.querySelector('[data-act="cancel"]').addEventListener('click', () => ui.close());
        panel.querySelector('[data-act="team-quick-send"]').addEventListener('click', () => {
          const ta = panel.querySelector('#quick-team');
          const texte = (ta.value || '').trim();
          if (texte.length < 10) { ui.fieldError(ta, 'Encore quelques mots : nous avons besoin de comprendre ce qui se passe.'); return; }
          const btn = panel.querySelector('[data-act="team-quick-send"]');
          ui.loading(btn, true, 'Envoi…');
          setTimeout(() => {
            const fil = envoyer(texte, topic);
            ui.loading(btn, false);
            ui.close();
            if (!fil) { ui.toast('Envoi impossible pour le moment.', 'err'); return; }
            apresEnvoi(fil);
            if (SEVE.router.path && SEVE.router.path().indexOf('/app/team') === 0) { SEVE.router.refresh(); }
          }, 600);
        });
      }
    });
  };

  /* Actions de la fenêtre partagées avec la page */
  SEVE.act('team-topic', function (el) {
    const zone = el.closest('#team-topics, .modal__body');
    if (!zone) { return; }
    zone.querySelectorAll('[data-topic]').forEach((b) => { b.classList.remove('is-on', 'chip--green'); });
    el.classList.add('is-on', 'chip--green');
  });

  SEVE.act('team-quick', function (el) {
    const topic = el.getAttribute('data-topic') || 'question';
    const ta = document.querySelector('#team-input');
    if (ta) {
      ta.focus();
      const zone = document.querySelector('#team-topics');
      if (zone) {
        zone.querySelectorAll('[data-topic]').forEach((b) => {
          const on = b.getAttribute('data-topic') === topic;
          b.classList.toggle('is-on', on);
          b.classList.toggle('chip--green', on);
        });
      }
      ta.placeholder = 'Écrivez-nous sur : ' + ((store.teamTopic(topic) || {}).label || 'ce sujet').toLowerCase();
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    SEVE.flows.teamHelpModal(topic);
  });

  SEVE.act('team-focus', function () {
    const ta = document.querySelector('#team-input');
    if (ta) { ta.focus(); ta.scrollIntoView({ block: 'center', behavior: 'smooth' }); }
  });

  /* Depuis le tableau de bord : compose directement dans le coin bien-être.
     La démonstration partage le même fil local que /app/team et /admin/help. */
  SEVE.act('bienetre-envoyer', function () {
    const ta = document.querySelector('#bienetre-message');
    if (!ta) { return; }
    const texte = (ta.value || '').trim();
    if (texte.length < 10) {
      ui.fieldError(ta, 'Écrivez quelques mots de plus pour que l’on comprenne votre message.');
      ta.focus();
      return;
    }
    const fil = store.sendTeamMessage({ text: texte, topic: 'soutien', context: 'coin-bien-etre' });
    if (!fil) { ui.toast('Votre message n’a pas pu être enregistré.', 'err'); return; }
    ta.value = '';
    ui.toast('Message ajouté à votre conversation de démonstration. Vous pouvez le relire dans « Parler à l’équipe ». En ligne, une messagerie serveur sera nécessaire pour qu’une équipe réelle le reçoive.', 'ok');
    SEVE.router.refresh();
  });

  SEVE.act('team-send', function () {
    const ta = document.querySelector('#team-input');
    if (!ta) { return; }
    const texte = (ta.value || '').trim();
    if (texte.length < 10) { ui.fieldError(ta, 'Encore quelques mots : nous avons besoin de comprendre ce qui se passe.'); return; }
    const fil = envoyer(texte, sujetSelectionne());
    if (!fil) { ui.toast('Envoi impossible pour le moment.', 'err'); return; }
    ta.value = '';
    apresEnvoi(fil);
    SEVE.router.refresh();
  });

  /* Bouton flottant : présent partout dans l’espace membre */
  /* Le bouton de soutien ouvre la fenêtre sur le sujet « j’ai besoin de parler » :
     le délai annoncé au membre est alors de 1 heure ouvrée. */
  SEVE.act('team-help', function () {
    if (!store.isAuthed()) {
      /* Sans compte, on explique où l’on va : la connexion mène directement au fil. */
      ui.toast('Connectez-vous : votre message part ensuite dans la conversation privée avec l’équipe.', 'info');
      SEVE.router.navigate('/login?next=' + encodeURIComponent('/app/team'));
      return;
    }
    if (store.currentUser().role === 'admin') { return; }
    SEVE.flows.teamHelpModal('soutien');
  });

  /* ==================================================================== */
  /* Réglages du confort                                                   */
  /* ==================================================================== */
  SEVE.act('care-toggle', SEVE.flows.sure(function (el) {
    const cle = el.getAttribute('data-key');
    const avant = store.care();
    const apres = !avant[cle];
    store.saveCare({ [cle]: apres });
    if (cle === 'pause') {
      ui.toast(apres
        ? 'Pause activée : plus de nouvelles demandes, vos conversations restent ouvertes.'
        : 'Vous êtes de nouveau visible. Bon retour — rien n’a été perdu.', 'ok');
    } else {
      ui.toast(apres ? 'Mode discret activé : vous sortez des résultats publics.' : 'Mode discret désactivé : vous réapparaissez dans les résultats.', 'ok');
    }
    SEVE.router.refresh();
  }));

  SEVE.act('care-rythme', SEVE.flows.sure(function (el) {
    store.saveCare({ rythme: el.getAttribute('data-key') });
    ui.toast('Rythme enregistré : ' + store.CARE_RYTHME[el.getAttribute('data-key')].label.toLowerCase() + '.', 'ok');
    SEVE.router.refresh();
  }));

  SEVE.act('care-accompagnement', SEVE.flows.sure(function (el) {
    const cle = el.getAttribute('data-key');
    store.saveCare({ accompagnement: cle });
    ui.toast(cle === 'renforce'
      ? 'Accompagnement renforcé activé : une référente prend de vos nouvelles chaque semaine.'
      : 'Accompagnement standard : nous répondons quand vous écrivez.', 'ok');
    SEVE.router.refresh();
  }));

  SEVE.act('care-callback', SEVE.flows.sure(function () {
    const slot = document.querySelector('#care-slot');
    const choix = slot ? slot.value : 'matin';
    const libelle = { matin: 'plutôt le matin', apresmidi: 'plutôt l’après-midi', soir: 'plutôt en fin de journée' }[choix] || 'quand vous pouvez';
    const fil = envoyer('Bonjour, je préfère être appelée : ' + libelle + '. Je suis disponible sur un créneau de 20 minutes, et je ne souhaite pas préparer de document.', 'appel');
    if (!fil) { ui.toast('Envoi impossible pour le moment.', 'err'); return; }
    ui.toast('Demande d’appel envoyée. ' + fil.referent + ' vous propose deux créneaux.', 'ok');
    SEVE.router.refresh();
  }));

  /* ==================================================================== */
  /* Côté administration : lire, répondre, suivre                          */
  /* ==================================================================== */
  function ouvrirFil(id) {
    const t = store.teamThreadById(id);
    if (!t) { return; }
    const p = store.get(t.user);
    const tp = store.teamTopic(t.topic) || {};
    const st = store.TEAM_STATUS[t.status];

    ui.modal({
      title: p ? p.name : t.user,
      subtitle: (tp.label || '') + ' · ' + (t.referent ? 'référent : ' + t.referent : 'aucun référent') + ' · ' + st.hint,
      size: 'lg',
      body: '' +
        '<div class="care-thread" id="admin-thread">' + bulles(t.messages) + '</div>' +
        '<div class="field mt-16"><label class="label" for="admin-reply">Votre réponse</label>' +
        '<textarea class="textarea" id="admin-reply" rows="5" placeholder="Nommez la personne, reprenez ce qu’elle a écrit, dites ce que vous faites. Aucune promesse de résultat."></textarea></div>' +
        '<div class="row gap-10 mt-12" style="flex-wrap:wrap;align-items:center">' +
        '<select class="select" id="admin-referent" style="max-width:200px">' +
        ['Élise', 'Nadia', 'Sofia', 'Marc'].map((r) => '<option' + (t.referent === r ? ' selected' : '') + '>' + r + '</option>').join('') +
        '</select>' +
        '<select class="select" id="admin-status" style="max-width:200px">' +
        /* On répond : le fil passe donc à « Répondu » par défaut, modifiable. */
        Object.keys(store.TEAM_STATUS).map((k) => {
          const choisi = t.status === 'nouveau' ? k === 'repondu' : t.status === k;
          return '<option value="' + k + '"' + (choisi ? ' selected' : '') + '>' + esc(store.TEAM_STATUS[k].label) + '</option>';
        }).join('') +
        '</select>' +
        '<span class="tiny muted">' + icon('clock', 12) + ' Délai annoncé au membre : ' + esc(store.teamDelay(t.topic)) + '</span>' +
        '</div>' +
        '<div class="mt-16"><p class="tiny muted">' + icon('scale', 12) + ' Rappel de posture : répondre à la personne, jamais promettre un résultat, et toujours laisser une décision à sa main.</p></div>',
      footer: ui.btn({ label: 'Fermer', variant: 'ghost', act: 'cancel' }) +
        ui.btn({ label: 'Prendre en charge', variant: 'outline', act: 'admin-help-status', data: { id: t.id, status: 'pris_en_charge' } }) +
        ui.btn({ label: 'Envoyer la réponse', variant: 'primary', act: 'admin-help-reply', data: { id: t.id }, icon: 'send' }),
      onMount(panel) {
        panel.querySelector('[data-act="cancel"]').addEventListener('click', () => ui.close());
        panel.querySelector('[data-act="admin-help-status"]').addEventListener('click', (e) => {
          const referent = (panel.querySelector('#admin-referent') || {}).value;
          store.setTeamStatus(t.id, 'pris_en_charge', referent);
          ui.toast('Fil pris en charge' + (referent ? ' par ' + referent : '') + '.', 'ok');
          ui.close();
          SEVE.router.refresh();
        });
        panel.querySelector('[data-act="admin-help-reply"]').addEventListener('click', () => {
          const ta = panel.querySelector('#admin-reply');
          const texte = (ta.value || '').trim();
          if (texte.length < 10) { ui.fieldError(ta, 'Dix caractères minimum : le membre doit sentir qu’une personne a lu.'); return; }
          const referent = (panel.querySelector('#admin-referent') || {}).value || 'Élise';
          const status = (panel.querySelector('#admin-status') || {}).value || 'repondu';
          const btn = panel.querySelector('[data-act="admin-help-reply"]');
          ui.loading(btn, true, 'Envoi…');
          setTimeout(() => {
            store.replyTeamThread(t.id, { text: texte, referent: referent, status: status });
            ui.loading(btn, false);
            ui.close();
            ui.toast('Réponse envoyée à ' + (p ? p.name : 'ce membre') + '. Le fil est à jour.', 'ok');
            SEVE.router.refresh();
          }, 600);
        });
      }
    });
    const fil = document.querySelector('#admin-thread');
    if (fil) { fil.scrollTop = fil.scrollHeight; }
  }

  SEVE.act('admin-help-open', function (el) { ouvrirFil(el.getAttribute('data-id')); });
  SEVE.act('admin-help-status', function (el) {
    const id = el.getAttribute('data-id');
    const status = el.getAttribute('data-status') || 'pris_en_charge';
    store.setTeamStatus(id, status);
    ui.toast('Statut mis à jour.', 'ok');
    SEVE.router.refresh();
  });
})();
