/* ==========================================================================
   Sève — « Mon compte OnlyFans » (espace créateur)
   --------------------------------------------------------------------------
   Trois écrans : vue d’ensemble (statistiques + flux en direct), publications
   (composer et suivre), tarifs (abonnement, ventes à l’unité, estimation).

  Honnêteté du dispositif : OnlyFans ne propose pas d’API publique. Sève ne se
  connecte donc pas au compte et ne demande jamais de mot de passe. Ce qui
  fonctionne vraiment : la créatrice relie son compte à Sève avec un code à six
  chiffres qu’elle choisit, saisit ses chiffres (ou colle un relevé CSV), et
  Sève les conserve sur le serveur, calcule ses séries, ses moyennes et ses
  estimations. Tant qu’aucun relevé n’existe, les écrans affichent un aperçu de
  démonstration — et le disent en clair.
   ========================================================================== */
(function () {
  const U = SEVE.util;
  const ui = SEVE.ui;
  const store = SEVE.store;
  const C = SEVE.components;
  const OF = SEVE.of;
  const icon = SEVE.icons.svg;

  SEVE.views = SEVE.views || {};

  const ONGLETS = [
    { id: 'apercu', label: 'Vue d’ensemble', href: '#/app/of' },
    { id: 'publications', label: 'Publications', href: '#/app/of/publications' },
    { id: 'tarifs', label: 'Tarifs', href: '#/app/of/tarifs' }
  ];

  function onglets(actif) {
    return '<div class="tabs mt-20">' + ONGLETS.map((o) =>
      '<a class="tab' + (o.id === actif ? ' is-active' : '') + '" href="' + o.href + '">' + o.label + '</a>').join('') + '</div>';
  }

  function tete(titre, texte, actions) {
    return '<div class="page-head"><div><h1>' + U.esc(titre) + '</h1><p>' + U.esc(texte) + '</p></div>' +
      (actions ? '<div class="row gap-10" style="flex-wrap:wrap">' + actions + '</div>' : '') + '</div>';
  }

  /* Le code de démonstration : six chiffres, stables pour un pseudo donné. */
  function codeDemo(pseudo) {
    const n = Math.floor(OF.grain('code', String(pseudo || 'demo').toLowerCase()) * 900000) + 100000;
    return String(n).slice(0, 6);
  }

  /** « 16 octobre 2026 · il y a 2 h » pour les publications récentes, la date seule au-delà. */
  function quand(iso) {
    const rel = U.fmtRelative(iso);
    return /\d{4}/.test(rel) ? rel : U.fmtDate(iso) + ' · ' + rel;
  }

  function visLabel(p) {
    if (p.visibility === 'ppv') return 'payant · ' + OF.euros(p.price);
    if (p.visibility === 'custom') return 'sur commande';
    if (p.visibility === 'gratuit') return 'aperçu public';
    return 'inclus abonnés';
  }

  /* ================================================================== */
  /* 1. VUE D’ENSEMBLE                                                   */
  /* ================================================================== */
  SEVE.views.ofAccount = {
    title: 'Mon compte OnlyFans',
    render() {
      const acc = store.ofAccount();
      const dem = store.ofDemo();

      if (!acc.connected) {
        return tete('Mon compte OnlyFans',
          'Relie ton compte à Sève : tu saisis tes chiffres, Sève les garde, les calcule et te dit où tu en es.',
          '') + onglets('apercu') +
          '<section class="card card--pad reveal mt-20" style="max-width:660px">' +
          '<h3>Relier ton compte</h3>' +
          '<p class="small muted mt-8">Sève ne se connecte pas à OnlyFans : aucun mot de passe, aucun script sur ta page — c’est interdit par les conditions d’usage et ça te mettrait en danger. Ce que tu fais ici : tu relies ton compte à Sève avec un <b>code à six chiffres que tu choisis</b>, puis tu saisis tes chiffres quand tu veux. Sève les calcule, les garde pour toi et te prévient quand quelque chose décroche.</p>' +
          '<form id="of-form" novalidate class="mt-16">' +
          '<div class="field"><label class="label" for="of-user">Ton identifiant OnlyFans <span class="req">*</span></label>' +
          '<input class="input" id="of-user" value="' + U.esc(dem.username ? '@' + dem.username : '') + '" placeholder="@tonpseudo" autocomplete="off" spellcheck="false"></div>' +
          '<div class="field mt-12"><label class="label" for="of-code">Ton code de relevé (6 chiffres) <span class="req">*</span></label>' +
          '<input class="input" id="of-code" inputmode="numeric" maxlength="6" placeholder="6 chiffres" autocomplete="off">' +
          '<p class="help">Choisis-le toi-même : il protège tes relevés, et Sève n’en garde qu’une empreinte — jamais le code lui-même. Il n’a rien à voir avec ton mot de passe OnlyFans.</p></div>' +
          '<div class="row gap-10 mt-16" style="flex-wrap:wrap">' +
          ui.btn({ label: 'Relier mon compte', variant: 'primary', act: 'of-connect', icon: 'link' }) +
          ui.btn({ label: 'Voir avec des chiffres d’exemple', variant: 'outline', act: 'of-demo-connect' }) +
          '</div></form></section>' +

          '<section class="mt-20" style="max-width:660px">' +
          ui.fold({ label: 'Pourquoi Sève ne te demande jamais ton mot de passe OnlyFans', bare: true, html:
            '<p class="small muted">OnlyFans ne met aucune interface à disposition des outils extérieurs. Pour lire un compte, il faudrait donc passer par un procédé détourné (mot de passe partagé, script sur ta page) : c’est interdit par les conditions d’usage du site et ça t’exposerait, toi. Sève ne le fera pas.</p>' +
            '<p class="small muted mt-8">Ce qui <b>fonctionne</b> vraiment ici : ton tableau de bord Sève garde tes chiffres, calcule tes séries (vues, abonnés, revenus), t’alerte quand ça décroche, et prépare ton accompagnement avec l’équipe. Ce qui reste à OnlyFans : publier, répondre, encaisser. Ce qui viendra plus tard : lire le compte automatiquement, dès qu’OnlyFans ouvrira un accès officiel — la page se branchera dessus sans que tu aies à réapprendre l’écran.</p>' }) +

          ui.fold({ label: 'Où trouver ces chiffres sur OnlyFans (2 minutes)', bare: true, html:
            '<ul class="stack gap-8 small muted mt-8">' +
            '<li><b>Abonnés</b> — page d’accueil de ton tableau de bord, en haut (« Fans » / « Abonnés »).</li>' +
            '<li><b>Vues et interactions</b> — Statistiques, période « 30 derniers jours ».</li>' +
            '<li><b>Revenus</b> — Statistiques puis Revenus : prends le net de la journée, ou exporte le tableau (CSV) et colle-le ici.</li>' +
            '<li>Un relevé par semaine suffit pour suivre une tendance ; un relevé par jour rend l’alerte de décrochage plus fine.</li>' +
            '</ul>' }) +
          '</section>';
      }

      const st = store.ofStats();
      const plan = acc.plan || OF.DEMO.plan;
      const est = store.ofEstimation();
      const serveur = acc.serveur || {};

      return tete('Mon compte OnlyFans',
        '@' + acc.username + ' · ' + (st.reel
          ? 'dernier relevé ' + U.fmtDate(st.releveLe)
          : (st.vide ? 'aucun chiffre saisi pour l’instant' : 'relié ' + U.fmtRelative(acc.connectedAt))),
        ui.btn({ label: 'Synchroniser', variant: 'outline', act: 'of-sync', icon: 'refresh' })) +
        onglets('apercu') +

        '<div class="mt-20">' + ui.banner(
          st.reel
            ? { variant: 'ok', icon: 'checkCircle',
                html: '<b>Chiffres que tu as saisis.</b> ' + st.jours + ' relevé' + (st.jours > 1 ? 's' : '') +
                  ' enregistré' + (st.jours > 1 ? 's' : '') + ' — le dernier le ' + U.fmtDate(st.releveLe) + '. Sève ne lit rien à ta place : tout vient de toi.<br>' +
                  (serveur.ok
                    ? '<span class="small">Conservé <b>sur le serveur</b> — tu les retrouves depuis un autre appareil. Dernière écriture ' + U.fmtRelative(serveur.at) + '.</span>'
                    : '<span class="small">Conservé <b>dans ce navigateur</b> pour l’instant. ' + (serveur.detail ? U.esc(serveur.detail) + ' ' : '') + 'Aucune donnée n’a quitté ton appareil.</span>') }
            : (st.vide
              ? { variant: 'soft', icon: 'info',
                  html: '<b>Aucun chiffre pour l’instant.</b> Ton compte est relié, mais tu n’as encore rien saisi : Sève n’invente rien, donc les cases restent vides jusqu’à ton premier relevé. Recopie les chiffres de ton tableau de bord OnlyFans juste en dessous (deux minutes) : tout se remplit tout de suite après.' }
              : { variant: 'soft', icon: 'info',
                  html: '<b>Aperçu de démonstration.</b> Aucun relevé n’est encore enregistré : les chiffres ci-dessous sont un exemple, pas ton compte. Saisis ton premier relevé plus bas et ils deviennent les tiens.' })
        ) + '</div>' +

        /* ---------------------------------- Chiffres ---------------------------------- */
        '<div id="of-kpis" class="kpis mt-16">' + kpis(st) + '</div>' +

        /* --------------------------- Remplissage automatique -------------------------- */
        sectionDepot(acc, st) +

        /* ----------------------------------- Relevés ---------------------------------- */
        sectionReleves(acc, st) +

        /* --------------------------------- Graphiques --------------------------------- */
        (st.jours > 1 ? '<div class="dash-grid dash-grid--2 mt-16">' +
          '<section class="panel reveal"><div class="panel__head"><h3>' + icon('eye', 16) + 'Vues</h3>' +
          '<span class="tiny muted tnum">' + U.fmtNum(st.vues30) + ' sur ' + Math.min(30, st.jours) + ' j</span></div>' +
          '<div class="panel__body">' + ui.sparkline(st.serieVues.map((d) => d.valeur), { height: 74 }) +
          '<div class="between mt-8"><span class="tiny muted">' + U.fmtDate(st.serieVues[0].jour) + '</span><span class="tiny muted">' + U.fmtDate(st.serieVues[st.serieVues.length - 1].jour) + '</span></div></div></section>' +
          '<section class="panel reveal"><div class="panel__head"><h3>' + icon('wallet', 16) + 'Revenus</h3>' +
          '<span class="tiny muted tnum">' + OF.euros0(st.revenus30) + ' sur 30 j</span></div>' +
          '<div class="panel__body">' + ui.bars(st.serieRevenus.map((d) => ({
            label: d.jour.slice(8) + '/' + d.jour.slice(5, 7), value: d.valeur,
            display: U.fmtNum(d.valeur) + ' €'
          }))) + '</div></section>' +
          '</div>' : '') +

        (st.reel || st.vide ? '' : '<div class="dash-grid dash-grid--2 mt-16">' +
          '<section class="panel reveal"><div class="panel__head"><h3>' + icon('eye', 16) + 'Vues — 30 derniers jours</h3>' +
          '<span class="tiny muted tnum">' + U.fmtNum(st.vues30) + ' au total</span></div>' +
          '<div class="panel__body">' + ui.sparkline(st.serieVues.map((d) => d.valeur), { height: 74 }) +
          '<div class="between mt-8"><span class="tiny muted">il y a 30 jours</span><span class="tiny muted">aujourd’hui · ' + U.fmtNum(st.vuesJour) + '</span></div></div></section>' +
          '<section class="panel reveal"><div class="panel__head"><h3>' + icon('wallet', 16) + 'Revenus — 14 derniers jours</h3>' +
          '<span class="tiny muted tnum">' + OF.euros0(st.revenus30) + ' sur 30 j</span></div>' +
          '<div class="panel__body">' + ui.bars(st.serieRevenus.map((d) => ({
            label: d.jour.slice(8) + '/' + d.jour.slice(5, 7), value: d.valeur,
            display: U.fmtNum(d.valeur) + ' €'
          })).slice(-7)) + '</div></section>' +
          '</div>') +

        /* ------------------------------- Activité --------------------------------- */
        (st.vide
          ? '<section class="panel reveal mt-16" id="of-suivi"><div class="panel__head"><h3>' + icon('history', 16) + 'Ton suivi commence ici</h3></div>' +
            '<div class="panel__body"><p class="small muted">Ce que Sève fera de tes relevés, dès le premier jour : ' +
            'courbes de vues et d’abonnés, revenus jour par jour, moyenne sur 30 jours, alerte si la tendance décroche. ' +
            'Rien ne s’affiche avant que tu aies saisi tes chiffres — tu ne verras jamais ici un nombre que tu n’as pas écrit.</p></div></section>'
          : (st.reel
          ? '<section class="panel reveal mt-16" id="of-live"><div class="panel__head"><h3>' + icon('history', 16) + 'Tes derniers relevés</h3>' +
            '<span class="tiny muted">' + st.jours + ' jour' + (st.jours > 1 ? 's' : '') + ' enregistré' + (st.jours > 1 ? 's' : '') + '</span></div>' +
            '<div class="panel__body">' + historiqueReleves(st, 8) + '</div></section>'
          : '<section class="panel reveal mt-16" id="of-live">' +
            '<div class="panel__head"><h3>' + icon('zap', 16) + '<span class="dot dot--live"></span>En direct</h3>' +
            '<div class="row gap-10">' + ui.btn({
              label: acc.live ? 'Mettre en pause' : 'Reprendre', variant: 'outline', size: 'xs',
              act: 'of-live-toggle', icon: acc.live ? 'pause' : 'play'
            }) + '</div></div>' +
            '<div class="panel__body">' + fluxHTML() +
            '<p class="tiny muted mt-12">Exemple d’activité : ces événements sont fabriqués pour montrer l’écran. Ils disparaissent dès que tu saisis ton premier relevé — place aux vrais chiffres.</p>' +
            '</div></section>')) +

        /* ---------------------------------- Critères ---------------------------------- */
        '<div class="dash-grid dash-grid--2 mt-16">' +
        criteres() +
        '<section class="panel reveal"><div class="panel__head"><h3>' + icon('wallet', 16) + 'Tes tarifs</h3>' +
        ui.btn({ label: 'Modifier', variant: 'outline', size: 'xs', href: '#/app/of/tarifs', icon: 'edit' }) + '</div>' +
        '<div class="panel__body"><ul class="stack gap-8 small">' +
        '<li><span class="muted">Abonnement : </span>' + OF.euros(plan.monthly) + ' par mois</li>' +
        '<li><span class="muted">Contenu à l’unité : </span>' + OF.euros(plan.ppv) + '</li>' +
        '<li><span class="muted">Estimation indicative : </span>' + (est.total === null
          ? 'pas encore calculable — saisis d’abord ton nombre d’abonnés'
          : OF.euros0(est.total) + ' par mois à ce prix' + (st.reel ? ', sur la base de tes ' + U.fmtNum(st.abonnes) + ' abonnés relevés' : ' (exemple)')) + '</li>' +
        '</ul><p class="tiny muted mt-12">Une estimation n’est jamais une promesse : elle sert à comparer deux prix, pas à annoncer un revenu.</p></div></section>' +
        '</div>' +

        '<div class="mt-16">' + ui.fold({ label: 'Ce que Sève garde — et ce qu’elle ne fera jamais', bare: true, html:
          '<ul class="stack gap-8 small muted mt-8">' +
          '<li>' + icon('checkCircle', 14) + ' Gardé : tes relevés (abonnés, vues, interactions, revenus), tes tarifs, tes publications préparées.</li>' +
          '<li>' + icon('checkCircle', 14) + ' Modifiable par toi seule, à tout moment : tu peux retirer un relevé, une publication, ou décrocher ton compte ci-dessous.</li>' +
          '<li>' + icon('ban', 14) + ' Jamais : ton mot de passe OnlyFans, tes coordonnées bancaires, tes conversations privées avec tes abonnés.</li>' +
          '<li>' + icon('ban', 14) + ' Jamais : publier, répondre à un abonné ou envoyer un contenu sans ton clic — Sève n’a techniquement aucun accès à ton compte.</li>' +
          '<li>' + icon('ban', 14) + ' Jamais : toucher à ton argent. Tes gains arrivent sur <b>ton</b> compte bancaire, au nom vérifié chez OnlyFans, et la commission d’un manager se règle par virement direct entre vous deux (le relevé se prépare dans « Paiements & RIB »). Un compte au nom d’un tiers est refusé par OnlyFans et peut faire geler le tien.</li>' +
          '</ul>' })
          + '<div class="mt-12">' + ui.btn({ label: 'Décrocher mon compte (tes relevés restent)', variant: 'ghost', size: 'xs', act: 'of-deconnect', icon: 'logout' }) + '</div>'
          + '</div>';
    },
    mount(ctx) {
      demarrerDirect(ctx);
      brancherDepot(ctx);
      /* L'état du serveur dit si la boîte de dépôt est prête : s'il a changé,
         on redessine la page pour l'annoncer. */
      const avant = (SEVE.api.sante() || {}).depot_mail || '';
      SEVE.api.reglages().then((j) => {
        if (j && j.ok && ((j.depot_mail || '') !== avant)) { SEVE.router.refresh(); }
      });
      /* Compte relié sans le mode démonstration : on tente de retrouver les
         relevés enregistrés sur le serveur (autre appareil, autre navigateur). */
      const acc = store.ofAccount();
      if (acc.connected && acc.code && !acc.demo) { recharger(); }
    }
  };

  /* -------------------------- Saisie et suivi des relevés -------------------------- */
  /** Un champ chiffré du formulaire de relevé. */
  function champChiffre(id, label, aide, dernier) {
    return '<div class="field"><label class="label" for="' + id + '">' + label + '</label>' +
      '<input class="input" id="' + id + '" inputmode="numeric" autocomplete="off"' +
      (dernier ? ' placeholder="' + U.esc(String(dernier)) + '"' : '') + '>' +
      (aide ? '<p class="help">' + aide + '</p>' : '') + '</div>';
  }

  /**
   * Enregistre les chiffres d'un dépôt (fichier, lettre ou texte collé).
   * Le navigateur lit tout de suite ; le serveur reçoit la même copie pour
   * qu'elle se retrouve depuis un autre appareil. Rien n'est inventé : si
   * aucun chiffre n'est lisible, on le dit et on n'écrit rien.
   */
  function traiterDepot(texte, nom) {
    const source = OF.estLettre(texte) ? 'mail' : 'fichier';
    const jour = OF.jourDeLettre(texte);
    const lignes = OF.texteEnReleves(texte, jour, source);
    if (!lignes.length) {
      ui.toast('Rien de lisible dans ' + nom + ' : aucun chiffre n’a été enregistré. Sève n’invente pas.', 'err', { title: 'Rien à lire' });
      return 0;
    }
    const nb = store.ofReleveImporter(lignes, source);
    store.ofDepotMarquer({ source: source, jours: nb, ou: nom });
    ui.toast(nb + ' jour' + (nb > 1 ? 's' : '') + ' lu' + (nb > 1 ? 's' : '') + ' dans ' + nom + ' — rien à recopier.', 'ok', { title: 'C’est rempli' });
    SEVE.router.refresh();
    SEVE.api.depot(texte, { source: source, jour: jour }).then((r) => {
      if (r && r.ok) {
        store.ofMarquerServeur(true);
        ui.toast('Enregistré sur le serveur : tu le retrouveras depuis un autre appareil.', 'info');
      } else if (r && !r.hors_ligne && r.erreur) {
        ui.toast('Serveur : ' + r.erreur + ' Les chiffres restent sur cet appareil.', 'err');
      }
    });
    return nb;
  }

  /** Le dépôt d'un fichier : glisser-déposer ou choix dans l'explorateur. */
  function brancherDepot(ctx) {
    const zone = ctx.root.querySelector('#of-drop');
    const input = ctx.root.querySelector('#of-fichier');
    if (!zone || !input) { return; }

    const lireFichier = (f) => {
      if (!f) { return; }
      const lecteur = new FileReader();
      lecteur.onload = () => traiterDepot(String(lecteur.result || ''), f.name || 'ton fichier');
      lecteur.onerror = () => ui.toast('Ce fichier n’a pas pu être lu.', 'err');
      lecteur.readAsText(f, 'utf-8');
    };

    U.on(input, 'change', '#of-fichier', () => {
      lireFichier(input.files && input.files[0]);
      input.value = '';
    });
    ['dragenter', 'dragover'].forEach((ev) => zone.addEventListener(ev, (e) => {
      e.preventDefault();
      zone.classList.add('is-over');
    }));
    ['dragleave', 'drop'].forEach((ev) => zone.addEventListener(ev, (e) => {
      e.preventDefault();
      zone.classList.remove('is-over');
    }));
    zone.addEventListener('drop', (e) => {
      const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
      lireFichier(f);
    });
  }

  /** Les sources, dites en clair, pour que chaque chiffre soit situé. */
  function sourceTexte(src) {
    if (src === 'mail') { return 'relevée dans tes e-mails OnlyFans'; }
    if (src === 'fichier') { return 'lue dans ton fichier exporté'; }
    if (src === 'outil') { return 'envoyée par un outil que tu as branché'; }
    return 'saisie à la main';
  }

  function sourceCourte(src) {
    if (src === 'mail') { return 'e-mail'; }
    if (src === 'fichier') { return 'fichier'; }
    if (src === 'outil') { return 'outil'; }
    return 'saisie';
  }

  /**
   * Remplissage automatique : tout ce qui évite de recopier les chiffres.
   *   1. le dépôt d'un fichier exporté depuis le tableau de bord OnlyFans ;
   *   2. le collage d'un export ou d'une lettre OnlyFans ;
   *   3. le transfert automatique de ses e-mails, relevé par le serveur.
   * Aucun mot de passe OnlyFans n'est demandé, à aucun moment.
   */
  function sectionDepot(acc, st) {
    const depot = store.ofDepot();
    const cle = store.ofCleDepot();
    const boite = (SEVE.api.sante() || {}).depot_mail || '';

    return '<section class="panel reveal mt-16" id="of-depot">' +
      '<div class="panel__head"><h3>' + icon('folder', 16) + 'Remplissage automatique</h3>' +
      '<span class="tiny muted">' + (depot
        ? 'dernier dépôt ' + U.fmtRelative(depot.at) + ' — ' + depot.jours + ' jour' + (depot.jours > 1 ? 's' : '')
        : 'aucun dépôt pour l’instant') + '</span></div>' +
      '<div class="panel__body">' +
      '<p class="small muted">Sève ne se connecte jamais à ton compte OnlyFans : aucun mot de passe, aucun script sur ta page — c’est interdit par leurs conditions d’usage et ça exposerait ton compte. ' +
      'En revanche elle peut aller chercher tes chiffres toute seule par les deux voies qu’OnlyFans met vraiment à ta disposition : <b>tes fichiers exportés</b> et <b>tes e-mails</b>.</p>' +

      '<label class="dropzone mt-12" id="of-drop" for="of-fichier">' +
      icon('doc', 20) +
      '<b>Dépose ici ton export OnlyFans</b>' +
      '<span class="tiny muted">CSV, TXT ou une lettre OnlyFans (.eml) — ou clique pour choisir le fichier. Sève lit les lignes et remplit tes journées toute seule.</span>' +
      '<input type="file" id="of-fichier" accept=".csv,.txt,.eml,.tsv,text/plain,text/csv" hidden>' +
      '</label>' +

      ui.fold({ label: 'Ou colle ici ton export / ta lettre OnlyFans', bare: true, html:
        '<p class="small muted mt-8">Depuis ton tableau de bord OnlyFans : Statistiques → export, ou Revenus → export. Colle le contenu tel quel : Sève reconnaît aussi bien les lignes (une par jour) que les phrases (« Tu as 9 999 abonnés »).</p>' +
        '<textarea class="input mt-8" id="of-depot-texte" rows="5" spellcheck="false" placeholder="forme attendue (chiffres d’exemple) :&#10;jour;abonnes;revenus;vues;likes&#10;2026-10-10;9999;123,45;45678;6789&#10;— ou une phrase —&#10;« Tu as 9 999 abonnés. Revenus du jour : 123,45 € »"></textarea>' +
        '<div class="row gap-10 mt-12" style="flex-wrap:wrap">' +
        ui.btn({ label: 'Lire ces chiffres', variant: 'primary', act: 'of-depot-lire', icon: 'checkCircle' }) +
        ui.btn({ label: 'Coller ce que j’ai copié', variant: 'outline', act: 'of-depot-coller', icon: 'doc' }) +
        ui.btn({ label: 'Voir un exemple', variant: 'ghost', size: 'sm', act: 'of-depot-exemple', icon: 'info' }) +
        '</div>' }) +

      '<div class="mt-16">' + ui.fold({ label: 'Faire arriver mes e-mails OnlyFans tout seuls', bare: true, html:
        '<p class="small muted mt-8">' + (boite
          ? 'Crée une règle de transfert automatique dans ta boîte mail : « tout message venant de OnlyFans → <b>' + U.esc(boite) + '</b> ». Sève relève cette boîte toute seule, toutes les heures, et en sort tes chiffres. Tu arrêtes le transfert quand tu veux : ton compte OnlyFans et ton mot de passe ne sont jamais concernés.'
          : 'Le relevé automatique de la boîte e-mail n’est pas encore activé sur ce site : il demande une boîte de dépôt chez l’hébergeur (voir INSTALLATION-HOSTINGER.md, section « Dépôt automatique »). En attendant, dépose une lettre OnlyFans (.eml) juste au-dessus : elle est lue de la même façon.') +
        '</p>' +
        '<div class="mt-12"><span class="tiny muted">Ma clé de dépôt</span>' +
        (cle
          ? '<div class="row gap-10 mt-8" style="flex-wrap:wrap"><input class="input" id="of-cle" value="' + U.esc(cle) + '" readonly spellcheck="false" style="max-width:340px;font-family:ui-monospace,SFMono-Regular,Menlo,monospace">' +
            ui.btn({ label: 'Copier', variant: 'outline', size: 'sm', act: 'of-cle-copier' }) + '</div>' +
            '<p class="help">À garder pour toi : elle permet d’écrire des relevés, jamais d’en lire. Ne la donne qu’à un outil que tu as choisi.</p>'
          : '<div class="mt-8">' + ui.btn({ label: 'Créer ma clé de dépôt', variant: 'outline', size: 'sm', act: 'of-cle-creer', icon: 'key' }) +
            '<p class="help">Utile seulement si tu branches un outil extérieur : le dépôt de fichier ne demande aucune clé.</p></div>') +
        '</div>' }) + '</div>' +

      (depot ? '<p class="tiny muted mt-12">' + icon('checkCircle', 13) + ' Dernier dépôt ' + U.fmtRelative(depot.at) +
        ' : ' + depot.jours + ' jour' + (depot.jours > 1 ? 's' : '') + ' ' + (depot.source === 'mail' ? 'relevé' + (depot.jours > 1 ? 's' : '') + ' dans tes e-mails OnlyFans' : 'lu' + (depot.jours > 1 ? 's' : '') + ' dans ton fichier exporté') +
        '. Tu peux retirer un jour dans le tableau ci-dessous.</p>' : '') +
      '</div></section>';
  }

  function sectionReleves(acc, st) {
    const dernier = store.ofDernierReleve();
    const jourDefaut = new Date().toISOString().slice(0, 10);
    return '<section class="panel reveal mt-16" id="of-releves">' +
      '<div class="panel__head"><h3>' + icon('calendar', 16) + 'Ton relevé du jour</h3>' +
      '<span class="tiny muted">' + (st.jours ? st.jours + ' jour' + (st.jours > 1 ? 's' : '') + ' enregistré' + (st.jours > 1 ? 's' : '') : 'aucun relevé pour l’instant') + '</span></div>' +
      '<div class="panel__body">' +
      '<p class="small muted">Prends deux minutes sur ton tableau de bord OnlyFans, recopie les chiffres du jour, Sève s’occupe du reste (séries, moyennes, alertes de décrochage).</p>' +
      '<div class="grid mt-12" style="grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px">' +
      '<div class="field"><label class="label" for="of-jour">Jour</label>' +
      '<input class="input" id="of-jour" type="date" value="' + jourDefaut + '" max="' + jourDefaut + '"></div>' +
      champChiffre('of-abonnes', 'Abonnés', '', dernier ? dernier.abonnes : '') +
      champChiffre('of-revenus', 'Revenus du jour (€)', '', dernier ? dernier.revenus : '') +
      champChiffre('of-vues', 'Vues', '', dernier ? dernier.vues : '') +
      champChiffre('of-likes', 'J’aime', '', dernier ? dernier.likes : '') +
      '</div>' +
      '<div class="row gap-10 mt-12" style="flex-wrap:wrap">' +
      ui.btn({ label: 'Enregistrer ce relevé', variant: 'primary', act: 'of-releve', icon: 'checkCircle' }) +
      (dernier ? ui.btn({ label: 'Retirer le dernier', variant: 'ghost', size: 'sm', act: 'of-releve-del', data: { jour: dernier.jour }, icon: 'trash' }) : '') +
      '</div>' +
      ui.fold({ label: 'Où trouver ces chiffres sur OnlyFans, écran par écran', bare: true, html:
        '<ul class="stack gap-8 small muted mt-8">' +
        '<li><b>Abonnés</b> — en haut de ton tableau de bord OnlyFans (le total affiché, pas seulement les nouveaux).</li>' +
        '<li><b>Vues et j’aime</b> — Statistiques, période « 30 derniers jours » : prends le total à date, ou le chiffre du jour.</li>' +
        '<li><b>Revenus du jour (€)</b> — Statistiques puis Revenus : la ligne du jour, net tel qu’affiché. Si tu exportes le tableau, colle-le dans le champ ci-dessous.</li>' +
        '<li>Un relevé par semaine suffit pour voir une tendance ; un relevé par jour rend l’alerte de décrochage plus précise.</li>' +
        '</ul><p class="tiny muted mt-8">Recopie ce que tu lis, sans arrondir : plus tes chiffres sont proches de ton écran OnlyFans, plus ton suivi est juste.</p>' }) +
      ui.fold({ label: 'Coller un relevé complet (plusieurs jours d’un coup)', bare: true, html:
        '<p class="small muted mt-8">Depuis ton export OnlyFans ou ton tableur : une ligne par jour. En-tête facultatif, virgule ou point-virgule, dates en 2026-10-16 ou 16/10/2026.</p>' +
        '<textarea class="input mt-8" id="of-csv" rows="5" spellcheck="false" placeholder="jour;abonnes;revenus;vues;likes&#10;2026-10-10;87600;380,20;39000;6800&#10;2026-10-11;87700;402,10;39500;6900"></textarea>' +
        '<div class="row gap-10 mt-12" style="flex-wrap:wrap">' +
        ui.btn({ label: 'Importer ces jours', variant: 'outline', act: 'of-import', icon: 'folder' }) +
        '</div><p class="help">Un jour déjà enregistré est remplacé, jamais dupliqué. Rien n’est envoyé à OnlyFans : ce texte reste entre toi et Sève.</p>' }) +
      '</div></section>';
  }

  /** Les derniers relevés, en tableau compact, avec retrait possible. */
  function historiqueReleves(st, maxi) {
    const jours = store.ofReleves().slice(-(maxi || 8)).reverse();
    if (!jours.length) { return '<p class="small muted">Aucun relevé enregistré pour l’instant.</p>'; }
    return '<div class="table-wrap"><table class="table"><thead><tr>' +
      '<th>Jour</th><th>Abonnés</th><th>Revenus</th><th>Vues</th><th>J’aime</th><th></th>' +
      '</tr></thead><tbody>' + jours.map((r) =>
        '<tr><td>' + U.fmtDate(r.jour) + '<br><span class="tiny muted">' + sourceCourte(r.source) + '</span></td>' +
        '<td class="tnum">' + U.fmtNum(r.abonnes) + '</td>' +
        '<td class="tnum">' + OF.euros(r.revenus) + '</td>' +
        '<td class="tnum">' + U.fmtNum(r.vues) + '</td>' +
        '<td class="tnum">' + U.fmtNum(r.likes) + '</td>' +
        '<td class="cell-actions">' + ui.btn({ label: 'Modifier', variant: 'ghost', size: 'xs', act: 'of-releve-edit', data: { jour: r.jour }, icon: 'edit' }) +
        ui.btn({ label: 'Retirer', variant: 'ghost', size: 'xs', act: 'of-releve-del', data: { jour: r.jour }, icon: 'trash' }) + '</td></tr>').join('') +
      '</tbody></table></div>' +
      '<p class="tiny muted mt-8">Ce tableau est ton suivi : il reste à toi et n’est jamais partagé avec un manager sans ton accord.</p>';
  }

  function kpis(st) {
    /* Compte relié sans aucun relevé : des tirets, jamais des chiffres
       fabriqués. Une case vide dit la vérité ; un chiffre inventé la trahit. */
    if (st.vide) {
      return [
        ui.kpi({ label: 'Abonnés', value: '—', icon: 'users', foot: 'à saisir' }),
        ui.kpi({ label: 'Vues · 7 jours', value: '—', icon: 'eye', foot: 'à saisir' }),
        ui.kpi({ label: 'Interactions · 7 jours', value: '—', icon: 'trending', foot: 'à saisir' }),
        ui.kpi({ label: 'Revenus · 30 jours', value: '—', icon: 'wallet', foot: 'à saisir' })
      ].join('');
    }
    return [
      ui.kpi({ label: 'Abonnés', value: U.fmtK(st.abonnes), icon: 'users', foot: '+' + U.fmtNum(st.nouveaux30) + ' sur 30 jours' }),
      ui.kpi({ label: 'Vues · 7 jours', value: U.fmtK(st.vues7), icon: 'eye', foot: U.fmtK(st.vuesJour) + ' aujourd’hui' }),
      ui.kpi({ label: 'Interactions · 7 jours', value: U.fmtK(st.interactions7), icon: 'trending', foot: U.fmtK(st.likes30) + ' j’aime sur 30 jours' }),
      ui.kpi({ label: 'Revenus · 30 jours', value: OF.euros0(st.revenus30), icon: 'wallet', foot: OF.euros0(st.revenusJour) + ' aujourd’hui' })
    ].join('');
  }

  function fluxHTML() {
    const acc = store.ofAccount();
    const items = OF.flux(7);
    return '<div class="oflive' + (acc.live ? ' is-live' : '') + '" data-live-list>' + items.map((e) =>
      '<div class="liverow"><span class="liverow__icon">' + icon(e.icon, 15) + '</span>' +
      '<span class="liverow__body"><span>' + e.texte + '</span><em>' + U.esc(e.detail) + '</em></span>' +
      '<span class="tiny muted tnum">' + U.fmtTime(e.at) + '</span></div>').join('') + '</div>';
  }

  function criteres() {
    const me = store.me();
    const goals = (me.goals || []).slice(0, 2);
    const spe = SEVE.taxo.labels((me.specialties || []).slice(0, 3));
    return ui.panel({
      title: 'Tes critères de collaboration', icon: 'target',
      action: ui.btn({ label: 'Modifier', variant: 'outline', size: 'xs', href: '#/app/profile?tab=looking', icon: 'edit' }),
      body: '<ul class="stack gap-8 small">' +
        '<li><span class="muted">Objectifs : </span>' + U.esc(goals.join(' · ') || 'à préciser') + '</li>' +
        '<li><span class="muted">Points forts : </span>' + U.esc(spe.join(' · ') || 'à préciser') + '</li>' +
        '<li><span class="muted">Disponibilité : </span>' + U.esc(me.availability === 'active' ? 'disponible' : me.availability === 'paused' ? 'en pause' : 'à préciser') + '</li>' +
        '</ul><p class="tiny muted mt-12">Ces critères alimentent les recommandations et l’aide au matching. Tu peux les changer à tout moment : rien n’est figé.</p>'
    });
  }

  /* ================================================================== */
  /* 2. PUBLICATIONS                                                     */
  /* ================================================================== */
  SEVE.views.ofPosts = {
    title: 'Publications',
    render() {
      const acc = store.ofAccount();
      const posts = store.ofPosts();
      const locaux = posts.filter((p) => p.local).length;

      return tete('Publications',
        'Écris, joins tes photos, choisis qui les voit. Rien ne part sans ton clic — et tu peux tout retirer.',
        locaux ? ui.btn({ label: 'Publier sur OnlyFans', variant: 'outline', act: 'of-export', icon: 'arrowUpRight' }) : '') +
        onglets('publications') +

        '<div class="mt-20">' + ui.banner({
          variant: 'soft', icon: 'info',
          html: '<b>Démonstration.</b> Les photos que tu joins restent sur ton appareil : aucun envoi vers OnlyFans ni vers un serveur de Sève. Le compositeur montre exactement l’écran qui servira une fois la liaison officielle disponible.'
        }) + '</div>' +

        '<section class="card card--pad reveal mt-16">' +
        '<h3>Nouvelle publication</h3>' +
        '<form id="of-post" novalidate class="mt-12">' +
        '<div class="field"><label class="label" for="of-caption">Légende</label>' +
        '<textarea class="input" id="of-caption" rows="3" placeholder="Ce que tu veux dire à tes abonnés…"></textarea></div>' +
        '<div class="grid mt-12" style="grid-template-columns:repeat(auto-fit,minmax(220px,1fr))">' +
        '<div class="field"><span class="label">Qui peut voir</span>' +
        '<input type="hidden" id="of-vis" value="abonnes">' +
        '<div class="chips"><div class="chips__row" data-vis-row>' + [
          ['abonnes', 'Abonnés — inclus'], ['ppv', 'Payant à l’unité'],
          ['custom', 'Sur commande'], ['gratuit', 'Aperçu hors abonnement']
        ].map((o) => '<button type="button" class="chip chip--choice' + (o[0] === 'abonnes' ? ' is-on' : '') +
          '" data-vis="' + o[0] + '">' + o[1] + '</button>').join('') + '</div></div>' +
        '</div>' +
        '<div class="field"><label class="label" for="of-price">Prix de déblocage (€)</label>' +
        '<input class="input" id="of-price" type="number" min="3" max="200" step="0.5" value="' + acc.plan.ppv + '"></div>' +
        '</div>' +
        '<div class="field mt-12"><label class="label" for="of-files">Photos</label>' +
        '<input class="input" id="of-files" type="file" accept="image/*" multiple>' +
        '<div id="of-shots" class="ofshots mt-12"></div>' +
        '<p class="help">Aperçu local uniquement : les fichiers ne quittent pas ton appareil.</p></div>' +
        '<div class="row gap-10 mt-16" style="flex-wrap:wrap">' +
        ui.btn({ label: 'Publier', variant: 'primary', act: 'of-publish', icon: 'send' }) +
        ui.btn({ label: 'Garder en brouillon', variant: 'outline', act: 'of-draft' }) +
        '</div></form></section>' +

        '<div class="between mt-24"><h2>Historique</h2><span class="tiny muted">' + posts.length + ' publication(s)</span></div>' +
        '<div class="stack gap-12 mt-12">' + posts.map(postCard).join('') + '</div>';
    },
    mount(ctx) {
      brancherPhotos(ctx);
      brancherVisibilite(ctx);
    }
  };

  function postCard(p) {
    const type = p.type === 'video' ? 'video' : 'camera';
    return '<section class="card card--pad reveal">' +
      '<div class="between" style="align-items:flex-start;gap:14px">' +
      '<div style="min-width:0">' +
      '<div class="row gap-8" style="flex-wrap:wrap;align-items:center">' + icon(type, 15) +
      '<b class="small">' + U.esc(p.caption || 'Sans légende') + '</b>' +
      '<span class="chip chip--sm">' + U.esc(visLabel(p)) + '</span>' +
      (p.local ? '<span class="chip chip--sm chip--outline">sur ton appareil</span>' : '') +
      (p.statut === 'brouillon' ? '<span class="chip chip--sm">brouillon</span>' : '') +
      '</div>' +
      '<p class="tiny muted mt-4">' + quand(p.at) + '</p></div>' +
      '<div class="row gap-12" style="flex-wrap:wrap">' +
      ((p.vues || p.likes || p.commentaires)
        ? '<span class="tiny muted row gap-4" style="white-space:nowrap">' + icon('eye', 13) + U.fmtNum(p.vues) + '</span>' +
          '<span class="tiny muted row gap-4" style="white-space:nowrap">' + icon('heart', 13) + U.fmtNum(p.likes) + '</span>' +
          '<span class="tiny muted row gap-4" style="white-space:nowrap">' + icon('message', 13) + U.fmtNum(p.commentaires) + '</span>'
        : '<span class="tiny muted">chiffres au prochain relevé</span>') +
      (p.revenus ? '<span class="tiny strong">' + OF.euros(p.revenus) + '</span>' : '') +
      ui.btn({ label: 'Retirer', variant: 'ghost', size: 'xs', act: 'of-del', data: { id: p.id }, icon: 'trash' }) +
      '</div></div></section>';
  }

  /* ================================================================== */
  /* 3. TARIFS                                                           */
  /* ================================================================== */
  SEVE.views.ofPricing = {
    title: 'Tarifs',
    render() {
      const acc = store.ofAccount();
      const plan = acc.plan;
      return tete('Tarifs et abonnement',
        'Ton prix, ta promo, tes contenus à l’unité. L’estimation t’aide à décider — elle ne promet rien.',
        '') + onglets('tarifs') +

        '<div class="grid grid--side mt-20" style="align-items:start">' +
        '<section class="card card--pad reveal">' +
        '<h3>Mes prix</h3>' +
        '<form id="of-plan" novalidate class="mt-12">' +
        '<div class="formgrid">' +
        '<div class="field"><label class="label" for="of-monthly">Abonnement mensuel (€)</label>' +
        '<input class="input" id="of-monthly" data-of="monthly" type="number" min="3" max="49" step="0.5" value="' + plan.monthly + '">' +
        '<p class="help">Prix affiché sur ton profil OnlyFans. Entre 3 et 49 €.</p></div>' +
        '<div class="field"><label class="label" for="of-bundle">Pack 3 mois (€)</label>' +
        '<input class="input" id="of-bundle" data-of="bundle3" type="number" min="5" max="150" step="0.5" value="' + plan.bundle3 + '"></div>' +
        '<div class="field"><label class="label" for="of-promo">Promo de bienvenue (%)</label>' +
        '<input class="input" id="of-promo" data-of="promo" type="number" min="0" max="70" step="5" value="' + plan.promo + '"></div>' +
        '<div class="field"><label class="label" for="of-promo-mois">Durée de la promo (mois)</label>' +
        '<input class="input" id="of-promo-mois" data-of="promoMonths" type="number" min="1" max="12" step="1" value="' + plan.promoMonths + '"></div>' +
        '<div class="field"><label class="label" for="of-ppv">Contenu à l’unité (€)</label>' +
        '<input class="input" id="of-ppv" data-of="ppv" type="number" min="3" max="200" step="0.5" value="' + plan.ppv + '">' +
        '<p class="help">Photos et vidéos payantes hors abonnement.</p></div>' +
        '<div class="field"><label class="label" for="of-custom">Sur commande (€)</label>' +
        '<input class="input" id="of-custom" data-of="custom" type="number" min="10" max="500" step="5" value="' + plan.custom + '"></div>' +
        '<div class="field"><label class="label" for="of-tip">Pourboire suggéré (€)</label>' +
        '<input class="input" id="of-tip" data-of="tip" type="number" min="1" max="100" step="1" value="' + plan.tip + '"></div>' +
        '<div class="field"><label class="label" for="of-essai">Essai gratuit (jours)</label>' +
        '<input class="input" id="of-essai" data-of="freeTrialDays" type="number" min="0" max="30" step="1" value="' + (plan.freeTrialDays || 0) + '"></div>' +
        '</div>' +
        '<label class="row gap-8 mt-12 small"><input type="checkbox" id="of-welcome" data-of="welcomeOffer"' + (plan.welcomeOffer ? ' checked' : '') + '> <span>Proposer une promo de bienvenue aux nouveaux abonnés</span></label>' +
        '<div class="row gap-10 mt-16" style="flex-wrap:wrap">' +
        ui.btn({ label: 'Enregistrer mes prix', variant: 'primary', act: 'of-plan-save', icon: 'checkCircle' }) +
        ui.btn({ label: 'Revenir aux prix conseillés', variant: 'outline', act: 'of-plan-reset' }) +
        '</div></form></section>' +

        '<section id="of-estim">' + estimationHTML(plan) + '</section>' +
        '</div>' +

        '<div class="mt-16">' + ui.fold({ label: 'Comment cette estimation est calculée', bare: true, html:
          '<p class="small muted">Trois éléments : le nombre d’abonnés (88 000), la part réellement en renouvellement (environ 1 % — les autres sont des abonnés sans paiement en cours), et le prix moyen pondéré après promo. Les ventes à l’unité, les commandes personnalisées et les pourboires s’ajoutent au prorata de ce que ton compte réalise aujourd’hui. C’est une projection indicative : elle ne prédit ni tes résultats, ni les décisions de tes abonnés. Aucune somme ne passe par Sève.</p>' }) + '</div>';
    },
    mount(ctx) {
      const form = ctx.root.querySelector('#of-plan');
      if (!form) return;
      const recalc = () => { const box = ctx.root.querySelector('#of-estim'); if (box) box.innerHTML = estimationHTML(lirePlan(form)); };
      U.on(form, 'input', '[data-of]', recalc);
      U.on(form, 'change', '[data-of]', recalc);
    }
  };

  function lirePlan(form) {
    const out = {};
    Array.from(form.querySelectorAll('[data-of]')).forEach((el) => {
      const cle = el.getAttribute('data-of');
      out[cle] = el.type === 'checkbox' ? el.checked : Number(el.value);
    });
    return out;
  }

  function estimationHTML(plan) {
    const acc = store.ofAccount();
    const p = store.ofPlanValide(plan);
    const complet = Object.assign({}, acc.plan, p);
    const e = store.ofEstimation(complet);
    if (e.vide) {
      return '<section class="card card--pad reveal">' +
        '<h3>Estimation de tes revenus</h3>' +
        '<p class="small muted mt-8">Ton compte est relié mais tu n’as encore saisi aucun chiffre : Sève ne calcule rien sur une base inventée. ' +
        'Dès ton premier relevé (nombre d’abonnés, vues, revenus), l’estimation s’affiche ici et se recalcule à chaque changement de prix.</p>' +
        '<div class="mt-16">' + ui.btn({ label: 'Saisir mon relevé', variant: 'primary', href: '#/app/of', icon: 'calendar' }) + '</div>' +
        '<p class="tiny muted mt-12">Une estimation n’est jamais une promesse : elle sert à comparer deux prix, pas à annoncer un revenu.</p>' +
        '</section>';
    }
    return '<section class="card card--pad reveal">' +
      '<h3>Estimation de tes revenus</h3>' +
      '<p class="small muted mt-8">Au tarif saisi, sur ' + (acc.connected
        ? 'ta base actuelle d’abonnés (' + U.fmtNum(e.base) + ' abonnés en renouvellement)'
        : 'la base de ton profil de démonstration — relie ton compte pour affiner') + '. Estimation indicative — jamais une promesse.</p>' +
      '<div class="mt-16">' +
      '<span class="tiny muted">Revenu mensuel estimé</span>' +
      '<div class="tnum" style="font-size:27px;font-weight:700;letter-spacing:-.02em;color:var(--green-700);white-space:nowrap">' + OF.euros0(e.total) + '</div>' +
      '<span class="chip chip--sm mt-8" style="display:inline-block">prix moyen ' + OF.euros(e.prixMoyen) + '</span>' +
      '</div>' +
      '<div class="mt-16">' + ui.bars([
        { label: 'Abonnements', value: e.abo, display: OF.euros0(e.abo) },
        { label: 'Contenus à l’unité', value: e.ppv, display: OF.euros0(e.ppv) },
        { label: 'Sur commande', value: e.custom, display: OF.euros0(e.custom) },
        { label: 'Pourboires', value: e.tips, display: OF.euros0(e.tips) }
      ]) + '</div>' +
      '<p class="tiny muted mt-12">Base payante estimée : ' + U.fmtNum(e.base) + ' abonnés en renouvellement. Tu peux suspendre ou changer ces prix quand tu veux : ils t’appartiennent.</p>' +
      '</section>';
  }

  /* ================================================================== */
  /* FLUX EN DIRECT ET APERÇU DES PHOTOS                                 */
  /* ================================================================== */
  let minuteur = null;

  /** Un seul minuteur pour toute l’application ; il s’arrête de lui-même. */
  function demarrerDirect(ctx) {
    /* Relevés enregistrés : la page se rafraîchit depuis le serveur, pas depuis
       un flux inventé. Le minuteur ne sert qu'à l'aperçu de démonstration. */
    const etat = store.ofStats();
    if (etat.reel || etat.vide) {
      if (minuteur) { clearInterval(minuteur); minuteur = null; }
      return;   /* chiffres réels, ou compte relié sans chiffres : rien à animer */
    }
    const rafraichir = () => {
      const liste = document.querySelector('#of-live');
      if (!liste) { if (minuteur) { clearInterval(minuteur); minuteur = null; } return; }
      const acc = store.ofAccount();
      if (!acc.live) return;
      const html = fluxHTML();
      const cible = liste.querySelector('[data-live-list]');
      if (cible) cible.innerHTML = html;
      const kpiBox = document.querySelector('#of-kpis');
      if (kpiBox) kpiBox.innerHTML = kpis(store.ofStats());
    };
    if (minuteur) clearInterval(minuteur);
    minuteur = setInterval(rafraichir, 5000);
    const btn = ctx && ctx.root ? ctx.root.querySelector('[data-act="of-live-toggle"]') : null;
    if (btn) btn.setAttribute('aria-pressed', String(!!store.ofAccount().live));
  }

  /** La visibilité se choisit en un clic, sans menu à ouvrir. */
  function brancherVisibilite(ctx) {
    const row = ctx.root.querySelector('[data-vis-row]');
    const champ = ctx.root.querySelector('#of-vis');
    if (!row || !champ) { return; }
    row.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-vis]');
      if (!btn) { return; }
      row.querySelectorAll('[data-vis]').forEach((autre) => autre.classList.remove('is-on'));
      btn.classList.add('is-on');
      champ.value = btn.getAttribute('data-vis');
    });
  }

  function brancherPhotos(ctx) {
    const input = ctx.root.querySelector('#of-files');
    const zone = ctx.root.querySelector('#of-shots');
    if (!input || !zone) return;
    U.on(input, 'change', '#of-files', () => {
      zone.innerHTML = '';
      const fichiers = Array.from(input.files || []);
      if (!fichiers.length) return;
      fichiers.slice(0, 6).forEach((f) => {
        if (!/^image\//.test(f.type)) return;
        const src = URL.createObjectURL(f);
        const img = U.el('<img class="ofshot" alt="Aperçu local" src="' + src + '">');
        img.addEventListener('load', () => URL.revokeObjectURL(src));
        zone.appendChild(img);
      });
      const total = fichiers.length;
      zone.appendChild(U.el('<span class="tiny muted" style="align-self:center">' + total + ' fichier(s) prêt(s) — ' + Math.round(fichiers.reduce((s, f) => s + f.size, 0) / 1024) + ' Ko, sur ton appareil</span>'));
      store.ofAccount().fichiers = total;
    });
  }

  /* ================================================================== */
  /* ACTIONS                                                             */
  /* ================================================================== */
  /* ------------------------- Aller-retour avec le serveur ------------------------- */
  let rechargeEnCours = null;   /* une seule relecture à la fois */

  /** Écrit sur le serveur quand il répond ; sinon l’état local fait foi. */
  function auServeur(route, corps) {
    /* On attend la réponse du test de disponibilité : au premier clic, elle
       n'est pas encore connue, et écrire sans vérifier ferait croire à un échec. */
    return SEVE.api.sonde().then((ok) => {
      if (!ok) {
        store.ofMarquerServeur(false, 'Serveur injoignable.');
        return { ok: false, hors_ligne: true, erreur: 'Serveur injoignable.' };
      }
      return SEVE.api.envoie(route, corps);
    }).then((r) => {
      if (r && r.ok) {
        if (r.etat) { store.ofDepuisServeur(r.etat); } else { store.ofMarquerServeur(true); }
      } else {
        store.ofMarquerServeur(false, (r && r.erreur) || 'Écriture refusée.');
      }
      return r;
    });
  }

  /** Relit les relevés du serveur (silencieux : sert au chargement de la page). */
  function recharger(forcer) {
    store.refresh();                     /* un autre onglet a peut-être écrit */
    const acc = store.ofAccount();
    if (!acc.connected || !acc.code || acc.demo) { return Promise.resolve(null); }
    /* On ne redessine que si le serveur apporte quelque chose de nouveau :
       sans cette comparaison, chaque relecture relançait un rendu, qui
       relançait une relecture. */
    const avant = JSON.stringify(store.ofReleves());
    if (rechargeEnCours) { return rechargeEnCours; }
    /* Une écriture partie il y a moins de 4 secondes : le serveur peut encore
       répondre l'état d'avant. On ne relit pas tout de suite. */
    if (!forcer && Date.now() - (store.ofAccount().ecritLe || 0) < 4000) { return Promise.resolve(null); }
    rechargeEnCours = SEVE.api.sonde().then((ok) => {
      if (!ok) { store.ofMarquerServeur(false, 'Serveur injoignable.'); return null; }
      return SEVE.api.envoie('/etat', {}, 'GET').then((r) => {
        if (r && r.ok && r.etat) {
          store.ofDepuisServeur(r.etat);
          const change = forcer || JSON.stringify(store.ofReleves()) !== avant;
          if (change && SEVE.router && SEVE.router.refresh) { SEVE.router.refresh(); }
        } else if (r && r.ok) {
          store.ofMarquerServeur(true, '');
        }
        return r;
      });
    }).then((r) => { rechargeEnCours = null; return r; }, () => { rechargeEnCours = null; return null; });
    return rechargeEnCours;
  }

  /** Lit un champ du formulaire par son identifiant. */
  function valeur(id) {
    const el = document.querySelector(id);
    return el ? String(el.value || '').trim() : '';
  }

  SEVE.act('of-connect', function () {
    const pseudo = String(valeur('#of-user')).replace(/^@/, '').trim();
    const code = valeur('#of-code').replace(/\D/g, '');
    if (!pseudo) { ui.toast('Indique ton identifiant OnlyFans pour continuer.', 'err'); return; }
    if (!/^\d{6}$/.test(code)) { ui.toast('Choisis un code de relevé à six chiffres (il protège tes chiffres).', 'err'); return; }

    store.ofConnect({ username: pseudo, code: code });
    const p = auServeur('/connexion', { username: pseudo, code: code }).then((r) => {
      if (r && r.ok) {
        ui.toast('Compte relié. Saisis ton premier relevé : Sève calcule tout le reste.', 'ok', { title: 'C’est relié' });
      } else if (r && r.hors_ligne) {
        ui.toast('Compte relié sur cet appareil. Le serveur de relevés ne répond pas : tes chiffres restent ici.', 'info', { title: 'Relié localement' });
      } else {
        ui.toast((r && r.erreur) || 'La liaison a été refusée par le serveur.', 'err');
      }
      SEVE.router.refresh();
    });
    return p;
  });

  SEVE.act('of-demo-connect', function () {
    const pseudo = String(valeur('#of-user')).replace(/^@/, '').trim() || 'lyamoreau';
    const champ = document.querySelector('#of-code');
    if (champ) { champ.value = codeDemo(pseudo); }
    store.ofConnect({ username: pseudo, code: codeDemo(pseudo), demo: true });
    ui.toast('Aperçu de démonstration : les chiffres sont fabriqués pour montrer l’écran.', 'ok', { title: 'Mode démonstration' });
    SEVE.router.refresh();
  });

  SEVE.act('of-sync', function () {
    const acc = store.ofAccount();
    if (acc.demo) {
      store.ofSync();
      ui.toast('Aperçu de démonstration : rien à synchroniser, les chiffres sont fabriqués.', 'info');
      SEVE.router.refresh();
      return;
    }
    if (!acc.code) { ui.toast('Renseigne ton code de relevé pour retrouver tes chiffres.', 'err'); return; }
    SEVE.api.sonde().then((ok) => {
      if (!ok) {
        store.ofSync();
        store.ofMarquerServeur(false, 'Serveur injoignable.');
        ui.toast('Le serveur de relevés ne répond pas : tes chiffres restent sur cet appareil.', 'info', { title: 'Hors ligne' });
        SEVE.router.refresh();
        return;
      }
      return SEVE.api.envoie('/etat', {}, 'GET').then((r) => {
        if (r && r.ok && r.etat) {
          store.ofDepuisServeur(r.etat);
          ui.toast('Relevés relus : ' + store.ofReleves().length + ' jour(s) enregistré(s).', 'ok', { title: 'À jour' });
        } else if (r && r.ok) {
          store.ofSync();
          store.ofMarquerServeur(true, '');
          ui.toast('C’est le bon code : aucun relevé enregistré pour l’instant.', 'info');
        } else {
          store.ofMarquerServeur(false, (r && r.erreur) || '');
          ui.toast((r && r.erreur) || 'Lecture impossible.', 'err');
        }
        SEVE.router.refresh();
      });
    });
  });

  SEVE.act('of-deconnect', function () {
    const acc = store.ofAccount();
    return ui.confirm({
      title: 'Décrocher ton compte OnlyFans ?',
      text: 'Sève ne lira plus rien — elle ne lisait rien de toute façon. Tes relevés déjà saisis restent conservés, et tu peux te relier plus tard avec le même code.',
      detail: 'Tu pourras aussi les effacer quand tu veux, depuis cette page.',
      okLabel: 'Décrocher'
    }).then((ok) => {
      if (!ok) { return; }
      if (!acc.demo && acc.code) { auServeur('/deconnexion', {}); }
      store.ofDisconnect();
      ui.toast('Compte décroché. Tes relevés restent enregistrés.', 'info');
      SEVE.router.refresh();
    });
  });

  /* ---------------------------------- Relevés ---------------------------------- */
  SEVE.act('of-releve', function () {
    const releve = {
      jour: valeur('#of-jour'),
      abonnes: valeur('#of-abonnes'),
      revenus: valeur('#of-revenus'),
      vues: valeur('#of-vues'),
      likes: valeur('#of-likes')
    };
    if (!releve.jour) { ui.toast('Choisis le jour du relevé.', 'err'); return; }
    if (!releve.abonnes && !releve.revenus && !releve.vues) {
      ui.toast('Renseigne au moins les abonnés, les revenus ou les vues.', 'err'); return;
    }
    const propre = store.ofReleveAjouter(releve);
    if (!propre) { ui.toast('Ce relevé n’a pas pu être enregistré : vérifie la date.', 'err'); return; }
    ui.toast('Relevé du ' + U.fmtDate(propre.jour) + ' enregistré : tes chiffres sont à jour.', 'ok', { title: 'Bien reçu' });
    SEVE.router.refresh();
    auServeur('/releve', propre).then((r) => {
      if (r && !r.ok && !r.hors_ligne) { ui.toast((r.erreur || 'Le serveur a refusé ce relevé.') + ' Il est conservé sur cet appareil.', 'err'); }
    });
  });

  SEVE.act('of-import', function () {
    const texte = valeur('#of-csv');
    if (!texte) { ui.toast('Colle d’abord les lignes de ton relevé.', 'err'); return; }
    const lignes = OF.decouperCsv(texte);
    if (!lignes.length) { ui.toast('Aucune date reconnue. Exemple de ligne : 2026-10-16;88000;412,50;41800;7320', 'err'); return; }
    const nb = store.ofReleveImporter(lignes);
    ui.toast(nb + ' jour' + (nb > 1 ? 's' : '') + ' enregistré' + (nb > 1 ? 's' : '') + ' : tes séries sont recalculées.', 'ok', { title: 'Import terminé' });
    SEVE.router.refresh();
    auServeur('/import', { csv: texte }).then((r) => {
      if (r && !r.ok && !r.hors_ligne) { ui.toast((r.erreur || 'Import refusé par le serveur.') + ' Les jours sont conservés sur cet appareil.', 'err'); }
    });
  });

  /* ---------------------------------- Dépôt ---------------------------------- */
  SEVE.act('of-depot-lire', function () {
    const texte = valeur('#of-depot-texte');
    if (!texte) { ui.toast('Colle d’abord ton export ou ta lettre OnlyFans.', 'err'); return; }
    traiterDepot(texte, 'le texte collé');
  });

  /** Lire directement le presse-papiers : sur OnlyFans, copier puis un clic ici. */
  SEVE.act('of-depot-coller', function () {
    const champ = document.querySelector('#of-depot-texte');
    const suite = (texte) => {
      if (!texte || !String(texte).trim()) {
        ui.toast('Le presse-papiers est vide : copie d’abord tes chiffres sur OnlyFans (Ctrl/Cmd + C).', 'info');
        return;
      }
      if (champ) { champ.value = String(texte); }
      traiterDepot(String(texte), 'ce que tu as copié');
    };
    if (navigator.clipboard && navigator.clipboard.readText) {
      navigator.clipboard.readText().then(suite, () => ui.toast('Ton navigateur a refusé la lecture du presse-papiers : colle-le dans la zone avec Ctrl/Cmd + V.', 'info'));
    } else {
      ui.toast('Ce navigateur ne lit pas le presse-papiers tout seul : colle-le dans la zone avec Ctrl/Cmd + V.', 'info');
    }
  });

  SEVE.act('of-depot-exemple', function () {
    const champ = document.querySelector('#of-depot-texte');
    if (champ) {
      champ.value = 'jour;abonnes;revenus;vues;likes\n2026-10-09;9 998;122,30;45 600;6 780\n2026-10-10;9 999;123,45;45 678;6 789';
      champ.focus();
    }
    ui.toast('Exemple d’export : remplace ces lignes par les tiennes, puis « Lire ces chiffres ».', 'info');
  });

  SEVE.act('of-cle-creer', function () {
    SEVE.api.cleDepot().then((r) => {
      if (r && r.ok && r.cle) {
        store.ofDefinirCleDepot(r.cle);
        ui.toast('Clé créée. Garde-la : le serveur n’en connaît qu’une empreinte.', 'ok', { title: 'Clé de dépôt' });
        SEVE.router.refresh();
        return;
      }
      ui.toast((r && r.erreur) || 'Le serveur de relevés ne répond pas. La clé n’a pas été créée — le dépôt de fichier, lui, fonctionne sans clé.', 'err');
    });
  });

  SEVE.act('of-cle-copier', function () {
    const champ = document.querySelector('#of-cle');
    if (!champ) { return; }
    champ.select();
    const fini = () => ui.toast('Clé copiée.', 'ok');
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(champ.value).then(fini, () => { try { document.execCommand('copy'); fini(); } catch (e) { /* à recopier à la main */ } });
    } else {
      try { document.execCommand('copy'); fini(); } catch (e) { ui.toast('Copie refusée par le navigateur : sélectionne la clé à la main.', 'info'); }
    }
  });

  SEVE.act('of-releve-edit', function (el) {
    const jour = el.getAttribute('data-jour');
    const r = store.ofReleves().filter((x) => x.jour === jour)[0];
    if (!r) { ui.toast('Ce relevé n’est plus là.', 'info'); return; }
    const poser = (id, v) => {
      const champ = document.querySelector(id);
      if (champ) { champ.value = (v === 0 || v) ? String(v) : ''; }
    };
    poser('#of-jour', r.jour);
    poser('#of-abonnes', r.abonnes);
    poser('#of-revenus', r.revenus);
    poser('#of-vues', r.vues);
    poser('#of-likes', r.likes);
    const bloc = document.querySelector('#of-releves');
    if (bloc) { bloc.scrollIntoView({ behavior: 'smooth', block: 'center' }); }
    ui.toast('Chiffres du ' + U.fmtDate(jour) + ' chargés : corrige ce qui est faux, puis enregistre — ce jour sera remplacé, pas dupliqué.', 'info', { title: 'Correction' });
  });

  SEVE.act('of-releve-del', function (el) {
    const jour = el.getAttribute('data-jour');
    if (!jour) { return; }
    if (!store.ofReleveSupprimer(jour)) { ui.toast('Ce relevé n’était plus là.', 'info'); return; }
    ui.toast('Relevé du ' + U.fmtDate(jour) + ' retiré.', 'info');
    SEVE.router.refresh();
    auServeur('/releve/supprimer', { jour: jour });
  });

  SEVE.act('of-live-toggle', function () {
    const acc = store.ofAccount();
    acc.live = !acc.live;
    store.save();
    ui.toast(acc.live ? 'Le direct reprend.' : 'Le direct est en pause : tu peux revenir quand tu veux.', 'info');
    SEVE.router.refresh();
  });

  SEVE.act('of-publish', function () { publier(false); });
  SEVE.act('of-draft', function () { publier(true); });

  function publier(brouillon) {
    const cap = (document.querySelector('#of-caption') || {}).value || '';
    const vis = (document.querySelector('#of-vis') || {}).value || 'abonnes';
    const prix = Number((document.querySelector('#of-price') || {}).value || 0);
    const fichiers = document.querySelector('#of-files');
    const nb = fichiers && fichiers.files ? fichiers.files.length : 0;
    if (!String(cap).trim() && !nb) {
      ui.toast('Ajoute au moins une légende ou une photo.', 'err');
      return;
    }
    const pub = {
      caption: String(cap).trim(), visibility: brouillon ? 'brouillon' : vis,
      price: vis === 'ppv' || vis === 'custom' ? prix : 0,
      statut: brouillon ? 'brouillon' : 'publie', fichiers: nb, type: 'photo'
    };
    store.ofAddPost(pub);
    ui.toast(brouillon
      ? 'Brouillon enregistré : tu peux le reprendre plus tard.'
      : 'Publication enregistrée dans ton historique Sève. Les photos restent sur ton appareil ; Sève n’envoie rien à OnlyFans.',
      'ok', { title: brouillon ? 'Brouillon enregistré' : 'Publication enregistrée' });
    SEVE.router.refresh();
    auServeur('/publication', { caption: pub.caption, visibility: pub.visibility, price: pub.price });
  }

  SEVE.act('of-del', function (el) {
    const id = el.getAttribute('data-id');
    if (store.ofRemovePost(id)) {
      ui.toast('Publication retirée.', 'info');
      SEVE.router.refresh();
      if (/^srv/.test(String(id))) { auServeur('/publication/supprimer', { id: id }); }
    } else { ui.toast('Cette publication n’a pas pu être retirée.', 'err'); }
  });

  SEVE.act('of-export', function () {
    const brouillons = store.ofPosts().filter((p) => p.statut === 'brouillon' || p.local);
    const texte = brouillons.map((p) => p.caption).filter(Boolean).join('\n\n');
    if (!texte) { ui.toast('Rien à copier pour l’instant : écris d’abord une légende.', 'info'); return; }
    const copie = (navigator.clipboard && navigator.clipboard.writeText)
      ? navigator.clipboard.writeText(texte) : Promise.reject(new Error('presse-papier indisponible'));
    copie.then(() => {
      ui.toast('Légende copiée : colle-la dans OnlyFans. Sève ne peut pas publier à ta place — c’est voulu.', 'ok', { title: 'Copié' });
    }).catch(() => {
      ui.toast('Copie automatique impossible sur ce navigateur : sélectionne le texte à la main.', 'info');
    });
  });

  SEVE.act('of-plan-save', function () {
    const form = document.querySelector('#of-plan');
    if (!form) return;
    const plan = store.ofSavePlan(lirePlan(form));
    ui.toast('Prix enregistrés : abonnement à ' + OF.euros(plan.monthly) + ' par mois.', 'ok', { title: 'Tarifs mis à jour' });
    SEVE.router.refresh();
    auServeur('/plan', { plan: plan });
  });

  SEVE.act('of-plan-reset', function () {
    store.ofSavePlan(store.ofDemo().plan);
    ui.toast('Prix conseillés rétablis.', 'info');
    SEVE.router.refresh();
    auServeur('/plan', { plan: store.ofAccount().plan });
  });
})();
