/* ==========================================================================
   Sève — vues publiques : accueil, découverte, créateurs, managers,
   comment ça marche, aide au matching
   ========================================================================== */
(function () {
  const U = SEVE.util;
  const ui = SEVE.ui;
  const C = SEVE.components;
  const store = SEVE.store;
  const icon = SEVE.icons.svg;
  const T = SEVE.taxo;

  SEVE.views = SEVE.views || {};

  /* ================================================================== */
  /* ACCUEIL                                                             */
  /* ================================================================== */
  SEVE.views.home = {
    title: 'Trouvez le bon partenaire',
    render() {
      const s = store.stats();
      const creators = store.creators().filter((p) => p.featured).slice(0, 2);
      const managers = store.managers().filter((p) => p.featured).slice(0, 2);

      return '' +
        /* ------------------------------------------------------------- HERO */
        '<section class="hero"><span class="hero__glow"></span>' +
        '<div class="wrap hero__inner">' +
        '<div class="anim-up">' +
        '<span class="pillnote"><span class="dot dot--live"></span><b>' + (s.creators + s.managers) + ' profils fictifs visibles</b> · ' + s.managers + ' managers · ' + s.creators + ' créateurs</span>' +
        '<h1 class="mt-20">Trouvez le <span class="hl">bon partenaire</span> pour développer votre activité.</h1>' +
        '<p class="lede">Une plateforme simple pour mettre en relation créateurs, managers et agences.</p>' +
        '<div class="hero__cta">' +
        ui.btn({ label: 'Trouver un manager', variant: 'primary', size: 'lg', href: '#/managers', icon: 'users', iconSize: 18 }) +
        ui.btn({ label: 'Trouver des créateurs', variant: 'outline', size: 'lg', href: '#/creators', icon: 'camera', iconSize: 18 }) +
        '</div>' +
        '<div class="hero__trust">' +
        [{ icon: 'shieldCheck', t: 'Profils vérifiés' }, { icon: 'lock', t: 'Aucun paiement entre membres' }, { icon: 'scale', t: 'Charte claire, 18+' }]
          .map((x) => '<span class="hero__trustitem">' + icon(x.icon, 16) + U.esc(x.t) + '</span>').join('') +
        '</div>' +
        '</div>' +
        '<div class="hero__visual anim-up" style="animation-delay:60ms">' +
        '<div class="stack-cards">' +
        heroCard('pc pc--a', store.get('m2'), 'Agence vérifiée', '21 créateurs accompagnés') +
        heroCard('pc pc--c', store.get('c9'), 'Profil vérifié', '88 k abonnés · Paris') +
        '</div>' +
        '<div class="floaty floaty--2"><span class="chip chip--ok chip--sm" style="height:24px">' + icon('checkCircle', 13) + 'Demande acceptée</span>' +
        '<span class="tiny muted">Halo ↔ Lya</span></div>' +
        '</div></div></section>' +

        /* ----------------------------------------------- EXPLICATION « EN CLAIR » */
        '<section class="section section--alt"><div class="wrap">' +
        ui.sectionHead({ center: true, kicker: 'En clair', title: 'Qu’est-ce que Sève, concrètement ?', text: 'Sève est un annuaire qualifié avec boîte de réception. Vous cherchez un partenaire de travail, vous comparez des profils fictifs dans cette maquette — spécialités, expérience, disponibilité, conditions — puis vous vous contactez. Nous ne prenons aucune commission et nous n’intervenons jamais dans vos paiements.' }) +
        '<div class="splits">' +
        '<article class="split reveal"><span class="chip chip--green chip--sm">Vous êtes créateur / créatrice</span>' +
        '<h3 class="mt-16">Déléguer la vente, la croissance ou la production</h3>' +
        '<ul>' + [
          'Comparez les managers sur des faits : portefeuille, commissions, réactivité',
          'Voyez qui est disponible maintenant et qui ne l’est pas',
          'Écrivez vos limites une fois, elles sont affichées sur votre profil'
        ].map((t) => '<li>' + icon('check', 17) + U.esc(t) + '</li>').join('') + '</ul>' +
        ui.btn({ label: 'Voir les managers', variant: 'primary', href: '#/managers' }) +
        '</article>' +
        '<article class="split reveal"><span class="chip chip--green chip--sm">Vous êtes manager / agence</span>' +
        '<h3 class="mt-16">Recruter des profils sérieux, sans perdre de temps</h3>' +
        '<ul>' + [
          'Filtrez par réseau, expérience, langues et disponibilité',
          'Recevez des profils classés selon vos critères, avec les raisons',
          'Gardez toutes les demandes et les échanges au même endroit'
        ].map((t) => '<li>' + icon('check', 17) + U.esc(t) + '</li>').join('') + '</ul>' +
        ui.btn({ label: 'Voir les créateurs', variant: 'primary', href: '#/creators' }) +
        '</article>' +
        '</div>' +
        '<div class="steps mt-24">' + [
          { n: '1', t: 'Créez votre profil', d: 'Sept informations utiles, deux minutes.' },
          { n: '2', t: 'Comparez et échangez', d: 'Recherche filtrée, recommandations expliquées.' },
          { n: '3', t: 'Décidez', d: 'Vous contactez qui vous voulez, aux conditions que vous fixez.' }
        ].map((x) => '<article class="step reveal"><span class="step__n">' + x.n + '</span>' +
          '<h4 class="mt-16" style="font-size:15.5px">' + U.esc(x.t) + '</h4><p class="small muted mt-8">' + U.esc(x.d) + '</p></article>').join('') + '</div>' +
        '<p class="center small muted mt-24">Ce que nous ne faisons pas : ' +
        ['aucune commission sur vos revenus', 'aucun paiement entre membres', 'aucun contenu explicite hébergé', 'aucune garantie de résultat']
          .map((t) => '<span class="chip chip--sm">' + U.esc(t) + '</span>').join(' ') + '</p>' +
        '</div></section>' +

        /* -------------------------------------------------------- RECHERCHE */
        '<section class="section section--tight"><div class="wrap">' +
        '<div class="searchpanel reveal">' +
        '<div class="between" style="align-items:flex-start">' +
        '<div><h2 style="font-size:clamp(19px,2.2vw,24px)">Chercher un profil maintenant</h2>' +
        '<p class="small muted mt-4">Sans compte : parcourez librement. Créez un compte uniquement pour contacter.</p></div>' +
        '</div>' +
        '<div class="searchpanel__row mt-20">' +
        C.searchBar({ placeholder: 'Rechercher un créateur ou un manager' }) +
        ui.btn({ label: 'Rechercher', variant: 'primary', act: 'quick-search', icon: 'search' }) +
        '</div>' +
        '<div class="filters" id="home-filters">' +
        filterSelect('hf-type', 'Type de profil', [['all', 'Créateurs et managers'], ['creator', 'Créatrices & créateurs'], ['manager', 'Managers & agences']]) +
        filterSelect('hf-region', 'Localisation', [['all', 'Toutes les zones']].concat(T.REGIONS.map((r) => [r, r]))) +
        filterSelect('hf-spec', 'Spécialité', [['all', 'Toutes les spécialités']].concat(T.SPECIALTIES.map((x) => [x.id, x.label]))) +
        filterSelect('hf-av', 'Disponibilité', T.AVAILABILITY_FILTERS.map((a) => [a.id, a.label])) +
        '</div></div></div></section>' +

        /* --------------------------------------------------------- PROFILS */
        '<section class="section section--alt"><div class="wrap">' +
        '<div class="between mb-24">' +
        '<div><span class="kicker">Profils vérifiés</span><h2 class="mt-12">Qui cherche en ce moment</h2></div>' +
        '<a class="btn btn--outline hide-mobile" href="#/discover">Tout parcourir ' + icon('arrowRight', 16) + '</a>' +
        '</div>' +
        '<div class="grid grid--cards">' + creators.map((p) => C.profileCard(p)).join('') + '</div>' +
        '<div class="grid grid--cards mt-24">' + managers.map((p) => C.profileCard(p)).join('') + '</div>' +
        '<div class="center mt-32"><a class="btn btn--outline" href="#/discover">Voir tous les profils</a></div>' +
        '</div></section>' +

        /* --------------------------------------------- AIDE DE L’ÉQUIPE + CTA */
        '<section class="section section--tight"><div class="wrap">' +
        '<div class="card card--pad reveal" style="border-color:var(--green-100)">' +
        '<div class="between" style="flex-wrap:wrap;gap:20px">' +
        '<div style="max-width:62ch">' +
        '<span class="kicker">Besoin d’aide pour trouver un manager ?</span>' +
        '<h3 class="mt-12" style="font-size:clamp(18px,2.2vw,23px)">Notre équipe cherche pour vous</h3>' +
        '<p class="small muted mt-8">Notre équipe peut rechercher des profils correspondant à vos critères et vous aider à identifier des partenaires potentiels : présélection sous 72 h ouvrées, profils vérifiés, gratuit pour les créateurs.</p>' +
        '</div>' +
        '<div class="row gap-12" style="flex-wrap:wrap">' +
        ui.btn({ label: 'Demander l’aide de l’équipe', variant: 'primary', act: 'ask-team', icon: 'headset' }) +
        ui.btn({ label: 'En savoir plus', variant: 'ghost', href: '#/matching-help' }) +
        '</div></div></div>' +

        /* --------------------------------------------- « CHEZ VOUS » */
        '<section class="section section--tight"><div class="wrap">' +
        '<div class="sec-head sec-head--center reveal"><span class="kicker">Votre espace</span>' +
        '<h2>Vous arriverez quelque part où l’on prend soin de vous</h2>' +
        '<p class="lede">Un espace de travail se juge aussi à ce qu’il vous épargne : la pression, les messages qu’on n’a pas envie de lire, ' +
        'et la solitude quand quelque chose ne va pas.</p></div>' +

        '<div class="safe-strip safe-strip--compact reveal">' +
        '<div class="safe-strip__line">' + icon('heart', 17) +
        '<b>Vous arriverez quelque part où l’on prend soin de vous</b>' +
        '<span>Un espace où l’on peut faire une pause, écrire à une personne de l’équipe, et refuser sans se justifier.</span>' +
        ui.btn({ label: 'En savoir plus', variant: 'outline', size: 'sm', href: '#/chez-vous' }) +
        '</div>' +
        ui.fold({ label: 'Les quatre repères de votre espace', bare: true,
          html: '<div class="safe-strip__grid">' + [
            { i: 'pause', t: 'Faire une pause, à tout moment', d: 'Votre profil quitte la recherche en un clic. Vos conversations restent ouvertes.' },
            { i: 'headset', t: 'Une ligne directe vers l’équipe', d: 'Une référente nommée répond sous 4 h ouvrées — sous 1 h si quelque chose vous met mal à l’aise.' },
            { i: 'shieldCheck', t: 'Des repères clairs, jamais de jugement', d: 'Ce qui ne vous sera jamais demandé, et ce que vous pouvez refuser sans vous justifier.' },
            { i: 'heart', t: 'Vous décidez, nous proposons', d: 'Aucune mise en relation sans votre accord, aucune promesse de résultat.' }
          ].map((x) => '<div class="safe-strip__item">' + icon(x.i, 18) + '<div><b>' + U.esc(x.t) + '</b><span>' + U.esc(x.d) + '</span></div></div>').join('') + '</div>' }) +
        '</div>'
        '</div>' +

        '<div class="row gap-12 mt-24" style="justify-content:center;flex-wrap:wrap">' +
        ui.btn({ label: 'Créer mon espace', variant: 'primary', size: 'lg', href: '#/signup' }) +
        ui.btn({ label: 'Comment nous accompagnons', variant: 'outline', size: 'lg', href: '#/how-it-works', icon: 'shield' }) +
        '</div></div></section>' +

        '<div class="ctaband reveal mt-24"><span class="ctaband__grid"></span>' +
        '<h2>Prêt à trouver le bon partenaire ?</h2>' +
        '<p>Inscription en deux minutes, uniquement les informations utiles. Vous décidez ensuite qui vous contactez, et à quelles conditions.</p>' +
        '<div class="row">' +
        ui.btn({ label: 'Créer mon profil', variant: 'primary', size: 'lg', href: '#/signup' }) +
        ui.btn({ label: 'Parcourir les profils', variant: 'outline', size: 'lg', href: '#/discover' }) +
        '</div></div>' +
        '</div></section>';
    }
  };

  function heroCard(cls, p, badge, meta) {
    if (!p) return '';
    return '<article class="' + cls + '" data-href="#/profiles/' + p.id + '">' +
      ui.avatar(Object.assign({ square: p.role === 'manager' }, p), 'md') +
      '<div class="pc__id"><div class="pc__name">' + U.esc(p.name) + (p.verified ? ui.verified({ compact: true }) : '') + '</div>' +
      '<div class="pc__meta"><span>' + U.esc(badge) + '</span><span class="muted">·</span><span>' + U.esc(meta) + '</span></div>' +
      '<p class="pc__desc clamp-2">' + U.esc(p.bio) + '</p></div></article>';
  }

  function recMini(e) {
    const p = e.profile;
    return '<article class="card card--pad card--hover reveal" data-href="#/profiles/' + p.id + '>' +
      '<div class="row gap-12">' + ui.avatar(Object.assign({ square: p.role === 'manager' }, p), 'md') +
      '<div class="grow" style="min-width:0"><b style="font-size:14.5px;display:block">' + U.esc(p.name) + '</b>' +
      '<span class="small muted">' + U.esc(p.city) + ' · ' + U.esc(SEVE.flows.roleLabel(p)) + '</span></div>' +
      ui.ring(e.score, { size: 46, stroke: 4 }) + '</div>' +
      '<p class="small mt-12" style="color:var(--ink-2)">' + U.esc((e.reasons || [])[0] || '') + '</p></article>';
  }

  function filterSelect(id, label, options) {
    return '<div class="chips filter-quick" role="group" aria-label="' + U.esc(label) + '">' +
      '<span class="chips__label">' + U.esc(label) + '</span><input type="hidden" id="' + id + '" value="' + U.esc(options[0][0]) + '">' +
      '<div class="chips__row">' + options.map((o, i) => '<button type="button" class="chip chip--choice' + (i === 0 ? ' is-on' : '') +
        '" data-act="quick-pick" data-pick="' + id + '" data-value="' + U.esc(o[0]) + '" aria-pressed="' + (i === 0 ? 'true' : 'false') + '">' + U.esc(o[1]) + '</button>').join('') + '</div></div>';
  }
  SEVE.act('quick-pick', function (btn) {
    const field = document.getElementById(btn.getAttribute('data-pick'));
    if (!field) return;
    field.value = btn.getAttribute('data-value');
    btn.closest('.filter-quick').querySelectorAll('[data-pick]').forEach((b) => {
      const on = b === btn; b.classList.toggle('is-on', on); b.setAttribute('aria-pressed', String(on));
    });
  });

  /* ================================================================== */
  /* DÉCOUVRIR (mixte)                                                   */
  /* ================================================================== */
  SEVE.views.discover = {
    title: 'Découvrir',
    render(ctx) {
      const v = ctx.query;
      const me = store.me();
      const list = store.search({
        q: v.q, type: v.type || 'all', region: v.region, specialty: v.specialty,
        exp: v.exp, size: v.size, availability: v.availability, language: v.language, sort: v.sort
      });
      const limit = Number(v.limit || 9);
      const shown = list.slice(0, limit);

      return '' +
        '<section class="section section--tight">' +
        '<div class="wrap">' +
        ui.sectionHead({ level: 1, kicker: 'Découvrir', title: 'Parcourez librement, contactez quand vous êtes prêt', text: 'Recherchez par type de profil, zone, spécialité, expérience, taille de réseau ou de structure, et disponibilité. Aucun compte nécessaire pour explorer.' }) +
        '<div class="searchpanel reveal"><div data-filters>' +
        '<div class="searchpanel__row">' + C.searchBar({ value: v.q || '', placeholder: 'Rechercher un créateur ou un manager' }) +
        '<span class="chip chip--green hide-mobile">' + list.length + ' profils trouvés</span></div>' +
        '<div class="mt-16">' + C.filterBar({ values: v, fields: ['type', 'region', 'specialty', 'exp', 'size', 'availability', 'sort'] }) + '</div>' +
        '</div></div>' +
        '<div class="grid grid--cards mt-32">' +
        (shown.length ? shown.map((p) => C.profileCard(p, {
          score: me && me.role && me.id !== p.id ? store.scoreFor(me, p).score : null,
          why: me ? store.scoreFor(me, p).reasons : null
        })).join('')
          : ui.empty({
            icon: 'search', title: 'Aucun profil ne correspond à ces filtres',
            text: 'Élargissez la zone géographique ou retirez une spécialité : la base évolue chaque jour.',
            action: ui.btn({ label: 'Réinitialiser les filtres', variant: 'outline', act: 'go-discover-clear' })
          })) +
        '</div>' +
        (list.length > shown.length
          ? '<div class="center mt-32">' + ui.btn({ label: 'Afficher ' + Math.min(9, list.length - shown.length) + ' profils de plus', variant: 'outline', act: 'load-more', data: { path: '/discover', limit: limit + 9 } }) + '</div>'
          : '') +
        (me ? '' : '<div class="banner banner--soft mt-40">' + icon('info', 18) +
          '<div><b>Envie de contacter un profil ?</b> Créez un compte : les demandes, les réponses et l’historique restent centralisés, et vous gardez la trace de chaque échange. ' +
          '<a href="#/signup" style="color:var(--green-700);font-weight:600">Créer mon profil →</a></div></div>') +
        '</div></section>';
    },
    mount(ctx) {
      C.bindFilters(ctx.root, '/discover');
      SEVE.actions['go-discover-clear'] = () => SEVE.router.navigate('/discover');
      SEVE.actions['load-more'] = (el) => {
        const path = el.getAttribute('data-path');
        const limit = el.getAttribute('data-limit');
        const values = Object.assign({}, ctx.query, { limit });
        SEVE.router.navigate(path + U.query(values));
      };
    }
  };

  /* ================================================================== */
  /* CRÉATEURS                                                           */
  /* ================================================================== */
  SEVE.views.creators = {
    title: 'Créateurs',
    render(ctx) {
      const v = ctx.query;
      const list = store.search({
        q: v.q, type: 'creator', region: v.region, city: v.city, specialty: v.specialty,
        exp: v.exp, size: v.size ? v.size : undefined, availability: v.availability,
        language: v.language, sort: v.sort
      });
      const limit = Number(v.limit || 9);
      const shown = list.slice(0, limit);
      const me = store.me();

      return '<section class="section section--tight"><div class="wrap">' +
        ui.sectionHead({
          level: 1,
          kicker: 'Créatrices & créateurs',
          title: 'Trouvez des créateurs à accompagner',
          text: 'Chaque profil indique ses spécialités, son format d’audience, son expérience et ses attentes de collaboration. Les profils non vérifiés sont identifiés comme tels.'
        }) +
        '<div class="searchpanel reveal"><div data-filters>' +
        '<div class="searchpanel__row">' + C.searchBar({ value: v.q || '', placeholder: 'Rechercher par nom, ville, spécialité…' }) +
        '<span class="chip chip--green hide-mobile">' + list.length + ' créateurs</span></div>' +
        '<div class="mt-16">' + C.filterBar({ values: v, fields: ['region', 'city', 'specialty', 'exp', 'size', 'availability', 'language', 'sort'] }) + '</div>' +
        '</div></div>' +
        '<div class="grid grid--cards mt-24">' +
        (shown.length ? shown.map((p) => C.profileCard(p, {
          score: me && me.role === 'manager' ? store.scoreFor(me, p).score : null,
          why: me && me.role === 'manager' ? store.scoreFor(me, p).reasons : null
        })).join('')
          : ui.empty({
            title: 'Aucun créateur ne correspond à ces filtres',
            text: 'Les filtres les plus restrictifs sont souvent la spécialité et la disponibilité. Essayez une zone plus large.',
            action: ui.btn({ label: 'Réinitialiser', variant: 'outline', act: 'reset-creators' })
          })) +
        '</div>' +
        (list.length > shown.length ? '<div class="center mt-32">' +
          ui.btn({ label: 'Afficher plus de créateurs', variant: 'outline', act: 'load-more', data: { path: '/creators', limit: limit + 9 } }) + '</div>' : '') +
        '<div class="card card--pad mt-40" style="background:var(--surface)">' +
        '<div class="between" style="flex-wrap:wrap;gap:16px"><div style="max-width:56ch">' +
        '<h3>Vous ne trouvez pas le profil attendu ?</h3>' +
        '<p class="small muted mt-8">Notre équipe peut rechercher des profils selon vos critères précis (langues, créneaux horaires, type de contenu, niveau d’expérience) et vous transmettre une présélection argumentée.</p></div>' +
        ui.btn({ label: 'Demander une présélection', variant: 'primary', act: 'ask-team' }) + '</div></div>' +
        '</div></section>';
    },
    mount(ctx) {
      C.bindFilters(ctx.root, '/creators');
      SEVE.actions['reset-creators'] = () => SEVE.router.navigate('/creators');
    }
  };

  /* ================================================================== */
  /* MANAGERS                                                            */
  /* ================================================================== */
  SEVE.views.managers = {
    title: 'Managers & agences',
    render(ctx) {
      const v = ctx.query;
      const list = store.search({
        q: v.q, type: 'manager', region: v.region, city: v.city, specialty: v.specialty,
        exp: v.exp, size: v.size ? v.size : undefined, availability: v.availability,
        language: v.language, sort: v.sort
      });
      const limit = Number(v.limit || 9);
      const shown = list.slice(0, limit);
      const me = store.me();

      return '<section class="section section--tight"><div class="wrap">' +
        ui.sectionHead({
          level: 1,
          kicker: 'Managers & agences',
          title: 'Trouvez un manager ou une agence qui vous correspond',
          text: 'Managers indépendants, agences, équipes de chatting et studios de production : comparez la structure, le portefeuille, les commissions annoncées et la disponibilité réelle.'
        }) +
        '<div class="searchpanel reveal"><div data-filters>' +
        '<div class="searchpanel__row">' + C.searchBar({ value: v.q || '', placeholder: 'Rechercher par nom, ville, méthode…' }) +
        '<span class="chip chip--green hide-mobile">' + list.length + ' managers</span></div>' +
        '<div class="mt-16">' + C.filterBar({ values: v, fields: ['region', 'city', 'specialty', 'exp', 'size', 'availability', 'language', 'sort'] }) + '</div>' +
        '</div></div>' +
        '<div class="banner banner--soft mt-24">' + icon('info', 18) +
        '<div><b>Ce que vous voyez ici est déclaratif et vérifié a minima.</b> Le nombre de créateurs accompagnés, le type de structure et la commission annoncée sont contrôlés au moment de la vérification du profil. Demandez toujours un contrat écrit avant de commencer.</div></div>' +
        '<div class="grid grid--cards mt-24">' +
        (shown.length ? shown.map((p) => C.profileCard(p, {
          score: me && me.role === 'creator' ? store.scoreFor(me, p).score : null,
          why: me && me.role === 'creator' ? store.scoreFor(me, p).reasons : null
        })).join('')
          : ui.empty({
            title: 'Aucun manager ne correspond à ces filtres',
            text: 'Essayez d’élargir la zone ou de retirer la disponibilité immédiate : les bonnes structures sont souvent ouvertes aux propositions plutôt que « disponibles ».',
            action: ui.btn({ label: 'Réinitialiser', variant: 'outline', act: 'reset-managers' })
          })) +
        '</div>' +
        (list.length > shown.length ? '<div class="center mt-32">' +
          ui.btn({ label: 'Afficher plus de managers', variant: 'outline', act: 'load-more', data: { path: '/managers', limit: limit + 9 } }) + '</div>' : '') +
        '<div class="card card--pad mt-40"><div class="between" style="flex-wrap:wrap;gap:16px"><div style="max-width:58ch">' +
        '<h3>Besoin d’aide pour trouver un manager ?</h3>' +
        '<p class="small muted mt-8">Notre équipe peut rechercher des profils correspondant à vos critères et vous aider à identifier des partenaires potentiels. Vous recevez une présélection sous 72 h ouvrées.</p></div>' +
        ui.btn({ label: 'Demander l’aide de l’équipe', variant: 'primary', act: 'ask-team' }) + '</div></div>' +
        '</div></section>';
    },
    mount(ctx) {
      C.bindFilters(ctx.root, '/managers');
      SEVE.actions['reset-managers'] = () => SEVE.router.navigate('/managers');
    }
  };

  /* ================================================================== */
  /* COMMENT ÇA MARCHE                                                   */
  /* ================================================================== */
  SEVE.views['how-it-works'] = {
    title: 'Comment ça marche',
    render() {
      return '' +
        '<section class="section section--tight"><div class="wrap wrap--narrow">' +
        ui.sectionHead({ level: 1, kicker: 'Comment ça marche', title: 'Un fonctionnement lisible de bout en bout', text: 'De la création du profil au premier contrat, voici exactement ce qui se passe — y compris la façon dont nous calculons les recommandations et dont nous vérifions les profils.' }) +
        '</div></section>' +

        '<section class="section section--tight" style="padding-top:0"><div class="wrap">' +
        C.steps([
          { title: 'Un profil complet mais minimal', text: 'Sept informations utiles : nom public, localisation, spécialités, présentation, expérience, portfolio, critères de recherche. Pas d’adresse postale, pas de pièce d’identité affichée, pas de numéro de téléphone obligatoire.' },
          { title: 'La vérification', text: 'Un membre de l’équipe contrôle l’identité (créateur) ou la structure et le représentant légal (manager/agence), ainsi que l’historique de signalements. Un badge discret indique les profils vérifiés.' },
          { title: 'Recherche & recommandations', text: 'Vous filtrez ou laissez le moteur comparer vos critères déclarés. Les recommandations affichent le score et les raisons, ainsi que les points de vigilance.' },
          { title: 'Demande de collaboration', text: 'Un message structuré : qui vous êtes, ce que vous cherchez, à quelles conditions. La demande arrive dans la messagerie du destinataire avec son historique.' },
          { title: 'Conversation & décision', text: 'La messagerie centralise les échanges. Les deux parties gardent une trace écrite. Aucune obligation de signer : vous pouvez refuser ou archiver à tout moment.' },
          { title: 'Accompagnement par l’équipe', text: 'Si vous ne trouvez pas, notre équipe prend la recherche en charge et vous transmet une présélection, avec les vérifications déjà effectuées.' }
        ]) +
        '</div></section>' +

        '<section class="section section--alt"><div class="wrap">' +
        '<div class="grid grid--split">' +
        '<div>' + ui.sectionHead({ kicker: 'Méthodologie', title: 'Comment le score de compatibilité est calculé' }) +
        '<p class="lede">Le score va de 35 % à 97 %. Il compare six familles de critères déclarés, pondérées. Il ne prédit aucun revenu et ne remplace pas un échange humain : c’est un outil de tri.</p>' +
        '<div class="mt-24">' + ui.bars([
          { label: 'Spécialités', value: 34, display: '34 pts' },
          { label: 'Localisation', value: 15, display: '15 pts' },
          { label: 'Expérience', value: 14, display: '14 pts' },
          { label: 'Objectifs', value: 15, display: '15 pts' },
          { label: 'Disponibilité', value: 12, display: '12 pts' },
          { label: 'Langues & volume', value: 10, display: '10 pts' }
        ], { max: 34 }) + '</div>' +
        '<div class="banner banner--warn mt-24">' + icon('alert', 18) +
        '<div><b>Ce que nous ne faisons pas :</b> garantir des résultats, classer les profils par « meilleur manager », ni masquer les points de vigilance. Les scores sont visibles par les deux parties, sans jeu de pouvoir caché.</div></div>' +
        '</div>' +
        '<div class="card card--pad reveal">' +
        '<h3>Les critères, en détail</h3>' +
        '<dl class="defs mt-16">' + [
          ['Spécialités', 'Chevauchement entre les spécialités recherchées et celles déclarées par le profil.'],
          ['Localisation', 'Ville, pays, puis zone. La proximité facilite les tournages et les réunions.'],
          ['Expérience', 'Écart entre les niveaux déclarés, exprimé en années d’activité.'],
          ['Disponibilité', 'Disponible, ouvert aux propositions, peu disponible ou complet.'],
          ['Objectifs', 'Objectifs partagés : structurer, scaler, déléguer, changer de marché…'],
          ['Préférences', 'Forme de collaboration visée : commission, retainer, forfait, essai.'],
          ['Signaux de confiance', 'Profil vérifié, ancienneté, réactivité annoncée, absence de signalement.']
        ].map((d) => '<div class="def"><dt>' + U.esc(d[0]) + '</dt><dd>' + U.esc(d[1]) + '</dd></div>').join('') + '</dl>' +
        '</div></div></div></section>' +

        '<section class="section"><div class="wrap">' +
        ui.sectionHead({ center: true, kicker: 'Vérification', title: 'Ce que signifie « profil vérifié »', text: 'Un badge discret, mais un contrôle réel. Voici précisément ce que nous vérifions — et ce que nous ne pouvons pas vérifier.' }) +
        '<div class="grid grid--3">' +
        ['<b>Créateurs</b> : identité avec document officiel, confirmation de majorité, cohérence entre le profil public et les comptes déclarés.',
          '<b>Managers & agences</b> : existence légale de la structure, identification du représentant, vérification de l’absence de litige signalé sur la plateforme.',
          '<b>Ce que nous ne vérifions pas</b> : le montant exact de vos revenus, la qualité de la production future, ni les engagements contractuels que vous prendrez. Nous vous rappelons les points de vigilance avant toute signature.']
          .map((t, i) => '<article class="card card--pad reveal"><span class="notif__icon">' + icon(['shieldCheck', 'building', 'info'][i], 18) + '</span>' +
            '<p class="mt-16" style="color:var(--ink-2);font-size:14.2px">' + t + '</p></article>').join('') +
        '</div>' +
        '<div class="grid grid--4 mt-24">' +
        C.trustItems([
          { icon: 'flag', title: 'Signalement', text: 'Motif + description, suivi par l’équipe' },
          { icon: 'ban', title: 'Blocage', text: 'Immediat et réversible' },
          { icon: 'eye', title: 'Statut visible', text: 'Suspendu, en pause, archivé' },
          { icon: 'history', title: 'Historique', text: 'Chaque demande conservée' }
        ]) + '</div>' +
        '</div></section>' +

        '<section class="section section--alt"><div class="wrap wrap--narrow">' +
        ui.sectionHead({ kicker: 'Questions fréquentes', title: 'Ce que l’on nous demande le plus' }) +
        faq([
          ['Sève prélève-t-il une commission ?', 'Non. Sève ne prend aucun pourcentage sur vos revenus et ne se rémunère pas sur les échanges. La plateforme facturera à terme des options de mise en avant, jamais une commission sur vos collaborations.'],
          ['Comment êtes-vous sûr que les membres sont majeurs ?', 'Chaque profil est vérifié avant d’être mis en relation : document officiel, contrôle de majorité, et signalement immédiat possible en cas de doute. Un profil suspecté d’être mineur est suspendu le temps de la vérification.'],
          ['Puis-je refuser une demande sans conséquence ?', 'Oui. Refuser, ignorer ou archiver une demande n’affecte ni votre visibilité ni votre classement. Aucun profil ne peut voir que vous avez refusé.'],
          ['Qui voit mes informations ?', 'Les informations affichées sur votre profil public, et rien d’autre. Votre email, votre document d’identité et vos paramètres de sécurité restent privés — l’équipe de vérification y accède uniquement pour traiter votre dossier.'],
          ['Que se passe-t-il si un manager me demande de l’argent ?', 'Signalez-le immédiatement : c’est interdit et considéré comme un cas prioritaire. Les demandes de frais de dossier, de « pack de lancement » ou d’avance sont contraires aux règles de la plateforme.'],
          ['Puis-je supprimer mon compte et mes données ?', 'Oui, depuis vos paramètres. La suppression est définitive sous 30 jours : profil, messages et demandes sont effacés, seules les données comptables ou les dossiers de signalement en cours sont conservés le temps légal nécessaire.']
        ]) +
        '<div class="center mt-32">' + ui.btn({ label: 'Poser une autre question à l’équipe', variant: 'outline', act: 'ask-team' }) + '</div>' +
        '</div></section>';
    }
  };

  function faq(items) {
    return '<div class="faq">' + items.map((it, i) =>
      '<details class="faq__item" ' + (i === 0 ? 'open' : '') + '><summary>' + U.esc(it[0]) + '<span class="faq__chev">' + icon('chevronDown', 18) + '</span></summary>' +
      '<div class="faq__body">' + U.esc(it[1]) + '</div></details>').join('') + '</div>';
  }

  /* ================================================================== */
  /* AIDE AU MATCHING (page publique)                                    */
  /* ================================================================== */
  /* ================================================================== */
  /* CHEZ VOUS (page publique)                                           */
  /* ================================================================== */
  SEVE.views['chez-vous'] = {
    title: 'Chez vous',
    render() {
      return '' +
        '<section class="section section--tight"><div class="wrap">' +
        ui.sectionHead({
          level: 1,
          kicker: 'Chez vous',
          title: 'Un espace qui prend soin de vous',
          lede: 'Vous n’arrivez pas dans un marché. Vous arrivez dans un espace de travail — avec une personne à qui parler, un droit de refuser, et la possibilité de faire une pause sans rien perdre.'
        }) +
        '<div class="safe-strip reveal">' + [
          { i: 'pause', t: 'Faire une pause, à tout moment', d: 'Votre profil quitte la recherche en un clic, vos conversations restent ouvertes, et personne n’est prévenu.' },
          { i: 'headset', t: 'Une personne, pas un guichet', d: 'Une référente nommée vous répond : sous 1 heure ouvrée si vous êtes mal à l’aise, sous 4 heures pour le reste.' },
          { i: 'scale', t: 'Vous décidez, nous proposons', d: 'Aucune mise en relation sans votre accord, aucune promesse de résultat, aucune obligation de réponse.' },
          { i: 'heart', t: 'Des ressources, tout de suite', d: '3919 (violences faites aux femmes), 17·112 (urgences), internet-signalement.gouv.fr — si un échange vous met mal à l’aise.' }
        ].map((x) => '<div class="safe-strip__item">' + icon(x.i, 18) + '<div><b>' + U.esc(x.t) + '</b><span>' + U.esc(x.d) + '</span></div></div>').join('') +
        '</div>' +

        '<div class="grid grid--2 mt-24">' + [
          { i: 'lock', t: 'Ce qui ne vous sera jamais demandé', d: 'Vos mots de passe, vos coordonnées bancaires, vos conversations privées avec vos abonnés.' },
          { i: 'ban', t: 'Ce que vous pouvez refuser', d: 'Une mise en relation, un manager, une session, une photo. Sans justification, et sans que cela vous ferme la porte.' }
        ].map((x) => '<article class="card card--pad reveal"><span class="notif__icon">' + icon(x.i, 17) + '</span>' +
          '<h4 class="mt-16">' + U.esc(x.t) + '</h4><p class="small muted mt-8">' + U.esc(x.d) + '</p></article>').join('') + '</div>' +

        '<div class="mt-24">' + ui.fold({ label: 'Comment on s’y prend, concrètement', bare: false, html:
          '<ul class="stack gap-8 small muted mt-8">' +
          '<li>' + icon('checkCircle', 14) + ' Votre profil indique ce que vous acceptez et ce que vous refusez : la recherche ne vous propose que ça.</li>' +
          '<li>' + icon('checkCircle', 14) + ' Chaque demande de collaboration arrive chez vous avec le détail du profil, et vous répondez — ou pas.</li>' +
          '<li>' + icon('checkCircle', 14) + ' Le bouton « besoin de parler / soutien », en bas à droite, atteint directement le bureau de l’équipe.</li>' +
          '<li>' + icon('checkCircle', 14) + ' Si quelque chose vous met mal à l’aise, vous pouvez bloquer un profil : il ne vous réapparaîtra plus.</li>' +
          '</ul>' }) + '</div>' +

        '<div class="row gap-12 mt-24" style="flex-wrap:wrap">' +
        ui.btn({ label: 'Créer un compte', variant: 'primary', href: '#/signup', icon: 'userPlus' }) +
        ui.btn({ label: 'Comment ça marche', variant: 'outline', href: '#/how-it-works' }) +
        '</div>' +
        '</div></section>';
    }
  };

  SEVE.views['matching-help'] = {
    title: 'Aide au matching',
    render() {
      const me = store.me();
      const mine = me ? store.applications({ user: me.id }) : [];
      return '' +
        '<section class="section section--tight"><div class="wrap">' +
        '<div class="grid grid--split">' +
        '<div>' +
        ui.sectionHead({ level: 1, kicker: 'Service de mise en relation', title: 'Besoin d’aide pour trouver un manager ?' }) +
        '<p class="lede">Notre équipe peut rechercher des profils correspondant à vos critères et vous aider à identifier des partenaires potentiels. Vous recevez une présélection argumentée, avec les vérifications déjà réalisées.</p>' +
        '<div class="safe-strip mt-24 reveal">' + [
          { i: 'headset', t: 'Une ligne directe, même sans demande', d: 'Vous n’êtes pas obligée de passer par ce formulaire : depuis votre espace, un bouton « Parler à l’équipe » est présent partout. Une référente nommée vous répond.' },
          { i: 'pause', t: 'Faire une pause n’annule rien', d: 'Vous pouvez mettre votre profil en pause ou en mode discret à tout moment, et revenir quand vous voulez. Personne n’en est informé.' }
        ].map((x) => '<div class="safe-strip__item">' + icon(x.i, 18) + '<div><b>' + U.esc(x.t) + '</b><span>' + U.esc(x.d) + '</span></div></div>').join('') +
        '</div>' +

        '<div class="grid grid--2 mt-32">' + [
          { icon: 'target', t: 'Critères précis', d: 'Langues, créneaux horaires, type de contenu, niveau d’expérience, forme de collaboration.' },
          { icon: 'clock', t: '72 h ouvrées', d: 'Délai habituel. Les demandes urgentes (suspicion de risque) passent en priorité.' },
          { icon: 'shieldCheck', t: 'Profils vérifiés', d: 'Nous vérifions nous-mêmes avant de vous transmettre une liste.' },
          { icon: 'percent', t: 'Gratuit pour les créateurs', d: 'Aucun frais, aucune commission prélevée sur vos revenus.' }
        ].map((x) => '<article class="card card--pad reveal"><span class="notif__icon">' + icon(x.icon, 17) + '</span>' +
          '<h4 class="mt-16">' + U.esc(x.t) + '</h4><p class="small muted mt-8">' + U.esc(x.d) + '</p></article>').join('') + '</div>' +
        '</div>' +
        '<div class="card card--pad reveal" id="form">' +
        '<h3>Demande d’accompagnement</h3>' +
        '<p class="small muted mt-8">Cinq champs suffisent : objectifs, spécialités recherchées, localisation, critères et description du besoin. Nous ne demandons rien d’autre.</p>' +
        '<div class="mt-20">' + SEVE.flows.applicationFormHTML(me) + '</div>' +
        '</div>' +
        '</div></div></section>' +
        (mine.length ? '<section class="section section--tight" style="padding-top:0"><div class="wrap">' +
          '<h3>Vos demandes d’accompagnement</h3>' +
          '<div class="stack gap-12 mt-16">' + mine.map((a) =>
            '<div class="reqrow"><div class="reqrow__body"><div class="between"><b>' + U.esc((store.APPLI_LABELS[a.status] || a.status)) + '</b>' +
            '<span class="small muted">' + U.fmtRelative(a.created) + '</span></div>' +
            '<p class="small muted mt-8">' + U.esc(a.need) + '</p>' +
            '<div class="chips mt-12">' + T.labels(a.specialties).map((l) => '<span class="chip chip--sm">' + U.esc(l) + '</span>').join('') + '</div></div></div>').join('') + '</div>' +
          '</div></section>' : '');
    },
    mount(ctx) {
      const form = ctx.root.querySelector('#appform');
      if (!form) return;
      const submit = ctx.root.querySelector('[data-act="submit-application"]');
      submit.addEventListener('click', (e) => {
        e.preventDefault();
        const me = store.me();
        if (!me) return SEVE.flows.needAuth('Pour demander l’aide de notre équipe, créez un compte ou connectez-vous.');
        if (!ui.validate(form)) return;
        ui.loading(submit, true, 'Envoi…');
        setTimeout(() => {
          store.createApplication({
            user: me.id, type: me.role === 'manager' ? 'manager' : 'créateur',
            goals: Array.from(form.querySelector('#af-goals').selectedOptions).map((o) => o.value),
            specialties: Array.from(form.querySelector('#af-spec').selectedOptions).map((o) => o.value),
            location: form.querySelector('#af-loc').value,
            criteria: form.querySelector('#af-criteria').value,
            need: form.querySelector('#af-need').value
          });
          ui.loading(submit, false);
          ui.toast('Demande reçue. Notre équipe vous répond sous 72 h ouvrées.', 'ok');
          SEVE.router.refresh();
        }, 900);
      });
    }
  };
})();
