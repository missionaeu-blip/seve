/* ==========================================================================
   Sève — espace administrateur
   ========================================================================== */
(function () {
  const U = SEVE.util;
  const ui = SEVE.ui;
  const C = SEVE.components;
  const store = SEVE.store;
  const T = SEVE.taxo;
  const icon = SEVE.icons.svg;

  SEVE.views = SEVE.views || {};

  function head(title, subtitle, actions) {
    return '<div class="page-head"><div><h1>' + U.esc(title) + '</h1>' +
      (subtitle ? '<p>' + U.esc(subtitle) + '</p>' : '') + '</div>' +
      '<div class="row gap-10" style="flex-wrap:wrap">' + (actions || '') + '</div></div>';
  }

  function table(headers, rows, emptyText) {
    if (!rows.length) return ui.empty({ icon: 'search', title: 'Aucun élément', text: emptyText || 'Rien à afficher avec ces filtres.' });
    return '<div class="table-wrap"><table class="table"><thead><tr>' +
      headers.map((h) => '<th>' + h + '</th>').join('') + '</tr></thead><tbody>' + rows.join('') + '</tbody></table></div>';
  }

  function userCell(p, sub) {
    if (!p) return '<span class="muted small">Profil supprimé</span>';
    return '<div class="tcell">' + ui.avatar(Object.assign({ square: p.role === 'manager' }, p), 'sm') +
      '<div class="tcell__txt"><b>' + U.esc(p.name) + (p.verified ? ' ' + ui.verified({ compact: true }) : '') + '</b>' +
      '<span>' + U.esc(sub || (SEVE.flows.roleLabel(p) + ' · ' + p.city)) + '</span></div></div>';
  }

  function statusChip(p) {
    const map = {
      active: ['chip--ok', 'Actif'], pending: ['chip--warn', 'En vérification'],
      suspended: ['chip--danger', 'Suspendu'], archived: ['chip--danger', 'Archivé']
    };
    const cfg = map[p.status || 'active'] || map.active;
    return '<span class="chip chip--sm ' + cfg[0] + '"><span class="statusdot statusdot--' + (p.status || 'active') + '"></span>' + cfg[1] + '</span>';
  }

  /* ================================================================== */
  /* VUE D’ENSEMBLE                                                      */
  /* ================================================================== */
  SEVE.act('admin-refuge-toggle', function () {
    const u = store.currentUser();
    if (!u || u.role !== 'admin') { ui.toast('Accès réservé à l’administration.', 'err'); return; }
    SEVE.refuge.basculer().then((r) => {
      if (!r.ok) { ui.toast(r.erreur || 'Bascule refusée par le serveur.', 'err'); return; }
      ui.toast('Mode global enregistré pour tous les visiteurs. Les comptes existants sont conservés.', 'ok');
      /* applique() a déjà rafraîchi la page courante : ne pas déclencher
         un deuxième rendu pendant que le panneau admin est remplacé. */
    });
  });

  SEVE.views.adminDashboard = {
    title: 'Administration',
    render() {
      const s = store.stats();
      const reports = store.reports({ status: 'open' }).slice(0, 4);
      const pendingProfiles = store.profiles().filter((p) => !p.verified || p.status === 'pending');
      const requests = store.requests({ status: 'pending' }).slice(0, 5);
      const apps = store.applications({ status: 'new' });

      return head('Vue d’ensemble', 'Modération, vérification des profils et suivi de l’activité de la plateforme.',
        ui.btn({ label: 'Traiter les signalements', variant: 'danger', href: '#/admin/reports', icon: 'flag' }) +
        ui.btn({ label: 'Vérifier des profils', variant: 'primary', href: '#/admin/profiles', icon: 'shieldCheck' })
      ) +
        '<section class="panel refuge-admin-panel" id="admin-mode-refuge">' +
        '<div class="panel__head"><h3>' + icon('heart', 17) + ' Orientation du site</h3></div>' +
        '<div class="panel__body"><p><b>' + (SEVE.refuge.actif() ? 'Espace refuge actif' : 'Plateforme de mise en relation active') + '</b></p>' +
        '<p class="small muted">Le mode refuge transforme tout le site public et l’espace créatrice en lieu gratuit d’écoute et de soutien. ' +
        'Quand vous le désactivez, les anciens espaces reviennent. Les comptes enregistrés dans chaque navigateur ne sont pas supprimés.</p>' +
        '<p class="small muted">La démo conserve comptes et messages sur chaque appareil, et ne constitue pas encore une messagerie d’équipe partagée. ' +
        (SEVE.refuge.serveur() ? (SEVE.refuge.adminSeve() ? 'Ce réglage est GLOBAL : il s’applique à tout le site, à tous les comptes et aux nouveaux visiteurs, pas seulement à votre appareil.' : (SEVE.refuge.indisponible() ? 'Impossible de contacter le serveur. Aucun changement local ne sera fait ; rechargez la page et réessayez.' : 'Connectez-vous comme admin Sève, puis rechargez Sève pour modifier le site entier.')) :
          'La bascule exige le serveur PHP. Cet aperçu ne modifie pas le site en ligne.') + '</p>' +
        (SEVE.refuge.serveur() && !SEVE.refuge.adminSeve() ?
          '<a class="btn btn--outline mt-12" href="#/admin/connexion">Se connecter à l’administration Sève</a>' : '') +
        '<div class="mt-12">' + ui.btn({ label: SEVE.refuge.actif() ? 'Revenir au site habituel' : 'Activer le site refuge',
          variant: 'primary', act: 'admin-refuge-toggle', icon: 'heart',
          disabled: !SEVE.refuge.serveur() || !SEVE.refuge.adminSeve() || SEVE.refuge.indisponible() }) + '</div></div></section>' +
        '<div class="mt-12"><a class="btn btn--outline" href="#/admin/refuge">Voir les conversations refuge →</a> <a class="btn btn--outline" href="#/admin/majorite">Contrôles de majorité →</a> <a class="btn btn--outline" href="#/admin/images">PNG à modérer →</a></div>' +
        '<div class="kpis mt-20">' +
        ui.kpi({ label: 'Utilisateurs', value: s.users, icon: 'users', foot: s.creators + ' créateurs · ' + s.managers + ' managers' }) +
        ui.kpi({ label: 'Demandes en attente', value: s.pending, icon: 'send', foot: s.requests + ' demandes au total' }) +
        ui.kpi({ label: 'Signalements ouverts', value: s.reportsOpen, icon: 'flag', foot: reports.filter((r) => r.severity === 'high').length + ' cas prioritaire(s)' }) +
        ui.kpi({ label: 'Profils vérifiés', value: s.verified + ' / ' + (s.creators + s.managers), icon: 'shieldCheck', foot: (s.creators + s.managers - s.verified) + ' en attente de vérification' }) +
        ui.kpi({ label: 'Accompagnements', value: s.applicationsOpen, icon: 'headset', foot: s.applications + ' demandes reçues' }) +
        ui.kpi({ label: 'Messages', value: s.messages, icon: 'message', foot: s.conversations + ' conversations' }) +
        ui.kpi({ label: 'RIB à vérifier', value: store.payoutsStats().declared, icon: 'wallet', foot: store.payoutsStats().verified + ' vérifiés · ' + store.payoutsStats().total + ' comptes' }) +
        '</div>' +

        '<div class="dash-grid mt-20">' +
        '<section class="panel"><div class="panel__head"><h3>' + icon('trending', 16) + 'Inscriptions (12 dernières périodes)</h3>' +
        '<span class="small muted">' + s.signups[s.signups.length - 1] + ' cette période</span></div>' +
        '<div class="panel__body">' + ui.sparkline(s.signups) +
        '<div class="row gap-16 mt-12"><div><span class="tiny muted">Total</span><b style="display:block">' + U.fmtNum(s.signups.reduce((a, b) => a + b, 0)) + '</b></div>' +
        '<div><span class="tiny muted">Mises en relation</span><b style="display:block">' + U.fmtNum(s.matches.reduce((a, b) => a + b, 0)) + '</b></div>' +
        '<div><span class="tiny muted">Visites</span><b style="display:block">' + U.fmtNum(s.traffic.reduce((a, b) => a + b, 0)) + '</b></div></div>' +
        '</div></section>' +

        '<section class="panel"><div class="panel__head"><h3>' + icon('flag', 16) + 'Signalements récents</h3>' +
        '<a class="small strong" href="#/admin/reports" style="color:var(--green-700)">Tout voir</a></div>' +
        (reports.length ? '<div class="panel__list">' + reports.map((r) =>
          '<button class="panelrow" data-href="#/admin/reports">' +
          '<span class="notif__icon" style="background:' + (r.severity === 'high' ? 'var(--danger-bg);color:var(--danger)' : 'var(--warn-bg);color:var(--warn)') + '">' + icon('flag', 16) + '</span>' +
          '<span class="panelrow__body"><b>' + U.esc(r.reason) + '</b><span>' + U.esc(r.targetName) + ' · signalé par ' + U.esc((r.byProfile && r.byProfile.name) || 'un membre') + '</span></span>' +
          '<span class="panelrow__meta">' + U.fmtRelative(r.created) + '</span></button>').join('') + '</div>'
          : ui.empty({ icon: 'checkCircle', title: 'Aucun signalement ouvert', text: 'Tous les dossiers sont traités.' })) +
        '</section>' +

        '<section class="panel"><div class="panel__head"><h3>' + icon('shieldCheck', 16) + 'File de vérification</h3>' +
        '<a class="small strong" href="#/admin/profiles" style="color:var(--green-700)">Gérer</a></div>' +
        '<div class="panel__list">' + pendingProfiles.slice(0, 5).map((p) =>
          '<div class="panelrow" style="cursor:default">' + userCell(p, p.role === 'manager' ? p.kind : 'Créatrice · ' + U.fmtK(p.subs || 0) + ' abonnés') +
          '<div class="cell-actions">' + ui.btn({ label: 'Vérifier', variant: 'soft', size: 'xs', act: 'admin-verify', data: { id: p.id } }) +
          ui.btn({ label: 'Profil', variant: 'ghost', size: 'xs', href: '#/profiles/' + p.id }) + '</div></div>').join('') + '</div></section>' +

        '<section class="panel"><div class="panel__head"><h3>' + icon('send', 16) + 'Demandes récentes</h3>' +
        '<a class="small strong" href="#/admin/requests" style="color:var(--green-700)">Tout voir</a></div>' +
        '<div class="panel__list">' + requests.map((r) =>
          '<button class="panelrow" data-href="#/admin/requests">' + ui.avatar(r.fromProfile, 'sm') +
          '<span class="panelrow__body"><b>' + U.esc(r.fromProfile.name) + ' → ' + U.esc(r.toProfile.name) + '</b>' +
          '<span class="clamp-2">' + U.esc(r.message.slice(0, 110)) + '…</span></span>' +
          '<span class="panelrow__meta">' + U.fmtRelative(r.created) + '</span></button>').join('') + '</div></section>' +

        '<section class="panel"><div class="panel__head"><h3>' + icon('headset', 16) + 'Accompagnements à traiter</h3>' +
        '<a class="small strong" href="#/admin/applications" style="color:var(--green-700)">Ouvrir</a></div>' +
        (apps.length ? '<div class="panel__list">' + apps.slice(0, 4).map((a) =>
          '<button class="panelrow" data-href="#/admin/applications">' +
          '<span class="notif__icon">' + icon('headset', 16) + '</span>' +
          '<span class="panelrow__body"><b>' + U.esc((a.profile && a.profile.name) || 'Membre') + '</b>' +
          '<span>' + U.esc(a.location) + ' · ' + T.labels(a.specialties).slice(0, 2).join(', ') + '</span></span>' +
          '<span class="panelrow__meta">' + U.fmtRelative(a.created) + '</span></button>').join('') + '</div>'
          : ui.empty({ icon: 'checkCircle', title: 'Aucune demande en attente', text: 'Les demandes d’accompagnement traitées restent consultables.' })) +
        '</section>' +
        '</div>' +

        '<div class="card card--pad mt-20">' +
        '<h3>Actions de modération rapides</h3>' +
        '<div class="adminbar mt-16" style="flex-wrap:wrap;gap:10px">' +
        ui.btn({ label: 'Vérifier un profil', variant: 'outline', size: 'sm', href: '#/admin/profiles', icon: 'shieldCheck' }) +
        ui.btn({ label: 'Suspendre un compte', variant: 'outline', size: 'sm', href: '#/admin/users', icon: 'ban' }) +
        ui.btn({ label: 'Traiter un signalement', variant: 'outline', size: 'sm', href: '#/admin/reports', icon: 'flag' }) +
        ui.btn({ label: 'Contrôler les messages signalés', variant: 'outline', size: 'sm', href: '#/admin/messages', icon: 'message' }) +
        ui.btn({ label: 'Vérifier les coordonnées de paiement', variant: 'outline', size: 'sm', href: '#/admin/payouts', icon: 'wallet' }) +
        ui.btn({ label: 'Réinitialiser la démonstration', variant: 'danger', size: 'sm', act: 'admin-reset', icon: 'refresh' }) +
        '</div></div>';
    }
  };

  /* ================================================================== */
  /* UTILISATEURS                                                        */
  /* ================================================================== */
  SEVE.views.adminUsers = {
    title: 'Utilisateurs',
    render(ctx) {
      const q = ctx.query.q || '';
      const role = ctx.query.role || 'all';
      const users = store.allUsers({ q, role });
      const rows = users.map((u) => '<tr>' +
        '<td>' + (u.profile ? userCell(u.profile, u.email) : '<div class="tcell"><div class="tcell__txt"><b>' + U.esc(u.name) + '</b><span>' + U.esc(u.email) + '</span></div></div>') + '</td>' +
        '<td><span class="chip chip--sm">' + (u.role === 'admin' ? 'Administrateur' : u.role === 'manager' ? 'Manager' : 'Créateur') + '</span></td>' +
        '<td>' + (u.profile ? statusChip(u.profile) : '<span class="muted small">—</span>') + '</td>' +
        '<td>' + (u.verified ? ui.verified({ compact: true }) : '<span class="muted small">non vérifié</span>') + '</td>' +
        '<td class="small muted">' + U.fmtDate(u.joined, { short: true }) + '</td>' +
        '<td><div class="cell-actions">' +
        (u.profile ? ui.btn({ label: 'Profil', variant: 'ghost', size: 'xs', href: '#/profiles/' + u.profile.id }) : '') +
        (u.role === 'admin' ? '' : (u.suspended
          ? ui.btn({ label: 'Réactiver', variant: 'soft', size: 'xs', act: 'admin-unsuspend', data: { id: u.id } })
          : ui.btn({ label: 'Suspendre', variant: 'outline', size: 'xs', act: 'admin-suspend', data: { id: u.id } }))) +
        '</div></td></tr>').join('');

      return head('Utilisateurs', users.length + ' compte(s) — suspension, réactivation et accès aux profils.',
        ui.btn({ label: 'Exporter la liste', variant: 'outline', size: 'sm', act: 'admin-export', icon: 'doc' })) +
        '<div class="filterbar" data-filters><div class="filters">' +
        '<div class="filter" style="grid-column:span 2">' + C.searchBar({ value: q, id: 'adm-q', placeholder: 'Rechercher un nom ou un email' }) + '</div>' +
        C.chipsHTML({ key: 'role', label: 'Rôle', value: role, options: [['all', 'Tous les rôles'], ['creator', 'Créateurs'], ['manager', 'Managers'], ['admin', 'Administrateurs']] }) +
        '</div></div>' +
        '<div class="mt-20">' + table(['Compte', 'Rôle', 'Statut', 'Vérification', 'Inscription', ''], users.length ? [rows] : []) + '</div>';
    },
    mount(ctx) { C.bindFilters(ctx.root, '/admin/users'); }
  };

  /* ================================================================== */
  /* CRÉATEURS / MANAGERS (gestion des profils)                          */
  /* ================================================================== */
  function profileTable(role, ctx) {
    const q = ctx.query.q || '';
    const filter = ctx.query.status || 'all';
    const list = store.search({ q, type: role }).filter((p) => filter === 'all' || (filter === 'pending' ? !p.verified : p.status === filter));
    const rows = list.map((p) => '<tr>' +
      '<td>' + userCell(p, role === 'manager' ? p.kind : U.fmtK(p.subs || 0) + ' abonnés · ' + p.city) + '</td>' +
      '<td>' + C.specChips(p.specialties, 2) + '</td>' +
      '<td>' + (p.verified ? ui.verified({ label: 'Vérifié' }) : '<span class="muted small">En attente</span>') + '</td>' +
      '<td>' + statusChip(p) + '</td>' +
      '<td class="small muted">' + (store.reports({}).filter((r) => r.target === p.id).length || '—') + '</td>' +
      '<td><div class="cell-actions">' +
      ui.btn({ label: p.verified ? 'Retirer la vérification' : 'Vérifier', variant: p.verified ? 'ghost' : 'soft', size: 'xs', act: p.verified ? 'admin-unverify' : 'admin-verify', data: { id: p.id } }) +
      ui.btn({ label: 'Statut', variant: 'outline', size: 'xs', act: 'admin-status', data: { id: p.id } }) +
      ui.btn({ label: 'Profil', variant: 'ghost', size: 'xs', href: '#/profiles/' + p.id }) +
      ui.btn({ label: '', variant: 'ghost', size: 'xs', act: 'admin-delete', data: { id: p.id }, icon: 'trash', iconOnly: true, title: 'Supprimer le profil' }) +
      '</div></td></tr>').join('');

    return head(role === 'creator' ? 'Créateurs' : 'Managers',
      list.length + ' profil(s) — vérification, changement de statut et suppression.',
      ui.btn({ label: 'File de vérification', variant: 'outline', size: 'sm', href: '#/admin/profiles' })) +
      '<div class="filterbar" data-filters><div class="filters">' +
      '<div class="filter" style="grid-column:span 2">' + C.searchBar({ value: q, id: 'adm-q', placeholder: 'Rechercher un ' + (role === 'creator' ? 'créateur' : 'manager') }) + '</div>' +
      C.chipsHTML({ key: 'status', label: 'Statut', value: filter, options: [['all', 'Tous les statuts'], ['pending', 'Non vérifiés'], ['active', 'Actifs'], ['suspended', 'Suspendus'], ['archived', 'Archivés']] }) +
      '</div></div>' +
      '<div class="mt-20">' + table(['Profil', 'Spécialités', 'Vérification', 'Statut', 'Signalements', ''], list.length ? [rows] : []) + '</div>';
  }

  SEVE.views.adminCreators = { title: 'Créateurs', render(ctx) { return profileTable('creator', ctx); }, mount(ctx) { C.bindFilters(ctx.root, '/admin/creators'); } };
  SEVE.views.adminManagers = { title: 'Managers', render(ctx) { return profileTable('manager', ctx); }, mount(ctx) { C.bindFilters(ctx.root, '/admin/managers'); } };

  /* ================================================================== */
  /* DEMANDES                                                            */
  /* ================================================================== */
  SEVE.views.adminRequests = {
    title: 'Demandes',
    render(ctx) {
      const status = ctx.query.status || 'all';
      const list = store.requests({ status });
      const rows = list.map((r) => '<tr>' +
        '<td>' + userCell(r.fromProfile) + '</td>' +
        '<td>' + userCell(r.toProfile) + '</td>' +
        '<td><span class="small clamp-2" style="color:var(--ink-2);max-width:380px;display:block">' + U.esc(r.message) + '</span></td>' +
        '<td>' + ui.pill(r.status === 'pending' ? 'En attente' : r.status === 'accepted' ? 'Acceptée' : r.status === 'declined' ? 'Refusée' : 'Archivée',
          r.status === 'pending' ? 'pending' : r.status === 'accepted' ? 'accepted' : r.status === 'declined' ? 'declined' : 'archived') + '</td>' +
        '<td class="small muted">' + U.fmtRelative(r.created) + '</td>' +
        '<td><div class="cell-actions">' +
        ui.btn({ label: 'Voir', variant: 'ghost', size: 'xs', act: 'admin-request-open', data: { id: r.id } }) +
        (r.status === 'pending' ? ui.btn({ label: 'Archiver', variant: 'outline', size: 'xs', act: 'admin-request-archive', data: { id: r.id } }) : '') +
        '</div></td></tr>').join('');

      return head('Demandes de collaboration', list.length + ' demande(s) — inspection et archivage pour litige ou contenu contraire aux règles.') +
        '<div class="filterbar" data-filters><div class="filters">' +
        C.chipsHTML({ key: 'status', label: 'Statut', value: status, options: [['all', 'Tous les statuts'], ['pending', 'En attente'], ['accepted', 'Acceptées'], ['declined', 'Refusées'], ['archived', 'Archivées']] }) +
        '<div class="filter"><span class="label">Volume</span><span class="chip">' + list.filter((r) => r.status === 'pending').length + ' à surveiller</span></div>' +
        '</div></div>' +
        '<div class="mt-20">' + table(['Expéditeur', 'Destinataire', 'Message', 'Statut', 'Date', ''], list.length ? [rows] : []) + '</div>';
    },
    mount(ctx) { C.bindFilters(ctx.root, '/admin/requests'); }
  };

  /* ================================================================== */
  /* SIGNALEMENTS                                                        */
  /* ================================================================== */
  SEVE.views.adminReports = {
    title: 'Signalements',
    render(ctx) {
      const status = ctx.query.status || 'all';
      const severity = ctx.query.severity || 'all';
      const list = store.reports({ status, severity });
      const cards = list.map((r) => {
        const sev = r.severity === 'high' ? ['sev--high', 'Priorité haute'] : r.severity === 'mid' ? ['sev--mid', 'Priorité moyenne'] : ['sev--low', 'Priorité basse'];
        return '<article class="card card--pad reveal">' +
          '<div class="between" style="align-items:flex-start;gap:12px">' +
          '<div class="row gap-12">' + ui.avatar(Object.assign({ square: r.targetProfile && r.targetProfile.role === 'manager' }, r.targetProfile || { name: r.targetName }), 'md') +
          '<div><b style="font-size:15px">' + U.esc(r.targetName) + '</b>' +
          '<p class="small muted">Signalé par ' + U.esc((r.byProfile && r.byProfile.name) || 'un membre') + ' · ' + U.fmtRelative(r.created) + '</p></div></div>' +
          '<div class="row gap-8"><span class="sev ' + sev[0] + '">' + sev[1] + '</span>' +
          ui.pill(store.REPORT_STATUS[r.status], r.status === 'open' ? 'pending' : r.status === 'progress' ? 'accepted' : 'archived') + '</div></div>' +
          '<div class="banner banner--soft mt-16">' + icon('flag', 17) + '<div><b>' + U.esc(r.reason) + '</b><br>' + U.esc(r.detail) + '</div></div>' +
          (r.resolution ? '<p class="small muted mt-12">' + icon('checkCircle', 14) + ' ' + U.esc(r.resolution) + '</p>' : '') +
          '<div class="adminbar mt-16">' +
          ui.btn({ label: 'Traiter', variant: 'primary', size: 'sm', act: 'admin-report', data: { id: r.id } }) +
          ui.btn({ label: 'Voir le profil', variant: 'outline', size: 'sm', href: '#/profiles/' + r.target }) +
          ui.btn({ label: 'Message signalé', variant: 'ghost', size: 'sm', href: '#/admin/messages?case=' + r.id }) +
          (r.targetProfile && r.targetProfile.status === 'suspended'
            ? ui.btn({ label: 'Réactiver', variant: 'soft', size: 'sm', act: 'admin-unsuspend-profile', data: { id: r.target } })
            : ui.btn({ label: 'Suspendre', variant: 'danger', size: 'sm', act: 'admin-suspend-profile', data: { id: r.target } })) +
          ui.btn({ label: 'Retirer la vérification', variant: 'ghost', size: 'sm', act: 'admin-unverify', data: { id: r.target } }) +
          '</div></article>';
      }).join('');

      return head('Signalements', list.length + ' dossier(s). Les motifs sensibles (mineurs, paiement hors cadre, contrainte) doivent être traités sous 12 heures.',
        ui.btn({ label: 'Règles de la plateforme', variant: 'outline', size: 'sm', href: '#/legal/rules', icon: 'scale' })) +
        '<div class="filterbar" data-filters><div class="filters">' +
        C.chipsHTML({ key: 'status', label: 'Statut', value: status, options: [['all', 'Tous les statuts'], ['open', 'À traiter'], ['progress', 'En cours'], ['closed', 'Traités']] }) +
        C.chipsHTML({ key: 'severity', label: 'Priorité', value: severity, options: [['all', 'Toutes'], ['high', 'Haute'], ['mid', 'Moyenne'], ['low', 'Basse']] }) +
        '</div></div>' +
        '<div class="grid mt-20" style="gap:16px">' + (cards || ui.empty({ icon: 'checkCircle', title: 'Aucun signalement dans ce filtre', text: 'Les dossiers traités restent archivés et consultables.' })) + '</div>';
    },
    mount(ctx) { C.bindFilters(ctx.root, '/admin/reports'); }
  };

  /* ================================================================== */
  /* MESSAGES SIGNALÉS                                                   */
  /* ================================================================== */
  SEVE.views.adminMessages = {
    title: 'Messages signalés',
    render(ctx) {
      const caseId = ctx.query.case;
      const reports = store.reports({});
      const active = caseId ? reports.filter((r) => r.id === caseId)[0] : reports[0];
      const convs = store.conversations({}).filter((c) => active && (c.with === active.target || c.with === active.by));

      const list = reports.map((r) => '<button class="conv' + (active && r.id === active.id ? ' is-active' : '') + '" data-act="open-case" data-id="' + r.id + '">' +
        '<span class="notif__icon" style="background:' + (r.severity === 'high' ? 'var(--danger-bg);color:var(--danger)' : 'var(--bg-2);color:var(--ink-3)') + '">' + icon('flag', 15) + '</span>' +
        '<span class="conv__body"><span class="conv__top"><span class="conv__name">' + U.esc(r.targetName) + '</span>' +
        '<span class="conv__time">' + U.fmtRelative(r.created) + '</span></span>' +
        '<span class="conv__last">' + U.esc(r.reason) + '</span></span></button>').join('');

      return head('Messages signalés', 'Extraits de conversations rattachés à un signalement. Les pièces jointes ne sont jamais stockées sur Sève.',
        ui.btn({ label: 'Retour aux signalements', variant: 'outline', size: 'sm', href: '#/admin/reports', icon: 'flag' })) +
        '<div class="chat" style="grid-template-columns:320px 1fr">' +
        '<div class="chat__side"><div class="chat__sidehead"><b class="small">Dossiers</b>' +
        '<p class="tiny muted mt-4">' + reports.length + ' dossiers · ' + reports.filter((r) => r.status !== 'closed').length + ' ouverts</p></div>' +
        '<div class="chat__list">' + list + '</div></div>' +
        '<div class="chat__thread">' +
        (active ? '<div class="chat__head">' +
          ui.avatar(active.targetProfile || { name: active.targetName }, 'sm') +
          '<div style="flex:1;min-width:0"><div class="row gap-8"><b style="font-size:14.5px">' + U.esc(active.targetName) + '</b>' +
          '<span class="sev ' + (active.severity === 'high' ? 'sev--high' : 'sev--mid') + '">' + U.esc(active.reason) + '</span></div>' +
          '<span class="small muted">Signalé par ' + U.esc((active.byProfile && active.byProfile.name) || 'un membre') + ' · ' + U.fmtRelative(active.created) + '</span></div>' +
          '<div class="row gap-8">' + ui.btn({ label: 'Profil', variant: 'outline', size: 'sm', href: '#/profiles/' + active.target }) +
          ui.btn({ label: 'Traiter', variant: 'primary', size: 'sm', act: 'admin-report', data: { id: active.id } }) + '</div></div>' +
          '<div class="chat__flagbar">' + icon('alert', 16) + '<span>Extrait conservé pour instruction. Ne pas diffuser hors de l’équipe de modération.</span></div>' +
          '<div class="chat__body">' +
          (convs.length
            ? convs.map((c) => {
              const other = store.get(c.with);
              return c.messages.map((m) => '<div class="msg ' + (m.from === 'me' ? 'msg--me' : 'msg--them') + ' ' + (c.with === active.target ? 'msg--flag' : '') + '">' +
                '<div class="msg__bubble">' + U.esc(m.text) + '</div>' +
                '<span class="msg__time">' + U.esc((other && other.name) || c.name) + ' · ' + U.fmtDate(m.at, { short: true }) + ' ' + U.fmtTime(m.at) + '</span></div>').join('');
            }).join('')
            : '<div class="msg msg--them"><div class="msg__bubble">Aucun historique de conversation disponible pour ce dossier. Le signalement porte sur un échange hors messagerie ou sur un élément de profil.</div>' +
              '<span class="msg__time">Dossier ' + U.esc(active.id) + '</span></div>') +
          '</div>' +
          '<div class="chat__composer" style="flex-direction:column;align-items:stretch;gap:10px">' +
          '<div class="banner banner--soft" style="padding:12px 14px">' + icon('info', 17) +
          '<div class="small"><b>Rappel de procédure :</b> avertir, suspendre ou retirer la vérification. Toute décision est journalisée avec votre identifiant d’administrateur.</div></div>' +
          '<div class="row gap-8" style="flex-wrap:wrap">' +
          ui.btn({ label: 'Avertir le profil', variant: 'outline', size: 'sm', act: 'admin-warn', data: { id: active.target } }) +
          ui.btn({ label: 'Suspendre', variant: 'danger', size: 'sm', act: 'admin-suspend-profile', data: { id: active.target } }) +
          ui.btn({ label: 'Clôturer le dossier', variant: 'primary', size: 'sm', act: 'admin-report', data: { id: active.id } }) +
          '</div></div>'
          : ui.empty({ icon: 'message', title: 'Aucun dossier sélectionné', text: 'Choisissez un dossier à gauche pour consulter les extraits conservés.' })) +
        '</div></div>';
    },
    mount(ctx) {
      ctx.root.querySelectorAll('[data-act="open-case"]').forEach((b) => b.addEventListener('click', () => {
        SEVE.router.navigate('/admin/messages?case=' + b.getAttribute('data-id'));
      }));
      const body = ctx.root.querySelector('.chat__body');
      if (body) body.scrollTop = body.scrollHeight;
    }
  };

  /* ================================================================== */
  /* GESTION DES PROFILS                                                 */
  /* ================================================================== */
  SEVE.views.adminProfiles = {
    title: 'Gestion des profils',
    render() {
      const all = store.profiles();
      const pending = all.filter((p) => !p.verified);
      const suspended = all.filter((p) => p.status === 'suspended');
      const quick = (p) => '<div class="panelrow" style="cursor:default">' + userCell(p, p.role === 'manager' ? p.kind : U.fmtK(p.subs || 0) + ' abonnés · ' + p.city) +
        '<div class="cell-actions">' +
        ui.btn({ label: 'Vérifier', variant: 'soft', size: 'xs', act: 'admin-verify', data: { id: p.id } }) +
        ui.btn({ label: 'Profil', variant: 'ghost', size: 'xs', href: '#/profiles/' + p.id }) +
        '</div></div>';

      return head('Gestion des profils', all.length + ' profils — vérification, statuts, suppression. Chaque action est journalisée.',
        ui.btn({ label: 'Créateurs', variant: 'outline', size: 'sm', href: '#/admin/creators' }) +
        ui.btn({ label: 'Managers', variant: 'outline', size: 'sm', href: '#/admin/managers' })) +

        '<div class="modcard">' +
        '<section class="panel"><div class="panel__head"><h3>' + icon('shieldCheck', 16) + 'À vérifier (' + pending.length + ')</h3></div>' +
        (pending.length ? '<div class="panel__list">' + pending.slice(0, 6).map(quick).join('') + '</div>'
          : ui.empty({ icon: 'checkCircle', title: 'Tous les profils sont vérifiés', text: 'Les nouvelles inscriptions apparaîtront ici.' })) + '</section>' +
        '<section class="panel"><div class="panel__head"><h3>' + icon('ban', 16) + 'Comptes suspendus (' + suspended.length + ')</h3></div>' +
        (suspended.length ? '<div class="panel__list">' + suspended.map((p) => '<div class="panelrow" style="cursor:default">' + userCell(p) +
          '<div class="cell-actions">' + ui.btn({ label: 'Réactiver', variant: 'soft', size: 'xs', act: 'admin-unsuspend-profile', data: { id: p.id } }) + '</div></div>').join('') + '</div>'
          : ui.empty({ icon: 'checkCircle', title: 'Aucun compte suspendu', text: 'Les suspensions apparaissent ici avec la date et le motif du dossier.' })) + '</section>' +
        '</div>' +

        '<div class="card card--pad mt-20">' +
        '<h3>Procédure de vérification</h3>' +
        '<div class="grid grid--3 mt-16">' + [
          ['1. Contrôle d’identité', 'Document officiel, correspondance avec le nom public, confirmation de majorité. Aucun document n’est conservé au-delà du contrôle.'],
          ['2. Contrôle de cohérence', 'Localisation, plateformes déclarées, portfolio : les éléments doivent concorder. Un doute sur l’âge entraîne une suspension immédiate.'],
          ['3. Décision journalisée', 'Vérification accordée, report avec demande de complément, ou refus motivé. Le membre est informé dans la messagerie.']
        ].map((x) => '<div class="banner banner--soft" style="align-items:flex-start">' + icon('checkCircle', 18) +
          '<div><b>' + x[0] + '</b><br>' + U.esc(x[1]) + '</div></div>').join('') + '</div>' +
        '</div>' +

        '<section class="panel mt-20"><div class="panel__head"><h3>' + icon('layers', 16) + 'Tous les profils</h3>' +
        '<span class="small muted">' + all.length + ' profils</span></div>' +
        '<div class="panel__list">' + all.map((p) => '<div class="panelrow" style="cursor:default">' + userCell(p) +
          '<div class="cell-actions">' +
          ui.btn({ label: p.verified ? 'Retirer la vérif.' : 'Vérifier', variant: p.verified ? 'ghost' : 'soft', size: 'xs', act: p.verified ? 'admin-unverify' : 'admin-verify', data: { id: p.id } }) +
          ui.btn({ label: 'Statut', variant: 'outline', size: 'xs', act: 'admin-status', data: { id: p.id } }) +
          ui.btn({ label: '', variant: 'ghost', size: 'xs', icon: 'trash', iconOnly: true, act: 'admin-delete', data: { id: p.id }, title: 'Supprimer' }) +
          '</div></div>').join('') + '</div></section>';
    }
  };

  /* ================================================================== */
  /* ACCOMPAGNEMENT                                                      */
  /* ================================================================== */
  SEVE.views.adminApplications = {
    title: 'Demandes d’accompagnement',
    render(ctx) {
      const status = ctx.query.status || 'all';
      const list = store.applications({ status });
      const cards = list.map((a) => '<article class="card card--pad reveal">' +
        '<div class="between" style="align-items:flex-start;gap:12px">' +
        '<div class="row gap-12">' + ui.avatar(a.profile || { name: 'Membre' }, 'md') +
        '<div><b style="font-size:15px">' + U.esc((a.profile && a.profile.name) || 'Membre supprimé') + '</b>' +
        '<p class="small muted">' + U.esc(a.type) + ' · ' + U.esc(a.location) + ' · ' + U.fmtRelative(a.created) + '</p></div></div>' +
        ui.pill(store.APPLI_LABELS[a.status] || a.status, a.status === 'new' ? 'pending' : a.status === 'progress' ? 'accepted' : 'archived') + '</div>' +
        '<dl class="defs mt-16">' +
        '<div class="def"><dt>Objectifs</dt><dd>' + U.esc((a.goals || []).join(' · ') || '—') + '</dd></div>' +
        '<div class="def"><dt>Spécialités recherchées</dt><dd>' + U.esc(T.labels(a.specialties).join(', ') || '—') + '</dd></div>' +
        '<div class="def"><dt>Critères</dt><dd>' + U.esc(a.criteria) + '</dd></div>' +
        '<div class="def"><dt>Besoin exprimé</dt><dd>' + U.esc(a.need) + '</dd></div>' +
        '<div class="def"><dt>Canal d’arrivée</dt><dd>' + U.esc(store.sourceLabel(a.source)) +
          (store.SOURCE_LABELS[a.source] ? '' : ' <span class="small muted">' + U.esc(a.source || '—') + '</span>') + '</dd></div>' +
        (a.assigned ? '<div class="def"><dt>Profil assigné</dt><dd>' + U.esc(((store.get(a.assigned) || {}).name) || a.assigned) + '</dd></div>' : '') +
        '</dl>' +
        '<div class="adminbar mt-16">' +
        ui.btn({ label: 'Prendre en charge', variant: 'outline', size: 'sm', act: 'admin-app-status', data: { id: a.id, status: 'progress' } }) +
        ui.btn({ label: 'Assigner un profil', variant: 'primary', size: 'sm', act: 'admin-app-assign', data: { id: a.id } }) +
        ui.btn({ label: 'Répondre au membre', variant: 'soft', size: 'sm', act: 'admin-app-reply', data: { id: a.id } }) +
        ui.btn({ label: 'Clôturer', variant: 'ghost', size: 'sm', act: 'admin-app-status', data: { id: a.id, status: 'closed' } }) +
        '</div></article>').join('');

      return head('Demandes d’accompagnement', list.length + ' demande(s). Chaque créateur doit recevoir une réponse sous 72 h ouvrées.',
        ui.btn({ label: 'Statistiques', variant: 'outline', size: 'sm', href: '#/admin/stats', icon: 'chart' })) +
        '<div class="filterbar" data-filters><div class="filters">' +
        C.chipsHTML({ key: 'status', label: 'Statut', value: status, options: [['all', 'Toutes'], ['new', 'Nouvelles'], ['progress', 'En cours'], ['matched', 'Mises en relation'], ['closed', 'Clôturées']] }) +
        '</div></div>' +
        '<div class="grid mt-20" style="gap:16px">' + (cards || ui.empty({ icon: 'checkCircle', title: 'Aucune demande dans ce filtre', text: 'Les demandes traitées restent consultables dans « Clôturées ».' })) + '</div>';
    },
    mount(ctx) { C.bindFilters(ctx.root, '/admin/applications'); }
  };

  /* ================================================================== */
  /* STATISTIQUES                                                        */
  /* ================================================================== */
  SEVE.views.adminStats = {
    title: 'Statistiques',
    render() {
      const s = store.stats();
      const specs = store.specialtyDistribution();
      const regions = store.regionDistribution();
      const conv = s.requests ? Math.round((s.accepted / s.requests) * 100) : 0;

      return head('Statistiques', 'Indicateurs d’usage et de modération. Aucune donnée individuelle n’est exposée ici.',
        ui.btn({ label: 'Exporter le rapport', variant: 'outline', size: 'sm', act: 'admin-export-report', icon: 'doc' })) +
        '<div class="kpis">' +
        ui.kpi({ label: 'Inscriptions cumulées', value: U.fmtNum(s.signups.reduce((a, b) => a + b, 0)), icon: 'userPlus', foot: '<span class="trend trend--up">+14 %</span> vs période précédente' }) +
        ui.kpi({ label: 'Mises en relation', value: U.fmtNum(s.matches.reduce((a, b) => a + b, 0)), icon: 'heart', foot: 'Dont ' + s.accepted + ' collaborations acceptées' }) +
        ui.kpi({ label: 'Taux d’acceptation', value: conv + ' %', icon: 'percent', foot: s.pending + ' demandes encore en attente' }) +
        ui.kpi({ label: 'Dossiers de modération', value: store.reports({}).length, icon: 'flag', foot: s.reportsOpen + ' ouverts · ' + s.suspended + ' suspensions actives' }) +
        ui.kpi({ label: 'Accompagnements', value: s.applications, icon: 'headset', foot: s.applicationsOpen + ' non clôturés' }) +
        ui.kpi({ label: 'Messages échangés', value: U.fmtNum(s.messages), icon: 'message', foot: s.conversations + ' conversations actives' }) +
        '</div>' +

        '<div class="dash-grid mt-20">' +
        '<section class="panel"><div class="panel__head"><h3>' + icon('trending', 16) + 'Trafic et inscriptions</h3></div>' +
        '<div class="panel__body"><div class="small muted mb-8">Visites</div>' + ui.sparkline(s.traffic) +
        '<div class="small muted mt-16 mb-8">Inscriptions</div>' + ui.sparkline(s.signups, { height: 48 }) + '</div></section>' +

        '<section class="panel"><div class="panel__head"><h3>' + icon('layers', 16) + 'Spécialités les plus déclarées</h3></div>' +
        '<div class="panel__body">' + ui.bars(specs.map((x) => ({ label: x.label, value: x.value }))) + '</div></section>' +

        '<section class="panel"><div class="panel__head"><h3>' + icon('globe', 16) + 'Répartition géographique</h3></div>' +
        '<div class="panel__body">' + ui.bars(regions.map((x) => ({ label: x.label, value: x.value }))) + '</div></section>' +

        '<section class="panel"><div class="panel__head"><h3>' + icon('wallet', 16) + 'Coordonnées de paiement</h3>' +
        '<a class="small strong" href="#/admin/payouts" style="color:var(--green-700)">Contrôler</a></div>' +
        '<div class="panel__body">' + (function () {
          const ps = store.payoutsStats();
          return '<div class="row gap-16 mb-16">' + ui.ring(ps.total ? Math.round((ps.verified / ps.total) * 100) : 0, { size: 62, caption: 'vérifiés' }) +
            '<div><b style="font-size:14.5px">' + ps.verified + ' / ' + ps.total + ' comptes contrôlés</b>' +
            '<p class="small muted mt-4">Contrôle formel : clé IBAN, clé RIB, format BIC, concordance du titulaire. Aucun accès bancaire.</p></div></div>' +
            ui.bars([
              { label: 'Vérifiées', value: ps.verified, display: String(ps.verified) },
              { label: 'À vérifier', value: ps.declared, display: String(ps.declared) },
              { label: 'À corriger', value: ps.rejected, display: String(ps.rejected) },
              { label: 'Jeux de démo', value: ps.demo, display: String(ps.demo) }
            ], { max: Math.max(1, ps.total) });
        })() + '</div></section>' +

        '<section class="panel"><div class="panel__head"><h3>' + icon('scale', 16) + 'Modération</h3></div>' +
        '<div class="panel__body">' + [
          ['Signalements reçus', store.reports({}).length],
          ['Dossiers traités', store.reports({ status: 'closed' }).length],
          ['Priorité haute en cours', store.reports({ status: 'open' }).filter((r) => r.severity === 'high').length],
          ['Suspensions actives', s.suspended],
          ['Profils bloqués par des membres', s.blocked],
          ['Vérifications en attente', store.profiles().filter((p) => !p.verified).length]
        ].map((r) => '<div class="between" style="padding:9px 0;border-bottom:1px solid var(--line)"><span class="small muted">' + r[0] + '</span>' +
          '<b class="tnum">' + r[1] + '</b></div>').join('') + '</div></section>' +
        '</div>';
    }
  };

  /* ================================================================== */
  /* ACTIONS D’ADMINISTRATION                                            */
  /* ================================================================== */
  SEVE.act('admin-verify', function (el) {
    const id = el.getAttribute('data-id');
    const p = store.get(id);
    store.setVerified(id, true);
    if (p && p.status === 'pending') store.setProfileStatus(id, 'active');
    ui.toast((p ? p.name : 'Profil') + ' est vérifié. Un message de confirmation est envoyé au membre.', 'ok', { title: 'Vérification accordée' });
    SEVE.router.refresh();
  });

  SEVE.act('admin-unverify', function (el) {
    const id = el.getAttribute('data-id');
    const p = store.get(id);
    ui.confirm({
      title: 'Retirer la vérification ?',
      text: 'Le badge disparaît du profil public. Le membre peut soumettre à nouveau ses justificatifs.',
      detail: p && p.verified ? 'Profil concerné : ' + p.name : '',
      okLabel: 'Retirer la vérification', danger: true
    }).then((ok) => {
      if (!ok) return;
      store.setVerified(id, false);
      ui.toast('Vérification retirée.', 'info');
      SEVE.router.refresh();
    });
  });

  SEVE.act('admin-status', function (el) {
    const id = el.getAttribute('data-id');
    const p = store.get(id);
    if (!p) return;
    ui.modal({
      title: 'Modifier le statut du profil',
      size: 'sm',
      subtitle: p.name + ' · ' + (p.role === 'manager' ? p.kind : 'Créatrice / Créateur'),
      body: '<div class="field"><label class="label" for="st-value">Nouveau statut</label>' +
        '<select class="select" id="st-value">' +
        [['active', 'Actif — visible et contactable'],
         ['pending', 'En vérification — visible, badge non accordé'],
         ['suspended', 'Suspendu — invisible, connexion bloquée'],
         ['archived', 'Archivé — retiré des recherches, données conservées']]
          .map((o) => '<option value="' + o[0] + '"' + (p.status === o[0] ? ' selected' : '') + '>' + o[1] + '</option>').join('') + '</select></div>' +
        '<div class="field mt-16"><label class="label" for="st-note">Motif / note interne</label>' +
        '<input class="input" id="st-note" placeholder="Ex. demande du membre, dossier de signalement, inactivité prolongée"></div>' +
        '<div class="banner banner--warn mt-16">' + icon('alert', 18) + '<div class="small">La suspension bloque la connexion du compte. Toute action est journalisée.</div></div>',
      footer: ui.btn({ label: 'Annuler', variant: 'ghost', act: 'cancel' }) + ui.btn({ label: 'Appliquer', variant: 'primary', act: 'apply-status' }),
      onMount(panel) {
        panel.querySelector('[data-act="cancel"]').addEventListener('click', () => ui.close());
        panel.querySelector('[data-act="apply-status"]').addEventListener('click', (e) => {
          ui.loading(e.currentTarget, true, 'Application…');
          setTimeout(() => {
            const status = panel.querySelector('#st-value').value;
            store.setProfileStatus(id, status);
            ui.close();
            ui.toast(p.name + ' : statut mis à jour.', 'ok', { title: 'Statut modifié' });
            SEVE.router.refresh();
          }, 500);
        });
      }
    });
  });

  SEVE.act('admin-delete', function (el) {
    const id = el.getAttribute('data-id');
    const p = store.get(id);
    if (!p) return;
    ui.confirm({
      title: 'Supprimer ce profil ?',
      text: 'Le profil, ses demandes et ses conversations sont retirés de la base de démonstration. En production, la suppression est soumise à un délai de rétention et à une validation à deux niveaux.',
      okLabel: 'Supprimer définitivement', danger: true
    }).then((ok) => {
      if (!ok) return;
      store.removeProfile(id);
      ui.toast('Profil supprimé.', 'info');
      SEVE.router.refresh();
    });
  });

  SEVE.act('admin-suspend', function (el) {
    const id = el.getAttribute('data-id');
    const u = store.allUsers({}).filter((x) => x.id === id)[0];
    ui.confirm({
      title: 'Suspendre ce compte ?',
      text: 'L’accès est bloqué immédiatement et le profil devient invisible. Le membre conserve ses données et peut demander un réexamen.',
      detail: u ? U.esc(u.name) + ' · ' + U.esc(u.email) : '',
      okLabel: 'Suspendre', danger: true
    }).then((ok) => {
      if (!ok) return;
      store.setUserStatus(id, 'suspended');
      ui.toast('Compte suspendu.', 'ok');
      SEVE.router.refresh();
    });
  });

  SEVE.act('admin-unsuspend', function (el) {
    store.setUserStatus(el.getAttribute('data-id'), 'active');
    ui.toast('Compte réactivé.', 'ok');
    SEVE.router.refresh();
  });

  SEVE.act('admin-suspend-profile', function (el) {
    const id = el.getAttribute('data-id');
    const p = store.get(id);
    ui.confirm({
      title: 'Suspendre ' + (p ? p.name : 'ce profil') + ' ?',
      text: 'Le profil devient invisible, la connexion est bloquée et le badge de vérification est retiré. Motif à consigner dans le dossier de signalement.',
      okLabel: 'Suspendre', danger: true
    }).then((ok) => {
      if (!ok) return;
      store.setProfileStatus(id, 'suspended');
      store.setVerified(id, false);
      ui.toast('Profil suspendu. L’auteur du signalement est informé du traitement.', 'ok');
      SEVE.router.refresh();
    });
  });

  SEVE.act('admin-unsuspend-profile', function (el) {
    store.setProfileStatus(el.getAttribute('data-id'), 'active');
    ui.toast('Profil réactivé.', 'ok');
    SEVE.router.refresh();
  });

  SEVE.act('admin-warn', function (el) {
    const id = el.getAttribute('data-id');
    const p = store.get(id);
    ui.modal({
      title: 'Avertir ' + (p ? p.name : 'ce profil'),
      size: 'sm',
      subtitle: 'Message envoyé dans la messagerie Sève, signé par l’équipe de modération.',
      body: '<div class="field"><label class="label" for="warn-text">Message</label>' +
        '<textarea class="textarea" id="warn-text">Bonjour, votre compte a fait l’objet d’un signalement. Nous vous rappelons les règles de la plateforme : aucun paiement entre membres, aucun contenu illicite, aucune pression sur les délais. Nous vous invitons à corriger votre comportement ou votre présentation. À défaut, votre profil pourra être suspendu.</textarea></div>',
      footer: ui.btn({ label: 'Annuler', variant: 'ghost', act: 'cancel' }) + ui.btn({ label: 'Envoyer l’avertissement', variant: 'primary', act: 'send-warn' }),
      onMount(panel) {
        panel.querySelector('[data-act="cancel"]').addEventListener('click', () => ui.close());
        panel.querySelector('[data-act="send-warn"]').addEventListener('click', (e) => {
          ui.loading(e.currentTarget, true, 'Envoi…');
          setTimeout(() => {
            store.pushNotification(p.role, {
              type: 'moderation', icon: 'alert', title: 'Avertissement de l’équipe Sève',
              text: 'Un signalement vous concernant a été traité', href: '#/app/messages'
            });
            ui.close();
            ui.toast('Avertissement envoyé au membre.', 'ok');
          }, 600);
        });
      }
    });
  });

  SEVE.act('admin-report', function (el) {
    const id = el.getAttribute('data-id');
    const r = store.reports({}).filter((x) => x.id === id)[0];
    if (!r) return;
    ui.modal({
      title: 'Traitement du signalement',
      subtitle: r.reason + ' · ' + r.targetName,
      size: 'lg',
      body: '<div class="banner banner--soft">' + icon('flag', 18) + '<div>' + U.esc(r.detail) + '</div></div>' +
        '<div class="formgrid mt-20">' +
        '<div class="field"><label class="label" for="mr-status">Statut du dossier</label><select class="select" id="mr-status">' +
        ['open', 'progress', 'closed'].map((k) => '<option value="' + k + '"' + (r.status === k ? ' selected' : '') + '>' + store.REPORT_STATUS[k] + '</option>').join('') + '</select></div>' +
        '<div class="field"><label class="label" for="mr-sev">Priorité</label><select class="select" id="mr-sev">' +
        [['high', 'Haute'], ['mid', 'Moyenne'], ['low', 'Basse']].map((k) => '<option value="' + k[0] + '"' + (r.severity === k[0] ? ' selected' : '') + '>' + k[1] + '</option>').join('') + '</select></div>' +
        '<div class="field span2"><label class="label" for="mr-res">Décision et réponse aux parties</label>' +
        '<textarea class="textarea" id="mr-res" placeholder="Ex. Avertissement adressé au profil, présentation corrigée, dossier clos. Aucun manquement caractérisé.">' + U.esc(r.resolution || '') + '</textarea>' +
        '<p class="help">Cette synthèse est communiquée aux deux parties dans la messagerie, sans détail sur l’identité du signalant.</p></div>' +
        '</div>' +
        '<div class="row gap-10 mt-16" style="flex-wrap:wrap">' +
        '<span class="small muted">Actions rapides :</span>' +
        ui.btn({ label: 'Avertir', variant: 'outline', size: 'sm', act: 'admin-warn', data: { id: r.target } }) +
        ui.btn({ label: 'Suspendre le profil', variant: 'danger', size: 'sm', act: 'admin-suspend-profile', data: { id: r.target } }) +
        '</div>',
      footer: ui.btn({ label: 'Annuler', variant: 'ghost', act: 'cancel' }) + ui.btn({ label: 'Enregistrer la décision', variant: 'primary', act: 'save-report' }),
      onMount(panel) {
        panel.querySelector('[data-act="cancel"]').addEventListener('click', () => ui.close());
        panel.querySelector('[data-act="save-report"]').addEventListener('click', (e) => {
          ui.loading(e.currentTarget, true, 'Enregistrement…');
          setTimeout(() => {
            store.updateReport(id, {
              status: panel.querySelector('#mr-status').value,
              severity: panel.querySelector('#mr-sev').value,
              resolution: panel.querySelector('#mr-res').value
            });
            ui.close();
            ui.toast('Dossier mis à jour. Les deux parties reçoivent la synthèse (démonstration).', 'ok');
            SEVE.router.refresh();
          }, 600);
        });
      }
    });
  });

  SEVE.act('admin-request-open', function (el) {
    const r = store.requestById(el.getAttribute('data-id'));
    if (!r) return;
    ui.modal({
      title: 'Demande de collaboration',
      subtitle: U.esc(r.fromProfile.name) + ' → ' + U.esc(r.toProfile.name),
      size: 'lg',
      body: '<div class="banner banner--soft">' + icon('send', 18) + '<div>' + U.esc(r.message) + '</div></div>' +
        (r.reply ? '<div class="banner banner--ok mt-12">' + icon('message', 18) + '<div>' + U.esc(r.reply) + '</div></div>' : '') +
        '<dl class="defs mt-20">' +
        '<div class="def"><dt>Statut</dt><dd>' + U.esc(r.status) + '</dd></div>' +
        '<div class="def"><dt>Créée le</dt><dd>' + U.fmtDate(r.created) + ' à ' + U.fmtTime(r.created) + '</dd></div>' +
        (r.updated ? '<div class="def"><dt>Dernière mise à jour</dt><dd>' + U.fmtDate(r.updated) + '</dd></div>' : '') +
        '<div class="def"><dt>Signaux</dt><dd>Demande de paiement hors plateforme : ' + (/frais|avance|paiement|paypal|virement direct/i.test(r.message) ? '<b style="color:var(--danger)">détecté automatiquement</b>' : 'aucun') + '</dd></div>' +
        '</dl>',
      footer: ui.btn({ label: 'Fermer', variant: 'ghost', act: 'cancel' }) +
        (r.status === 'pending' ? ui.btn({ label: 'Archiver la demande', variant: 'danger', act: 'archive-req' }) : ''),
      onMount(panel) {
        panel.querySelector('[data-act="cancel"]').addEventListener('click', () => ui.close());
        const a = panel.querySelector('[data-act="archive-req"]');
        if (a) a.addEventListener('click', () => {
          store.archiveRequest(r.id);
          ui.close();
          ui.toast('Demande archivée et retirée des listes actives.', 'info');
          SEVE.router.refresh();
        });
      }
    });
  });

  SEVE.act('admin-request-archive', function (el) {
    store.archiveRequest(el.getAttribute('data-id'));
    ui.toast('Demande archivée.', 'info');
    SEVE.router.refresh();
  });

  SEVE.act('admin-app-status', function (el) {
    const id = el.getAttribute('data-id');
    const status = el.getAttribute('data-status');
    store.updateApplication(id, { status });
    ui.toast('Demande d’accompagnement : ' + (store.APPLI_LABELS[status] || status).toLowerCase() + '.', 'ok');
    SEVE.router.refresh();
  });

  SEVE.act('admin-app-assign', function (el) {
    const id = el.getAttribute('data-id');
    const app = store.applications({}).filter((a) => a.id === id)[0];
    if (!app) return;
    const me = store.me();
    const role = app.profile && app.profile.role === 'creator' ? 'manager' : 'creator';
    const candidates = store.search({ type: role, specialty: (app.specialties || [])[0] }).slice(0, 8);
    ui.modal({
      title: 'Assigner un profil',
      subtitle: 'Le membre recevra une recommandation nominative de l’équipe, avec les raisons du rapprochement.',
      body: candidates.length
        ? '<div class="stack gap-12">' + candidates.map((p) => '<label class="check" style="align-items:flex-start">' +
          '<input type="radio" name="assign" value="' + p.id + '">' +
          '<span class="grow" style="min-width:0"><b style="display:block;font-size:14px">' + U.esc(p.name) + (p.verified ? ' · vérifié' : '') + '</b>' +
          '<span class="small muted">' + U.esc(SEVE.flows.roleLabel(p)) + ' · ' + U.esc(p.city) + ' · ' + T.labels((p.specialties || []).slice(0, 2)).join(', ') + '</span></span>' +
          '</label>').join('') + '</div>'
        : '<p class="small muted">Aucun profil ne correspond exactement aux spécialités demandées. Élargissez les critères ou contactez le membre.</p>',
      footer: ui.btn({ label: 'Annuler', variant: 'ghost', act: 'cancel' }) + ui.btn({ label: 'Assigner et recommander', variant: 'primary', act: 'do-assign' }),
      onMount(panel) {
        panel.querySelector('[data-act="cancel"]').addEventListener('click', () => ui.close());
        panel.querySelector('[data-act="do-assign"]').addEventListener('click', (e) => {
          const chosen = panel.querySelector('input[name="assign"]:checked');
          if (!chosen) { ui.toast('Sélectionnez un profil à assigner.', 'err'); return; }
          ui.loading(e.currentTarget, true, 'Assignation…');
          const target = chosen.value;
          setTimeout(() => {
            store.updateApplication(id, { status: 'matched', assigned: target });
            const p = store.get(target);
            if (app.profile) {
              const conv = store.ensureConversation(app.profile.id, target);
              store.sendMessage(conv.id, 'Bonjour, l’équipe Sève a présélectionné ce profil pour votre recherche : ' + p.name +
                ' (' + SEVE.flows.roleLabel(p) + ', ' + p.city + '). Motifs du rapprochement : ' + T.labels((p.specialties || []).slice(0, 2)).join(', ') +
                '. Vérifications effectuées : identité, structure et absence de signalement. Vous restez libre de contacter ou non.', 'them');
            }
            ui.close();
            ui.toast('Profil assigné. Le membre a reçu la recommandation dans sa messagerie.', 'ok', { title: 'Accompagnement traité' });
            SEVE.router.refresh();
          }, 700);
        });
      }
    });
  });

  SEVE.act('admin-app-reply', function (el) {
    const id = el.getAttribute('data-id');
    const app = store.applications({}).filter((a) => a.id === id)[0];
    if (!app) return;
    ui.modal({
      title: 'Répondre au membre',
      size: 'lg',
      body: '<div class="field"><label class="label" for="reply-text">Message de l’équipe</label>' +
        '<textarea class="textarea" id="reply-text" style="min-height:160px">Bonjour,\n\nNous avons étudié votre demande d’accompagnement. Merci pour les précisions fournies. Nous allons contacter les profils correspondant à vos critères et revenir vers vous avec une présélection sous 72 heures ouvrées.\n\nBien à vous,\nL’équipe Sève</textarea></div>',
      footer: ui.btn({ label: 'Annuler', variant: 'ghost', act: 'cancel' }) + ui.btn({ label: 'Envoyer le message', variant: 'primary', act: 'send-reply' }),
      onMount(panel) {
        panel.querySelector('[data-act="cancel"]').addEventListener('click', () => ui.close());
        panel.querySelector('[data-act="send-reply"]').addEventListener('click', (e) => {
          ui.loading(e.currentTarget, true, 'Envoi…');
          setTimeout(() => {
            const text = panel.querySelector('#reply-text').value;
            if (app.profile) {
              const conv = store.ensureConversation(app.profile.id, 'team');
              store.sendMessage(conv.id, text, 'them');
            }
            store.updateApplication(id, { status: app.status === 'new' ? 'progress' : app.status });
            ui.close();
            ui.toast('Message envoyé au membre.', 'ok');
            SEVE.router.refresh();
          }, 700);
        });
      }
    });
  });

  SEVE.act('admin-export', function () {
    const rows = [['id', 'nom', 'role', 'email', 'statut', 'verifie', 'inscription']].concat(
      store.allUsers({}).map((u) => [u.id, u.name, u.role, u.email, u.status || 'active', u.verified ? 'oui' : 'non', u.joined])
    );
    downloadCSV('seve-utilisateurs.csv', rows);
    ui.toast('Liste exportée au format CSV.', 'ok');
  });

  SEVE.act('admin-export-payouts', function () {
    const rows = [['profil', 'role', 'titulaire', 'domiciliation', 'iban_masque', 'bic', 'etat', 'mise_a_jour']]
      .concat(store.payouts({}).map((a) => [
        a.profile.name, a.profile.role, a.holder, a.bank || '', SEVE.iban.mask(a.iban), a.bic || '',
        (store.PAYOUT_STATUS[a.status] || {}).label || a.status, a.updated || 'jeu de demonstration'
      ]));
    downloadCSV('seve-coordonnees-paiement.csv', rows);
    ui.toast('Export généré avec les IBAN masqués (seules les 7 premières et 3 dernières positions apparaissent).', 'ok');
  });

  SEVE.act('admin-export-report', function () {
    const s = store.stats();
    const rows = Object.keys(s).filter((k) => typeof s[k] === 'number').map((k) => [k, s[k]]);
    downloadCSV('seve-statistiques.csv', [['indicateur', 'valeur']].concat(rows));
    ui.toast('Rapport exporté au format CSV.', 'ok');
  });

  SEVE.act('admin-reset', function () {
    ui.confirm({
      title: 'Réinitialiser la démonstration ?',
      text: 'Toutes les modifications locales (vérifications, suspensions, messages envoyés, profils créés) seront effacées et les données d’origine restaurées.',
      okLabel: 'Réinitialiser', danger: true
    }).then((ok) => {
      if (!ok) return;
      store.reset();
      store.logout();
      ui.toast('Données de démonstration réinitialisées.', 'info');
      SEVE.router.navigate('/');
    });
  });

  function downloadCSV(name, rows) {
    const csv = rows.map((r) => r.map((c) => '"' + String(c == null ? '' : c).replace(/"/g, '""') + '"').join(';')).join('\n');
    const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
  }
})();
