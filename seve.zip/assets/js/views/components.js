/* ==========================================================================
   Sève — composants de vue réutilisables (cartes, filtres, listes)
   ========================================================================== */
SEVE.components = (function () {
  const U = SEVE.util;
  const ui = SEVE.ui;
  const T = SEVE.taxo;
  const icon = SEVE.icons.svg;

  /* ------------------------------------------------------------------ */
  /* Cartes de profil                                                    */
  /* ------------------------------------------------------------------ */
  function specChips(ids, max) {
    const labels = T.labels(ids || [], 'SPECIALTIES');
    const shown = labels.slice(0, max || 4);
    return '<div class="chips">' + shown.map((l) => '<span class="chip chip--sm">' + U.esc(l) + '</span>').join('') +
      (labels.length > shown.length ? '<span class="chip chip--sm chip--outline">+' + (labels.length - shown.length) + '</span>' : '') + '</div>';
  }

  function metaLine(p) {
    return '<div class="pcard__meta">' + icon('mapPin', 14) + '<span>' + U.esc(p.city) + ', ' + U.esc(p.country) + '</span>' +
      '<span class="muted">·</span><span>' + U.esc(p.region) + '</span></div>';
  }

  /**
   * Carte de profil complète — adaptée au rôle et au contexte (public / appariement).
   */
  function profileCard(p, opts) {
    opts = opts || {};
    const score = opts.score;
    const isManager = p.role === 'manager';
    const stats = isManager
      ? [[U.fmtNum(p.creatorsCount || 0), 'créateurs'], [kindShort(p.kind), 'structure'], [p.commission || '—', 'commission']]
      : [[U.fmtK(p.subs || 0), 'abonnés'], [expShort(p.exp), 'expérience'], [p.breakdown || langCount(p), 'langues']];

    return '<article class="card card--hover pcard reveal' + (opts.compact ? '' : '') + '" data-href="#/profiles/' + p.id + '" role="link" tabindex="0">' +
      '<div class="pcard__head">' +
      ui.avatar(Object.assign({ square: isManager }, p), 'lg') +
      '<div class="pcard__id">' +
      '<div class="pcard__name">' + U.esc(p.name) + (p.verified ? ui.verified({ compact: true }) : '') + '</div>' +
      (isManager ? '<div class="pcard__meta">' + icon('briefcase', 14) + '<span>' + U.esc(p.kind || 'Manager') + '</span></div>' : '') +
      metaLine(p) +
      '</div>' +
      (score != null ? ui.ring(score, { size: 54, caption: 'compat.' }) : '') +
      '</div>' +
      '<div class="mt-16">' + specChips(p.specialties, 3) + '</div>' +
      '<p class="pcard__desc clamp-2">' + U.esc(p.bio) + '</p>' +
      (opts.why && opts.why.length
        ? '<div class="rec__why">' + opts.why.slice(0, 2).map((w) => '<span class="rec__whyitem">' + U.esc(w) + '</span>').join('') + '</div>'
        : '') +
      '<div class="pcard__stats">' + stats.map((s) =>
        '<div class="pcard__stat"><b>' + U.esc(s[0]) + '</b><span>' + U.esc(s[1]) + '</span></div>').join('') + '</div>' +
      '<div class="pcard__foot">' +
      ui.btn({ label: 'Voir le profil', variant: opts.score != null ? 'outline' : 'primary', size: 'sm', href: '#/profiles/' + p.id }) +
      (opts.showContact === false ? '' : ui.btn({
        label: 'Contacter', variant: opts.score != null ? 'primary' : 'soft', size: 'sm',
        act: 'contact-profile', data: { id: p.id }, icon: 'send', iconSize: 15
      })) +
      '<span class="ml-auto">' + ui.status(p.availability, { small: true }) + '</span>' +
      '</div></article>';
  }

  function kindShort(kind) {
    const map = {
      'Manager indépendant': 'solo', 'Agence de management': 'agence',
      'Equipe de chatting': 'équipe chat', 'Studio de production': 'studio'
    };
    return map[kind] || (kind ? 'structure' : '—');
  }

  function expShort(expId) {
    const e = T.EXPERIENCE.filter((x) => x.id === expId)[0];
    if (!e) return '—';
    return e.label.replace(/\s*\(moins d’1 an\)/,'').replace(' et plus', '+');
  }

  function langCount(p) { return (p.languages || []).length + ' langues'; }

  function profileCardSkeleton() { return ui.skeletonCards(6); }

  /* ------------------------------------------------------------------ */
  /* Lignes de demande                                                   */
  /* ------------------------------------------------------------------ */
  const REQ_LABEL = {
    pending: ['En attente', 'pending'], accepted: ['Acceptée', 'accepted'],
    declined: ['Non retenue', 'declined'], archived: ['Archivée', 'archived'], sent: ['Envoyée', 'pending']
  };

  function requestRow(r, opts) {
    opts = opts || {};
    const other = opts.side === 'sent' ? r.toProfile : r.fromProfile;
    const label = REQ_LABEL[r.status] || ['En attente', 'pending'];
    const isManagerTarget = other.role === 'manager';
    const actions = opts.actions === false ? '' :
      (opts.side === 'received' && r.status === 'pending'
        ? '<div class="reqrow__foot">' +
          ui.btn({ label: 'Accepter', variant: 'primary', size: 'sm', act: 'req-accept', data: { id: r.id } }) +
          ui.btn({ label: 'Refuser', variant: 'ghost', size: 'sm', act: 'req-decline', data: { id: r.id } }) +
          ui.btn({ label: 'Voir le profil', variant: 'outline', size: 'sm', href: '#/profiles/' + other.id }) +
          '</div>'
        : '<div class="reqrow__foot">' +
          (r.status === 'accepted' ? ui.btn({ label: 'Ouvrir la conversation', variant: 'primary', size: 'sm', act: 'open-thread', data: { id: other.id } }) : '') +
          ui.btn({ label: 'Voir le profil', variant: 'outline', size: 'sm', href: '#/profiles/' + other.id }) +
          (r.status === 'pending' ? ui.btn({ label: 'Annuler', variant: 'ghost', size: 'sm', act: 'req-archive', data: { id: r.id } }) : '') +
          (r.status === 'declined' ? ui.btn({ label: 'Archiver', variant: 'ghost', size: 'sm', act: 'req-archive', data: { id: r.id } }) : '') +
          '</div>');

    return '<article class="reqrow reveal">' +
      ui.avatar(Object.assign({ square: isManagerTarget }, other), 'md') +
      '<div class="reqrow__body">' +
      '<div class="between" style="gap:10px">' +
      '<div style="min-width:0"><div class="row gap-8"><b style="font-size:15px">' + U.esc(other.name) + '</b>' +
      (other.verified ? ui.verified({ compact: true }) : '') + '</div>' +
      '<div class="small muted mt-4">' + U.esc(SEVE.flows.roleLabel(other)) + ' · ' + U.esc(other.city) + ' · ' + U.fmtRelative(r.created) + '</div></div>' +
      ui.pill(label[0], label[1]) + '</div>' +
      (r.message ? '<p class="reqrow__msg clamp-3">' + U.esc(r.message) + '</p>' : '') +
      (r.reply && r.status !== 'pending'
        ? '<div class="banner banner--soft mt-12" style="padding:12px 14px">' + icon('message', 17) + '<div><b>Réponse de ' + U.esc(other.name) + '</b><br>' + U.esc(r.reply) + '</div></div>'
        : '') +
      actions +
      '</div></article>';
  }

  /* ------------------------------------------------------------------ */
  /* Recommandations                                                     */
  /* ------------------------------------------------------------------ */
  function recCard(entry, opts) {
    opts = opts || {};
    const p = entry.profile;
    return '<article class="card card--hover pcard pcard--rec reveal">' +
      '<div class="pcard__head">' +
      ui.avatar(Object.assign({ square: p.role === 'manager' }, p), 'lg') +
      '<div class="pcard__id">' +
      '<div class="pcard__name">' + U.esc(p.name) + (p.verified ? ui.verified({ compact: true }) : '') + '</div>' +
      metaLine(p) +
      '</div>' + ui.ring(entry.score, { size: 58, caption: 'compat.' }) + '</div>' +
      '<div class="matchline">' + icon('sparkles', 16) +
      '<span class="small" style="color:var(--green-800)">Nous pensons que ce profil pourrait vous correspondre.</span></div>' +
      '<p class="pcard__desc clamp-2">' + U.esc(p.bio) + '</p>' +
      '<div class="mt-12">' + (entry.reasons || []).slice(0, 3).map((r) => '<div class="row gap-8 small" style="color:var(--ink-2);margin-top:7px">' +
        '<span style="color:var(--green-600)">' + icon('check', 14) + '</span>' + U.esc(r) + '</div>').join('') + '</div>' +
      ((entry.cautions || []).length ? '<p class="tiny muted mt-12">' + icon('info', 13) + ' ' + U.esc(entry.cautions[0]) + '</p>' : '') +
      '<div class="pcard__foot">' +
      ui.btn({ label: 'Voir le profil', variant: 'outline', size: 'sm', href: '#/profiles/' + p.id }) +
      ui.btn({ label: 'Contacter', variant: 'primary', size: 'sm', act: 'contact-profile', data: { id: p.id }, icon: 'send', iconSize: 15 }) +
      '<span class="ml-auto">' + ui.status(p.availability, { small: true }) + '</span>' +
      '</div></article>';
  }

  function scoreLegendText() {
    return 'Le score compare vos critères déclarés (spécialités, zone, expérience, disponibilité). Un repère pour prioriser — jamais une garantie de résultat.';
  }

  function scoreLegend() {
    return '<p class="tiny muted" style="display:flex;gap:7px;align-items:flex-start;max-width:70ch">' +
      '<span style="color:var(--ink-4)">' + icon('info', 14) + '</span>' +
      '<span>' + scoreLegendText() + '</span></p>';
  }

  /* ------------------------------------------------------------------ */
  /* Recherche & filtres                                                 */
  /* ------------------------------------------------------------------ */
  function searchBar(o) {
    o = o || {};
    return '<div class="search">' + icon('search', 18) +
      '<input class="input" id="' + (o.id || 'q') + '" data-filter="q" type="search" autocomplete="off" ' +
      'placeholder="' + U.esc(o.placeholder || 'Rechercher un créateur ou un manager') + '" value="' + U.esc(o.value || '') + '" aria-label="Recherche">' +
      '</div>';
  }

  /**
   * Un critère de filtre, en pastilles : tout est visible, un seul geste suffit.
   * Aucun menu déroulant — il faut ouvrir, chercher, cliquer : trois gestes pour
   * un filtre, et on ne voit pas ce qui est disponible avant d'avoir ouvert.
   * Les pastilles défilent horizontalement quand il y en a beaucoup.
   */
  function chipsHTML(o) {
    const valeur = String(o.value == null || o.value === '' ? 'all' : o.value);
    const options = o.options || [];
    return '<div class="chips" role="group" aria-label="' + U.esc(o.label) + '">' +
      '<span class="chips__label">' + U.esc(o.label) + '</span>' +
      '<div class="chips__row">' +
      options.map((opt) => {
        const value = String(Array.isArray(opt) ? opt[0] : opt.id);
        const label = Array.isArray(opt) ? opt[1] : opt.label;
        if (value.indexOf('__') === 0) {   /* séparateur de groupe : une simple étiquette */
          return '<span class="chips__group">' + U.esc(label.replace(/^—\s*|\s*—$/g, '')) + '</span>';
        }
        const on = value === valeur;
        return '<button type="button" class="chip chip--choice' + (on ? ' is-on' : '') + '"' +
          ' data-filter="' + U.esc(o.key) + '" data-value="' + U.esc(value) + '"' +
          (on ? ' aria-pressed="true"' : '') + '>' + U.esc(label) + '</button>';
      }).join('') +
      '</div></div>';
  }

  /** Toutes les clés de filtre déjà posées, pour savoir quoi déplier. */
  function filtresActifs(v, champs) {
    return (champs || []).filter((k) => v[k] && v[k] !== 'all' && !(k === 'sort' && v[k] === 'relevance'));
  }

  /**
   * Barre de filtres standard. opts.fields = liste de clés ; opts.values = valeurs courantes.
   * opts.kind : 'all' | 'creator' | 'manager' (détermine les filtres pertinents)
   */
  function filterBar(opts) {
    opts = opts || {};
    const v = opts.values || {};
    const facets = SEVE.store.facets();
    const fields = opts.fields || ['type', 'location', 'specialty', 'exp', 'size', 'availability'];
    /* Les deux premiers critères restent à l'écran ; les suivants se déplient,
       et restent dépliés si l'un d'eux est déjà actif. */
    const visibles = fields.slice(0, 2);
    const autres = fields.slice(2);
    const actif = filtresActifs(v, autres).length > 0;
    let html = '<div class="filters filters--chips">';
    const second = [];
    const selectHTML = (o) => (visibles.indexOf(o.key) >= 0 ? chipsHTML(o) : (second.push(chipsHTML(o)), ''));

    if (fields.indexOf('type') >= 0) {
      html += selectHTML({
        id: 'f-type', key: 'type', label: 'Type de profil', value: v.type || 'all',
        options: [['all', 'Tous les profils'], ['creator', 'Créatrices & créateurs'], ['manager', 'Managers & agences']]
      });
    }
    if (fields.indexOf('location') >= 0) {
      html += selectHTML({
        id: 'f-region', key: 'region', label: 'Localisation', value: v.region || 'all',
        options: [['all', 'Toutes les zones']].concat(facets.regions.map((r) => [r, r]))
      });
    }
    if (fields.indexOf('city') >= 0) {
      html += selectHTML({
        id: 'f-city', key: 'city', label: 'Ville', value: v.city || 'all',
        options: [['all', 'Toutes les villes']].concat(facets.cities.map((c) => [c, c]))
      });
    }
    if (fields.indexOf('specialty') >= 0) {
      const groups = {};
      facets.specialities.forEach((s) => { (groups[s.group] = groups[s.group] || []).push(s); });
      const options = [['all', 'Toutes les spécialités']];
      Object.keys(groups).forEach((g) => {
        options.push(['__' + g, '— ' + g + ' —']);
        groups[g].forEach((s) => options.push([s.id, s.label]));
      });
      html += selectHTML({ id: 'f-spec', key: 'specialty', label: 'Spécialité', value: v.specialty || 'all', options });
    }
    if (fields.indexOf('exp') >= 0) {
      html += selectHTML({
        id: 'f-exp', key: 'exp', label: 'Expérience', value: v.exp || 'all',
        options: [['all', 'Toutes expériences']].concat(T.EXPERIENCE.map((e) => [e.id, e.label]))
      });
    }
    if (fields.indexOf('size') >= 0) {
      const isManager = v.type === 'manager';
      const source = isManager ? T.TEAMSIZE.map((t) => [t.id, t.label + ' dans l’équipe']) : T.NETWORK.map((n) => [n.id, n.label]);
      html += selectHTML({
        id: 'f-size', key: 'size', label: isManager ? 'Taille de la structure' : 'Taille du réseau', value: v.size || 'all',
        options: [['all', isManager ? 'Toutes tailles' : 'Tous formats de réseau']].concat(source)
      });
    }
    if (fields.indexOf('availability') >= 0) {
      html += selectHTML({
        id: 'f-av', key: 'availability', label: 'Disponibilité', value: v.availability || 'all',
        options: T.AVAILABILITY_FILTERS.map((a) => [a.id, a.label])
      });
    }
    if (fields.indexOf('language') >= 0) {
      html += selectHTML({
        id: 'f-lang', key: 'language', label: 'Langue de travail', value: v.language || 'all',
        options: [['all', 'Toutes les langues']].concat(T.LANGUAGES.map((l) => [l, l]))
      });
    }
    if (fields.indexOf('sort') >= 0) {
      html += selectHTML({
        id: 'f-sort', key: 'sort', label: 'Trier par', value: v.sort || 'relevance',
        options: [['relevance', 'Pertinence'], ['recent', 'Arrivées récentes'], ['network', 'Volume / portefeuille'], ['experience', 'Expérience']]
      });
    }

    if (second.length) {
      html += '<details class="filters__more"' + (actif ? ' open' : '') + '>' +
        '<summary>' + icon('filter', 15) + ' Affiner la recherche' +
        (actif ? ' <span class="chips__count">' + filtresActifs(v, fields).length + '</span>' : '') + '</summary>' +
        '<div class="filters__more-body">' + second.join('') + '</div></details>';
    }
    html += '</div><div class="activefilters mt-16" id="activefilters">' + activeFilters(v, opts) + '</div>';
    return html;
  }

  function activeFilters(v, opts) {
    const map = {
      type: (x) => x === 'creator' ? 'Créateurs' : 'Managers',
      region: (x) => x,
      city: (x) => 'Ville : ' + x,
      specialty: (x) => T.labels([x])[0],
      exp: (x) => expShort(x),
      size: (x) => [].concat(T.NETWORK, T.TEAMSIZE).filter((o) => o.id === x).map((o) => o.label)[0] || x,
      availability: (x) => (T.AVAILABILITY_FILTERS.filter((a) => a.id === x)[0] || {}).label || x,
      language: (x) => x
    };
    const chips = Object.keys(v).filter((k) => v[k] && v[k] !== 'all' && k !== 'sort' && k !== 'q' && map[k]).map((k) =>
      '<span class="afilter">' + U.esc(map[k](v[k])) + '<button data-clear="' + k + '" aria-label="Retirer ce filtre">' + icon('x', 11) + '</button></span>');
    if (v.q) chips.unshift('<span class="afilter">Recherche : ' + U.esc(v.q) + '<button data-clear="q" aria-label="Retirer la recherche">' + icon('x', 11) + '</button></span>');
    const any = chips.length;
    return (any ? chips.join('') + '<button class="btn btn--ghost btn--xs" data-clear="all">Tout effacer</button>' : '<span class="small muted">Aucun filtre actif — affinez la liste ci-dessus.</span>');
  }

  /**
   * Branche les filtres sur l’URL : chaque changement met à jour la requête,
   * ce qui permet de partager une recherche ou de revenir en arrière.
   */
  function bindFilters(root, basePath, opts) {
    opts = opts || {};
    const container = root.querySelector('[data-filters]');
    const scope = container || root;
    /** Toutes les valeurs courantes des filtres, pastilles et champs confondus. */
    function valeurs() {
      const out = {};
      scope.querySelectorAll('[data-filter]').forEach((el) => {
        if (el.hasAttribute('data-value')) { return; }   /* pastille : traitée plus bas */
        out[el.getAttribute('data-filter')] = el.type === 'multiple'
          ? Array.from(el.selectedOptions).map((o) => o.value) : el.value;
      });
      scope.querySelectorAll('[data-filter][data-value].is-on').forEach((el) => {
        out[el.getAttribute('data-filter')] = el.getAttribute('data-value');
      });
      Object.keys(out).forEach((k) => { if (out[k] === 'all' || out[k] === '') { delete out[k]; } });
      return out;
    }

    /* Une pastille : un clic, la liste se met à jour tout de suite (pas d'aller-retour). */
    scope.querySelectorAll('[data-filter][data-value]').forEach((el) => {
      el.addEventListener('click', () => {
        const key = el.getAttribute('data-filter');
        const value = el.getAttribute('data-value');
        const dejaLa = el.classList.contains('is-on');
        scope.querySelectorAll('[data-filter="' + key + '"][data-value]').forEach((autre) => {
          autre.classList.remove('is-on');
          autre.removeAttribute('aria-pressed');
        });
        const valeurs2 = valeurs();
        if (dejaLa) { delete valeurs2[key]; } else { el.classList.add('is-on'); el.setAttribute('aria-pressed', 'true'); valeurCourante(key, dejaLa ? 'all' : value); }
        const suivant = dejaLa ? valeurs() : Object.assign({}, valeurs2, { [key]: value });
        SEVE.router.navigate(basePath + U.query(suivant));
      });
    });

    /* La pastille choisie et le champ caché restent alignés (pour « Réinitialiser »). */
    function valeurCourante(key, value) {
      const champ = scope.querySelector('[data-filter="' + key + '"]:not([data-value])');
      if (champ) { champ.value = value; }
    }

    const push = U.debounce(function () {
      const q = U.query(valeurs());
      SEVE.router.navigate(basePath + q);
    }, opts.debounce || 260);

    scope.querySelectorAll('[data-filter]').forEach((el) => {
      if (el.hasAttribute('data-value')) { return; }      /* pastille : déjà branchée */
      if (el.tagName === 'SELECT') el.addEventListener('change', push);
      else el.addEventListener('input', push);
      if (el.type === 'search') {
        el.addEventListener('keydown', (e) => { if (e.key === 'Enter') { push(); el.blur(); } });
      }
    });

    root.querySelectorAll('[data-clear]').forEach((btn) => btn.addEventListener('click', () => {
      const key = btn.getAttribute('data-clear');
      if (key === 'all') { SEVE.router.navigate(basePath); return; }
      const values = valeurs();
      delete values[key];
      if (key === 'q') {
        const q = root.querySelector('[data-filter="q"]');
        if (q) q.value = '';
      }
      SEVE.router.navigate(basePath + U.query(values));
    }));
  }

  /* ------------------------------------------------------------------ */
  /* Autres blocs                                                        */
  /* ------------------------------------------------------------------ */
  function steps(items) {
    return '<div class="steps">' + items.map((s, i) =>
      '<article class="step reveal"><span class="step__n">' + (i + 1) + '</span><h3>' + U.esc(s.title) + '</h3><p>' + U.esc(s.text) + '</p></article>').join('') + '</div>';
  }

  function trustItems(items) {
    return items.map((t) => '<div class="trustbar__item">' + icon(t.icon, 19) +
      '<div><b>' + U.esc(t.title) + '</b><span>' + U.esc(t.text) + '</span></div></div>').join('');
  }

  function portfolioTiles(items) {
    return '<div class="tiles">' + (items || []).map((it) =>
      '<article class="tile reveal"><div class="tile__media">' + icon(mediaIcon(it.type), 26) + '</div>' +
      '<div class="tile__body"><b>' + U.esc(it.title) + '</b><span>' + U.esc(it.meta) + '</span></div>' +
      '<div style="padding:0 13px 12px"><span class="tag">' + U.esc(it.type) + '</span></div></article>').join('') + '</div>';
  }

  function mediaIcon(type) {
    const t = (type || '').toLowerCase();
    if (t.indexOf('vidéo') >= 0 || t.indexOf('live') >= 0) return 'video';
    if (t.indexOf('photo') >= 0 || t.indexOf('production') >= 0 || t.indexOf('direction') >= 0) return 'image';
    if (t.indexOf('croissance') >= 0 || t.indexOf('acquisition') >= 0) return 'trending';
    if (t.indexOf('pricing') >= 0 || t.indexOf('monétisation') >= 0 || t.indexOf('fanvue') >= 0) return 'wallet';
    if (t.indexOf('analytics') >= 0 || t.indexOf('reporting') >= 0) return 'chart';
    if (t.indexOf('conformité') >= 0) return 'scale';
    if (t.indexOf('organisation') >= 0 || t.indexOf('méthode') >= 0) return 'layers';
    return 'sparkles';
  }

  function timeline(items) {
    return '<div class="timeline">' + (items || []).map((t) =>
      '<div class="tl reveal"><span class="tl__dot"></span><div>' +
      '<span class="tl__period">' + U.esc(t.period) + '</span>' +
      '<h4>' + U.esc(t.title) + '</h4>' +
      (t.org ? '<p class="small muted">' + U.esc(t.org) + '</p>' : '') +
      (t.note ? '<p class="mt-8" style="color:var(--ink-2);font-size:14px">' + U.esc(t.note) + '</p>' : '') +
      '</div></div>').join('') + '</div>';
  }

  function emptyState(o) { return ui.empty(o); }

  function panelList(rows) {
    return '<div class="panel__list">' + rows.join('') + '</div>';
  }

  function profileStats(p) {
    const m = p.metrics || {};
    if (p.role === 'manager') {
      return [
        { label: 'Créateurs accompagnés', value: U.fmtNum(p.creatorsCount || 0) },
        { label: 'Structure', value: (T.TEAMSIZE.filter((t) => t.id === p.team)[0] || {}).label || '—' },
        { label: 'Commission', value: p.commission || '—' },
        { label: 'Réactivité annoncée', value: m.response || '—' }
      ];
    }
    return [
      { label: 'Abonnés', value: U.fmtK(p.subs || 0) },
      { label: 'Revenus déclarés', value: m.revenue || '—' },
      { label: 'Expérience', value: expShort(p.exp) },
      { label: 'Réactivité annoncée', value: m.response || '—' }
    ];
  }

  return {
    activeFilters, scoreLegendText,
    specChips, profileCard, recCard, scoreLegend, requestRow, searchBar, filterBar, bindFilters, chipsHTML,
    steps, trustItems, portfolioTiles, timeline, profileStats, profileCardSkeleton, panelList, emptyState,
    kindShort, expShort, roleChips: specChips
  };
})();
