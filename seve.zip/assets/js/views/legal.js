/* ==========================================================================
   Sève — pages légales, consentement, 404
   ========================================================================== */
(function () {
  const U = SEVE.util;
  const ui = SEVE.ui;
  const store = SEVE.store;
  const icon = SEVE.icons.svg;

  SEVE.views = SEVE.views || {};

  /* Informations fournies par l’éditeur : pseudonyme Sève, courriel public et Hostinger.
     Selon sa déclaration, son identité réelle a été communiquée à l’hébergeur. */
  const DOCS = {
    mentions: { title:'Mentions légales', updated:'18 octobre 2026', kicker:'Éditeur et hébergement',
      lede:'Sève est édité par une personne physique déclarant agir à titre non professionnel.', sections:[
        ['Éditeur', ['Pseudonyme public : Sève. L’éditeur déclare avoir communiqué ses nom, prénom et coordonnées réels à l’hébergeur conformément au régime applicable aux éditeurs non professionnels. Aucune entreprise ou numéro SIRET n’est revendiqué.', 'Contact pour toute question, demande relative aux données ou signalement : missiona.eu@gmail.com.']],
        ['Hébergeur', ['Hostinger International Limited, 61 Lordou Vironos str., 6023 Larnaca, Chypre. Contact et informations de l’hébergeur : https://www.hostinger.com/contact et https://www.hostinger.com/legal/universal-terms-of-service-agreement. Vérifiez que cette entité figure sur votre contrat d’hébergement.']],
        ['Portée', ['Le refuge et sa messagerie privée sont des services Sève. L’annuaire de démonstration contient des profils fictifs ; aucun profil réel n’y est présenté sans consentement. Le site ne se présente pas comme un service de secours ou de conseil médical.']]
      ] },
    privacy: { title:'Politique de confidentialité', updated:'18 octobre 2026', kicker:'Vos données',
      lede:'La personne éditant Sève gère les comptes et le fil de discussion privé. Contact : missiona.eu@gmail.com.', sections:[
        ['Données et finalités', ['Le compte refuge enregistre nom choisi, e-mail, mot de passe haché, dates de création et de contrôle de majorité, référence de contrôle, messages et images envoyés. Les fichiers de preuve d’identité ne sont pas conservés dans Sève : le contrôle est effectué manuellement par l’administrateur. N’envoyez pas votre pièce dans le chat.', 'Le fil privé est destiné à échanger avec l’administration Sève. Les PNG, potentiellement explicites, sont réencodés pour retirer les métadonnées, stockés hors accès web et soumis à validation humaine. L’attestation des droits des personnes représentées et l’accord d’envoi sont demandés pour chaque image. Les anciens fils de la démonstration restent dans le navigateur et ne sont pas envoyés à l’équipe.']],
        ['Base et destinataires', ['La gestion du compte et du fil repose sur la fourniture du service demandé ; la sécurisation et la modération répondent à la protection des utilisateurs et à la prévention des abus. Ne transmettez pas de données de santé ou de documents sensibles dans le chat. Les messages et PNG sont accessibles à l’administration Sève ; les PNG ne sont pas publiés dans un annuaire.', 'Hébergement : Hostinger. Le lieu précis des serveurs et les conditions de sauvegarde dépendent du contrat d’hébergement souscrit par l’éditeur ; nous ne prétendons pas connaître ces informations.']],
        ['Conservation', ['Les données de compte et les messages restent enregistrés tant que le compte est actif ou jusqu’à une demande d’effacement recevable ; l’administrateur traite les demandes à missiona.eu@gmail.com. Une image retirée par la modération est effacée du stockage actif. Les tentatives de connexion sont limitées par une fenêtre de quinze minutes. Les sauvegardes de l’hébergeur, si elles existent, dépendent de sa politique : demandez leur portée et leurs durées à l’éditeur.']],
        ['Vos droits', ['Vous pouvez demander accès, rectification, effacement, limitation ou opposition selon les règles applicables à missiona.eu@gmail.com. Une vérification d’identité appropriée peut être demandée avant de communiquer des données. Vous pouvez saisir la CNIL : https://www.cnil.fr.']],
        ['Sécurité et traceurs', ['Mots de passe hachés, sessions serveur avec cookie HttpOnly, Secure sur HTTPS et SameSite=Lax, protection CSRF pour les écritures, limitation des tentatives administrateur. Les images ne sont accessibles qu’à la personne qui les a envoyées après validation et à l’administration Sève.', 'Les préférences et les données de démonstration peuvent être conservées dans le navigateur. Aucun traceur de publicité ou d’analyse facultatif n’est activé par ce code.']]
      ] },
    terms: { title:'Conditions générales d’utilisation', updated:'18 octobre 2026', kicker:'Utiliser Sève',
      lede:'Le refuge gratuit comprend un compte personnel et un fil privé avec l’administration Sève.', sections:[
        ['Accès et âge', ['L’inscription requiert une déclaration de majorité ; une réponse oui au formulaire ne vaut pas contrôle de pièce. Tout PNG requiert en plus un contrôle manuel réel de majorité enregistré par l’administrateur. Les mineurs ne doivent pas utiliser ce service.']],
        ['Services et limites', ['Le fil privé est reçu par l’administration Sève mais ne constitue pas une permanence d’urgence, un accompagnement thérapeutique ou un conseil juridique. En danger immédiat, composez le 17 ou le 112. Les profils de l’annuaire et chiffres de la démonstration restent fictifs et ne constituent pas de vraies collaborations.']],
        ['Consentement et images', ['Avant chaque PNG, la personne expéditrice affirme détenir les droits et le consentement de toutes les personnes représentées. Tout contenu impliquant un mineur, non consenti, violent, illicite ou frauduleux est interdit. Les images sont privées, modérées avant visibilité et peuvent être retirées ensuite. Une déclaration de l’expéditrice ne remplace pas l’examen humain.']],
        ['Signalement', ['Pour signaler un contenu ou demander son retrait : missiona.eu@gmail.com avec les informations permettant de le retrouver ; ne joignez pas de pièce intime au signalement. L’éditeur examine et retire les contenus interdits. En cas de menace immédiate, contactez les autorités.']],
        ['Paiements', ['Sève ne facture pas d’abonnement dans cette version, n’encaisse ni ne redistribue de fonds pour des tiers. Tout paiement éventuel entre créatrice et manager doit être organisé directement entre eux avec un prestataire acceptant l’activité.']]
      ] },
    rules: { title:'Modération et sécurité', updated:'18 octobre 2026', kicker:'Protection des membres',
      lede:'L’administration Sève vérifie manuellement les PNG avant qu’ils soient visibles dans un fil privé.', sections:[
        ['Interdictions', ['Mineurs, contenus sexuels non consentis, coercition, fraude, menaces, harcèlement, usurpation et divulgation de données privées sont interdits.']],
        ['Décisions', ['Chaque PNG est conservé hors accès web en attendant une décision de l’administrateur. Celui-ci peut approuver ou retirer, y compris après approbation. Le compte émetteur ne peut pas diffuser l’image à d’autres membres depuis Sève.']],
        ['Signalements', ['Écrivez à missiona.eu@gmail.com avec le motif, la date et les références utiles. Un bouton de signalement d’une fiche fictive ne constitue pas un signalement serveur ; privilégiez le courriel. Pour une urgence : 17 ou 112.']]
      ] },
    financement: { title:'Comment Sève est financé', updated:'18 octobre 2026', kicker:'Transparence économique',
      lede:'L’éditeur déclare ne pas percevoir de revenus de ce service à ce jour.', sections:[
        ['Service actuel', ['Le refuge est gratuit. Sève n’encaisse pas les revenus OnlyFans, ne facture aucun abonnement et ne redistribue pas de paiements. Aucun partenariat rémunéré n’est présenté comme actif.']],
        ['Évolution', ['Si le modèle change, les conditions et mentions correspondantes devront être mises à jour avant toute offre payante. Une absence de revenu ne détermine pas à elle seule le statut juridique de l’activité.']]
      ] }
  };

  function renderDoc(key, ctx) {
    const doc = DOCS[key];
    const toc = doc.sections.map((s, i) =>
      '<a href="#/legal/' + key + '?#' + i + '" class="legal__tocitem" data-scroll="' + i + '">' + U.esc(s[0]) + '</a>').join('');

    return '<section class="section section--tight"><div class="wrap">' +
      '<div class="row gap-12 mb-24" style="flex-wrap:wrap">' +
      '<a class="btn btn--ghost btn--sm" href="#/">' + icon('arrowLeft', 15) + '<span>Retour à l’accueil</span></a>' +
      ['mentions', 'terms', 'privacy', 'rules', 'cookies', 'financement'].map((k) =>
        '<a class="chip chip--sm' + (k === key ? ' chip--green' : '') + '" href="#/legal/' + k + '">' +
        U.esc(k === 'mentions' ? 'Mentions' : k === 'terms' ? 'CGU' : k === 'privacy' ? 'Confidentialité' : k === 'rules' ? 'Règles' : k === 'financement' ? 'Financement' : 'Cookies') + '</a>').join('') +
      '</div>' +
      '<div class="grid grid--side">' +
      '<article class="prose">' +
      '<span class="kicker">' + U.esc(doc.kicker) + '</span>' +
      '<h1 class="mt-12">' + U.esc(doc.title) + '</h1>' +
      '<p class="lede mt-16">' + U.esc(doc.lede) + '</p>' +
      '<p class="small muted mt-8">' + U.esc(doc.updated) + '</p>' +
      '<div class="note mt-24">' + U.esc('Pour les signalements et demandes de données : missiona.eu@gmail.com. Ne transmettez pas de pièce d’identité dans le chat.') + '</div>' +
      doc.sections.map((s, i) => '<section id="sec-' + i + '"><h2>' + U.esc(s[0]) + '</h2>' +
        s[1].map((p) => '<p>' + U.esc(p) + '</p>').join('') + '</section>').join('') +
      '</article>' +
      '<aside class="sticky-side">' +
      '<div class="card card--pad"><h4>Sur cette page</h4><nav class="legal__toc mt-12">' + toc + '</nav></div>' +
      '<div class="card card--pad card--soft"><h4>Question juridique ?</h4><p class="small muted mt-8">Contact : missiona.eu@gmail.com. Pour un conseil individuel, consultez un professionnel.</p></div>' +
      '</aside></div></div></section>';
  }

  SEVE.views.legal = {
    render(ctx) {
      const key = ctx.params.doc || ({ '/mentions-legales': 'mentions', '/politique-confidentialite': 'privacy', '/cgu': 'terms', '/financement': 'financement' }[ctx.path]);
      if (key === 'cookies') return cookiesView();
      if (!DOCS[key]) return SEVE.views.notfound.render(ctx);
      return renderDoc(key, ctx);
    },
    mount(ctx) {
      const root = ctx.root;
      root.querySelectorAll('[data-scroll]').forEach((a) => a.addEventListener('click', (e) => {
        e.preventDefault();
        const target = root.querySelector('#sec-' + a.getAttribute('data-scroll'));
        if (target) window.scrollTo({ top: target.getBoundingClientRect().top + window.scrollY - 90, behavior: 'smooth' });
      }));
      bindCookieForm(root);
    }
  };

  /* ------------------------------------------------------------------ */
  /* Cookies & consentement                                             */
  /* ------------------------------------------------------------------ */
  function cookieRow(id, title, text, required, checked) {
    return '<div class="setrow"><div class="setrow__txt"><b>' + U.esc(title) + (required ? ' <span class="tag">Toujours actif</span>' : '') + '</b>' +
      '<p>' + U.esc(text) + '</p></div>' +
      '<div class="setrow__ctrl">' +
      (required
        ? '<span class="chip chip--ok chip--sm">' + icon('check', 13) + 'Requis</span>'
        : '<label class="switch"><input type="checkbox" data-ck="' + id + '"' + (checked ? ' checked' : '') + '><span class="switch__track"></span></label>') +
      '</div></div>';
  }

  function cookiesView() {
    const c = store.consent() || {};
    return '<section class="section section--tight"><div class="wrap wrap--narrow">' +
      '<span class="kicker">Consentement</span>' +
      '<h1 class="mt-12">Cookies, mesure d’usage et consentement</h1>' +
      '<p class="lede mt-16">Sève fonctionne avec un minimum de traceurs. Vous pouvez modifier vos choix à tout moment : ils sont enregistrés sur cet appareil et appliqués immédiatement.</p>' +

      '<div class="card card--pad mt-32" id="ck-form">' +
      '<h3>Vos préférences</h3>' +
      cookieRow('essential', 'Cookies nécessaires', 'Session, sécurité, prévention de la fraude, mémorisation de vos filtres et de votre consentement. Sans eux, la plateforme ne peut pas fonctionner.', true, true) +
      cookieRow('analytics', 'Mesure d’usage', 'Inactif dans cette version. Aucun outil de mesure facultatif n’est chargé.', false, !!c.analytics) +
      cookieRow('personalization', 'Personnalisation', 'Mémorisation de vos préférences d’affichage (tri par défaut, format de liste, dernière recherche).', false, !!c.personalization) +
      cookieRow('newsletter', 'Informations produit', 'Inactif dans cette version. Aucun système d’envoi commercial n’est branché.', false, !!c.newsletter) +
      '<div class="row gap-12 mt-20" style="flex-wrap:wrap">' +
      ui.btn({ label: 'Enregistrer mes choix', variant: 'primary', act: 'save-cookies' }) +
      ui.btn({ label: 'Tout refuser sauf nécessaire', variant: 'outline', act: 'refuse-cookies' }) +
      '<span class="small muted">Dernière mise à jour : ' + U.esc(c.at ? U.fmtDate(c.at) : 'aucun choix enregistré') + '</span>' +
      '</div></div>' +

      '<div class="prose mt-32"><h2>Majorité et consentement</h2><p>Une déclaration d’âge seule ne constitue pas une vérification. Aucun contenu explicite réel ne doit être ouvert avant contrôle conforme et procédure de consentement.</p></div>' +
      '</div></section>';
  }

  let ckHandlersBound = false;
  function bindCookieForm(root) {
    if (!root.querySelector('#ck-form')) return;
    const save = (values) => {
      store.saveConsent(Object.assign({ decided: true, essential: true }, values));
      document.documentElement.classList.remove('has-consent');
      ui.toast('Vos préférences de consentement sont enregistrées.', 'ok');
      const bar = document.getElementById('consent-bar');
      if (bar) bar.remove();
      SEVE.router.refresh();
    };
    const collect = () => {
      const v = {};
      root.querySelectorAll('[data-ck]').forEach((i) => { v[i.getAttribute('data-ck')] = i.checked; });
      return v;
    };
    SEVE.actions['save-cookies'] = () => save(collect());
    SEVE.actions['refuse-cookies'] = () => {
      root.querySelectorAll('[data-ck]').forEach((i) => { i.checked = false; });
      save({ analytics: false, personalization: false, newsletter: false });
    };
  }

  SEVE.views.avantOuverture = { title: 'Service en préparation', render() {
    return '<section class="section"><div class="wrap wrap--narrow"><span class="kicker">Ouverture suspendue</span>' +
      '<h1 class="mt-16">Sève prépare son service.</h1>' +
      '<p class="lede mt-16">Cette version montre des profils et chiffres fictifs. Les inscriptions, paiements et mises en relation réels ne sont pas ouverts. Ne transmettez pas de documents personnels ou de contenu intime.</p>' +
      '<p>Une identité de connexion créée auparavant peut encore ouvrir son compte refuge, mais les messages restent uniquement sur son appareil et ne parviennent à aucune équipe.</p>' +
      '<p>Vérification de majorité, messagerie serveur, procédure de modération, informations de l’éditeur et droits RGPD doivent être mis en place avant l’ouverture.</p>' +
      '<div class="row gap-12 mt-24" style="flex-wrap:wrap"><a class="btn btn--outline" href="#/mentions-legales">Mentions légales</a>' +
      '<a class="btn btn--outline" href="#/politique-confidentialite">Confidentialité</a>' +
      '<a class="btn btn--outline" href="#/financement">Financement</a></div></div></section>';
  }};

  /* ------------------------------------------------------------------ */
  /* 404                                                                */
  /* ------------------------------------------------------------------ */
  SEVE.views.notfound = {
    title: 'Page introuvable',
    render() {
      return '<section class="section"><div class="wrap wrap--narrow center">' +
        '<span class="kicker" style="justify-content:center">Erreur 404</span>' +
        '<h1 class="mt-16">Cette page n’existe pas (ou plus)</h1>' +
        '<p class="lede mt-16">Le lien est peut-être incomplet, ou le profil a été retiré. Voici les chemins les plus utiles.</p>' +
        '<div class="row gap-12 mt-32" style="justify-content:center;flex-wrap:wrap">' +
        ui.btn({ label: 'Découvrir les profils', variant: 'primary', href: '#/discover' }) +
        ui.btn({ label: 'Créateurs', variant: 'outline', href: '#/creators' }) +
        ui.btn({ label: 'Managers', variant: 'outline', href: '#/managers' }) +
        '</div></div></section>';
    }
  };
})();
