/* ==========================================================================
   Sève — amorçage de l’application & actions globales
   ========================================================================== */
(function () {
  const U = SEVE.util;
  const L = SEVE.layout;
  const ui = SEVE.ui;

  /* ---------------------------------------------------------------- */
  /* Panneaux (notifications, compte) & tiroirs                        */
  /* ---------------------------------------------------------------- */
  function closePanels(except) {
    U.$$('.pmenu__panel').forEach((p) => { if (p !== except) p.remove(); });
  }
  function closeDrawer() {
    const d = U.$('.drawer');
    const s = U.$('.scrim');
    if (d) d.remove();
    if (s) s.remove();
    const b = U.$('[data-act="toggle-drawer"]');
    if (b) b.setAttribute('aria-expanded', 'false');
  }
  function closeSide() {
    const s = U.$('#side');
    if (s) s.classList.remove('is-open');
    const sc = U.$('.side-scrim');
    if (sc) sc.remove();
  }

  function togglePanel(button, builder) {
    const slot = button.parentElement.querySelector('.pmenu__slot');
    if (!slot) return;
    if (slot.firstElementChild) { slot.innerHTML = ''; return; }
    closePanels();
    slot.innerHTML = builder();
  }

  SEVE.act('toggle-drawer', function (el) {
    const slot = document.getElementById('drawer-slot');
    if (!slot) return;
    if (slot.firstElementChild) { closeDrawer(); return; }
    slot.innerHTML = L.drawer(window.location.hash);
    el.setAttribute('aria-expanded', 'true');
  });

  SEVE.act('close-drawer', closeDrawer);

  SEVE.act('close-ribbon', function () {
    U.storage.set('seve.ribbon', 'closed');
    const bar = document.getElementById('demobar');
    if (bar) {
      bar.style.transition = 'opacity 180ms, transform 180ms';
      bar.style.opacity = '0';
      bar.style.transform = 'translateY(-6px)';
      setTimeout(() => bar.remove(), 200);
    }
  });

  SEVE.act('toggle-side', function () {
    const side = document.getElementById('side');
    if (!side) return;
    side.classList.add('is-open');
    const sc = U.el('<div class="scrim side-scrim" data-act="close-side"></div>');
    document.body.appendChild(sc);
  });
  SEVE.act('close-side', function () { closeSide(); });

  function role() {
    const u = SEVE.store.currentUser();
    return u ? u.role : 'creator';
  }

  SEVE.act('toggle-notifs', function (el) { togglePanel(el, () => L.notifPanel(role())); });
  SEVE.act('toggle-usermenu', function (el) { togglePanel(el, () => L.userPanel(role())); });

  SEVE.act('mark-notifs', function () {
    SEVE.store.markNotificationsRead(role());
    const badge = U.$('[data-act="toggle-notifs"] .badge-count');
    if (badge) badge.remove();
    closePanels();
    ui.toast('Toutes vos notifications sont marquées comme lues.', 'ok');
  });

  SEVE.act('gotohref', function (el) {
    const href = el.getAttribute('data-href');
    closePanels();
    closeDrawer();
    if (href) SEVE.router.navigate(href.replace(/^#/, ''));
  });

  /* ---------------------------------------------------------------- */
  /* Session                                                           */
  /* ---------------------------------------------------------------- */
  SEVE.act('logout', function () {
    ui.confirm({
      title: 'Se déconnecter ?',
      text: 'Votre session sera fermée sur cet appareil. Vos demandes et vos messages restent enregistrés.',
      okLabel: 'Se déconnecter'
    }).then((ok) => {
      if (!ok) return;
      const u = SEVE.store.currentUser();
      if (u && u.role === 'admin' && SEVE.refuge) SEVE.refuge.adminLogout();
      SEVE.store.logout();
      closePanels();
      closeDrawer();
      closeSide();
      if (u && u.role === 'admin') SEVE.router.navigate('/login');
      else SEVE.router.navigate('/');
      ui.toast('Vous êtes déconnecté. À bientôt sur Sève.', 'info');
    });
  });

  /* Comptes de démonstration : accès en un clic, sans email ni mot de passe */
  SEVE.act('demo-login', function (el) {
    const wanted = el.getAttribute('data-role');
    if (wanted === 'admin') { ui.toast('Utilisez la connexion administrateur Sève sécurisée.', 'info'); SEVE.router.navigate('/admin/connexion'); return; }
    ui.loading(el, true, 'Ouverture…');
    setTimeout(() => {
      const res = SEVE.store.quickLogin(wanted);
      ui.loading(el, false);
      if (!res.ok) { ui.toast(res.error, 'err'); return; }
      const dest = wanted === 'admin' ? '/admin' : wanted === 'manager' ? '/app' : '/app';
      SEVE.router.navigate(dest);
      ui.toast(wanted === 'admin' ? 'Espace administrateur ouvert (démonstration).'
        : wanted === 'manager' ? 'Bonjour Halo Management — espace manager ouvert.'
          : 'Bonjour Lya — espace créateur ouvert.', 'ok');
    }, 520);
  });

  /* ---------------------------------------------------------------- */
  /* Consentement                                                      */
  /* ---------------------------------------------------------------- */
  function decide(analytics) {
    SEVE.store.saveConsent({ decided: true, essential: true, analytics: !!analytics, version: 1 });
    document.documentElement.classList.remove('has-consent');
    document.documentElement.style.setProperty('--consent-h', '0px');
    const bar = document.getElementById('consent-bar');
    if (bar) {
      bar.style.transition = 'opacity 200ms, transform 200ms';
      bar.style.opacity = '0';
      bar.style.transform = 'translateY(8px)';
      setTimeout(() => bar.remove(), 220);
    }
    ui.toast(analytics ? 'Merci. Mesure d’usage activée, vous pouvez la désactiver à tout moment.' : 'Merci. Seuls les cookies nécessaires sont utilisés.', 'ok');
  }
  SEVE.act('consent-accept', function () { decide(true); });
  SEVE.act('consent-essential', function () { decide(false); });

  /* ---------------------------------------------------------------- */
  /* Interactions globales                                             */
  /* ---------------------------------------------------------------- */
  document.addEventListener('click', function (e) {
    const actionEl = e.target.closest('[data-act]');
    const linkEl = e.target.closest('[data-href]');
    const inPanel = e.target.closest('.pmenu__panel');

    if (actionEl) {
      const name = actionEl.getAttribute('data-act');
      const fn = SEVE.actions[name];
      if (fn) {
        if (actionEl.tagName === 'A' && !actionEl.getAttribute('href')) e.preventDefault();
        fn(actionEl, e);
        if (name !== 'toggle-notifs' && name !== 'toggle-usermenu') { /* noop */ }
        return;
      }
    }
    if (linkEl) {
      e.preventDefault();
      const href = linkEl.getAttribute('data-href');
      closePanels();
      // Un lien de notification reste utile : on notifie la lecture
      if (inPanel && href && href.indexOf('/messages') > -1) SEVE.store.markRead(href.split('/').pop());
      SEVE.router.navigate(href.replace(/^#/, ''));
      return;
    }
    // Clic ailleurs : fermer les panneaux
    if (!inPanel && !e.target.closest('[data-act^="toggle-"]')) closePanels();
  });

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') { closePanels(); closeDrawer(); closeSide(); return; }
    /* Accessibilité : les cartes et lignes cliquables sont utilisables au clavier */
    if (e.key === 'Enter' || e.key === ' ') {
      const target = e.target;
      if (target && target.matches && target.matches('[data-href]') && !target.matches('button, a')) {
        e.preventDefault();
        SEVE.router.navigate(target.getAttribute('data-href').replace(/^#/, ''));
      }
    }
  });

  window.addEventListener('hashchange', function () { closeDrawer(); closePanels(); closeSide(); });

  /* ---------------------------------------------------------------- */
  /* Démarrage                                                         */
  /* ---------------------------------------------------------------- */
  function boot() {
    const bandeau = L.consentBar();
    /* Le routeur réécrit #app à chaque changement de page : le bandeau est donc
       posé dans <body>, sinon il disparaîtrait au premier rendu. */
    if (bandeau) {
      document.body.appendChild(U.el(bandeau));
      document.documentElement.classList.add('has-consent');
      /* Le bouton de soutien remonte au-dessus de la hauteur réelle du bandeau. */
      const caler = () => {
        const bar = document.querySelector('.consent');
        document.documentElement.style.setProperty('--consent-h', (bar ? Math.ceil(bar.getBoundingClientRect().height) : 0) + 'px');
      };
      caler();
      window.addEventListener('resize', caler);
    }
    SEVE.router.start();
    /* Relit périodiquement le mode global, y compris sur une page déjà ouverte. */
    if (SEVE.refuge) {
      SEVE.refuge.charger();
      setInterval(() => SEVE.refuge.charger(), 30000);
    }
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
