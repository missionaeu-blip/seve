<?php
declare(strict_types=1);

/* Standalone secours endpoint: ne charge pas le bootstrap de l'application. */
const APP_KEY = 'seve';
const APP_LABEL = 'Seve';
const APP_ROOT = __DIR__;
const APP_BASE = '/seve/';
const APP_LOG = __DIR__ . '/data/php-errors.log';

ini_set('display_errors', '0');
header('X-Robots-Tag: noindex, nofollow, noarchive');
header('Cache-Control: no-store, private');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: no-referrer');

function h(string $s): string { return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function https_request(): bool {
    return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
}
$sessionPath = APP_BASE === '/' ? '/' : APP_BASE;
session_name('maint_' . APP_KEY);
session_set_cookie_params([
    'lifetime' => 0, 'path' => $sessionPath, 'secure' => https_request(),
    'httponly' => true, 'samesite' => 'Strict'
]);
session_start();

/* Le fichier de hachages doit vivre hors de public_html et n'est pas fourni. */
$docroot = rtrim((string)($_SERVER['DOCUMENT_ROOT'] ?? ''), DIRECTORY_SEPARATOR);
$privateAuth = $docroot !== ''
    ? dirname($docroot) . '/missiona-config/maintenance-auth.php'
    : '';
$authHashes = [];
if ($privateAuth !== '' && is_file($privateAuth) && is_readable($privateAuth)) {
    try { $loaded = require $privateAuth; if (is_array($loaded)) $authHashes = $loaded; }
    catch (Throwable $e) { $authHashes = []; }
}
$adminHash = (string)($authHashes[APP_KEY] ?? '');

function rate_state(bool $failure = false, bool $clear = false): array {
    $ip = (string)($_SERVER['REMOTE_ADDR'] ?? 'unknown');
    $name = sys_get_temp_dir() . '/maint-' . APP_KEY . '-' . hash('sha256', $ip) . '.json';
    $fp = @fopen($name, 'c+');
    if (!$fp) return ['blocked' => true, 'unavailable' => true];
    @chmod($name, 0600);
    if (!flock($fp, LOCK_EX)) { fclose($fp); return ['blocked' => true, 'unavailable' => true]; }
    rewind($fp);
    $raw = stream_get_contents($fp);
    $state = json_decode(is_string($raw) ? $raw : '', true);
    if (!is_array($state) || time() - (int)($state['since'] ?? 0) > 900) {
        $state = ['since' => time(), 'failures' => 0];
    }
    if ($clear) $state = ['since' => time(), 'failures' => 0];
    if ($failure) $state['failures'] = (int)$state['failures'] + 1;
    $blocked = (int)$state['failures'] >= 6;
    rewind($fp); ftruncate($fp, 0);
    fwrite($fp, json_encode($state)); fflush($fp);
    flock($fp, LOCK_UN); fclose($fp);
    return ['blocked' => $blocked, 'unavailable' => false];
}

if (!empty($_SESSION['maint_ok']) && time() - (int)($_SESSION['maint_at'] ?? 0) > 900) {
    $_SESSION = [];
    session_regenerate_id(true);
}
if (empty($_SESSION['maint_csrf'])) $_SESSION['maint_csrf'] = bin2hex(random_bytes(32));
$error = '';
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $postedCsrf = (string)($_POST['csrf'] ?? '');
    if (!hash_equals((string)$_SESSION['maint_csrf'], $postedCsrf)) {
        $error = 'Session expirée. Recharge la page et réessaie.';
    } elseif (isset($_POST['logout'])) {
        $_SESSION = [];
        session_regenerate_id(true);
        $_SESSION['maint_csrf'] = bin2hex(random_bytes(32));
    } else {
        $rate = rate_state();
        $pass = (string)($_POST['password'] ?? '');
        if ($rate['blocked']) {
            $error = 'Trop de tentatives. Réessaie dans quinze minutes.';
        } elseif ($adminHash === '') {
            $error = 'Accès diagnostic non configuré. L’administrateur doit installer le fichier privé de hachages.';
        } elseif (strlen($pass) <= 1024 && password_verify($pass, $adminHash)) {
            rate_state(false, true);
            session_regenerate_id(true);
            $_SESSION['maint_ok'] = true;
            $_SESSION['maint_at'] = time();
            $_SESSION['maint_csrf'] = bin2hex(random_bytes(32));
        } else {
            rate_state(true);
            $error = 'Mot de passe incorrect.';
        }
    }
}
if (!empty($_SESSION['maint_ok'])) $_SESSION['maint_at'] = time();

function add_check(array &$out, string $name, bool $ok, string $detail): void {
    $out[] = ['name' => $name, 'ok' => $ok, 'detail' => $detail];
}
function diagnostics(): array {
    $checks = [];
    add_check($checks, 'PHP', version_compare(PHP_VERSION, '8.1.0', '>='), PHP_VERSION . ' · ' . PHP_SAPI);
    $required = APP_KEY === 'pannacotaclub' ? ['pdo', 'pdo_mysql'] : ['pdo', 'pdo_sqlite'];
    if (APP_KEY === 'seve') $required[] = 'gd';
    foreach (array_unique($required) as $ext) add_check($checks, 'Extension ' . $ext, extension_loaded($ext), extension_loaded($ext) ? 'chargée' : 'absente');
    add_check($checks, 'Fichier d’entrée', is_readable(APP_ROOT . '/index.php'), is_readable(APP_ROOT . '/index.php') ? 'lisible' : 'absent ou non lisible');
    add_check($checks, 'Configuration', is_readable(APP_ROOT . '/config.php'), is_readable(APP_ROOT . '/config.php') ? 'fichier présent' : 'absent ou non lisible');
    $dataDir = APP_ROOT . '/data';
    add_check($checks, 'Dossier de données', is_dir($dataDir) && is_readable($dataDir), is_dir($dataDir) ? (is_writable($dataDir) ? 'lisible et inscriptible' : 'lecture seule') : 'absent');

    if (APP_KEY === 'missiona') {
        try {
            require_once APP_ROOT . '/config.php';
            /* Ne pas inclure includes/db.php : son initialisation peut créer le dossier externe. */
            $file = defined('DB_FILE') ? (string)DB_FILE : '';
            if ($file === '') {
                $external = dirname(APP_ROOT) . '/missiona-data/missiona.sqlite';
                $internal = APP_ROOT . '/data/missiona.sqlite';
                $file = is_file($external) ? $external : $internal;
            }
            if ($file === '' || !is_file($file) || !is_readable($file)) {
                add_check($checks, 'SQLite Missiona', false, 'fichier de base absent ou illisible');
            } elseif (!extension_loaded('pdo_sqlite')) {
                add_check($checks, 'SQLite Missiona', false, 'extension pdo_sqlite absente');
            } else {
                $real = realpath($file);
                if ($real === false) throw new RuntimeException('fichier introuvable');
                $uri = 'sqlite:file:' . str_replace('%2F', '/', rawurlencode($real)) . '?mode=ro';
                $pdo = new PDO($uri, null, null, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
                $pdo->query('SELECT 1')->fetchColumn();
                $pdo = null;
                add_check($checks, 'SQLite Missiona', true, 'connexion en lecture seule réussie');
            }
        } catch (Throwable $e) { add_check($checks, 'SQLite Missiona', false, 'échec (' . get_class($e) . ')'); }
    } elseif (APP_KEY === 'pannacotaclub') {
        try {
            $cfg = require APP_ROOT . '/config.php';
            $d = is_array($cfg) && isset($cfg['db']) && is_array($cfg['db']) ? $cfg['db'] : null;
            if (!$d) throw new RuntimeException('configuration absente');
            $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=%s', $d['host'], (int)$d['port'], $d['name'], $d['charset']);
            $pdo = new PDO($dsn, $d['user'], $d['pass'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
            $pdo->query('SELECT 1')->fetchColumn();
            $pdo = null;
            add_check($checks, 'MySQL PannacottaClub', true, 'connexion et requête SELECT 1 réussies');
        } catch (Throwable $e) { add_check($checks, 'MySQL PannacottaClub', false, 'échec (' . get_class($e) . ')'); }
    } else {
        $local = APP_ROOT . '/config-local-seve.php';
        add_check($checks, 'Configuration admin Seve', is_readable($local), is_readable($local) ? 'fichier local lisible' : 'fichier absent ou non lisible');
    }
    return $checks;
}
function safe_log_lines(): array {
    if (is_link(APP_LOG) || !is_file(APP_LOG) || !is_readable(APP_LOG)) return [];
    $lines = @file(APP_LOG, FILE_IGNORE_NEW_LINES);
    if (!is_array($lines)) return [];
    $lines = array_slice($lines, -80);
    foreach ($lines as &$line) {
        $line = preg_replace('/\b(password|passwd|secret|token|api[_-]?key|authorization)\b\s*[:=]\s*[^\s,;]+/i', '$1=[masqué]', $line) ?? $line;
        $line = preg_replace('/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i', '[email masqué]', $line) ?? $line;
    }
    unset($line);
    return $lines;
}
?><!doctype html>
<html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>Diagnostic — <?= h(APP_LABEL) ?></title>
<style>
:root{color-scheme:light;--ink:#17202a;--muted:#667085;--line:#dce2e8;--bg:#f3f6f8;--ok:#146c43;--bad:#b42318;--blue:#174ea6}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.5 system-ui,-apple-system,Segoe UI,sans-serif}.wrap{max-width:1000px;margin:36px auto;padding:0 18px}.card{background:#fff;border:1px solid var(--line);border-radius:16px;padding:24px;margin-bottom:18px;box-shadow:0 4px 16px #1525360a}h1{font-size:24px;margin:0 0 6px}h2{font-size:18px;margin:0 0 14px}.muted{color:var(--muted)}label{display:block;margin:12px 0 5px;font-weight:650}input[type=password]{width:100%;max-width:450px;padding:12px;border:1px solid #aeb8c2;border-radius:9px;font-size:16px}button{border:0;border-radius:9px;background:var(--blue);color:white;padding:11px 18px;margin-top:14px;font-size:15px;font-weight:650;cursor:pointer}.error{color:var(--bad);background:#fff1f0;padding:10px 12px;border-radius:8px;margin:12px 0}.tag{font-weight:700}.ok{color:var(--ok)}.bad{color:var(--bad)}table{width:100%;border-collapse:collapse}th,td{text-align:left;vertical-align:top;padding:9px 8px;border-bottom:1px solid var(--line)}th{font-size:13px;color:var(--muted)}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#111827;color:#e5e7eb;padding:16px;border-radius:10px;max-height:500px;overflow:auto;font:12px/1.5 ui-monospace,monospace}.top{display:flex;justify-content:space-between;gap:12px;align-items:center}.hint{font-size:13px;color:var(--muted)}
</style></head><body><main class="wrap">
<section class="card"><div class="top"><div><h1>Diagnostic de secours — <?= h(APP_LABEL) ?></h1><div class="muted">Rapport privé · <?= h(date('d/m/Y H:i:s T')) ?></div></div><a href="<?= h(APP_BASE) ?>maintenance.html">Page maintenance</a></div></section>
<?php if (empty($_SESSION['maint_ok'])): ?>
<section class="card"><h2>Accès administrateur</h2><p class="muted">Les journaux et contrôles sont réservés à l’administrateur.</p>
<?php if ($adminHash === ''): ?><div class="error">L’accès de secours n’est pas encore configuré dans le fichier privé hors de public_html.</div><?php endif; ?>
<?php if ($error !== ''): ?><div class="error"><?= h($error) ?></div><?php endif; ?>
<form method="post" autocomplete="on"><input type="hidden" name="csrf" value="<?= h((string)$_SESSION['maint_csrf']) ?>"><label for="password">Mot de passe administrateur</label><input id="password" name="password" type="password" autocomplete="current-password" required maxlength="1024"><button type="submit">Ouvrir le rapport</button></form>
<p class="hint">Si l’accès n’est pas configuré, le hachage doit être ajouté au fichier privé hors de public_html. Aucun mot de passe ne doit être envoyé par e-mail ou à une IA.</p></section>
<?php else: ?>
<section class="card"><div class="top"><h2>État des composants</h2><form method="post"><input type="hidden" name="csrf" value="<?= h((string)$_SESSION['maint_csrf']) ?>"><button name="logout" value="1" type="submit">Déconnexion</button></form></div>
<table><thead><tr><th>Contrôle</th><th>État</th><th>Détail</th></tr></thead><tbody>
<?php foreach (diagnostics() as $row): ?><tr><td><?= h($row['name']) ?></td><td class="<?= $row['ok']?'ok':'bad' ?> tag"><?= $row['ok']?'OK':'À vérifier' ?></td><td><?= h($row['detail']) ?></td></tr><?php endforeach; ?>
</tbody></table><p class="hint">Ce diagnostic ne lance aucune migration et n’écrit pas dans la base. Une vérification peut échouer si l’hébergement ou le service de base est entièrement arrêté.</p></section>
<section class="card"><h2>Dernières erreurs PHP (80 lignes max.)</h2>
<?php $logs=safe_log_lines(); if ($logs): ?><pre><?= h(implode("\n",$logs)) ?></pre><?php else: ?><p class="muted">Aucun journal lisible trouvé à l’emplacement configuré : <?= h(basename(APP_LOG)) ?>. Les erreurs peuvent être dans le journal Hostinger.</p><?php endif; ?></section>
<?php endif; ?></main></body></html>
