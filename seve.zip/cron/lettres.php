<?php
declare(strict_types=1);

/* ==========================================================================
   SÈVE — relevé de la boîte de dépôt (lettres OnlyFans)
   --------------------------------------------------------------------------
   Ce que fait ce script : il ouvre une boîte e-mail qui reçoit les messages
   OnlyFans (transfert automatique créé par la créatrice depuis sa propre
   adresse), lit les lettres non lues, en sort les chiffres (abonnés, revenus,
   vues, j'aime) et les enregistre comme relevés dans le compte Sève dont
   l'adresse correspond à l'expéditeur.

   Ce qu'il ne fait pas, et ne fera jamais : se connecter au compte OnlyFans de
   qui que ce soit, demander un mot de passe, ou poser un script sur une page.
   OnlyFans n'ouvre aucune interface aux outils extérieurs ; passer par un
   identifiant et un mot de passe serait interdit par leurs conditions d'usage
   et exposerait le compte à une suspension.

   Usage en ligne de commande -------------------------------------------------
     php cron/lettres.php --simuler          voir ce qui serait fait, sans rien écrire
     php cron/lettres.php --fichier x.eml    lire une lettre (test, dépannage)
     php cron/lettres.php                    relever la boîte et enregistrer

   Appel depuis une tâche planifiée (hPanel → Cron) ---------------------------
     php /home/…/public_html/seve/cron/lettres.php
   ou, si l'hébergeur n'offre pas de cron, par une adresse secrète :
     https://missiona.eu/seve/cron/lettres?cle=<cron_cle>   (à définir dans config.php)
   ========================================================================== */

require_once dirname(__DIR__) . '/includes/bootstrap.php';
require_once dirname(__DIR__) . '/includes/donnees.php';

/* ------------------------------------------------------ accès au script */
/* 'cli-server' = le serveur intégré de PHP, c'est-à-dire le banc de test local,
   jamais un hébergement réel : on le traite comme la ligne de commande. */
$cli = in_array(PHP_SAPI, ['cli', 'cli-server', 'phpdbg'], true);
$enLigne = !$cli;
if ($enLigne) {
    $attendue = (string) seve_cfg('cron_cle', '');
    $presentee = (string) ($_GET['cle'] ?? '');
    if ($attendue === '' || !hash_equals($attendue, $presentee)) {
        http_response_code(404);
        exit('Introuvable.');
    }
    header('Content-Type: text/plain; charset=UTF-8');
}

$simuler = in_array('--simuler', $argv ?? [], true) || isset($_GET['simuler']);
$fichier = '';
foreach ((array) ($argv ?? []) as $i => $a) {
    if ($a === '--fichier' && isset($argv[$i + 1])) { $fichier = (string) $argv[$i + 1]; }
}

/** Petite sortie lisible, à l'écran comme dans un journal de cron. */
function dire(string $texte): void
{
    echo $texte . "\n";
}

/* ------------------------------------------------- 1. une lettre, à la main */
if ($fichier !== '') {
    if (!is_readable($fichier)) { dire('Fichier illisible : ' . $fichier); exit(2); }
    $releves = seve_lettre_en_releves((string) file_get_contents($fichier));
    if (!$releves) { dire('Aucun chiffre lisible dans cette lettre : rien n’a été enregistré.'); exit(0); }
    foreach ($releves as $r) {
        dire('→ ' . $r['jour'] . ' : ' . $r['abonnes'] . ' abonnés, ' . $r['revenus'] . ' €, '
            . $r['vues'] . ' vues, ' . $r['likes'] . ' j’aime');
    }
    exit(0);
}

/* ---------------------------------------------------- 2. la boîte e-mail */
$hote = (string) seve_cfg('depot_imap_hote', '');
$utilisateur = (string) seve_cfg('depot_imap_utilisateur', '');
$motdepasse = (string) seve_cfg('depot_imap_motdepasse', '');
$dossier = (string) seve_cfg('depot_imap_dossier', 'INBOX');
$drapeau = (string) seve_cfg('depot_imap_drapeau', '/imap/ssl');

if ($hote === '' || $utilisateur === '') {
    dire('Dépôt par e-mail non configuré.');
    dire('Renseignez depot_imap_hote, depot_imap_utilisateur et depot_imap_motdepasse dans config.php,');
    dire('puis créez un transfert automatique de vos messages OnlyFans vers cette boîte.');
    dire('En attendant, le dépôt de fichier fonctionne déjà : exportez vos statistiques OnlyFans');
    dire('et déposez le fichier dans votre espace Sève, onglet « Mon compte OnlyFans ».');
    exit(0);
}
if (!function_exists('imap_open')) {
    dire('L’extension IMAP de PHP n’est pas active sur ce serveur.');
    dire('Activez-la dans hPanel (PHP → extensions) ou utilisez la tâche planifiée sans IMAP.');
    exit(1);
}

$boite = imap_open('{' . $hote . ':993' . $drapeau . '}' . $dossier, $utilisateur, $motdepasse, 0, 1);
if (!$boite) {
    dire('Boîte injoignable : ' . (string) imap_last_error());
    exit(1);
}
$lettres = imap_search($boite, 'UNSEEN') ?: [];
dire(count($lettres) . ' lettre(s) non lue(s).');

$bilan = ['lues' => 0, 'releves' => 0, 'muettes' => 0, 'inconnues' => 0];
foreach ($lettres as $numero) {
    $brut = (string) imap_fetchheader($boite, (int) $numero) . "\r\n"
        . (string) imap_body($boite, (int) $numero);
    $lettre = seve_lettre_parties($brut);
    $releves = seve_lettre_en_releves($brut);
    $bilan['lues']++;

    if (!$releves) {
        $bilan['muettes']++;
        if (!$simuler) { imap_setflag_full($boite, (string) $numero, '\\Seen'); }
        continue;
    }

    /* L'expéditeur désigne le compte : elle transfère ses lettres depuis
       l'adresse qui lui sert à ouvrir Sève. */
    $email = (string) ($lettre['de'] ?? '');
    $etat = $email !== '' ? seve_lire($email) : seve_etat_vide();
    if ($email === '' || (($etat['code_hash'] ?? '') === '' && empty($etat['connected']))) {
        $bilan['inconnues']++;
        dire('  · lettre d’une adresse inconnue (' . ($email !== '' ? $email : 'expéditeur illisible') . ') : ignorée');
        if (!$simuler) { imap_setflag_full($boite, (string) $numero, '\\Seen'); }
        continue;
    }

    foreach ($releves as $r) {
        dire('  · ' . $email . ' : ' . $r['jour'] . ' → ' . $r['abonnes'] . ' abonnés, ' . $r['revenus'] . ' €');
        if ($simuler) { continue; }
        seve_enregistrer_releve($etat, $r);
        $bilan['releves']++;
    }
    if (!$simuler) {
        seve_journal($etat, 'depot-mail', count($releves) . ' jour(s)');
        seve_ecrire($email, $etat);
        imap_setflag_full($boite, (string) $numero, '\\Seen');
    }
}
imap_close($boite);

dire('');
dire(($simuler ? '[simulation] ' : '') . $bilan['lues'] . ' lettre(s) lue(s), '
    . $bilan['releves'] . ' relevé(s) enregistré(s), ' . $bilan['muettes'] . ' sans chiffre, '
    . $bilan['inconnues'] . ' d’une adresse inconnue.');
